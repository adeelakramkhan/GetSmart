
#include "Daemon.h"
bool NoMore(maindl *mdl);
int SendEchoRequest(SOCKET s,SOCKADDR_IN *ctrladdr);
unsigned long RecvEchoReply(SOCKET s, SOCKADDR_IN *lpsaFrom, u_char *pTTL);

void basicdl::GotDNS(LPARAM lParam)
{
#ifdef _WIN32
	hostent*h;
	h=(hostent*) gethostbuff;
	gethosthnd=NULL;
	if (HIWORD(lParam) && (!gethostbuff[0]) || (!h->h_addr_list))
#endif // _WIN32
#ifdef __unix__
	if (lParam!=4)
#endif
	{
		if (++err[1]>3)
		{
			err[1]=0;
			doerr(1);
			return;
		}
		fireaddr.sin_addr.s_addr=0;
		QueryDNS();
		return;
	}
	unsigned long *ftpip;
#ifdef _WIN32
        ftpip = (unsigned long*)( *(h->h_addr_list));
#endif
#ifdef __unix__
	ftpip=(unsigned long*)gethostbuff;
#endif
	char *tmp;
	switch (useproxy)
	{
	case 1:
		tmp=cfg.Proxy.FHost;
		break;
	case 2:
		tmp=cfg.Proxy.HHost;
		break;
	case 3:
		if (!fireaddr.sin_addr.s_addr)
			tmp=cfg.Proxy.sockshost;
		else tmp=mir->nfo->host;
		break;
	default:
		tmp=mir->nfo->host;
		break;
	}
	new dnstable(tmp,*ftpip);
	if ((useproxy==3) && !fireaddr.sin_addr.s_addr)
	{
		fireaddr.sin_addr.s_addr=*ftpip;
		QueryDNS();
		return;
	}
	ctrladdr.sin_addr.s_addr=*ftpip;
	free(gethostbuff);
	gethostbuff=NULL;
	for (int j=0;j<4;j++)
	  printf("%d_",((char*)&ctrladdr.sin_addr.s_addr)[j]);
	printf("newone\n");
	status=0;
	ActOnStatus();
}

void maindl::KillMain()
{
	int i,j=splitdex;
	wait=false;
	if (type==5)
	{
		for (i=0;i<=splitdex;i++)
			if (splitdl[i] && ((dlproxy*)splitdl[i])->senddata)
				{
					((dlproxy*)splitdl[i])->CloseSock(proxsock,false);
					((dlproxy*)splitdl[i])->senddata=false;
				}
	}
	for (i=0;i<=j;i++)
		if (splitdl[i])
			if (spliton==1)
			{
				strncpy(bstxt[splitdl[i]->txtpos],GetSTR(65,"Paused"),80);
				dds();
				splitdl[i]->KillDL();
				break;
			}
			else
			{
				strncpy(bstxt[splitdl[i]->txtpos],GetSTR(65,"Paused"),80);
				dds();
				splitdl[i]->KillDL();
			}
}

void basicdl::KillDL()
{
//  bool log=false;
  int j,known=-1;
  CloseSockets();
#ifdef _WIN32
  if (mdl->hcatch!=NULL)
  {
	  KillTimer(mdl->hcatch,1);
	  EndDialog(mdl->hcatch,0);
	  return;
  }
#endif
  if (gethosthnd)
    {
#ifdef _WIN32
      WSACancelAsyncRequest(gethosthnd);
#endif
#ifdef __unix__
      {
	printf("about to kill child...(pid==%d)\n",gethosthnd);
        kill(gethosthnd,9);
      }
#endif
      gethosthnd=0;
    }
  if ((type==4) || (type==6) || (type==8) || (type==7) && ((gsdl*)this)->table)
    {
      RideOn();
      return;
    }

	if (type==5)
	{
		if ((mdl->spliton>1) && ((dlproxy*)this)->senddata && (mdl->rsize))
		{
			status=0;
			ActOnStatus();
			return;
		}
	}
	if (fp)
	{
		fflush(fp);
		fclose(fp);
		fp=NULL;
	}

	if (hamdex>-1)
	{
		mdl->hamdl[hamdex]=NULL;
		mdl->hamon--;
		actdls[actpos]=NULL;
		for (j=0;j<=lastact;j++)
			if (actdls[j]) known=j;
		if (known<lastact) lastact=known;
	}
	else
	{
		mdl->splitdl[splitdex]=NULL;
		if (mdl->busydl==this)
		{
			for (j=0;j<=mdl->hamdex;j++)
				if (mdl->hamdl[j])
					mdl->hamdl[j]->KillDL();
			mdl->busydl=NULL;
		}
		mdl->spliton--;
		status=0;
		CheckLog();
		actdls[actpos]=NULL;
		for (j=0;j<=lastact;j++)
			if (actdls[j]) known=j;
		if (known<lastact) lastact=known;
	}
	maindl *tmp=mdl;
	if (!mdl->spliton && (mdl->type==5) && ((dlproxy*)this)->senddata)
	{
		if (mdl->proxsock!=INVALID_SOCKET)
			if (!((dlproxy*)this)->sentbytes)
			{
				char str[1024];
				strcpy(str,"HTTP/1.0 204 GetSmart will take it from here\r\n\r\n");
				//strcat(str,"Server: GetSmart "VERSION" acting as proxy server\r\n");
				//strcat(str,"Location: http://getsmart.hypermart.net\r\n");
				//strcat(str,"Proxy-Connection: close\r\n\r\n");
				send(mdl->proxsock,str,strlen(str),0);
				LINGER linger;
				linger.l_onoff=1;
				linger.l_linger=5;
				setsockopt(mdl->proxsock,SOL_SOCKET,SO_LINGER,(char *)&linger,
						sizeof(linger));
				shutdown(mdl->proxsock,2);
				RMSelectSock(mdl->proxsock);
				closesocket(mdl->proxsock);
				//sock--;
				mdl->proxsock=INVALID_SOCKET;
			}
			else
				CloseSock(mdl->proxsock,false);

		for (j=0; j<TOPMAXSPLIT;j++)
		{
			char str[1024],match[1024];
			sprintf(str,"%s%s (%ld)*",mdl->ldir,mdl->lfn,j);
			if (FFirstFile(str,match))
			do
			{
				sprintf(str,"%s%s",mdl->ldir,match);
				_unlink(str);
			} while (FNextFile(match));
		}					
	}
	delbdl();
	if (!tmp->spliton)
	{
		if (tmp->type==1)
		{
			activemain--;
			activedl--;
			tmp->mirrorhead->ser->actdl--;
		}
		else
			if (tmp->type==5) activebr--;
		if (lastmact!=tmp->actpos)
		{
			actmdls[tmp->actpos]=actmdls[lastmact];
			actmdls[tmp->actpos].mdl->actpos=tmp->actpos;
		}
		actmdls[lastmact].mdl=NULL;
		lastmact--;
		time_t tp;
		time(&tp);
		tmp->totaltime+=(tp-tmp->starttime);
		SaveURLs();
		if (!tmp->Chk4Del())
			STELLGUI(MDL_STOP,tmp,0);
/*			if (type==5)
			{
				if (nfo->prot==1)
					CloseSock(((ftpproxy*)this)->proxsock,false);
				if (nfo->prot==2)
					CloseSock(((httpproxy*)this)->proxsock,false);
				for (j=0; j<MAXSPLIT;j++)
				{
					HANDLE hf;
					WIN32_FIND_DATA ff;
					char str[1000];
					sprintf(str,"%s%s (%ld)*",nfo->ldir,nfo->lfn,j);
					if ((hf=FindFirstFile(str,&ff))!=INVALID_HANDLE_VALUE)
					do
					{
						sprintf(str,"%s%s",nfo->ldir,ff.cFileName);
						_unlink(str);
					} while (FindNextFile(hf,&ff));
				}					
				SendMessage(Hgui,WM_D_MAIN,(WPARAM) mdl,3);
				delete mdl;
			}
			*/
	}
}

void basicdl::CallResDNS(char*tmp2)
{
#ifdef _WIN32
  if (!gethostbuff) gethostbuff=(char*) malloc(MAXGETHOSTSTRUCT);
  if (gethosthnd!=NULL)
	WSACancelAsyncRequest(gethosthnd);
  memset(gethostbuff,0,MAXGETHOSTSTRUCT);
  ctrladdr.sin_addr.s_addr=0;
  gethosthnd=WSAAsyncGetHostByName(hwndg,WM_USER+actpos+1,
				   tmp2,gethostbuff,MAXGETHOSTSTRUCT);
#endif // _WIN32
#ifdef __unix__
  /* Actual DNSproc */
  /*if (gethostbuff!=NULL)
    gethostbuff=malloc(sizeof(struct hostent));*/
  struct hostent *h=0;
  int c_pipe[2];
 pipe(c_pipe);
  datasock=c_pipe[0];
  fcntl(datasock,F_SETFL,O_NONBLOCK);
  maxfd=MAX(maxfd,datasock);
  FD_SET(datasock,&rdsocks);
  gethosthnd=fork();
  if (!gethosthnd)
    {
       close(c_pipe[0]);
      printf("in child:: about to resolve!!!!!!!!!!!!!!!!!!!!!!!: %s\n",tmp2);
      printf("actpos::%d\n",actpos);
       h=gethostbyname(tmp2);
      //herror("gethostbyname:");
       printf("i'm here!!\n\n\n");
       //for (int i=0;i<4;i++)
       //printf("%d_",(h->h_addr_list[0])[i]);
       //printf("\n");
       printf("child::  dns rep\n");
       if (h==NULL)
	 printf("c: dns fail'd!\n");
        if (h!=NULL)
	     write(c_pipe[1],h->h_addr_list[0],h->h_length);
        else{
	printf("child::Error!\n\n");
	char c=0;
	write(c_pipe[1],&c,1);
      }
      close(c_pipe[1]);
       printf("child:: exiting!\n");
      _exit(0); /* currently not caught */
    }else
       close(c_pipe[1]);
#endif __unix__
}

bool basicdl::StealSock()
{
	/* scans all bdls in server and steal a socket
		from one of them. */
	int i,j;
	struct sersp_tag{
		unsigned short sp;
	};
	sersp_tag sersp[1024];
	short last=-1;
	memset(sersp,0,sizeof(sersp));
	
	basicdl*bdl=mir->ser->bdlhead;
	while (bdl)
	{
#define _I bdl->mdl->actpos
		if ((bdl!=this) && (bdl->type==1))
		{
			sersp[_I].sp++;
			last=max(last,_I);
		}
		bdl=bdl->sernext;
#undef _I
	}
	if (last==-1) return false;
	short maxi=0,vic=-1,prior=0;
	unsigned long speed=(unsigned)-1;
	for (i=1;i<6;i++)
	{
		for (j=0;j<=last;j++)
			if ((sersp[j].sp) && (actmdls[j].mdl->prior==i))
				if ((sersp[j].sp>maxi) || (sersp[j].sp==maxi) &&
					(speed>actmdls[j].mdl->cps) && (actmdls[j].mdl->prior<=prior))
				{
					maxi=sersp[j].sp;
					vic=j;
					prior=actmdls[j].mdl->prior;
					speed=actmdls[j].mdl->cps;
				}
		if (maxi>1) break;
	}
	if ((maxi==1) && (prior>=mdl->prior))
		return false;
	short vicsp=-1;
       	speed=(unsigned)-1;
	for (i=0;i<=actmdls[vic].mdl->splitdex;i++)
		if (actmdls[vic].mdl->splitdl[i] &&
			(actmdls[vic].mdl->splitdl[i]->mir->ser==mir->ser))
			if (actmdls[vic].mdl->splitdl[i]->cps<speed)
			{
				speed=actmdls[vic].mdl->splitdl[i]->cps;
				vicsp=i;
			}
	if (ISFTP(this) && ISFTP(actmdls[vic].mdl->splitdl[vicsp]))
	{
		SendSock(actmdls[vic].mdl->splitdl[vicsp]->ctrlsock);
		actmdls[vic].mdl->splitdl[vicsp]->KillDL();
		mdl->MainFunc(1,this);
		return true;
	}
	else
	{
		actmdls[vic].mdl->splitdl[vicsp]->KillDL();
		return true;
	}	
}	

bool basicdl::QueryDNS()
{
  printf("in query dns::allo!\n");
	if (!strlen(mir->nfo->host))
		return false;
	char str[1024];
	if (cfg.Dial.Use && !IsConnected())
    {
		DetectedHangup();
		return false;
    }
	if ((type==1) && !mdl->dosplit)
	{
		if (activesocks>cfg.maxsocks)
		{
			if (mdl->spliton==1)
			{
				if (!StealSock())
				{
					basicdl* bdl=FindLSS(mdl->prior);
					if (bdl==NULL)
					{
						wstatus(GetSTR(59,"Your server limit doesn't allow any more sockets."));
						dds();
						KillDL();
						return false;
					}
					bdl->KillDL();
				}
			}
			else
			{
				wstatus(GetSTR(59,"Your server limit doesn't allow any more sockets."));
				dds();
				KillDL();
				return false;
			}
			if (status>0) return true;
		}
		
		if ((mir->ser->actcon>mir->ser->maxcon)||
			(mir->used>mir->ser->maxeach))
		{
			if ((mdl->spliton>1) || (!StealSock()))
			{
				wstatus(GetSTR(59,"Your server limit doesn't allow any more sockets."));
				dds();
				KillDL();
				return false;
			}
			if (status>0) return true;
		}
	}
	time(&timeout);
	if (!mdl->isdl)
		mdl->timeout=timeout;
	time2dl=timeout;
	pause=false;
	strcpy(str,GetSTR(29,"Resolving host name..."));
	wstatus(str);
	wb(str,0);
	dds();
	bool res=false;
	// res -> if this is a numbered ip
	char *tmp,*tmp2;
	switch (useproxy)
    {
    case 1:
		tmp=cfg.Proxy.FHost;
		tmp2=tmp;
		break;
    case 2:
		tmp=cfg.Proxy.HHost;
		tmp2=tmp;
		break;
    case 3:
		if (!fireaddr.sin_addr.s_addr)
			tmp=cfg.Proxy.sockshost;
		else tmp=mir->nfo->host;
		tmp2=tmp;
		break;
    default:
		tmp=mir->nfo->host;
		tmp2=tmp;
		break;
    }
	unsigned char d[4];
	while (*tmp)
    {
		if (((*tmp<'0') || (*tmp>'9')) && (*tmp!='.'))
		{
			res=true;
			break;
		}
		tmp++;
    }
	if (res)
	{
		unsigned long ip=GetDNSFromTable(tmp2);
		if (ip)
			memcpy(&d,&ip,4);
		else
		{
		  //hostent *h;
		  //h=gethostbyname(tmp2);
		  CallResDNS(tmp2);
		  return true;
		  //memcpy(&d,h->h_addr_list[0],4);
		}
	}
	else
    {
		tmp=tmp2;
		for (int i=0;i<4;i++)
		{
			d[i]=atoi(tmp);
			tmp=strchr(tmp,'.');
			if (!tmp && (i<3))
			{
				CallResDNS(tmp2);
				return true;
			}
			tmp++;
		}
    }
	unsigned long *ftpip = (unsigned long *) &d;
	if ((useproxy==3) && !fireaddr.sin_addr.s_addr)
    {
		fireaddr.sin_addr.s_addr=*ftpip;
		return QueryDNS();
    }
	ctrladdr.sin_addr.s_addr=*ftpip;
	status=0;
	return ActOnStatus();
}

int basicdl::CloseSock(SOCKET &hSock,bool read)
{
  char achDiscard[AVGBUFSIZE];
  int nRet=0;
  if (hSock == INVALID_SOCKET) return 0;
#ifdef _WIN32
if ((os.dwPlatformId==VER_PLATFORM_WIN32_WINDOWS)&& 
		(os.dwMajorVersion==4) && !os.dwMinorVersion)
{
    LINGER linger;
	linger.l_onoff=1;
	linger.l_linger=0;
	setsockopt(hSock,SOL_SOCKET,SO_LINGER,(const char *)&linger,
				sizeof(linger));
	WSAAsyncSelect(hSock, hwndg, 0, 0);
}
#endif
/*	u_long uu=0;
	ioctlsocket(hSock,FIONBIO,&uu);
    LINGER linger;
	linger.l_onoff=0;
	linger.l_linger=5;
	setsockopt(hSock,SOL_SOCKET,SO_LINGER,(const char *)&linger,
		sizeof(linger));
  closesocket(hSock);
  hSock=INVALID_SOCKET;
  return 0;
/*
  RMSelectSock(hSock);

  SockNBlock(hSock);
  LINGER ling;
  ling.l_onoff=1;
  ling.l_linger=5;
  setsockopt(hSock,SOL_SOCKET,SO_LINGER,(char *)&ling,
	     sizeof(ling));*/
/*  if (!read)
    {
      closesocket(hSock);
      hSock=INVALID_SOCKET;
      return 0;
    }
  nRet = shutdown (hSock, 2);*/
	RMSelectSock(hSock);
#ifndef SD_BOTH
#define SD_BOTH 2
#endif
  nRet=shutdown(hSock,SD_BOTH);
  read=false;
  if (nRet != SOCKET_ERROR) 
    {
      nRet = 1;
      while (nRet && (nRet != SOCKET_ERROR))
	{
	  if (read)
	    {
	      if (type!=4)
			  nRet = ReadData(hSock);
		  else nRet = ReadCtrl();
	    }
	  else
	    nRet = recv (hSock, (char*)achDiscard, AVGBUFSIZE, 0);
	}
    }
  nRet=closesocket(hSock);
  //sock--;
  hSock = INVALID_SOCKET;
  return (nRet);
}

void basicdl::GetFN(char *str)
{
	char ldir[_MAX_PATH];
	if (mdl->istmpdir)
		strcpy(ldir,cfg.tmpdir);
	else strcpy(ldir,mdl->ldir);
	if (mdl->sps[splitdex])
		sprintf(str,"%s%s (%ld) %ld-%ld",ldir,mdl->lfn,splitdex,
		mdl->sps[splitdex],mdl->spe[splitdex]);
	else
	{
		sprintf(str,"%s%s",ldir,mdl->lfn);
		if (splitdex)
		{
			int hg;
			hg=4;
		}
	}
	if (strlen(cfg.stamp))
		strcat(str,cfg.stamp);
}

int basicdl::ReadFTPCtrl()
{
	err[1]=0;
	int ret=0,i=0,r;
	time(&timeout);
	if (!mdl->isdl)
		mdl->timeout=timeout;
	char *tmp2;
	char res[AVGBUFSIZE*2],str[AVGBUFSIZE*2];
	ret=ReadSocket(ctrlsock,res,readbuff,readbuffi);
	if (ret<=0) return 0;
	GetLine(res,str);
	//printf("st: %d\n",status);
	while (strlen(str))
	{
		while (strlen(str)&&((*(str+3) == '-') || (*(str)==' ')))
		{
			wb(str,4);
			GetLine(res,str);
		}
		if (!strlen(str))
			return ret;
		if (abort || strncmp(str,"226",3))
			wb(str,2);
		r=atoi(str);
		lastcmd[1]=lastcmd[0];
		lastcmd[0]=r;
		tmp2=strchr(que[quedex],' ');
		char tmp[40];
		memset(tmp,0,40);
		if (tmp2) memcpy(tmp,que[quedex],tmp2-que[quedex]);
		else memcpy(tmp,que[quedex],40);
/*		if (abort && (r==426))
		{
			AbortFTP();
			return 0;
		}*/
		if (!abort || (r==226) || (r==225) || (r==426) || (r==500))
		switch (r)
		{
		case 220:
			status=1;
			if (!ActOnStatus()) return 0;
			break;

		case 331:
			if (!strcmp(tmp,"USER"))
			{
				dq();
				status++;
				if (!ActOnStatus()) return 0;
			}
			break;

		case 230:
			if (!strcmp(tmp,"PASS") || !strcmp(tmp,"USER"))
			{
				dq();
				strcpy(str,GetSTR(25,"Logged in."));
				dds();
				wstatus(str);
				mdl->MainFunc(1,this);
			}
			break;

		case 200:
		case 213:
			if (!strcmp(tmp,"SIZE"))
			{
				dq();
				if (!mdl->rsize)
				{
					mdl->rsize=atoi(str+4);
					if (type==1) log_size();
				}
/*				else
					if (mdl->rsize && (mdl->rsize!=(unsigned)atoi(str+4)))
						mdl->rsize=atoi(str+4);*/
				if ((type==1) && cfg.mirr.autosearch &&
					!mdl->mirsearch)
				{
					mdl->mirsearch=true;
					mdl->Search4Mir();
				}
				if (type==6)
				{
					((dlchk*)this)->mmir->rsize=mdl->rsize;
					if ((((dlchk*)this)->mmir==((dlchk*)this)->mmdl->mirrorhead) &&
						!((dlchk*)this)->mmdl->rsize)
						((dlchk*)this)->mmdl->rsize=((dlchk*)this)->mmir->rsize;
					if (((dlchk*)this)->mmdl->rsize && 
						((dlchk*)this)->mmir->rsize!=((dlchk*)this)->mmdl->rsize)
					{
						RideOn();
						return 0;
					}
				}
				if (!mdl->spe[splitdex])
					mdl->spe[splitdex]=mdl->rsize-1;
				//tell gui we've got size.
				status++;
				if (!ActOnStatus()) return 0;
			}
			else
				if (r==200)
				{
					dq();
					status++;
					if (!ActOnStatus()) return 0;
				}
				break;

		case 250:
			dq();
			strcpy(str,"PWD\r\n");
			wb(str,1);
			WriteFTP(str);
			break;

		case 257:
			dq();
			tmp2=strchr(str,'"');
			if (!cwd)
				cwd=DupString(tmp2+1);
			else
				cwd=ReDupString(cwd,tmp2+1);
			tmp2=strchr(cwd,'"');
			*tmp2=0;
			if ((strlen(cwd)>1) && (cwd[strlen(cwd)-1]!='/'))
			{
				strcpy(str,cwd);
				strcat(str,"/");
				cwd=ReDupString(cwd,str);
			}
			mdl->mirrorhead->nfo->rdir=ReDupString(mdl->mirrorhead->nfo->rdir,cwd);
			sprintf(str,GetSTR(26,"Browsing %s%s"),mdl->mirrorhead->nfo->host,cwd);
			dds();
			mdl->lfn=ReDupString(mdl->lfn,str);
			// tell gui a new dir in browser.
			TELLGUI(GBR_UPDATE,mdl,0);
			status=6;
			if (!ActOnStatus()) return 0;
			break;

		case 350:
			if (!strcmp(tmp,"REST"))
			{
				if (!mdl->info)
				{
					mdl->resume=true;
					if (type==6)
					{
						((dlchk*)this)->mmir->resume=true;
						if ((((dlchk*)this)->mmir==((dlchk*)this)->mmdl->mirrorhead) &&
							!((dlchk*)this)->mmdl->resume)
							((dlchk*)this)->mmdl->resume=((dlchk*)this)->mmir->resume;
					}
//					SendMessage(Hgui,WM_D_INFO,(WPARAM)this->actpos,4);
					// tell gui we've got info.
				}
				resume=true;
				err[3]=0;
			}
			dq();
			status++;
			if (!ActOnStatus()) return 0;
			break;

		case 125:
		case 150:
			if (!strcmp(tmp,"RETR") || !strncmp(tmp,"LIST",4))
			{
				if (!mdl->rsize || (type==2))
				{
					tmp2=strrchr(str,'(');
					if (tmp2)
					{
						tmp2++;
						if (!mdl->rsize)
						{
							mdl->rsize=atoi(tmp2);
							if (type==1) log_size();
						}
						/*else
							if (mdl->rsize && (mdl->rsize!=(unsigned)atoi(tmp2)))
								mdl->rsize=atoi(tmp2);*/
						if ((type==1) && cfg.mirr.autosearch &&
							!mdl->mirsearch)
						{
							mdl->mirsearch=true;
							mdl->Search4Mir();
						}
						if (type==6)
						{
							((dlchk*)this)->mmir->rsize=mdl->rsize;
							if ((((dlchk*)this)->mmir==((dlchk*)this)->mmdl->mirrorhead) &&
								!((dlchk*)this)->mmdl->rsize)
								((dlchk*)this)->mmdl->rsize=((dlchk*)this)->mmir->rsize;
							if (((dlchk*)this)->mmdl->rsize && 
								((dlchk*)this)->mmir->rsize!=((dlchk*)this)->mmdl->rsize)
							{
								RideOn();
								return 0;
							}
						}
						if (!mdl->spe[splitdex])
							mdl->spe[splitdex]=mdl->rsize-1;
					}
				}
			}
			else
			{
				if (status<8)
				{
					TimedOut();
					return 0;
				}
			}
			status++;
			if (!ActOnStatus()) return 0;
			// tell gui starting dl;
//			SendMessage(Hgui,WM_D_INFO,(WPARAM)this->actpos,3);
			break;
		
		case 550:
			if (!strcmp(tmp,"CWD"))
			{
				dq();
				strcpy(str,"PWD\r\n");
				wb(str,1);
				WriteFTP(str);
				break;
			}
			if (status>=8)
			{
				mdl->ErrMsg=ReDupString(mdl->ErrMsg,str);
				doerr(6);
				return 1;
			}
			else
			{
				dq();
				status++;
				if (!ActOnStatus()) return 0;
			}
			break;
		
		case 425:
		case 426:
		case 450:
		case 451:
			if (status>=8) status=0;
			else
				if (status>6) status=6;
			if (!ActOnStatus() || !strlen(res)) return 0;
			break;

		case 530:
			if ((status==1) || (status==2))
			{
				if ((unsigned) ret<strlen(str)+3)
				{
					if (++err[4]>=3)
					{
						err[4]=0;
						mdl->ErrMsg=ReDupString(mdl->ErrMsg,str);
						doerr(4);
						return 1;
					}
					status=0;
					if (!ActOnStatus()) return 0;
					break;
				}
			}
			else
			{
				status++;
				if (!ActOnStatus()) return 0;
				break;
			}

		case 421:
		  if ((status==1) || (status==2))
		    {
		      unsigned long r=0;
		      time_t tp=0;
		      maindl *tmp;
		      if (!busy) busy=true;
		      busyretry++;
		      if (mdl->usehammer)
			{
			  if (!mdl->busytimestarted)
			    time(&mdl->busytimestarted);
			  if (!mdl->busydl)
			    mdl->MainFunc(2,this);
			  if (mdl->usemaxhammerretry)
			    {
			      for (i=0;i<=mdl->hamdex;i++)
				if (mdl->hamdl[i])
				  r+=mdl->hamdl[i]->busyretry;
			      for (i=0;i<=mdl->splitdex;i++)
				if (mdl->splitdl[i])
				  r+=mdl->splitdl[i]->busyretry;
			    }
			  if (mdl->usemaxhammertime) time(&tp);
			  if (mdl->usemaxhammerretry && (cfg.maxhammerretry<=r) ||
			      mdl->usemaxhammertime && 
			      (tp-mdl->busytimestarted>=cfg.maxhammertime))
			    {
			      r=0;
			      mdl->usehammer=false;
			      for (i=0;i<=mdl->splitdex;i++)
				if (mdl->splitdl[i])
				  mdl->splitdl[i]->busyretry=0;
			      mdl->busytimestarted=0;
			      bool ret=false;
			      if (hamdex!=-1) ret=true;
			      tmp=mdl;
			      for (i=0;i<=tmp->hamdex;i++)
				if (tmp->hamdl[i])
				  tmp->hamdl[i]->KillDL();
			      tmp->busydl=NULL;
			      if (ret) return false;
			    }
			  else
					{
						status=0;
						ActOnStatus();
						return 0;
					}
				}
				if (hammerpause) break;
				if (mdl->useretry)
				{
					if (!mdl->busytimestarted)
						time(&mdl->busytimestarted);
					time(&lastbusyretry);
					hammerpause=true;
					sprintf(str,GetSTR(27,"Busy, pausing for %ld, seconds."),
							cfg.nohammerbusydelay);
					dds();
					wstatus(str);
					if (mdl->usemaxbusyretry)
						for (i=0;i<=mdl->splitdex;i++)
							if (mdl->splitdl[i])
								r+=mdl->splitdl[i]->busyretry;
					if (mdl->usemaxbusytime) time(&tp);
					if (mdl->usemaxbusyretry && (cfg.maxbusyretry<=r) ||
						mdl->usemaxbusytime && 
						(tp-mdl->busytimestarted>=cfg.maxbusytime))
					{
						tmp=mdl;
						for (i=0;i<=tmp->splitdex;i++)
							if (tmp->splitdl[i] && 
								tmp->splitdl[i]->busy)
								tmp->splitdl[i]->KillDL();
						return false;
					}
				}
				else
				{
					strcpy(str,GetSTR(30,"Site is busy. Will try again later."));
					dds();
					wstatus(str);
					if (type==1) log_wr(str,true);
					KillDL();
					return false;
				}
			}
			break;

		case 226:
		case 225:
			if (abort)
			{
				abort=false;
				if (status>6) status=6;
				if (!ActOnStatus()) return 0;
			}
			break;

		case 553:
		case 500:
		case 502:
		case 501:
		case 504:
			if (abort)
			{
				abort=false;
				if (status>6) status=6;
				if (!ActOnStatus()) return 0;
				break;
			}
			if (!strcmp(tmp,"CWD"))
			{
				dq();
				strcpy(str,"PWD\r\n");
				wb(str,1);
				WriteFTP(str);
				break;
			}
			if (!strcmp(tmp,"REST"))
			{
				resume=false;
//				SendMessage(Hgui,WM_D_INFO,(WPARAM)this->actpos,4);
				// tell gui no resume.
				checkint=false;
				dq();
				status++;
				if (!ActOnStatus()) return 0;
				break;
			}
			if ((status>=8) && !strstr(str,"byte offset"))
			{
				mdl->ErrMsg=ReDupString(mdl->ErrMsg,str);
				doerr(5);
				return 1;
			}
			if (status>=8) status=7;
			status++;
			dq();
			if (!ActOnStatus()) return 0;
			break;
		case 227:
		  if (datasock!=INVALID_SOCKET)
		    CloseSock(datasock,false);
		  //datasock = socket(AF_INET,SOCK_STREAM,0);
		  GETSOCK(datasock,AF_INET,SOCK_STREAM,0);
		  int len;
		  char *bt;
		  char IP[4];
		  len=sizeof(struct sockaddr_in);
		  pasvaddr.sin_family=AF_INET;
	  
		  bt=strchr(str,'(')+1;
		  IP[0]=atoi(bt);
		  //		  pasvaddr.sin_addr.S_un.S_un_b.s_b1=atoi(bt);
		  bt=strchr(bt,',')+1;
		  IP[1]=atoi(bt);
		  //pasvaddr.sin_addr.S_un.S_un_b.s_b2=atoi(bt);
		  bt=strchr(bt,',')+1;
		  IP[2]=atoi(bt);
		  //pasvaddr.sin_addr.S_un.S_un_b.s_b3=atoi(bt);
		  bt=strchr(bt,',')+1;
		  IP[3]=atoi(bt);
		  //		  pasvaddr.sin_addr.S_un.S_un_b.s_b4=atoi(bt);
		  bt=strchr(bt,',')+1;
		  unsigned long *ftpip;
		  ftpip= (unsigned long *) IP;
		  pasvaddr.sin_addr.s_addr=*ftpip;

		  unsigned char b;
		  b=atoi(bt);
		  bt=strchr(bt,',')+1;
		  pasvaddr.sin_port=MAKEWORD(b,atoi(bt));
		  AddSelectSock(datasock,actpos);
		  if (useproxy==3)
		    {
		      firedata=true;
		      if (!fireaddr.sin_addr.s_addr)
			for (int j=0;j<=lastact;j++)
			  if (actdls[j] && actdls[j]->fireaddr.sin_addr.s_addr)
			    {
			      memcpy(&fireaddr,&actdls[j]->fireaddr,sizeof(fireaddr));
			      break;
			    }
		      if (!fireaddr.sin_addr.s_addr)
			{
			  CloseSock(datasock,false);
			  status=0;
			  fireaddr.sin_addr.s_addr=0;
			  QueryDNS();
			  return false;
				}
				connect(datasock,(SOCKADDR*)&fireaddr,sizeof(struct sockaddr));
		    }
			else
				connect(datasock,(SOCKADDR*)&pasvaddr,sizeof(struct sockaddr));
			break;
		default:
			status++;
			if (!ActOnStatus()) return 0;
		  break;
		}
		GetLine(res,str);
	}
	return ret;
}

int basicdl::GenHTTPCtrl(char *buf3)
{
	char str[1024],*tmp;
	err[1]=0;

	if (firstread)
	{
		firstread=false;
		if (strnicmp(buf3,"HTTP",4))
		{
			status=2;
			//tmp=strstr(buf3,"\r\n\r\n");
			return 8;
		}
	}

	if ((status!=1) && !strnicmp(buf3,"HTTP",4) && !httpres)
	{
		CloseSockets();
		status=0;
		ActOnStatus();
		return -1;
	}

	if ((status==1) && !strnicmp(buf3,"HTTP",4))
	{
		char *tmp2;
		tmp2=strchr(buf3,32)+1;
		httpres=atoi(tmp2);
		return 0;
	}

	strcpy(str,"Content-type: multipart");
	if (!strnicmp(buf3,str,strlen(str)))
	{
		tmp=strstr(buf3,"boundary=");
		if (tmp)
		{
			if (!boundary)
				boundary=DupString(tmp+9);
			else
				boundary=ReDupString(boundary,tmp+9);
			if (boundary[0]=='"')
				memmove(boundary,boundary+1,strlen(boundary)-1);
			boundary[strlen(boundary)-1]='\0';
			if (boundary[strlen(boundary)-1]=='"')
				boundary[strlen(boundary)-1]='\0';
			multipart=true;
			return 1;
		}
	}

	if (!strnicmp(buf3,"Content-range:",14) && mdl->splitdex)
	{
		strcpy(str,buf3);
		tmp=strrchr(str,'-');
		*tmp='\0';
		unsigned cr=0;
		if (checkint) cr=fbufsize;
		if ((mdl->sps[splitdex]+mdl->localbytes[splitdex]-cr)!=(unsigned)atoi(strrchr(str,' ')+1))
		{
			TimedOut();
			return -1;
		}
	}

	strcpy(str,"Content-length: ");
	if (!strnicmp(buf3,str,strlen(str)) || 
		!strnicmp(buf3,"Content-range:",14) || !strnicmp(buf3,"Range:",6))
	{
		if (!mdl->rsize || !resume)
		{
			if (!strnicmp(buf3,str,strlen(str)))
			{
				if (!mdl->splitdex)
				{
					tmp=strchr(buf3,':');
					tmp=tmp+2;
					if (!mdl->rsize)
					{
						mdl->rsize=atoi(tmp);
						if (type==1) log_size();
					}
					else
						mdl->rsize=atoi(tmp);
					if (resume)
						mdl->rsize+=mdl->localbytes[splitdex]+mdl->sps[splitdex]-fbufsize;
					if (!mdl->spe[splitdex]) mdl->spe[splitdex]=mdl->rsize-1;
				}
			}
			else
			{
				tmp=strchr(buf3,'/');
				if (!tmp)
				{
					tmp=strrchr(buf3,'-');
					if (!resume && tmp)
						if (*(tmp-1)!='0')
						{
							resume=true;
							mdl->resume=true;
						}
				}
				if (tmp)
				{
					tmp++;
					if (!mdl->rsize)
					{
						mdl->rsize=atoi(tmp);
						if (type==1) log_size();
					}
					if (!mdl->spe[splitdex])
						mdl->spe[splitdex]=mdl->rsize-1;
				}
			}
			if (type==6)
			{
				((dlchk*)this)->mmir->rsize=mdl->rsize;
				if ((((dlchk*)this)->mmir==((dlchk*)this)->mmdl->mirrorhead) &&
					!((dlchk*)this)->mmdl->rsize)
					((dlchk*)this)->mmdl->rsize=((dlchk*)this)->mmir->rsize;
				if (((dlchk*)this)->mmdl->rsize && 
					((dlchk*)this)->mmir->rsize!=((dlchk*)this)->mmdl->rsize)
				{
					RideOn();
					return -1;
				}
			}
		}
		return 2;
	}

	strcpy(str,"Accept-ranges: ");
	if (!strnicmp(buf3,str,strlen(str)))
	{
		if (!mdl->resume && !mdl->localbytes[splitdex] && !mdl->sps[splitdex] && !mdl->reschk)
			mdl->reschk=1;
		return 100;
	}

	strcpy(str,"Connection: Keep-Alive");
	if (!strnicmp(buf3,str,strlen(str)))
	{
		keepalive=true;
		return 4;
	}
	strcpy(str,"Location: ");
	if (!strnicmp(buf3,str,strlen(str)) &&(httpres>=300)&&(httpres<=399))
	{
		//char *s1,*s2;
		//s1 = _strlwr( _strdup(&buf3[10]));
		//s2=_strlwr(_strdup(sfn));				
		//if (strstr(s1,s2))
		{
			relocation=true;
			return 5;
		}
	}
	if (multipart)
	{
		strcpy(str,"--multipart-boundary");
		if (!strnicmp(buf3,str,strlen(str)) ||
			!strnicmp(buf3,"multipart-boundary",18)) multipart=false;
		else
			if (boundary && 
				!strnicmp(buf3+2,boundary,strlen(boundary)))
				multipart=false;
		if (!multipart)
		{
			if (readbuffi>0)
			{
				int cut=4;
				tmp=strstr(readbuff,"\r\n\r\n");
				if (!tmp)
				{
					tmp=strstr(readbuff,"\n\n");
					cut=2;
				}
				if (tmp)
				{
					tmp+=cut;
					if (readbuffi-(tmp-readbuff)==0)
					{
						readbuffi=0;
						readbuff[0]='\0';
						return 6;
					}
					memmove(readbuff,tmp,
						readbuffi-(tmp-readbuff));
					readbuffi-=(tmp-readbuff);
				}
			}
			return 6;
		}
	}
	
	//** cookie
	strcpy(str,"Set-Cookie: ");
	if (!strnicmp(buf3,str,strlen(str)))
	{
		//unsigned long dw=1000;
		//				if (prot==1) strcpy(str,"ftp://");
		//				else strcpy(str,"http://");
		//				strcat(str,addr);
		//				if (!InternetGetCookie(str,NULL,str,&dw))
		{
			//strncpy(mdl->ErrMsg,buf3,300);
			//					doerr(10);
			return 1;
		}
		//				strcpy(location,str);
		return 7;
	}
	if ((!strncmp(buf3,"\r\n",2) || (buf3[0]==10)) && !multipart)
		return 8;
	return 100;
}

int basicdl::ReadHTTPCtrl()
{
	if (status==3) return ReadData(ctrlsock);
	time(&timeout);
	if (!mdl->isdl)
		mdl->timeout=timeout;
	int ret=0;
	unsigned int localbytes0;
	char res[AVGBUFSIZE*2],str[AVGBUFSIZE*2],buf3[AVGBUFSIZE*2];
	if (mdl->spe[splitdex] && 
		((mdl->localbytes[splitdex]+mdl->sps[splitdex])>=(mdl->spe[splitdex]+1)))
	{
		RideOn();
		return 0;
	}
	ret=ReadSocket(ctrlsock,res,readbuff,readbuffi);
	if (ret<=0) return 0;
	GetLine(res,str);
	while (strlen(str))
	{
		while (*str==' ')
		{
			wb(str,4);
			GetLine(res,str);
		}
		if (!strlen(str))
			return ret;
		wb(str,2);
		strcpy(buf3,str);
		
		switch (GenHTTPCtrl(buf3))
		{
		case -1:
			return 0;
			break;
		case 0:
			resume=false;
			switch (httpres)
			{
			case 200:
			case 206:
				if (httpres==206)
				{
					resume=true;
					if (type==6)
					{
						((dlchk*)this)->mmir->resume=true;
						if ((((dlchk*)this)->mmir==((dlchk*)this)->mmdl->mirrorhead) &&
							!((dlchk*)this)->mmdl->resume)
							((dlchk*)this)->mmdl->resume=((dlchk*)this)->mmir->resume;
					}
					if (!mdl->resume)
						mdl->resume=true;
					err[3]=0;
				}
				else resume=false;
				status=2;
				mdl->MainFunc(1,this);
				break;
			case 302:
			case 301:
				status=2;

				break;
			default:
				mdl->ErrMsg=ReDupString(mdl->ErrMsg,buf3);
				doerr(8);
				return 1;
			}
			break;
		case 2:
			if (!mdl->spe[splitdex])
				mdl->spe[splitdex]=mdl->rsize-1;
			if (!resume && mdl->rsize)
			{
				checkint=false;
				if (mdl->splitdex) localbytes0=mdl->localbytes[splitdex]+mdl->sps[splitdex];
				else localbytes0=mdl->localbytes[splitdex];
				if (mdl->rsize<=localbytes0)
				{
					mdl->spdone[splitdex]=true;
					RideOn();
					return 0;
				}
			}
			//Tell GUI we've got size.
			break;
		case 5:
			if (relocation)
			{
				char *location=DupString(buf3+10);
				if (location[strlen(location)-2]=='\r')
					location[strlen(location)-2]='\0';
				else
					if (location[strlen(location)-1]=='\n')
						location[strlen(location)-1]='\0';
					
					// add relocation support.
				dlnfo *n=ConvertURL(location);
				MoveMirr(AddMirror(mdl,n));
/*				if (type==6)
				{
					mirrors *mm=AddMirror(((dlchk*)this)->mmdl,n);
					maindl *rbak=((dlchk*)this)->mmir->rmdl;
					((dlchk*)this)->mmir->status=ReDupString(((dlchk*)this)->mmir->status,
						"This URL is a link to a mirror below.");
					((dlchk*)this)->mmir->rmdl=NULL;
					((dlchk*)this)->mmir=mm;
					((dlchk*)this)->mmir->rmdl=rbak;
					((dlchk*)this)->mmir->relocation=true;
				}*/
				mir->relocation=true;
				delete n;
				CloseSockets();
				QueryDNS();
				free(location);
				return false;
			}
			break;
		case 8:
			if (status!=2)
			{
				status=0;
				ActOnStatus();
				return 0;
			}
			status=3;
			if (!mdl->info)
			{
				if (resume) 
					mdl->resume=resume;
				mdl->info=true;
				// tell gui we've got info.
				SaveURLs();
			}
			if (resume && (!mdl->splitdex ||
				(mdl->dosplit>mdl->splitdex+1)))
				if (mdl->dosplit>1)
					mdl->ChangeSplit(mdl->dosplit);
			if (!resume && mdl->splitdex)
			{
				doerr(3);
				return 0;
			}
			if (mdl->localbytes[splitdex] && !resume)
			{
				if ((mdl->resume) || mdl->splitdex)
					if (++err[3]>=5)
					{
						err[3]=0;
						mdl->ErrMsg=ReDupString(mdl->ErrMsg,buf3);
						doerr(3);
						return 1;
					}
					else
					{
						status=0;
						return ActOnStatus();
					}
					BadFN();
			}
			GetFN(str);
			if (fp)
			{
				fflush(fp);
				fclose(fp);
				fp=NULL;
			}
			if (type!=6)
			{
#ifdef OPEN1
				fp=fopen(str,"a+bc");
				if (!fp)
				{
					doerr(11);
					return 0;
				}
				//setvbuf(fp,NULL,cfg.flushsize,_IOFBF);
#endif
			}
			if (readbuffi>0)
				if (ReadData(INVALID_SOCKET)==-2)
					return 0;
			readbuffi=0;
			strcpy(str,GetSTR(28,"Downloading file."));
			wb(str,0);
			wstatus(str);
			dds();
			return ret;
		}
		GetLine(res,str);
	}
	return ret;
}

void maindl::MainFunc(int tp,basicdl *dl)
{
	switch (tp)
	{
	case 1:
		dl->CheckLog();
		logged=true;
		if ISFTP(dl)
		{
			int i;
			dl->busy=false;
			if (dl->splitdex>-1)
			{
				if (busydl==dl)
				{
					for (i=0;i<=hamdex;i++)
						if (hamdl[i]) hamdl[i]->KillDL();
					dl->mdl->hamdex=-1;
					busydl=NULL;
					for (i=0;i<=splitdex;i++)
						if (splitdl[i] && 
							splitdl[i]->busy)
							break;
					if (i>splitdex) busytimestarted=0;
				}
			}
			else
			{
				busydl->SendSock(dl->ctrlsock);
				busydl->busy=false;
				dl->ctrlsock=INVALID_SOCKET;
				dl->status=0;
				dl->CheckLog();
				for (i=0;i<=hamdex;i++)
					if (hamdl[i]) hamdl[i]->KillDL();
				busydl->status=3;
				busydl->CheckLog();
				if (!busydl->ActOnStatus()) return;
				for (i=0;i<=splitdex;i++)
					if (splitdl[i] && 
						splitdl[i]->busy)
						break;
				if (i>splitdex) busytimestarted=0;
				busydl->mdl->hamdex=-1;
				busydl=NULL;
				return;
			}
			dl->busy=false;
			dl->status=3;
			dl->CheckLog();
			if (!dl->ActOnStatus()) return;
		}
		break;
	case 2:
		if (!busydl && ISFTP(dl))
		{
			int j;
			busydl=dl;
			for (j=0;j<cfg.maxhammer;j++)
				Cr8DL(dl->mir,-1,j,true);
		}
		break;
	}
}

void basicdl::BadFN()
{
	char str[1024];
	unsigned long result;
	GetFN(str);
	strcat(str,".Incomplete");
	if (fp)
	{
		fflush(fp);
		fclose(fp);
		fp=NULL;
	}
	fp=fopen(str,"rb");
	if (fp) 
	{
		result=GetFSize(fp);
		fclose(fp);
		fp=NULL;
	}
	else result=0;
	if (result>=mdl->localbytes[splitdex])
	{
		GetFN(str);
		_unlink(str);
	}
	else 
	{
		_unlink(str);
		char *strtmp=DupString(str);
		GetFN(str);
		rename(str,strtmp);
		free(strtmp);
	}
	mdl->lbytes-=mdl->localbytes[splitdex];
	mdl->localbytes[splitdex]=0;
}

void basicdl::ActOnClose(SOCKET sock)
{
	//SOCKADDR sa;
	//int ret=sizeof(SOCKADDR);
	//if (getpeername(sock,&sa,&ret)!=SOCKET_ERROR)
	if ((type==7)&&((gsdl*)this)->table)
	{
		KillDL();
		return;
	}
	if (mdl->rsize)
		return;
	if (sock==ctrlsock)
	{
		if (ISFTP(this) &&  (pause || hammerpause))
		{
			wb(GetSTR(31,"Server closed control connection."),0);
			CloseSock(ctrlsock,false);
			dds();
		}
		else
			if (ISHTTP(this) && (status==3))
			{
				CloseSock(ctrlsock,true);
				CloseData();
				return;
			}
			else
			{
				wb(GetSTR(32,"Server closed control connection, reconnecting."),3);
				status=0;
				ActOnStatus();
				dds();
			}
			return;
	}
	if (sock==datasock)
	{
		CloseSock(datasock,true);
		CloseData();
	}
}

void basicdl::ActOnAccept(SOCKET sock)
{
	if (sock==listensock)
	{
	  //SOCKET tmp;
	  //tmp=datasock;
	  datasock=accept(listensock,NULL,NULL);
	  //sock++;
	  //AddSock(datasock);
#if __unix__
		FD_SET(datasock,&rdsocks);
		FD_SET(datasock,&wrsocks);
		printf("actonaccept:: datasock: %d\n\n",datasock);
#endif //__unix__

		CloseSock(listensock,false);
		if (type==2)
		{
			// Telll GUI we're getting the list of files.
			//if (mir->nfo->prot==1) ((browseftp*)this)->readbuffi2=0;
		}
		return;
	}
else
printf("got bad accept: sock:%d\n",datasock);
}

void basicdl::ActOnConnect(SOCKET sock,LPARAM lParam)
{
	if (sock==ctrlsock)
	{
		ConnectCtrl(lParam);
		return;
	}
	if (sock==datasock)
	{
		ConnectPASV(lParam);
		return;
	}
}

void basicdl::doerr(int en)
{
	maindl *tmp;
	char str[1024];
	status=0;
	if (fp)
	{
		fflush(fp);
		fclose(fp);
		fp=NULL;
	}
	CloseSockets();
	CheckLog();
	switch (en)
	{
	case 1:
		sprintf(str,GetSTR(33,"Can't resolve host name. Check your URL - %s doesn't exist."),mir->nfo->host);
		mdl->ErrMsg=ReDupString(mdl->ErrMsg,str);
		break;
	case 2:
		strcpy(str,GetSTR(34,"Host refused to connect - probably closed."));
		break;
	case 3:
		strcpy(str,GetSTR(35,"Server refuses to resume file."));
		break;
	case 4:
		strcpy(str,GetSTR(36,"Error logging in - Password incorrect?"));
		break;
	case 5:
		strcpy(str,GetSTR(37,"Server refuses to download - bad account?"));
		break;
	case 6:
		strcpy(str,GetSTR(38,"Error downloading file - check you file name."));
		break;
	case 8:
		strcpy(str,GetSTR(43,"Error downloading file (Can't access file - not found or no access)."));
		break;
	case 9:
		strcpy(str,GetSTR(39,"Can't initiate download - will try again."));
		break;
	case 10:
		strcpy(str,GetSTR(40,"This download requires a cookie - you will have to browse the URL to get one."));
		break;
	case 11:
		strcpy(str,GetSTR(41,"Can't write to disk, check your download directory and the file name."));
		break;
	case 12:
		strcpy(str,GetSTR(227,"Error accessing firewall."));
		break;
	case 13:
		strcpy(str,GetSTR(42,"Can't write to disk, disk may be full."));
		break;
	}
	dds();
	wb(str,3);
	if (type==1) log_wr(str,true);
	//if (type==6) wstatus(str);
	wstatus(str);
	if (type==2)
	{
		pause=true;
		return;
	}
	if ((type==8)||(type==7)&&((gsdl*)this)->table)
	{
		KillDL();
		return;
	}
//	if ((type!=4) && (type!=5) && (type!=6))
//		SendMessage(Hgui,WM_D_ERROR,(WPARAM) actpos,(LPARAM) str);
	// Tell gui, error
	tmp=mdl;
	time_t tp;
	time(&tp);
	if (tmp->spliton==1)
	{
		tmp->error.en=en;
		tmp->error.t=tp;
		tmp->error.c[en]++;
	}
	mir->en=en;
	mirrors *ismir=mdl->GetBestMirror();
	if (en<6)
		if (mir->ser->actcon==1)
		{
			mir->ser->en=en;
			mir->ser->errtime=tp;
		}
	if (mir->used>1)
		mir->en=0;
	else mir->errtime=tp;
	if (ismir!=NULL)
	{
		MoveMirr(ismir);
		QueryDNS();
	}
	else KillDL();
//	CheckAuto(mb->lfn);
}

bool basicdl::ActOnFTPStatus()
{
	unsigned int result;
	char str[1024];
	if (status && abort) return true;
	//abort=false;
	printf("Status: %d\n",status);
	time(&timeout);
	if (!mdl->isdl)
		mdl->timeout=timeout;
	switch (status)
	{
	default:
		return GenActOnFTPStatus();
		break;
	case 0:
		abort=false;
		if (!busy && (++err[9]>=11))
		{
			err[9]=0;
			mdl->ErrMsg=ReDupString(mdl->ErrMsg,GetSTR(18,"GetSmart tried to initiate a download\
10 times\nand was not successful.\nIf you are in\auto download mode, it will try again later."));
			dds();
			doerr(9);
			return false;
		}
		return GenActOnFTPStatus();
		break;
		
	case 7:
		if (fp)
		{
			fflush(fp);
			fclose(fp);
			fp=NULL;
		}
		result=0;
		GetFN(str);
		fp=fopen(str,"rb");
		if (fp) 
		{
			result=GetFSize(fp);
			InitIntCheck(result);
			fflush(fp);
			fclose(fp);
			fp=NULL;
		}
		else
		{
			result=0;
			checkint=false;
		}
		mdl->localbytes[splitdex]=result;
		if (mdl->splitdex) 
		{
			result+=mdl->sps[splitdex];
			if (result>=mdl->spe[splitdex])
			{
				mdl->spdone[splitdex]=true;
				RideOn();
				return false;
			}
		}
		else 
			if (mdl->rsize && (result>=mdl->rsize))
			{
				RideOn();
				return false;
			}
		return GenActOnFTPStatus();
		break;
	case 8:
		// tell GUI there's info (size & resume)
		if (resume && mdl->localbytes[splitdex] || mdl->sps[splitdex])
		{
			if (!checkint || checkint && (mdl->sps[splitdex]+mdl->localbytes[splitdex]-fbufsize))
				if (/*(lastcmd[1]!=200) ||*/ (lastcmd[0]!=350))
				{
					status++;
					TimedOut();
					return false;
				}
		}
		mdl->retries++;
		if (!mdl->info)
		{
			if (resume)
				mdl->resume=resume;
			mdl->info=true;
			SaveURLs();
		}
		if (resume && (!mdl->splitdex ||
			(mdl->dosplit>mdl->splitdex+1)))
			if (mdl->dosplit>=1) mdl->ChangeSplit(mdl->dosplit);
			if (!resume && mdl->splitdex)
			{
				doerr(3);
				return 0;
			}
			if (mdl->localbytes[splitdex] && !resume)
			{
				if ((mdl->resume) || mdl->splitdex)
					if (++err[3]>=5)
					{
						err[3]=0;
						strcpy(mdl->ErrMsg,GetSTR(44,"This server supported \
resuming when first initiated.\nIt probably uses different server \
types \nbecause it can't Resume now.\nIf you are in auto download \
mode, GetSmart will try again later."));
						dds();
						doerr(3);
						return false;
					}
					else
					{
						status=0;
						return ActOnStatus();
					}
					result=0;
					BadFN();
					//SendMessage(Hgui,WM_D_INFO,(WPARAM) this->actpos,7);
					//Tell GUI starting file all over.
			}
			GetFN(str);
			if (fp)
			{
				fflush(fp);
				fclose(fp);
				fp=NULL;
			}
			if (type!=6)
			{
#ifdef OPEN1
				fp=fopen(str,"a+bc");
				if (!fp)
				{
					doerr(11);
					return false;
				}
				//setvbuf(fp,NULL,cfg.flushsize,_IOFBF);
#endif
			}
			sprintf(str,"RETR %s%s\r\n",mir->nfo->rdir,mir->nfo->rfn);
			wb(str,1);
			WriteFTP(str);
			strcpy(str,GetSTR(28,"Downloading file..."));
			dds();
			wstatus(str);
			break;
		}
		return true;
}

bool basicdl::GenActOnFTPStatus()
{
	char str[1024];
 	if (status && abort) return true;
	abort=false;
	time(&timeout);
	if (!mdl->isdl)
		mdl->timeout=timeout;
	switch (status)
	{
	case 0:
		CheckLog();
		CloseSockets();
		if (!ctrladdr.sin_addr.s_addr || (useproxy==3) && !fireaddr.sin_addr.s_addr)
		{
			fireaddr.sin_addr.s_addr=0;
			return QueryDNS();
		}
		//if (splitdex!=-1)
			//mdl->spdone[splitdex]=false;
		if (type!=6) Ping();
		if (!InitCtrl()) return 1;
		readbuffi=0;
		pause=false;
		strcpy(str,GetSTR(45,"waiting for connect.."));
		dds();
		wb(str,0);
		wstatus(str);
		FILE *fp0;
		fp0=NULL;
/*		GetFN(str);
		fp0=fopen(str,"rb");
		unsigned long result;
		result=0;
		if (fp0)
		{
			result=(unsigned)(_filelength(_fileno(fp0)));
			if (result!=mdl->localbytes[splitdex])
			{
				int hj;
				hj=1;
			}
			fclose(fp0);
		}
		sprintf(str,"DEBUG - localbytes:%ld  FileSize:%ld",mdl->localbytes[splitdex],result);
		log_wr(str,true);*/
		break;
	case 1:
		strcpy(str,GetSTR(46,"Sending Login.."));
		wstatus(str);
		if (useproxy==1)
		{
			switch (cfg.Proxy.FTPT)
			{
			case 0:
			case 1:
			default:
				sprintf(str,"USER %s@%s:%ld\r\n",mir->nfo->user,
					mir->nfo->host,mir->nfo->port);
				break;
			}
		}
		else
			sprintf(str,"USER %s\r\n",mir->nfo->user);
		wb(str,1);
		WriteFTP(str);
		break;
	case 2:
		strcpy(str,GetSTR(47,"Sending Password.."));
		wstatus(str);
		sprintf(str,"PASS %s\r\n",mir->nfo->pass);
		WriteFTP(str);
		if (cfg.hidepass) strcpy(str,"PASS *****\r\n");
		wb(str,1);
		break;
	case 3:
		strcpy(str,GetSTR(48,"Checking for resume support.."));
		wstatus(str);
		strcpy(str,"REST 1\r\n");
		wb(str,1);
		WriteFTP(str);
		fp0=NULL;
		GetFN(str);
/*		fp0=fopen(str,"rb");
		if (fp0)
		{
			if ((unsigned)(_filelength(_fileno(fp0)))!=mdl->localbytes[splitdex])
			{
				int hj;
				hj=1;
			}
			fclose(fp0);
		}*/
		break;
	case 4:
		switch (mdl->ftpmode)
		{
		case 0:
		  if (!strrchr(mir->nfo->rfn,'.'))
		    {
		      strcpy(str,"TYPE I\r\n");
		      break;
		    }
		  char *s1,*s2;
		  s1=_strlwr(_strdup(strrchr(mir->nfo->rfn,'.')));
		  s2=_strlwr(_strdup(cfg.asciiext));
		  sprintf(str,"%s;",s1);
		  if (s1 && strstr(s2,str))
		    strcpy(str,"TYPE A\r\n");
		  else strcpy(str,"TYPE I\r\n");
		  free(s1);
		  free(s2);
		  break;
		case 1:
		  strcpy(str,"TYPE A\r\n");
		  break;
		case 2:
		  strcpy(str,"TYPE I\r\n");
		  break;
		}
		wb(str,1);
		WriteFTP(str);
		break;
	case 5:
		strcpy(str,GetSTR(49,"Checking file size.."));
		wstatus(str);
		sprintf(str,"SIZE %s%s\r\n",mir->nfo->rdir,mir->nfo->rfn);
		wb(str,1);
		WriteFTP(str);		
		break;
	case 6:
		strcpy(str,GetSTR(50,"Initializing transfer.."));
		wstatus(str);
		if (cfg.Proxy.Passive)
		{
			strcpy(str,"PASV\r\n");
			wb(str,1);
			WriteFTP(str);	
			break;
		}
		InitData();
		break;
	case 7:		
		if (resume)
		{
			if (mdl->localbytes[splitdex]) 
			{
				strcpy(str,GetSTR(51,"Resuming file.."));
				wstatus(str);
			}
			if (checkint)
				sprintf(str,"REST %ld\r\n",mdl->localbytes[splitdex]+mdl->sps[splitdex]-fbufsize);
			else 
				sprintf(str,"REST %ld\r\n",mdl->localbytes[splitdex]+mdl->sps[splitdex]);
			wb(str,1);
			WriteFTP(str);
			strcpy(que[quedex],"xxxx");
		}
		else
		{
			status++;
			if (!ActOnStatus())
			{
				dds();
				return false;
			}
		}
		break;
	}
	dds();
	return true;
}

bool basicdl::GenActOnHTTPStatus()
{
	char str[1024];
	switch (status)
	{
	case 0:
		CheckLog();
		CloseSockets();
		//Ping();
		if (!ctrladdr.sin_addr.s_addr || (useproxy==3) && !fireaddr.sin_addr.s_addr)
		{
			fireaddr.sin_addr.s_addr=0;
			return QueryDNS();
		}
		//mdl->spdone[splitdex]=false;
		if (++err[9]>=11)
		{
			err[9]=0;
			mdl->ErrMsg=ReDupString(mdl->ErrMsg,
				GetSTR(18,"GetSmart tried to initiate a download 10\
times\nand was not successful.\nIf you are in auto download mode, it\
 will try again later."));
			dds();
			doerr(9);
			return false;
		}
		printf("Calling ping, splitdex: %d\n",splitdex);
		if (type!=6) Ping();
		printf("after ping.. calling init ctrl, splitdex: %d\n",splitdex);
		if (!InitCtrl()) return false;
		printf("after initctrl, splitdex: %d\n",splitdex);
		readbuffi=0;
		pause=false;
		strcpy(str,GetSTR(45,"waiting for connect.."));
		wb(str,0);
		wstatus(str);
		break;
	}
	dds();
	return true;
}

bool basicdl::ActOnHTTPStatus()
{
	unsigned int result;
	char str[AVGBUFSIZE];
	time(&timeout);
	if (!mdl->isdl)
		mdl->timeout=timeout;
	switch (status)
	{
	case 0:
		return GenActOnHTTPStatus();
		break;
	case 1:
		firstread=true;
		CheckLog();
		if (type==2)
			TELLGUI(GBR_CLEAN,mdl,0);
		char str2[AVGBUFSIZE],str3[AVGBUFSIZE];
		result=0;
		mdl->retries++;
		readbuffi=0;
		relocation=false;
		GetFN(str);
		if (fp)
		{
			fflush(fp);
			fclose(fp);
			fp=NULL;
		}
		fp=fopen(str,"rb");
		if (fp) 
		{
			result=GetFSize(fp);
			InitIntCheck(result);
			fclose(fp);
			fp=NULL;
		}
		else 
		{
			checkint=false;
			result=0;
		}
		mdl->localbytes[splitdex]=result;
		if (mdl->splitdex) result+=mdl->sps[splitdex];
		if (result && mdl->spe[splitdex] && ((mdl->spe[splitdex]+1)<=result))
		{
			mdl->spdone[splitdex]=true;
			RideOn();
			return false;
		}
		if (useproxy==2)
		{
			//char str2[1000];
			ConstURL(mir->nfo,str2);
			rcs(str2);
			sprintf(str,"GET %s HTTP/1.0\r\nHost: %s\r\n",str2,mir->nfo->host);
			if (strlen(cfg.Proxy.huser))
			{
				sprintf(str2,"%s:%s",cfg.Proxy.huser,cfg.Proxy.hpass);
				Base64(str2,str3);
				sprintf(str2,"Proxy-Authorization: Basic %s\r\n",str3);
				strcat(str,str2);
			}
			if (cfg.Proxy.nocache)
				strcat(str,"Pragma: no-cache\r\nCache-Control: no-cache\r\n");
		}
		else
		{
			sprintf(str2,"%s%s",mir->nfo->rdir,mir->nfo->rfn);
			rcs(str2);
			sprintf(str,"GET %s HTTP/1.0\r\nHost: %s\r\n",str2,
				mir->nfo->host);
		}
		strcat(str,"Range: bytes=");
		strcpy(str2,str);
		if (mdl->spe[splitdex])
		{
			if (checkint) 
				sprintf(str,"%s%ld-%ld\r\nRequest-Range: bytes=%ld-%ld\r\n",str2,
				result-fbufsize,mdl->spe[splitdex],result-fbufsize,mdl->spe[splitdex]);
			else
				sprintf(str,"%s%ld-%ld\r\nRequest-Range: bytes=%ld-%ld\r\n",str2,
				result,mdl->spe[splitdex],result,mdl->spe[splitdex]);
		}
		else
		{
			if (type==6)
			{
				checkint=false;
				result=1;
			}
			if (checkint) 
				sprintf(str,"%s%ld-\r\nRequest-Range: bytes=%ld-\r\n",str2,
				result-fbufsize,result-fbufsize);
			else
				sprintf(str,"%s%ld-\r\nRequest-Range: bytes=%ld-\r\n",str2,
				result,result);
		}
		if (cfg.referer)
		{
			char pr[100];
			if (mir->nfo->prot==1)
				strcpy(pr,"ftp://");
			else
				strcpy(pr,"http://");
			sprintf(str2,"Referer: %s%s/index.html\r\n",pr,mir->nfo->host);
			strcat(str,str2);
		}
		if (!cfg.uuagent)
			strcat(str,"User-agent: GetSmart/"VERSION"\r\n");
		else
		{
			sprintf(str2,"User-agent: %s\r\n",cfg.uagent);
			strcat(str,str2);
		}
		if (strcmp("anonymous",mir->nfo->user)||
			strcmp(cfg.Email,mir->nfo->pass))
		{
			sprintf(str2,"%s:%s",mir->nfo->user,mir->nfo->pass);
			Base64(str2,str3);
			sprintf(str2,"Authorization: Basic %s\r\n",str3);
			strcat(str,str2);
		}
		strcat(str,"Accept: *.*, */*\r\nConnection: Keep-Alive\r\n\r\n");
		wb(str,1);
		send(ctrlsock,str,strlen(str),0);
		break;
	}
	return true;
}

void basicdl::ActOnWrite(SOCKET sock)
{
}

void basicdl::ActOnRead(SOCKET sock)
{
	if (sock==ctrlsock)
    {
		if (firectrl)
			if (ChkFire(ctrlsock))
				firectrl=false;
			else
				return;
			ReadCtrl();
			return;
    }
	if (sock==datasock)
    {
		if (firedata)
			if (ChkFire(datasock))
				firedata=false;
			else
				return;
			ReadData(datasock);
			return;
    }
	if (sock==pingsock)
    {
		SOCKADDR_IN fromaddr;
		unsigned char ttl;
		pingtime=RecvEchoReply(pingsock,&fromaddr,&ttl);
		mdl->pingtime=pingtime;
		if ((type==6) && (((dlchk*)this)->mmir->pmdl==mdl))
		{
			if (pingtime<10000)
			{
				((dlchk*)this)->mmir->pingcount++;
				((dlchk*)this)->mmir->pingsum+=pingtime;	
			}
			else
			{
				int i;
				i=0;
			}
			mir->NextPing(this);
			return;
		}
		else
		{
			RMSelectSock(pingsock);
			closesocket(pingsock);
			//sock--;
			pingsock=INVALID_SOCKET;
		}
		return;
	}
}

int basicdl::WriteFTP(char *str)
{
	time(&timeout);
	if (!mdl->isdl)
		mdl->timeout=timeout;
	if (quedex<-1) quedex=-1;
	if (strnicmp(str,"NOOP",4))
	{
		pause=false;
		quedex++;
		if (quedex==10)
			repq();
		memcpy(que[quedex],str,40);
	}
	return send(ctrlsock,str,strlen(str),0);
}

void basicdl::dq()
{
	if (quedex>=0)
		quedex--;
}

void basicdl::repq()
{
	int ret;
	quedex--;	
	for (ret=0;ret<quedex;ret++)
			memcpy(que[ret],que[ret+1],40);
}

int basicdl::ReadSocket(SOCKET readsock,char *res,char *&readbuff,
						unsigned long &readbuffi)
{
	char *ftpr;
	int ret,i=0,i2=0;
	if (ctrlsock==INVALID_SOCKET) return 0;
	if (readbuffi) memcpy(res,readbuff,readbuffi);
	ret=recv(readsock,&res[readbuffi],AVGBUFSIZE/2,0);
	res[readbuffi+ret]='\0';
	if (!ret || (ret==SOCKET_ERROR))
		return 0;
	ret+=readbuffi;
	ftpr=res;
	//bool mp=false;
	while (i<ret)
	{
		while ((i<ret) && (*ftpr!='\n'))
		{
			i++;
			ftpr++;
		}
		if (i>=ret) break;
			else i2=i+1;
		if ((type!=4) && (mir->nfo->prot==2) && (!strncmp((ftpr-3),"\r\n\r\n",4) || 
			!strncmp((ftpr-1),"\n\n",2)))
		{
			break;
		}
		i++;
		ftpr++;
	}
	readbuffi=ret-i2;
	if ((readbuffi<0) || (readbuffi>AVGBUFSIZE))
		readbuffi=0;
	if ((readbuffi+i2)>AVGBUFSIZE)
		readbuffi=0;
	if (readbuffi)
	{
		if (readbuff)
			readbuff=(char*) realloc(readbuff,readbuffi);
		else
			readbuff=(char*) malloc(readbuffi);
		memcpy(readbuff,&res[i2],readbuffi);
	}
	return i2;
}

bool maindl::Cr8DL(mirrors *mir,int sp,int hm,bool start)
{
	if ((sp!=-1) && (type!=4) && (type!=6) &&
		( (sp>cfg.maxsplit)||(splitdl[sp]!=NULL) ))
		return false;
	if ((hm!=-1) && (type!=6) && ( (hm>MAXHAMMER) || (hamdl[hm]!=NULL) ))
		return false;
	if ((avmir!=NULL) && ((type==1) || (type==2) || (type==7)))
		mir=avmir;
	else
	  if (mir==NULL)
	    {
	      if (!spliton)
		{
		  strncpy(mstxt,GetSTR(67,"Can't start download. No available mirrors."),80);
		  dds();
		}
	      return false;
	    }
	short proxy;

	if (dialing)
	  {
	    if (((type==1) || (type==2) || (type==7)) && (avmir!=NULL))
	      {
		avmir=NULL;
		RMSelectSock(avsock);
		closesocket(avsock);
		//sock--;
		avsock=INVALID_SOCKET;
	      }
	    wasactive=true;
	    return false;
	  }
	if ((lastact==-1) && (maincount>0) && !IsConnected())
	{
	  wasactive=true;
	  StartDial();
	  return false;
	}
	proxy=GetMirProxy(mir,type);
	if (proxy==-1)
	{
		if (((type==1) || (type==2) || (type==7)) && (avmir!=NULL))
		{
			avmir=NULL;
			RMSelectSock(avsock);
			closesocket(avsock);
			//sock--;
			avsock=INVALID_SOCKET;
		}
		return false;
	}
//	create new struct according to type.

	basicdl *ndl;
	switch (type)
	{
	case 1:
		ndl=new dl(mir,type);
		break;
	case 2:
		ndl=new browsedl(mir);
		((browsedl*)ndl)->cwd=ReDupString(((browsedl*)ndl)->cwd,mir->nfo->rdir);
		break;
	case 4:
		ndl=new mirrsearch(mir,(maindl*) sp);
		sp=0;
		break;
	case 5:
		ndl=new dlproxy(mir);
		break;
	case 6:
		ndl=new dlchk(mir,type,(maindl*) sp);
		((dlchk*)ndl)->mmir=(mirrors*) hm;
		hm=-1;
		sp=0;
		break;
	case 7:
		ndl=new gsdl(mir);
		break;
	case 8:
		ndl=new gsul(mir);
		break;
	case 9:
		ndl=new upddlchk(mir);
		break;
	case 10:
		ndl=new upddl(mir);
		break;
	}
	ndl->useproxy=proxy;
	if (sp!=-1)
	{
		splitdl[sp]=ndl;
		spliton++;
		sessionbytes[sp]=0;
		ndl->splitdex=sp;
		if (splitdex<sp) splitdex=sp;
		ndl->txtpos=sp;
		if (bstxt[sp]==NULL)
			bstxt[sp]=(char *)malloc(MAXSTATUS);
	}
	else
	{
		hamdl[hm]=ndl;
		hamon++;
		ndl->hamdex=hm;
		if (hamdex<hm) hamdex=hm;
		ndl->txtpos=hm+TOPMAXSPLIT;
		if (bstxt[ndl->txtpos]==NULL)
			bstxt[ndl->txtpos]=(char *)malloc(MAXSTATUS);
		mir->ser->actcon--;
		mir->used--;
		activesocks--;
	}
	strncpy(bstxt[ndl->txtpos],GetSTR(65,"Paused"),80);
	dds();

	time(&ndl->starttime);
	time(&ndl->timeout);
	ndl->mdl=this;
	ndl->pause=false;
	killonstop=ndl->killonstop;
	int i;
	for (i=0;i<1024;i++)
		if (!actdls[i])
			break;
	if (i==1024)
	{
		delete ndl;
		if (((type==1) || (type==2)) && (avmir!=NULL))
		{
			avmir=NULL;
			RMSelectSock(avsock);
			closesocket(avsock);
			//sock--;
			avsock=INVALID_SOCKET;
		}
		return false;
	}
	ndl->intsmallsize=cfg.intsmallsize;
	if (i>lastact) lastact=i;
	actdls[i]=ndl;
	ndl->actpos=i;
	//tell gui  a small dl started.
	STELLGUI(BDL_START,ndl,0);

	if ((spliton==1) && !hamon)
	{
		wait=true;
		starttime=0;
		logged=false;
		mirsearch=false;
		if (type==1)
		{
			activemain++;
			activedl++;
			mirrorhead->ser->actdl++;
		}
		else
			if (type==5) activebr++;
		error.en=0;
		error.t=0;
		actpos=lastmact+1;
		actmdls[lastmact+1].mdl=this;
		sbytes=0;
		memset(sessionbytes,0,sizeof(sessionbytes));
		lastmact++;
		if (type==1) log_start();
		STELLGUI(MDL_START,this,0);
		if (type==1) StartMirrorCheck();
	}
	else
		if (type==1) CheckNextMirror(this);

	if ((start) && (type==1)) ndl->log_start();

	if (start && strlen(ndl->mir->nfo->host))
	{
		if (((type==1) || (type==2) || (type==7)) && (avmir!=NULL))
		{
			ndl->status=1;
			avmir=NULL;
			ndl->SendSock(avsock);
			if ISHTTP(ndl)
				ndl->ActOnStatus();
			else MainFunc(1,ndl);
			return true;
		}
		ndl->fireaddr.sin_addr.s_addr=0;
		if (!ndl->QueryDNS()) return false;
	}
	else
	{
		if (((type==1) || (type==2) || (type==7)) && (avmir!=NULL))
		{
			ndl->status=1;
			avmir=NULL;
			ndl->SendSock(avsock);
		}
		if (!strlen(ndl->mir->nfo->host))
			ndl->pause=true;
	}
	dds();
	if (((type==1) || (type==2) || (type==7)) && (avmir!=NULL))
	{
		avmir=NULL;
		RMSelectSock(avsock);
		closesocket(avsock);
		//sock--;
		avsock=INVALID_SOCKET;
	}
	if ((sp!=-1) && !splitdl[sp]) return false;
	return true;
}

void basicdl::SendSock(SOCKET &hsock)
{
	CloseSockets();
	ctrlsock=hsock;
	if ISFTP(this)
		AbortFTP();
	int len=sizeof(SOCKADDR);
	getpeername(hsock,(SOCKADDR FAR *)&ctrladdr,(OSsign int FAR *)&len);
	time(&timeout);
	if (!mdl->isdl)
		mdl->timeout=timeout;
	int nRet = 1;
	char achDiscard[AVGBUFSIZE];
	while (nRet && (nRet != SOCKET_ERROR))
		nRet = recv (hsock, (char*)achDiscard, sizeof(achDiscard), 0);
#ifdef _WIN32
	AddSelectSock(ctrlsock,actpos);
#endif
	hsock=INVALID_SOCKET;
}

void basicdl::CloseData()
{
	unsigned long totalbytes0;
	wb(GetSTR(52,"Server closed data connection."),0);
	dds();
	if (type==2)
	{
		pause=true;
		wb(GetSTR(80,"Finished receiving list."),0);
		dds();
		TELLGUI(GBR_END,mdl,0);
		// tell browser end of list
		return;
	}
	if (fp)
	{
		fflush(fp);
		fclose(fp);
		fp=NULL;
	}
	if (mdl->splitdex)
		totalbytes0=mdl->localbytes[splitdex]+mdl->sps[splitdex];
	else totalbytes0=mdl->localbytes[splitdex];
	if (!mdl->rsize || mdl->spdone[splitdex] || (mdl->rsize<=totalbytes0)) 
	{
		{
			mdl->spdone[splitdex]=true;
			RideOn();
		}
	}
	else 
	{
		wb(GetSTR(53,"Trying to resume."),3);
		TimedOut();
	}
	dds();
}

void basicdl::ConnectPASV(LPARAM lParam)
{	
	time(&timeout);
	if (!mdl->isdl)
		mdl->timeout=timeout;
	if (ConnectErr(lParam))
	  {
	  if (++err[2]>=5)
	    {
	      err[2]=0;
	      mdl->ErrMsg=ReDupString(mdl->ErrMsg,
			GetSTR(54,"Remote server refused to connect.\nThis can\
happen if it's closed or if you got the\nwrong port number.\
GetSmart tried connecting 5 times.\nIf you are in auto\
download mode, it will try again later."));
		  dds();
	      doerr(2);
	      return;
	    }
	ActOnStatus();
	return;
	  }
	else err[2]=0;

	SOCKADDR sa;
	unsigned int ret=sizeof(SOCKADDR);
	if (getpeername(datasock,&sa,(OSsign int*)&ret)==SOCKET_ERROR)
	{
		status=0;
		ActOnStatus();
		return;
	}

	if (firedata)
	  {
	    ConnectFire(datasock,pasvaddr);
	    return;
	  }
	char str[1024];
	strcpy(str,GetSTR(55,"Successfuly Connected to data port."));
	dds();
	wb(str,0);
	wstatus(str);
	if (type==2)
	  {
	    // tell gui Send message to GUI, getting list.
	    //if (nfo->prot==1) ((browseftp*)this)->readbuffi2=0;
	  }
	status++;
	ActOnStatus();
}

void basicdl::wstatus(char*str)
{
	strncpy(mdl->bstxt[txtpos],str,MAXSTATUS);
	if ((type==6) && (((dlchk*)this)->mmir->rmdl==mdl))
		((dlchk*)this)->mmir->status=ReDupString(((dlchk*)this)->mmir->status,str);
	int bigst=-1,sp=-1;
	for (int i=0;i<=mdl->splitdex;i++)
		if (mdl->splitdl[i] && (mdl->splitdl[i]->status>bigst))
		{
			bigst=mdl->splitdl[i]->status;
			sp=i;
		}
	if (sp==splitdex)
		strncpy(mdl->mstxt,str,MAXSTATUS);
	//log_wr(str,false);

}

void basicdl::wb(char*str,unsigned short c)
{
  printf("%s\n",str);
	char *a,*s1,*s2;
	int l;
/*	char str0[1000];
	sprintf(str0,"c:\\dl%d.log",splitdex);
	FILE *fp0=fopen(str0,"a+t");
	if (fp0):
	{
		strcpy(str0,str);
		strcat(str0,"\n");
		fwrite(str0,1,strlen(str0),fp0);
		fclose(fp0);
	}*/
	if (!strchr(str,'\n'))
	{
		new buffer(this,str,c);
		if (buffcount>=TOPMAXBUFFER)
		{
			buffer *tmp=buffhead;
			buffhead=buffhead->next;
			delete tmp;
		}
		return;
	}
	a=DupString(str);
	s1=a;
	s2=s1;
	while (s2=strchr(s2,'\n'))
	{
		l=s2-s1;
		if (l && (*(s2-1)=='\r')) *(s2-1)='\0';
		else *s2='\0';
		new buffer(this,s1,c);
		if (buffcount>=TOPMAXBUFFER)
		{
			buffer *tmp=buffhead;
			buffhead=buffhead->next;
			delete tmp;
		}
		s1=s2+1;
		s2++;

	}
	free(a);
#ifdef __unix__
	//printf(str);
#endif
}

void basicdl::ConnectCtrl(LPARAM lParam)
{
	char str[1024];
	time(&timeout);
	if (!mdl->isdl)
		mdl->timeout=timeout;
	if (status) return;
	if (ConnectErr(lParam))
	{
		if (++err[2]>=5)
		{
			err[2]=0;
			mdl->ErrMsg=ReDupString(mdl->ErrMsg,GetSTR(15,
				"Remote server refused to connect.\nThis can happen if it's closed or if you got the\nwrong\
port number. GetSmart tried connecting 5 times.\nIf you are in auto download mode, it will try again\
 later."));
			dds();
			doerr(2);
			return;
		}
		status=0;
		ActOnStatus();
		return;
	}
	else err[2]=0;

	SOCKADDR sa;
	unsigned int ret=sizeof(SOCKADDR);
	if (getpeername(ctrlsock,&sa,(OSsign int*)&ret)==SOCKET_ERROR)
	{
		status=0;
		ActOnStatus();
		return;
	}

	if (firectrl)
	{
		ConnectFire(ctrlsock,ctrladdr);
		return;
	}
	if (!status)
		if ISFTP(this)
		{
			strcpy(str,GetSTR(16,"Connected, waiting for welcome message."));
			wb(str,0);
			wstatus(str);
		}
		else
			{
				strcpy(str,GetSTR(17,"Connected."));
				wb(str,0);
				wstatus(str);
				status=1;
				ActOnStatus();
			}
	dds();
}

void basicdl::InitData()
{
	char str[1024];
	SOCKADDR_IN tmpaddr;
	int len=sizeof(struct sockaddr_in);
	if (listensock!=INVALID_SOCKET)
		CloseSock(listensock,false);
	if (datasock!=INVALID_SOCKET)
	  CloseSock(datasock,false);
	GETSOCK(listensock,AF_INET,SOCK_STREAM,0);
	AddSelectSock(listensock,actpos);
	getsockname(ctrlsock,(SOCKADDR FAR *)&tmpaddr,(OSsign int FAR *)&len);
	tmpaddr.sin_port=0;
	bind(listensock,(SOCKADDR*)&tmpaddr,sizeof(struct sockaddr_in));
	getsockname(listensock,(SOCKADDR FAR *)&tmpaddr,(OSsign int FAR *)&len);
	listen(listensock,1);
	sprintf(str,"PORT %d,%d,%d,%d,%d,%d\r\n",(tmpaddr.sin_addr.s_addr&0xff),
		(tmpaddr.sin_addr.s_addr&0xff00)>>8,(tmpaddr.sin_addr.s_addr&0xff0000)>>16,
		(tmpaddr.sin_addr.s_addr&0xff000000)>>24,(tmpaddr.sin_port&0xff),
		(tmpaddr.sin_port&0xff00)>>8);
	wb(str,1);
	WriteFTP(str);
}

bool basicdl::InitCtrl()
{
	if (cfg.Dial.Use && !IsConnected())
	{
		DetectedHangup();
		return false;
	}
	time(&timeout);
	ctrladdr.sin_family=AF_INET;
	if (ctrlsock!=INVALID_SOCKET)
		CloseSock(ctrlsock,false);
	GETSOCK(ctrlsock,AF_INET,SOCK_STREAM,0);
	AddSelectSock(ctrlsock,actpos);
	switch (useproxy)
	{
	case 1:
		ctrladdr.sin_port=htons(cfg.Proxy.FTPP);
		break;
	case 2:
		ctrladdr.sin_port=htons(cfg.Proxy.HTTPP);
		break;
	case 3:
		fireaddr.sin_port=htons(cfg.Proxy.socksport);
		ctrladdr.sin_port=htons(mir->nfo->port);
		fireaddr.sin_family=AF_INET;
		firectrl=true;
		break;
	default:
		ctrladdr.sin_port=htons(mir->nfo->port);
		break;
	}
	if ((type==6) && (((dlchk*)this)->mmir->pmdl==mdl))
	{
		Ping();
		return false;
	}
	int t;
	if (useproxy==3)
		t=connect(ctrlsock,(SOCKADDR*)&fireaddr,sizeof(struct sockaddr));
	else
	    t=connect(ctrlsock,(SOCKADDR*)&ctrladdr,sizeof(struct sockaddr));
	return true;
}

bool basicdl::ChkFire(SOCKET s)
{
	char str[1024];
	unsigned char firebuff[8];
	bool ferr=false;
	if (recv(s,(char*)firebuff,8,0)<8)
		ferr=true;
	else
	{
		if (firebuff[0]!='0')
			ferr=true;
		else
			switch (firebuff[1])
			{
			case 90:
				break;
			case 91:
				mdl->ErrMsg=ReDupString(mdl->ErrMsg,GetSTR(56,"FireWall request rejected or failed."));
				ferr=true;
				break;
			case 92:
			case 93:
				mdl->ErrMsg=ReDupString(mdl->ErrMsg,GetSTR(57,"FireWall request rejected due to GetSmart not supporting Ident, contact us."));
				ferr=true;
				break;
			default:
				mdl->ErrMsg=ReDupString(mdl->ErrMsg,GetSTR(58,"FireWall request rejected or failed, error unknown"));
				ferr=true;
				break;
			}
	}
	dds();
	if (ferr)
	{
		if (++err[12]>3)
		{
			doerr(12);
			return false;
		}
		status=0;
		ActOnStatus();
		return false;
	}

	if (s!=ctrlsock)
	{
		strcpy(str,GetSTR(55,"Successfuly Connected to data port."));
		dds();
		wb(str,0);
		wstatus(str);
		time(&timeout);
		if (!mdl->isdl)
			mdl->timeout=timeout;
		status++;
		return ActOnStatus();
	}
	if (mir->nfo->prot==1)
	{
		strcpy(str,GetSTR(16,"Connected, waiting for welcome message."));
		dds();
		wb(str,0);
		wstatus(str);
		time(&timeout);
		if (!mdl->isdl)
			mdl->timeout=timeout;
	}
	else
		if (mir->nfo->prot==2)
		{
			strcpy(str,GetSTR(17,"Connected."));
			dds();
			wb(str,0);
			wstatus(str);
			time(&timeout);
			if (!mdl->isdl)
				mdl->timeout=timeout;
			status=1;
			return ActOnStatus();
		}

	return true;
}

void GetTime(char *tm)
{
  char str[1024];
  TimeStruct ts;
  ts.Init();
  sprintf(str,"%.2d:%.2d:%.2d ",ts.h,ts.min,ts.sec);
  strcpy(tm,str);
}

inline void GetLogSP(char *sp)
{
	strcpy(sp,"         ");
}
	
void maindl::log_start()
{
	char str[1024],time[15],lang[50];
	GetTime(time);
	sprintf(lang,"%%s^$ %s",GetSTR(3,"New file: %s%s"));
	sprintf(str,lang,time,ldir,lfn);
	wrlog(this,str);
	char url[1024];
	ConstURL(mirrorhead->nfo,url);
	GetLogSP(time);
	sprintf(str,"%s   URL: %s",time,url);
	wrlog(this,str);
	if (istmpdir)
	{
		sprintf(lang,"%%s # %s",GetSTR(4,"Using temp dir: %s"));
		sprintf(str,lang,time,cfg.tmpdir);
		wrlog(this,str);
	}
	dds();
}

void maindl::log_end()
{
	char str[1024],time[15],lang[50];
	unsigned long d,sz=0;
	GetTime(time);
	sprintf(str,"%s%s",ldir,lfn);
	FILE*fp0=fopen(str,"rb");
	if (fp0)
	{
		sz=GetFSize(fp0);
		fclose(fp0);
	}
	if (!rsize) rsize=sz;
	sprintf(lang,"%%s $ %s",GetSTR(5,"\"%s%s\" size:%d - Download complete"));
	sprintf(str,lang,time,ldir,lfn,sz);
	wrlog(this,str);
	GetLogSP(time);
	d=begtime.DayDiff();
	if (d)
	{
		sprintf(lang,"%%s # %s",GetSTR(6,"Started %d days ago."));
		sprintf(str,lang,time,d);
		wrlog(this,str);
	}
	if (sz && totaltime)
	{
		char bak[1024];
		strcpy(bak,GetSTR2(7,"Average CPS %.2f kb/s."));
		sprintf(lang,"%%s # %s",bak);
		//d=sz/totaltime; // calc average CPS.
		sprintf(str,lang,time,sz/totaltime/1024.0);
		wrlog(this,str);
	}
	sprintf(lang,"%%s # %s",GetSTR(8,"%d retries."));
	sprintf(str,lang,time,retries);
	wrlog(this,str);
	dds();
}

void maindl::log_wr(char*s,bool iser)
{ 
	char str[1024],time[15];
	GetTime(time);
	sprintf(str,"%s%s %s - %s",time,(iser)? "!$":" $",lfn,s);
	wrlog(this,str);
	dds();
}

void basicdl::log_start()
{
	char str[1024],time[15],lang[50];
	GetTime(time);
	if (mdl->rsize)
	{
		if (mdl->sps[splitdex])
		{
			sprintf(lang,"%%s + %%s (%%d) %s",GetSTR(10,
				"starting -> %d-%d"));
			sprintf(str,lang,time,mdl->lfn,splitdex,mdl->sps[splitdex],
				mdl->spe[splitdex]);
		}
		else
		{
			sprintf(lang,"%%s + %%s %s",GetSTR(10,
				"starting -> %d-%d"));
			sprintf(str,lang,time,mdl->lfn,mdl->sps[splitdex],
				mdl->spe[splitdex]);
		}
	}
	else
		if (mdl->sps[splitdex])
		{
			sprintf(lang,"%%s + %%s (%%d) %s",GetSTR(10,
					"starting -> %d-?"));
			sprintf(str,lang,time,mdl->lfn,splitdex,
				mdl->sps[splitdex]);
		}
		else
		{
			sprintf(lang,"%%s + %%s %s",GetSTR(10,
				"starting -> %d-?"));
			sprintf(str,lang,time,mdl->lfn,mdl->sps[splitdex]);
		}

	wrlog(mdl,str);
	dds();
}

void basicdl::log_end()
{
	char str[1024],time[15],lang[50];
	GetTime(time);
	sprintf(lang,"%%s + %s",GetSTR(11,"%s (%d) Done."));
	sprintf(str,lang,time,mdl->lfn,splitdex);
	wrlog(mdl,str);
	dds();
}

void basicdl::log_wr(char*s,bool iser)
{ 
	char str[1024],time[15];
	GetTime(time);
	if (mdl->sps[splitdex])
		sprintf(str,"%s%s %s (%ld) - %s",time,(iser)? "!+":" +",
		mdl->lfn,splitdex,s);
	else
		sprintf(str,"%s%s %s - %s",time,(iser)? "!+":" +",
			mdl->lfn,s);
	wrlog(mdl,str);
	dds();
}

void basicdl::log_size()
{ 
	char str[1024],time[15];
	GetTime(time);
	sprintf(str,"%s $ %s: Size detected -  %d",time,mdl->lfn,
		mdl->rsize);
	wrlog(mdl,str);
	dds();
}

bool wrlog(maindl*m,char*str)
{
	//return 0;
	char fn[_MAX_PATH],date[30],tmp[1024];
	FILE*fp0=NULL;
	if (cfg.multilog && (m!=NULL))
	{
		if (cfg.logwdl)
			sprintf(fn,"%s%s.log",m->ldir,m->lfn);
		else
			sprintf(fn,"%s%s.log",cfg.logdir,m->lfn);
	}
	else
		sprintf(fn,"%s%s",cfg.logdir,cfg.logfn);
	fp0=fopen(fn,"a+t");
	if (!fp0) return false;
	TimeStruct ts;
	ts.Init();
	if (ts.D!=logday)
	{
		logday=ts.D;
		strcpy(date,GetSTR(9,"Date $d-$m-$yyy"));
		sprintf(tmp,"%.2d",ts.D);
		memcpy(strstr(date,"$d"),tmp,2);
		sprintf(tmp,"%.2d",ts.M+1);
		memcpy(strstr(date,"$m"),tmp,2);
		sprintf(tmp,"%.4d",ts.Y+1900);
		memcpy(strstr(date,"$y"),tmp,4);
		sprintf(tmp,"#%s\n",date);
		fwrite(tmp,1,strlen(tmp),fp0);
	}
	sprintf(tmp,"%s\n",str);
	fwrite(tmp,1,strlen(tmp),fp0);
	fclose(fp0);
	dds();
	return true;
}

void log_gen(char*s,bool iser)
{ 
	char str[1024],time[15];
	GetTime(time);
	sprintf(str,"%s%s %s",time,(iser)? "!*":" *",s);
	wrlog(NULL,s);
	dds();
}

bool maindl::ActMain(bool start)
{
	// activates a main d/l
	wait=false;
	int j;
	if (dialing)
	{
		wasactive=true;
		return 1;
	}
	FilterFN(lfn);
	
	if (_access(ldir,0))
		CreateDirectory(ldir,NULL);
	if (istmpdir)
		if (_access(cfg.tmpdir,0))
			CreateDirectory(cfg.tmpdir,NULL);
	if (_access(ldir,0) || istmpdir && _access(cfg.tmpdir,0))
	{
	  printf("ldir::%s tmpdir::%s\n",ldir,cfg.tmpdir);
		MsgBox(GetSTR(68,"Can't create download / temp directory."),
				0,MB_OK);
		dds();
		return false;
	}
	starttime=0;
	sessionlost=0;
	busytimestarted=0;
	if (!begtime.D)
		begtime.Init();
	
	if (!dosplit && (cfg.defsplit>1))
		dosplit=cfg.defsplit;	
	spliton=0;
	bool alldone=true;
	for (j=0;j<=splitdex;j++)
	{
		if (spdone[j])
			splitdl[j]=NULL;
		else
		{
			alldone=false;
			if (!spliton)
				Cr8DL(GetBestMirror(),j,-1,start);
			else Cr8DL(GetBestMirror(),j,-1,true);
		}
		if (dosplit && (spliton==dosplit)) break;
	}
	if (alldone)
	{
		BuildSplit();
		Chk4Del();
	}
	if (spliton)
	{
		wait=true;
		return true;
	}
	else
		return false;
}

mirrors* maindl::GetBestMirror()
{
	mirrors *mir=mirrorhead,*bmir=NULL,*uvmir=NULL;
	unsigned short used=(unsigned short)-1;
	time_t time2dl=-1;
	if (!rsize)
		if (!mirrorhead->en && (mir->ser->actdl<mir->ser->maxdl))
			return mirrorhead;
		else return NULL;
	while (mir)
	{
		if ((mir->time2dl || (mir==mirrorhead))&& MIRVALID(mir) && ((mir->ser->actdl<mir->ser->maxdl)||mir->used ) )
			if ((mir->ser->actcon<used) || (mir->ser->actcon==used) && 
				(mir->time2dl<time2dl))
			{
				if (((mir->ser->actcon+1)>mir->ser->maxcon) ||
					(mir->used>=mir->ser->maxeach))
					uvmir=mir;
				else
				{
					bmir=mir;
					used=mir->ser->actcon;
					time2dl=mir->time2dl;
				}
			}
		mir=mir->next;
	}
	if ((bmir==NULL) && (uvmir!=NULL))
		bmir=uvmir;
	return bmir;
}

maindl *CheckDup(dlnfo *nfo)
{
	maindl *tmp=listhead;
	while (tmp)
	{
		if ((tmp->type==1) && 
			!stricmp(nfo->rfn,tmp->mirrorhead->nfo->rfn))
			return tmp;
		tmp=tmp->next;
	}
	return NULL;
}

mirrors* AddMirror(maindl *mdl,dlnfo *nfo)
{
	mirrors *tmp=mdl->mirrorhead;
	while (tmp)
	{
		if (!strcmp(tmp->nfo->host,nfo->host) && 
			!strcmp(tmp->nfo->rdir,nfo->rdir))
			break;
		tmp=tmp->next;
	}
	if (tmp) return tmp;
	dlnfo *dltmp=new dlnfo(nfo);
	tmp=new mirrors(dltmp,mdl);
	//if ((mdl->smdl==NULL) && mdl->spliton) tmp->Ping();
	// tell gui ther's a new mirror
	delete dltmp;
	return tmp;
}


maindl*AddURL(dlnfo*newdl,char *ldir,char *lfn,short type,
			  short proxy,short dosp,time_t to,short prior,
				short mode,bool usehammer,bool useretry,
				bool checkint,bool smallint)
{
	char lfn0[_MAX_PATH],ldir0[_MAX_PATH];
	printf("AddURL::\n");
	if (lfn==NULL)
	{
		strncpy(lfn0,newdl->rfn,_MAX_PATH-1);
		lfn0[_MAX_PATH-1]='\0';
	}
	else
		strcpy(lfn0,lfn);
	if (ldir==NULL)
		GetExtDir(ldir0,lfn0);
	else
		strcpy(ldir0,ldir);
	if ((type==1) && strrchr(lfn0,'/'))
	{
		memmove(lfn0,strrchr(lfn0,'/')+1,strlen(strrchr(lfn0,'/')));
		if (!strlen(lfn0))
			strcpy(lfn0,"unknown");
	}
	maindl *mdl;
	if (type==1)
	{
		mdl=CheckDup(newdl);
		if (mdl)
		{
			AddMirror(mdl,newdl);
			delete newdl;
			return NULL;
		}
	}

	if (type==2)
	{
		char str[1024];
		sprintf(str,GetSTR(26,"Browsing %s%s"),newdl->host,newdl->rdir);
		strcpy(lfn0,str);
	}
	int prot=newdl->prot;
	mdl=new maindl(newdl,ldir0,lfn0,type);
	mdl->maxresumetimeout=to;
	if (proxy==9)
		mdl->useproxy=GetProxy(prot,type);
	else mdl->useproxy=proxy;
	mdl->dosplit=dosp;
	mdl->ftpmode=mode;
	mdl->prior=prior;
	if (usehammer) mdl->usehammer=true;
	if (useretry) mdl->useretry=true;
	mdl->usemaxbusytime=cfg.usemaxbusytime;
	mdl->usemaxbusyretry=cfg.usemaxbusyretry;
	mdl->usemaxhammertime=cfg.usemaxhammertime;
	mdl->usemaxhammerretry=cfg.usemaxhammerretry;
	mdl->checkint=checkint;
	mdl->smallint=smallint;

	if ((type==1) || (type==10))
		mdl->CheckExist();

	//tell gui a new mdl!!!
//	if (type!=6)
//		AddMirror(mdl,newdl);

	if (!loadurl) SaveURLs();
	if (!loadurl && (cfg.startdl && (activemain<cfg.maxactive) &&
		(mdl->type!=4) && (mdl->type!=5) && (mdl->type!=7) && (mdl->type!=8) && (mdl->type!=6) || mdl->type==2))
	{
		if (mdl->ActMain(true)==false)
		{
			mdl->KillMain();
			return NULL;
		}
	}
	else
		if ((mdl->type==1) && cfg.startdl)
		{
			mdl->wait=true;
			TELLGUI(UPDATE_MDL,mdl,0);
		}
	return mdl;
}

void maindl::CheckExist()
{
	char ffn[1024],match[_MAX_PATH];
	unsigned long tb;
	if (istmpdir)
		strcpy(ffn,cfg.tmpdir);
	else strcpy(ffn,ldir);
	strcat(ffn,lfn);
	if (strlen(cfg.stamp))
		strcat(ffn,cfg.stamp);
	FILE *fp=NULL;
	locallost=0;
	if (FFirstFile(ffn,match))
    {
		fp=fopen(ffn,"rb");
		if(fp) 
		{
			localbytes[0]=GetFSize(fp);
			fclose(fp);
			fp=NULL;
		}
		else localbytes[0]=0;
		if (istmpdir)
			strcpy(ffn,cfg.tmpdir);
		else strcpy(ffn,ldir);
		strcat(ffn,lfn);
		strcat(ffn," (0)*");
		int l;
		bool zer=false;
		if (FFirstFile(ffn,match))
		{
			l=0;
			zer=true;
			locallost+=localbytes[0];
		}
		else
		{
			l=1;
			if (istmpdir)
				strcpy(ffn,cfg.tmpdir);
			else strcpy(ffn,ldir);
			strcat(ffn,lfn);
			strcat(ffn," (1)*");
		}
		if ((FFirstFile(ffn,match)))
		{
			bool regdone,regv;
			unsigned long regsps,regspe;
			char *tmp,*tmp2;
			do
			{
				regdone=spdone[l];
				regsps=sps[l];
				regspe=spe[l];
				regv=true;
				spdone[l]=true;
				do
				{
					while (strstr(match,".Incomplete"))
						if (!FNextFile(match))
							break;
					if (strstr(match,".Incomplete"))
						break;
					if (istmpdir)
						strcpy(ffn,cfg.tmpdir);
					else strcpy(ffn,ldir);
					strcat(ffn,match);
					fp=fopen(ffn,"rb");
					if (fp) 
					{
						tb=GetFSize(fp);
						fclose(fp);
						fp=NULL;
					}
					else tb=0;
					tmp=strrchr(match,')');
					tmp2=strrchr(match,'-');
					tmp=tmp+2;
					tmp2++;
					if (!zer && (!spe[0] || 
						((unsigned)(atoi(tmp)-1)<spe[0])))
					{
						sps[0]=0;
						spe[0]=atoi(tmp)-1;
						if (localbytes[0]>=(spe[0]+1))
							spdone[0]=true;
						else spdone[0]=false;
					}
					if (regsps==(unsigned)atoi(tmp))
						regv=false;
					if (spdone[l])
					{
						localbytes[l]=tb;
						sps[l]=atoi(tmp);
						spe[l]=atoi(tmp2);
						if (localbytes[l]>=(spe[l]-sps[l]+1))
						{
							spdone[l]=true;
							locallost+=tb;
						}
						else spdone[l]=false;
					}
					else locallost+=tb;
				} while (FNextFile(match));
				if (spdone[l] && !localbytes[l])
					spdone[l]=false;
				if (spdone[l] && regv && !regdone && regsps)
				{
					spdone[l]=false;
					sps[l]=regsps;
					spe[l]=regspe;
				}
				do
				{
					if (!spdone[l] && !sps[l] && l)
						spdone[l]=true;
					l++;
					if (l>=cfg.maxsplit) break;
					if (istmpdir)
						strcpy(match,cfg.tmpdir);
					else strcpy(match,ldir);
					sprintf(ffn,"%s%s (%ld)*",match,lfn,l);
				} while (!FFirstFile(ffn,match));
			} while (l<cfg.maxsplit);
			splitdex=l-1;
			//spliton=l;
			if (!zer && spdone[0]) locallost+=localbytes[0];
		}
	}
	else
	{
		strcpy(ffn,ldir);
		strcat(ffn,lfn);
		FILE *fp=NULL;
		if (FFirstFile(ffn,match))
		{
			fp=fopen(ffn,"rb");
			if(fp) 
			{
				localbytes[0]=GetFSize(fp);
				fclose(fp);
				fp=NULL;
			}
			else localbytes[0]=0;
			if (istmpdir)
				strcpy(match,cfg.tmpdir);
			else strcpy(match,ldir);
			strcat(match,lfn);
			if (strlen(cfg.stamp))
				strcat(match,cfg.stamp);
			if (strcmp(ffn,match))
				MoveFile(ffn,match);
		}
	}
	int l;
	lbytes=locallost;
	for (l=0;l<=splitdex;l++)
		if (!spdone[l])
			lbytes+=localbytes[l];
}

bool basicdl::DoThing(SOCKET &hsock)
{
	if (type==6)
	{
		if (mdl==((dlchk*)this)->mmir->rmdl)
		{
			if (((dlchk*)this)->mmir->time2dl || ((dlchk*)this)->mmir->rsize)
			{
				short p;
				if (!((dlchk*)this)->mmdl->rsize)
					((dlchk*)this)->mmir->status=ReDupString(((dlchk*)this)->mmir->status,
						GetSTR(81,"Size of original file is still unknown. This mirror might be good."));
				else
					if (((dlchk*)this)->mmir->rsize!=((dlchk*)this)->mmdl->rsize)
						((dlchk*)this)->mmir->status=ReDupString(((dlchk*)this)->mmir->status,
							GetSTR(82,"Size mismatch, can't use this one."));
					else
					{
						if (mir->relocation)
						{
							mirrors *mm=AddMirror(((dlchk*)this)->mmdl,mir->nfo);
							mm->resume=((dlchk*)this)->mmir->resume;
							mm->rsize=((dlchk*)this)->mmir->rsize;
							mm->time2dl=((dlchk*)this)->mmir->time2dl;
							mm->info=((dlchk*)this)->mmir->info;
							mm->ping=((dlchk*)this)->mmir->ping;
							mm->pinglost=((dlchk*)this)->mmir->pinglost;
							mm->only1ip=((dlchk*)this)->mmir->only1ip;
							mm->en=((dlchk*)this)->mmir->en;
							mm->errtime=((dlchk*)this)->mmir->errtime;
							mm->pingcount=((dlchk*)this)->mmir->pingcount;
							mm->pingsum=((dlchk*)this)->mmir->pingsum;
							mm->pingtry=((dlchk*)this)->mmir->pingtry;
							((dlchk*)this)->mmir->ischeck=false;
							maindl *rbak=((dlchk*)this)->mmir->rmdl;
							((dlchk*)this)->mmir->status=ReDupString(((dlchk*)this)->mmir->status,
							GetSTR(83,"This URL is a link to a mirror below."));
							((dlchk*)this)->mmir->rmdl=NULL;
							((dlchk*)this)->mmir=mm;
							((dlchk*)this)->mmir->rmdl=rbak;
							((dlchk*)this)->mmir->relocation=true;
						}
						((dlchk*)this)->mmir->status=ReDupString(((dlchk*)this)->mmir->status,
								GetSTR(84,"This one is fine. It may be used."));
					}
				dds();
				p=ShouldUse(((dlchk*)this)->mmir);
				if (p!=-1)
				{
					basicdl *bdl=((dlchk*)this)->mmdl->splitdl[p];
					if (!bdl) return true;
					bdl->CloseSockets();
					bdl->MoveMirr(((dlchk*)this)->mmir);
					if (hsock!=INVALID_SOCKET)
					{
						bdl->SendSock(hsock);
						if ISFTP(bdl)
							((dlchk*)this)->mmdl->MainFunc(1,bdl);
						else
						{
							bdl->status=1;
							bdl->ActOnStatus();
						}
					}
					else
					{
						bdl->status=0;
						bdl->ActOnStatus();
					}
					//((dlchk*)this)->mmdl->RideOnSplit(p,hsock,((dlchk*)this)->mmir);
					hsock=INVALID_SOCKET;
				}
			}
			else
				if (mir->en)
					((dlchk*)this)->mmir->en=mir->en;
				else
				{
					((dlchk*)this)->mmir->status=ReDupString(((dlchk*)this)->mmir->status,
							GetSTR(79,"Not verified yet."));
					dds();
				}
			type=-1;
			if (((dlchk*)this)->mmdl->mirrorhead==((dlchk*)this)->mmir)
			{
				TELLGUI(UPDATE_MDL,((dlchk*)this)->mmdl,0);
				((dlchk*)this)->mmdl->UpdateMirStatus();
			}
			((dlchk*)this)->mmir->info=true;
			((dlchk*)this)->mmir->rmdl=NULL;
			((dlchk*)this)->mmir->ischeck=false;
			((dlchk*)this)->mmdl->mirchecks--;
			CheckNextMirror(((dlchk*)this)->mmdl);
		}
		else
		{
			type=-1;
			((dlchk*)this)->mmir->isping=false;
			((dlchk*)this)->mmir->pmdl=NULL;
			printf("finished ping calling isstartcheck\n");
			((dlchk*)this)->mmdl->IsStartCheck();
		}
		return true;
	}
	if (type==4)
	{
		type=-1;
		((mirrsearch*)this)->mmdl->searchsite++;
		if (((mirrsearch*)this)->mmdl->smdl!=NULL)
		{
			((mirrsearch*)this)->mmdl->smdl=NULL;
			((mirrsearch*)this)->mmdl->Search4Mir();
		}
		return true;
	}
	if (type==5)
	{
		type=-1;
		if (((dlproxy*)this)->writebuff)
		{
			free(((dlproxy*)this)->writebuff);
			((dlproxy*)this)->writebuff=NULL;
		}
		if (((dlproxy*)this)->senddata && (mdl->proxsock!=INVALID_SOCKET))
			CloseSock(mdl->proxsock,false);
		return true;
	}

	if (type==8)
	{
		if (mdl->spliton==1)
			if (((gsul*)this)->table!=NULL)
				((gsul*)this)->table->mdl=NULL;
		type=-1;
	}
	if ((type==7)&&((gsdl*)this)->table)
		type=-1;

	return true;
}

bool basicdl::RideOn()
{
	mdl->spdone[splitdex]=true;
	CheckLog();
	if (type==1)
	  log_end();
	maindl *tmp;
	short p;
	int j,jj,logstatus=3;
	if ISHTTP(this) logstatus=1;
	if ((type==8) || (type==7)&&((gsdl*)this)->table)
	{
		DoThing(ctrlsock);
		CloseSockets();
		KillDL();
		return true;
	}
	SOCKET hsock=ctrlsock;
	//hsock=INVALID_SOCKET;
	RMSelectSock(hsock);
	ctrlsock=INVALID_SOCKET;
	CloseSockets();
	if (fp)
	{
		fflush(fp);
		fclose(fp);
		fp=NULL;
	}
	if (type==1)
	{
		mdl->locallost+=mdl->spe[splitdex]-mdl->sps[splitdex]+1;
		SaveURLs();
	}
	else DoThing(hsock);
	p=-1;
	if (mdl->splitdex)
	{
		for (j=0;j<=mdl->splitdex;j++)
			if (!mdl->spdone[j]) break;
		if (j>mdl->splitdex)
		{
			if ((type==1) || (type==7) || (type==9) || (type==10))
				mdl->BuildSplit();
		}
		else
		{
			for (jj=0;jj<=mdl->splitdex;jj++)
				if (!mdl->spdone[jj] && !mdl->splitdl[jj])
					break;
			if (jj>mdl->splitdex)
			{
				char tbf;
				if (ISFTP(this) || 
					keepalive && (recv(hsock,&tbf,1,0)<=0))
					for (jj=0;jj<=mdl->splitdex;jj++)
						if (!mdl->spdone[jj] && mdl->splitdl[jj] && 
							(mdl->splitdl[jj]->status<logstatus))
							break;
				if ((jj>mdl->splitdex) && cfg.keepsplit &&
					mdl->DoKeepSplit(this,hsock,false))
					return true;
			}
			if (jj<=mdl->splitdex)
			{
				bool doks=false; //dokeepsplit
				if (mdl->splitdl[jj]) doks=true;
				mirrors *mirbak=mir;
				tmp=mdl;
				short sp=splitdex;
				activesocks--;
				mir->ser->actcon--;
				mir->used--;
				tmp->RideOnSplit(jj,hsock,mirbak);
				activesocks++;
				mirbak->ser->actcon++;
				mirbak->used++;
				KillDL();
				if (doks && cfg.keepsplit)
				{
					tmp->Cr8DL(tmp->GetBestMirror(),sp,-1,false);
					if (tmp->splitdl[sp]==NULL)
						return false;
					SOCKET hsock=INVALID_SOCKET;
					if (tmp->DoKeepSplit(tmp->splitdl[sp],hsock,false))
						return true;
					else
					{
						tmp->splitdl[sp]->KillDL();
						return false;
					}
				}
				return true;
			}
		}
	}
	else
		if ((type==1) || (type==5) || (type==7) || (type==9) || (type==10))
		{
			char str[_MAX_PATH],ffn[_MAX_PATH];
			if (mdl->istmpdir)
				strcpy(ffn,cfg.tmpdir);
			else strcpy(ffn,mdl->ldir);
			strcat(ffn,mdl->lfn);
			if (strlen(cfg.stamp))
				strcat(ffn,cfg.stamp);
			sprintf(str,"%s%s",mdl->ldir,mdl->lfn);
			if (strcmp(str,ffn))
			{
				if (!_access(str,0))
					_unlink(str);
				MoveFile(ffn,str);
			}
		}
	char tbf; // temp recv buffer
	if ((hsock==INVALID_SOCKET) || (status<logstatus) ||
		ISHTTP(this) &&	(!keepalive || (recv(hsock,&tbf,1,0)>0)) )
		CloseSock(hsock,false);

	if (type==7)
		CloseSock(hsock,false);

	server *serbak;
	mirrors *mi;
	mi=mir->ser->mirhead;
	while (mi)
		if ((mi->mdl!=mdl) && (mi->mdl->type==1))
			break;
		else mi=mi->sernext;
	if (mi!=NULL)
		serbak=mir->ser;
	else serbak=NULL;
	if (mdl->spliton==1)
		tmp=NULL;
	else tmp=mdl;
	bool ftp=ISFTP(this);
	short tp=mdl->type;
	if (type!=2) KillDL();
	if (hsock==INVALID_SOCKET)
		return false;
	if (!tmp && serbak && ((tp==1)|| (tp==2)))
		if (WakeMDL(serbak,hsock))
			return true;
	if (!serbak || !serbak->actcon || 
		!WhoNeedsSock(hsock,serbak,ftp,tmp))
	{
	  //RMSelectSock(hsock);
	  closesocket(hsock);
	  //sock--;
	  hsock=INVALID_SOCKET;
	  //CloseSock(hsock,false);
	}
	return true;
}

void maindl::RideOnSplit(int sp,SOCKET &hsock,mirrors* mir)
{
	if (!splitdl[sp])
	{
		if (avsock!=INVALID_SOCKET)
		{
			RMSelectSock(avsock);
			closesocket(avsock);
			//sock--;
		}
		avsock=hsock;
		avmir=mir;
		Cr8DL(mir,sp,-1,true);
		if (avmir!=NULL)
		{
			avmir=NULL;
			RMSelectSock(avsock);
			closesocket(avsock);
			//sock--;
			avsock=INVALID_SOCKET;
		}
	}
	else
	{
		splitdl[sp]->CloseSockets();
		splitdl[sp]->MoveMirr(mir);
		splitdl[sp]->SendSock(hsock);
		if (type==1) splitdl[sp]->log_start();
		if ISFTP(splitdl[sp])
			MainFunc(1,splitdl[sp]);
		else
		{
			splitdl[sp]->status=1;
			splitdl[sp]->ActOnStatus();
		}
	}
	hsock=INVALID_SOCKET;
}

void maindl::BuildSplit()
{
  printf("Building file...\n");
	FILE *f1,*f2;
	done=true;
	char match[_MAX_PATH],str[1024],ffn[_MAX_PATH],*tmp;
	char buf[65536],qmarks[]="?????";
	unsigned int min=(unsigned)-1,c=(unsigned)-1,bbytes=0;
	int i;
	sprintf(str,GetSTR(74,"Building file: %.1fk/%.1fk (%.1f%%)"),
			bbytes/1024.0,rsize/1024.0,
			(int) (bbytes*1000.0/rsize)/10.0);
	dds();
	strncpy(mstxt,str,80);
	for (i=strlen(qmarks)-1;i>=0;i--)
	{
		if (istmpdir)
			sprintf(str,"%s%s (%s)*",cfg.tmpdir,lfn,&qmarks[i]);
		else sprintf(str,"%s%s (%s)*",ldir,lfn,&qmarks[i]);
		if (FFirstFile(str,match))
			do
			{
				if (!strstr(match,".Incomplete"))
				{
					tmp=strrchr(match,')');
					tmp+=2;
					c=(unsigned) atoi(tmp);
					if (c && (c<min)) min=c;
				}
			} while (FNextFile(match));
	}
	if (c==-1)
	{
		MsgBox(GetSTR(60,"Can't find any splits, file can't be built!"),0,MB_OK);
		dds();
		return;
	}
	sprintf(ffn,"%s%s",ldir,lfn);
	if (istmpdir)
	{
		sprintf(str,"%s%s",cfg.tmpdir,lfn);
		if (strlen(cfg.stamp)) strcat(str,cfg.stamp);
		MoveFile(str,ffn);
	}
	else
		if (strlen(cfg.stamp))
		{
			strcpy(str,ffn);
			strcat(str,cfg.stamp);
			MoveFile(str,ffn);
		}
	f1=fopen(ffn,"r+bc");
	if (!f1)
	{
		sprintf(str,GetSTR(61,"Can't find %s, this file was supposed to be finished."),ffn);
		dds();
		MsgBox(str,0,MB_OK);
		return;
	}
	unsigned long sz=GetFSize(f1);
	if (sz<min)
	{
		strcpy(str,GetSTR(64,"Missing bytes %d-%d in this file."));
		dds();
		sprintf(ffn,str,sz,min-1);
		fclose(f1);
		MsgBox(ffn,0,MB_OK);
		return;
	}
	fseek(f1,min,SEEK_SET);
	for (;;)
	{
		sprintf(str,GetSTR(74,"Building file: %.1fk/%.1fk (%.1f%%)"),
			bbytes/1024.0,rsize/1024.0,
			(int) (bbytes*1000.0/rsize)/10.0);
		dds();
		strncpy(mstxt,str,80);
		for (i=strlen(qmarks)-1;i>=0;i--)
		{
			if (istmpdir)
				sprintf(str,"%s%s (%s) %d-*",cfg.tmpdir,lfn,
											&qmarks[i],min);
			else sprintf(str,"%s%s (%s) %d-*",ldir,lfn,&qmarks[i],
												min);
			if (FFirstFile(str,match))
			{
				while (strstr(match,".Incomplete"))
					if (!FNextFile(match))
						goto nfile;
				break;
			}
nfile:;
		}
		if (i==-1)
			break;
		//sprintf(str,"%s (?) %d*",ffn,min);
	//while (FindFirstFile(str,&ff)!=INVALID_HANDLE_VALUE)
//#ifdef _WIN32
		if (istmpdir)
			sprintf(ffn,"%s%s",cfg.tmpdir,match);
		else sprintf(ffn,"%s%s",ldir,match);
//#endif
//#ifdef __unix__
//		strcpy(ffn,match);
//#endif
		f2=fopen(ffn,"rb");
		if (!f2)
		{
			sprintf(str,GetSTR(61,"Can't find %s, this file was supposed to be finished."),ffn);
			dds();
			fclose(f1);
			MsgBox(str,0,MB_OK);
			return;
		}
		do
		{
			c=fread(buf,1,sizeof(buf),f2);
			fwrite(buf,1,c,f1);
		} while (!feof(f2) && !ferror(f2));
		tmp=strrchr(match,'-')+1;
		bbytes+=(atoi(tmp)-min+1);
		min=atoi(tmp)+1;
		fclose(f2);
		_unlink(ffn);
		//sprintf(str,"%s%s (?) %ld*",nfo->ldir,nfo->lfn,atoi(tmp)+1);
		//fseek(f1,min,SEEK_SET);
		fflush(f1);
	}
	//sz=GetFSize(f1);
	fclose(f1);
	if (type==1) log_wr(GetSTR(85,"File built."),false);
	dds();
	//if (RunExternal) DoRunExternal(m);
}

void maindl::DoSplit(int sp)
{
	char str[1024];
	FILE *fp0;
	if ((type!=1)&&(type!=5)) return;
	int dv,j;
	if ((sp<2) || (splitdex>0) || !rsize) return;
	dv=(rsize-localbytes[0])/sp;
	for (j=0;j<sp;j++)
	{
		sps[j]=localbytes[0]+1+j*dv;
		spe[j]=localbytes[0]+(j+1)*dv;
		if (j) localbytes[j]=0;
	}
	sps[0]=0;
	spe[sp-1]=rsize-1;
	splitdex=sp-1;
	SaveURLs();
	sessionbytes[0]=0;
	//if (splitdl[0])
	//	memset(splitdl[0]->cpsinfo,0,sizeof(splitdl[0]->cpsinfo));
	starttime=0;
	sbytes=0;
	for (j=1;j<sp;j++)
	{
		Cr8DL(GetBestMirror(),j,-1,true);
		char ldir0[_MAX_PATH];
		if (istmpdir)
			strcpy(ldir0,cfg.tmpdir);
		else strcpy(ldir0,ldir);
		if (sps[j])
			sprintf(str,"%s%s (%ld) %ld-%ld",ldir0,lfn,j,
			sps[j],spe[j]);
		else
			sprintf(str,"%s%s",ldir0,lfn);
		if (strlen(cfg.stamp))
			strcat(str,cfg.stamp);
			fp0=fopen(str,"w+bc");
			if (fp0)
			{
				fflush(fp0);
				fclose(fp0);
			}
	}
	if (splitdl[0] && ISHTTP(splitdl[0]))
		splitdl[0]->TimedOut();
}

bool maindl::DoKeepSplit(basicdl *bdl,SOCKET &hsock,bool force)
{
	unsigned long k=0,r=0;int i;
	char str[_MAX_PATH],str2[_MAX_PATH];
	time_t tp;
	basicdl*big=NULL;
	for (i=0;i<=splitdex;i++)
	{
		if (    splitdl[i] && !spdone[i] &&
			  (splitdl[i]!=bdl) &&
			( (spe[i]-sps[i]) > localbytes[i] ) &&
			( spe[i]-sps[i]-localbytes[i]>k)        )
		{
			k=spe[i]-sps[i]-localbytes[i]+1;
			big=splitdl[i];
		}
		if (!spdone[i] && ((spe[i]-sps[i]+1) < localbytes[i] ))
		{
			char err_str[300];
			sprintf(err_str,"Debug:: spe:%d sps:%d localbytes:%d diff:%d sp:%d",spe[i],sps[i],localbytes[i],spe[i]-sps[i],i);
			if (type==1) log_wr(err_str,true);
		}
	}
	if (!big) return false;
	time(&tp);
	tp-=big->starttime;
	if (tp==0) tp=1;
	if (sessionbytes[big->splitdex]/tp)
		r=k/(sessionbytes[big->splitdex]/tp);
	if (!force && r && (r<10) || (k<9000)) 
		return false;
	r=k>>1;
	//locallost+=spe[f->splitdex]-sps[f->splitdex]+1;
	sessionlost+=sessionbytes[bdl->splitdex];
	spe[bdl->splitdex]=spe[big->splitdex];
	sps[bdl->splitdex]=spe[big->splitdex]-r+1;
	spdone[bdl->splitdex]=false;
	localbytes[bdl->splitdex]=0;
	bdl->Clear();
	if ((hsock!=INVALID_SOCKET) || (avmir!=NULL))
	{
		if (avmir!=NULL)
		{
			hsock=avsock;
			bdl->MoveMirr(avmir);
			avmir=NULL;
			avsock=INVALID_SOCKET;
		}
		if (hsock!=INVALID_SOCKET)
		{
			//SOCKET tmpsock=hsock;
			bdl->SendSock(hsock);
		}
		//AddSelectSock(hsock,actpos);
		//bdl->CloseSockets();
		//bdl->ctrlsock=hsock;
	}
	time(&bdl->starttime);
	if (bdl->fp)
	{
		fflush(bdl->fp);
		fclose(bdl->fp);
		bdl->fp=NULL;
	}
	char tbf;
	if ((bdl->ctrlsock!=INVALID_SOCKET) && (ISFTP(bdl) ||
		ISHTTP(bdl) && bdl->keepalive && (recv(bdl->ctrlsock,&tbf,1,0)<=0)))
	{
		if ISFTP(bdl)
			MainFunc(1,bdl);
		else
		{
			bdl->status=1;
			bdl->ActOnStatus();
		}
	}
	else
	{
		if (hsock!=INVALID_SOCKET)
			bdl->CloseSock(hsock,false);
		bdl->status=0;
		if (!bdl->ActOnStatus()) return false;
	}
	bdl->GetFN(str);
	bdl->fp=fopen(str,"w+bc");
	if (bdl->fp)
	{
		fflush(bdl->fp);
		fclose(bdl->fp);
	}
	bdl->fp=NULL;
	SaveURLs();
	if (bdl->type==1) bdl->log_start();

	big->GetFN(str);
	spe[big->splitdex]-=r;
	if (big->fp)
	{
		fflush(big->fp);
		fclose(big->fp);
		big->fp=NULL;
	}
	/*	big->fp=fopen(str,"a+bc");	
	if (big->fp)
	{
			if ((unsigned)(_filelength(_fileno(big->fp))) > (unsigned)(spe[big->splitdex]-sps[big->splitdex]+1))
		{
			int jh;
			jh=1;
		}
		fclose(big->fp);
		big->fp=NULL;
		}*/

	big->GetFN(str2);
	rename(str,str2);
	if (big->err[7]) big->err[7]--;
	if (big->err[9]) big->err[9]--;
	if ((type==7) && big->status)
	{
		sprintf(str,"Update: %ld\r\n",spe[big->splitdex]);
		send(big->ctrlsock,str,strlen(str),0);
	}
	else
	{
		if ISHTTP(big) big->TimedOut();
#ifdef OPEN1
		else
			big->fp=fopen(str2,"a+bc");
#endif
	}
	return true;
}

int maindl::ChangeSplit(int newsp)
{
	if (!resume) return 0;
	printf("spliting to %d\n",newsp);
	int i;
	if ((type!=1) && (type!=5) && (type!=7)) return 0;
	if ((newsp==spliton) || !newsp) return true;
/*	if (!splitdex)
	{
		DoSplit(newsp);
		return true;
	}*/
	if (newsp<spliton)
	{
		while (newsp<spliton)
		{
			basicdl *bdl;
			bdl=FindLSS(NULL);
			strncpy(bstxt[bdl->txtpos],GetSTR(65,"Paused"),80);
			dds();
			bdl->KillDL();
		}
		SaveURLs();
		return true;
	}
	else
	{
		for (i=0;i<=splitdex;i++)
			if (!splitdl[i] && !spdone[i])
			{
				if (!Cr8DL(GetBestMirror(),i,-1,true))
					return false;
				if (newsp<=spliton)
				{
					SaveURLs();
					return true;
				}
			}
		for (i=0;i<=splitdex;i++)
			if (!splitdl[i] && spdone[i])
			{
				//spdone[i]=false;
				SOCKET hsock=INVALID_SOCKET;
				if (!Cr8DL(GetBestMirror(),i,-1,false) ||
						!DoKeepSplit(splitdl[i],hsock,true))
				{
					if (splitdl[i]) splitdl[i]->KillDL();
					SaveURLs();
					return false;
				}
				if (newsp<=spliton)
				{
					SaveURLs();
					return true;
				}
			}
		while (newsp>spliton)
		{
			i=splitdex+1;
			SOCKET hsock=INVALID_SOCKET;
			if (!Cr8DL(GetBestMirror(),i,-1,false) || 
				!DoKeepSplit(splitdl[i],hsock,true))
			{
				splitdex--;
				if (splitdl[i]) splitdl[i]->KillDL();
				SaveURLs();
				return false;
			}
		}
	}
	SaveURLs();
	return true;
}

basicdl* maindl::FindLSS(mirrors *mir)
{
	int used=0,vic=-1,i;
	unsigned long topsp=0;
	for (i=0;i<=splitdex;i++)
		if (splitdl[i] && (splitdl[i]->mir!=mir) && 
			((type!=5) || !(((dlproxy*)splitdl[i])->senddata)) && (
			(splitdl[i]->mir->ser->actcon>used) ||
			(splitdl[i]->mir->ser->actcon==used) &&
			(splitdl[i]->cps<topsp)) )
		{
			vic=i;
			used=splitdl[i]->mir->ser->actcon;
			topsp=splitdl[i]->cps;
		}
		if (vic!=-1)
			return splitdl[vic];
		else return NULL;
}

basicdl* FindLSS(short mprior)
{
	/* scans all bdls find lss. */
	int i,j,l;
	struct sersp_tag{
		unsigned short sp;
	};
	sersp_tag sersp[1024];
	short last=-1;
	memset(sersp,0,sizeof(sersp));
	for (l=0;l<lastmact;l++)
		if (actmdls[l].mdl->type==1)
		{
			sersp[l].sp=actmdls[l].mdl->spliton;
			last=l;
		}
	if (last==-1) return NULL;
	short maxi=0,vic=-1,prior=0;
       	unsigned long speed=(unsigned)-1;
	for (i=1;i<6;i++)
	{
		for (j=0;j<=last;j++)
			if ((sersp[j].sp) && (actmdls[j].mdl->prior==i))
				if ((sersp[j].sp>maxi) || (sersp[j].sp==maxi) &&
					(speed>actmdls[j].mdl->cps) && (actmdls[j].mdl->prior<=prior))
				{
					maxi=sersp[j].sp;
					vic=j;
					prior=actmdls[j].mdl->prior;
					speed=actmdls[j].mdl->cps;
				}
		if (maxi>1) break;
	}
	if ((maxi==1) && (prior>=mprior))
		return NULL;
	short vicsp=-1;
	speed=(unsigned)-1;
	for (i=0;i<=actmdls[vic].mdl->splitdex;i++)
		if (actmdls[vic].mdl->splitdl[i])
			if (actmdls[vic].mdl->splitdl[i]->cps<speed)
			{
				speed=actmdls[vic].mdl->splitdl[i]->cps;
				vicsp=i;
			}

	return actmdls[vic].mdl->splitdl[vicsp];
}

bool WhoNeedsSock(SOCKET &hsock,server *ser,bool ftp,maindl *mdl)
{
	basicdl *bdl=ser->bdlhead;
	short prior=0,topsp=0,stlog=3;
	if (!ftp) stlog=1;
	maindl *rmdl=NULL;
	basicdl *rbdl=NULL;
	bool fnlog=false,fnblog=false; //found not log
	while (bdl)
	{
		while ((bdl!=NULL) && 
			( (bdl->mdl==mdl) || ftp && (!ISFTP(bdl)) ||
				!ftp && (!ISHTTP(bdl)) || NoMore(bdl->mdl) || 
				(bdl->mir->used>=ser->maxeach)||(bdl->type!=1) ))
			bdl=bdl->sernext;
		if (bdl==NULL) break;
		if (!bdl->mdl->logged || !fnlog &&
			(bdl->status<stlog)|| !fnblog && 
			(!bdl->mdl->dosplit || (bdl->mdl->dosplit>bdl->mdl->spliton)) &&
			(bdl->mdl->spliton<cfg.maxsplit) &&
			((bdl->mdl->prior>prior) ||
			(bdl->mdl->prior==prior) && (bdl->mdl->spliton<topsp)) )
		{
			if (!bdl->mdl->logged)
			{
				if ((prior<bdl->mdl->prior) || !fnlog)
				{
					prior=bdl->mdl->prior;
					fnlog=true;
					rmdl=bdl->mdl;
					rbdl=bdl;
				}
			}
			else
				if (bdl->status<stlog)
				{
					if ((prior<bdl->mdl->prior) || !fnblog)
					{
						prior=bdl->mdl->prior;
						fnblog=true;
						rmdl=bdl->mdl;
						rbdl=bdl;
					}
				}
				else
				{
					prior=bdl->mdl->prior;
					topsp=bdl->mdl->spliton;
					rmdl=bdl->mdl;
				}
		}
		bdl=bdl->sernext;
	}
	if (rbdl!=NULL)
	{
		rbdl->CloseSockets();
		rbdl->SendSock(hsock);
		if ISFTP(rbdl)
			rbdl->mdl->MainFunc(1,rbdl);
		else
		{
			rbdl->status=1;
			rbdl->ActOnStatus();
		}
		hsock=INVALID_SOCKET;
		return true;
	}

	if ((rmdl!=NULL) && (rmdl->spliton<cfg.maxsplit))
	{
		mirrors *tmp=rmdl->mirrorhead;
		while (tmp)
			if (tmp->ser==ser) break;
			else tmp=tmp->next;
		if (tmp==NULL)
		{
			//CloseSock(hsock,false);
			return false;
		}
		avmir=tmp;
		if (avsock!=INVALID_SOCKET)
		{
			RMSelectSock(avsock);
			closesocket(avsock);
			//sock--;
		}
		avsock=hsock;
		rmdl->ChangeSplit(rmdl->spliton+1);
		avmir=NULL;
		if (avsock!=INVALID_SOCKET)
		{
		  RMSelectSock(avsock);
			closesocket(avsock);
			//sock--;
			avsock=INVALID_SOCKET;
		}
		return true;
	}
	return false;
}

void basicdl::CloseSockets()
{
	if (fp)
	{
		fflush(fp);
		fclose(fp);
		readcount=0;
		fp=NULL;
	}
	readbuffi=0;
	quedex=0;
	//memset(que,0,sizeof(que));
	if (datasock!=INVALID_SOCKET)
		CloseSock(datasock,false);
	if (ctrlsock!=INVALID_SOCKET)
		CloseSock(ctrlsock,false);
	if (pingsock!=INVALID_SOCKET)
	{
	  RMSelectSock(pingsock);
		closesocket(pingsock);
		//sock--;
		pingsock=INVALID_SOCKET;
	}
	if (gethosthnd)
#ifdef _WIN32
		WSACancelAsyncRequest(gethosthnd);
#endif// _WIN32
#ifdef __unix__
	{
	  printf("killing child (pid %d) in closesockets...\n",gethosthnd);
	  kill(gethosthnd,9);
	}
#endif

	CheckLog();
}

int basicdl::ReadData(SOCKET readsock)
{
	time(&timeout);
	isdl=true;
	mdl->isdl=true;
	mdl->timeout=timeout;
	if (type==6)
	{
		time_t tp;
		time(&tp);
		((dlchk*)this)->mmir->time2dl=tp-time2dl;
		((dlchk*)this)->mmir->info=true;
		RideOn();
		return -2;
	}
	if (!mir->info)
	{
		time_t tp;
		time(&tp);
		mir->resume=resume;
		mir->rsize=mdl->rsize;
		mir->time2dl=tp-time2dl;
		mir->info=true;
		mir->status=ReDupString(mir->status,
			GetSTR(86,"This is the main mirror. It works fine."));
		dds();
		mdl->UpdateMirStatus();
	}
	if ((type==1) && cfg.mirr.autosearch &&
					!mdl->mirsearch)
	{
		mdl->mirsearch=true;
		mdl->Search4Mir();
	}
	int ret=0,r;

//	** calc cps 
#ifndef gsdbg
	unsigned long tc=GetTickCount();
	calcid++;
	globalcpsinfo=0;
	gdlcpsinfo=0;
	gbrcpsinfo=0;
	for (r=0;r<=lastact;r++)
		if (actdls[r] && (actdls[r]->hamdex==-1))
			actdls[r]->CalcCps(tc);
	globalcps=globalcpsinfo;
	gdlcps=gdlcpsinfo;
	gbrcps=gbrcpsinfo;
#endif


//	** speed limit
	if (readsock!=INVALID_SOCKET)
	if (speedlimit && (cps>speedlimit) ||
		mdl->speedlimit && (mdl->cps>mdl->speedlimit) ||
		cfg.speedlimit && (globalcps>cfg.speedlimit) ||
		cfg.dlspeedlimit && (gdlcps>cfg.dlspeedlimit) && 
		(!cfg.slonlyifbr || activebr))

	{
		read=true;
		pause=true;
		return 0;
	}
	r=0;
	char str[1024];
	err[9]=0;
	//char *buf;
	/*
	tc=BUFSIZE;
	if (speedlimit && (speedlimit/2<tc)) tc=speedlimit/4;
	if (mdl->speedlimit && (mdl->speedlimit/2<tc)) tc=mdl->speedlimit/4;
	if (cfg.speedlimit && (cfg.speedlimit/2<tc)) tc=cfg.speedlimit/4;
	if (!tc) tc=1;
	*/
	read=false;
	pause=false;
	GetFN(str);
	char buf[50010];
	unsigned long cr,getbytes;
	if (readsock!=INVALID_SOCKET)
	{
#ifdef _WIN32
		ioctlsocket(readsock,FIONREAD,&cr);
		cr=1460;
#endif // win
#ifdef __unix__
		cr=1460;
#endif
		if (cr<=0) return cr;
		cr+=100;
		if (cr>50000) cr=50000;
		getbytes=cr;///2+1;
		if (maxrb<getbytes)
		{
	//		grbuf=(char *)realloc(grbuf,getbytes);
			maxrb=getbytes;
		}
	}
	else getbytes=cfg.rbufsize/2;
	//buf=grbuf;

	if ((readsock==INVALID_SOCKET) && ISHTTP(this) && (readbuffi))
		{
			ret=readbuffi;
			memcpy(buf,readbuff,readbuffi);
			readbuffi=0;
		}
		else
			ret=recv(readsock,buf,getbytes,0);
		pause=false;
		if ((ret<=0))
		{
			if (fp) fclose(fp);
			fp=NULL;
			//free(buf);
			return ret;
		}
	fp=fopen(str,"ab");
	if (!fp)
	{
		doerr(11);
		return 0;
	}
		if (checkint)
			cr=fbufsize-intsocksize;
		else cr=0;
		if (mdl->spe[splitdex] && 
			((mdl->localbytes[splitdex]+mdl->sps[splitdex]+ret-cr)>(mdl->spe[splitdex]+1)))
			ret=mdl->spe[splitdex]-mdl->sps[splitdex]+1-mdl->localbytes[splitdex]+cr;
		
		if (checkint)
		{
/*			char dbuf[10000];
			fseek(gfp,mdl->sps[splitdex]+mdl->localbytes[splitdex]-fbufsize+intsocksize,SEEK_SET);
			fread(dbuf,1,ret,gfp);
			if (memcmp(dbuf,buf,ret))
			{
				int hg;
				hg=1;
				//MsgBox("ERROR - NOT compare - small",0,MB_OK);
			}*/
			if (DoCheckInt(buf,ret))
			{
				if (fp) fclose(fp);
				fp=NULL;
				//free(buf);
				return ret;
			}
			if (!ret)
			{
				if (fp) fclose(fp);
				fp=NULL;
				return 0;
			}
		}
		if (!mdl->sessionbytes[splitdex])
		{
			time(&starttime);
			if (!mdl->starttime) mdl->starttime=starttime;
		}
		GetFN(str);
#ifdef OPEN1
		if (!fp)
		{
			//free(buf);
			return 0;
		}
#endif
		readcount+=ret;
		if (ret>0)
		{
/*			char dbuf[10000];
			fseek(gfp,mdl->sps[splitdex]+mdl->localbytes[splitdex],SEEK_SET);
			fread(dbuf,1,ret,gfp);
			if (memcmp(dbuf,buf,ret))
			{
				int hg;
				hg=1;
				//MsgBox("ERROR - NOT compare - small",0,MB_OK);
			}*/

		r=fwrite(buf,1,ret, fp);
		if (r<ret)
		{
			doerr(13);
			//free(buf);
			return -2;
		}
		  fclose(fp);
		  fp=NULL;
		}
		mdl->localbytes[splitdex]+=ret;
		mdl->lbytes+=ret;
		mdl->sessionbytes[splitdex]+=ret;
		mdl->sbytes+=ret;
		if (mdl->localbytes[splitdex] && mdl->spe[splitdex] && 
			((mdl->localbytes[splitdex]+mdl->sps[splitdex])>=(mdl->spe[splitdex]+1)))
		{
#ifdef OPEN1
			fflush(fp);
			if (fp) fclose(fp);
			fp=NULL;
#endif
			GetFN(str);
			/*		fp=fopen(str,"rb");
			if (mdl->localbytes[splitdex]!=GetFSize(fp))
			{
			int dg;
			dg=1;
			}
			fclose(fp);
			fp=NULL;*/
			mdl->spdone[splitdex]=true;
			//mdl->lbytes+=mdl->spe[splitdex]-mdl->sps[splitdex]+1-mdl->localbytes[splitdex];
			//mdl->localbytes[splitdex]=mdl->spe[splitdex]-mdl->sps[splitdex]+1;
			//if (ISFTP(this) && mdl->spe && ((mdl->spe[splitdex]+1)<mdl->rsize))
			//AbortFTP();
			if (fp) fclose(fp);
			fp=NULL;
			//free(buf);
			RideOn();
			return -2;
		}
	if (fp) fclose(fp);
	fp=NULL;
	//free(buf);
	if (mdl->reschk==1)
	{
		mdl->reschk=2;
		if (!TimedOut()) return -1;
	}
	return ret;
}

void basicdl::MoveMirr(mirrors *newm)
{
	unsigned long lb=mdl->localbytes[splitdex];
	int sbak=status;
	status=0;
	CheckLog();
//	mir->ser->actcon--;
//	mir->used--;
	status=sbak;
	RMfSer();
	mir=newm;
//	mir->ser->actcon++;
//	mir->used++;
	CheckLog();
	Add2Ser();
	Clear();
	mdl->localbytes[splitdex]=lb;
	useproxy=mdl->GetMirProxy(mir,type);
}

short maindl::GetMirProxy(mirrors *mir,short type)
{
	char str[1024];
	switch (useproxy)
	{
		case 0:
			return useproxy;
			break;
		case 3:
			if (!strlen(cfg.Proxy.sockshost))
			{
				strcpy(str,GetSTR(21,"This download is configured to use socks, but the socks host\
isn't configured!\n Check your Firewall / Proxy settings in the configuration"));
				dds();
				if (type==1) log_wr(str,true);
				MsgBox(str,0,MB_OK);
				return -1;
			}
			return useproxy;
			break;
		case 9:
			return GetProxy(mir->nfo->prot,type);
			break;
		case 1:
			if (!strlen(cfg.Proxy.FHost))
			{
				strcpy(str,GetSTR(19,"This download is configured to use FTP Proxy, but the FTP proxy\
isn't configured!\n Check your Firewall / Proxy settings in the configuration"));
				dds();
				if (type==1) log_wr(str,true);
				MsgBox(str,0,MB_OK);
				return -1;
			}
			if (mir->nfo->prot==1)
			{
				return useproxy;
				break;
			}
			return GetProxy(mir->nfo->prot,type);
			break;
		case 2:
			if (!strlen(cfg.Proxy.HHost))
			{
				strcpy(str,GetSTR(20,"This download is configured to use HTTP Proxy, but the HTTP proxy\
isn't configured!\n Check your Firewall / Proxy settings in the configuration"));
				dds();
				if (type==1) log_wr(str,true);
				MsgBox(str,0,MB_OK);
				return -1;
			}
			if ((mir->nfo->prot==2) || cfg.Proxy.HTTP4FTP)
			{
				return useproxy;
				break;
			}
			return GetProxy(mir->nfo->prot,type);
			break;
	}
	return -1;
	dds();
}

bool maindl::Chk4Del()
{
	int i;
	for (i=0;i<=splitdex;i++)
		if (!spdone[i]) break;
	if (!spliton && ((type==5) || (type==2))|| (i>splitdex))
	{
		done=true;
		for (i=0;i<=splitdex;i++)
		{
			char ffn[1024],match[1024];
			if (istmpdir)
				strcpy(match,cfg.tmpdir);
			else strcpy(match,ldir);
			sprintf(ffn,"%s%s (%ld)*",match,lfn,i);
			if ((FFirstFile(ffn,match)))
				do
				{
					if (strstr(match,".Incomplete"))
					{
						if (istmpdir)
							strcpy(ffn,cfg.tmpdir);
						else strcpy(ffn,ldir);
						strcat(ffn,match);
						_unlink(ffn);
					}
				} while (FNextFile(match));
		}
		STELLGUI(MDL_STOP,this,0);
		if (type==1) log_end();
		printf("Allo, DL complete :: %s\n",lfn);
		if (cfg.runexternal && (type==1)) DoRunExternal(this);
		if (type==9)
			upddlchk::ProcessChk(lfn);
		if (type==10)
		{
			char str[1024],*tmp;
			strcpy(str,mirrorhead->nfo->rdir);
			tmp=strrchr(str,'/');
			if (tmp)
			{
				*tmp='\0';
				tmp=strrchr(str,'/');
				if (tmp)
				{
					tmp+=6;
					upddl::ChkIfDone(atoi(tmp),((strnicmp(lfn,"gscmp",5)==0) & (strstr(lfn,".gsi")!=NULL)));
				}
			}
		}
		delmdl();
		
		return true;
	}
	return false;
}

void DoRunExternal(maindl *mdl)
{
#ifdef _WIN32
	char str[1000],*tmp;
	strcpy(str,_strlwr(cfg.externalparams));
	tmp=strstr(str,"%gs");
	strcpy(str,cfg.externalparams);
	if (tmp)
	{
		tmp[0]=0;
		tmp+=3;
		char str2[1000];
		strcpy(str2,tmp);
		strcat(str,mdl->ldir);
		strcat(str,mdl->lfn);
		strcat(str,str2);
	}
	SHELLEXECUTEINFO se;
	memset(&se,0,sizeof(se));
	se.cbSize=sizeof(se);
	se.fMask=SEE_MASK_NOCLOSEPROCESS;
	se.hwnd=HWND_DESKTOP;
	se.lpVerb=0;
	se.lpParameters=str;
	se.lpFile=cfg.externalfile;
	se.nShow=cfg.externalshow;
	ShellExecuteEx(&se);
#endif//_WIN32
}

void basicdl::AbortFTP()
{
	char str[8];
	strcpy(str,"ABOR\r\n");
	wb(str,1);
	send(ctrlsock,str,strlen(str),MSG_OOB);
	send(ctrlsock,str,strlen(str),0);
	if ((datasock!=INVALID_SOCKET))
	{
		send(datasock,str,strlen(str),MSG_OOB);
		send(datasock,str,strlen(str),0);
		send(datasock,str,strlen(str),MSG_OOB);
		send(datasock,str,strlen(str),0);
		CloseSock(datasock,false);
	}
	abort=true;
}

bool basicdl::TimedOut()
{
	if ((type==5) && (((dlproxy*)this)->post))
		return true;
	if ((type==8) ||(type==7)&&((gsdl*)this)->table)
	{
		KillDL();
		return false;
	}
	abort=true;
	time(&timeout);
	if (!mdl->isdl)
		mdl->timeout=timeout;
	if (fp)
	{
		fflush(fp);
		fclose(fp);
		readcount=0;
		fp=NULL;
	}
	readbuffi=0;
	int stbak=status;
	status=0;
	wstatus(GetSTR(62,"Timed out, Aborting..."));
	dds();
	status=stbak;
	if ((status<3) || ISHTTP(this))
	{
		status=0;
		err[7]=0;
		return ActOnStatus();
	}
	else
	{
		if (datasock!=INVALID_SOCKET) status=6;
		if (++err[7]>=2)
		{
			status=0;
			return ActOnStatus();
		}
		else
		{
			CheckLog();
			AbortFTP();
			return true;
		}
	}
}

void basicdl::CalcCps(unsigned long tick)
{
	int i;
	if (cpsinfo[0].tick==tick)
		cpsinfo[0].bytes=mdl->sessionbytes[splitdex];
	else
	{
		for (i=499;i>0;i--)
			cpsinfo[i]=cpsinfo[i-1];
		cpsinfo[0].tick=tick;
		cpsinfo[0].bytes=mdl->sessionbytes[splitdex];
	}
	for (i=499;i>=0;i--)
		if (cpsinfo[i].tick && ((tick-cpsinfo[i].tick)<=3000) &&
			(cpsinfo[i].bytes<=mdl->sessionbytes[splitdex])) break;
	if (i<=0) cps=0;
	else
		if (!(cpsinfo[0].tick-cpsinfo[i].tick)) cps=0;
		else
			cps=(unsigned long)((cpsinfo[0].bytes-cpsinfo[i].bytes)/((cpsinfo[0].tick-cpsinfo[i].tick)/1000.0));
	if (calcid!=mdl->cpsinfo.tick)
	{
		mdl->cpsinfo.tick=calcid;
		mdl->cpsinfo.sp=1;
		mdl->cpsinfo.cps=cps;
	}
	else
	{
		mdl->cpsinfo.sp++;
		mdl->cpsinfo.cps+=cps;
	}
	if (mdl->cpsinfo.sp>=mdl->spliton)
		mdl->cps=mdl->cpsinfo.cps;
	globalcpsinfo+=cps;
	if (type==5)
		gbrcpsinfo+=cps;
	else gdlcpsinfo+=cps;
}

void basicdl::DelBuffer()
{
	while (buffhead!=NULL)
	{
		buffer *tmp;
		tmp=buffhead;
		buffhead=buffhead->next;
		delete tmp;
	}
}

void maindl::DelBuffer()
{
	while (buffhead!=NULL)
	{
		buffer *tmp;
		tmp=buffhead;
		buffhead=buffhead->next;
		delete tmp;
	}
}

void basicdl::InitIntCheck(unsigned int result)
{
	if (!result || (mdl->reschk==2))
	{
		if (mdl->reschk==2)
			mdl->reschk=3;
		checkint=false;
		fbufsize=0;
	}
	else
		if (checkint)
		{
			intsocksize=0;
			if (result>cfg.intsize)
				fbufsize=cfg.intsize;
			else fbufsize=result;
/*			if (!intfilebuff)
			{
				if (fbufsize<intsmallsize)
				{
					intfilebuff=(char*)malloc(intsmallsize);
					intsockbuff=(char*)malloc(intsmallsize);
				}
				else
				{
					intfilebuff=(char*)malloc(fbufsize);
					intsockbuff=(char*)malloc(fbufsize);
				}
			}
			else
				if (fbufsize<intsmallsize)
				{
					intfilebuff=(char*)realloc(intfilebuff,intsmallsize);
					intsockbuff=(char*)realloc(intsockbuff,intsmallsize);
				}
				else
				{
					intfilebuff=(char*)realloc(intfilebuff,fbufsize);
					intsockbuff=(char*)realloc(intsockbuff,fbufsize);
				}
			if (result>=fbufsize)
				fseek(fp,result-fbufsize,SEEK_SET);
			fread(intfilebuff,1,fbufsize,fp);*/
		}
		else
			if (cfg.checksmallint)
			{
/*				if (!intfilebuff)
				{
					intfilebuff=(char*)malloc(intsmallsize);
					intsockbuff=(char*)malloc(intsmallsize);
				}*/
				checkint=true;
				intsocksize=0;
				if (result>intsmallsize)
					fbufsize=intsmallsize;
				else fbufsize=result;
/*				if (result>=fbufsize)
					fseek(fp,result-fbufsize,SEEK_SET);
				fread(intfilebuff,1,fbufsize,fp);*/
			}
			else
			{
				checkint=false;
				fbufsize=0;
			}
}

bool basicdl::DoCheckInt(char *buf,int &ret)
{
	char str[1024],*intfilebuff,*intsockbuff;
	intfilebuff=(char*)malloc(ret);
	intsockbuff=(char*)malloc(ret);
	unsigned long chk,pl=intsocksize;
	if (!intsocksize)
	{
		wb(GetSTR(73,"Comparing end of local file to the file on the server..."),0);
		dds();
	}
	if (fp)
	{
		fflush(fp);
		fclose(fp);
		fp=NULL;
	}
	GetFN(str);
	fp=fopen(str,"r+bc");
	if (!fp)
	{
		doerr(11);
		return 1;
	}
	if (mdl->localbytes[splitdex]>fbufsize)
		fseek(fp,mdl->localbytes[splitdex]+intsocksize-fbufsize,SEEK_SET);
	else
		if (intsocksize) fseek(fp,intsocksize,SEEK_SET);
	if (intsocksize+ret<=fbufsize)
	{
		fread(intfilebuff,1,ret,fp);
		intsocksize+=ret;
		chk=ret;
		ret=0;
		memcpy(intsockbuff,buf,chk);
	}
	else 
	{
		fread(intfilebuff,1,fbufsize-intsocksize,fp);
		chk=fbufsize-intsocksize;
		memcpy(intsockbuff,buf,chk);
		ret-=fbufsize-intsocksize;
		memmove(buf,&buf[fbufsize-intsocksize],ret);
		intsocksize=fbufsize;
	}
	
	// checking
	unsigned long i=chk;
	for (i=0;i<chk;i++)
		if (intsockbuff[i]!=intfilebuff[i])
			break;
	if ((i+pl)<50)
	{
		free(intfilebuff);
		free(intsockbuff);
		if (intsocksize==intsmallsize)
			strcpy(str,GetSTR(69,"Local file seems corrupted. GetSmart will try to recover."));
		else
			strcpy(str,GetSTR(70,"Local file seems corrupted. GetSmart will restart it."));
		dds();
		wb(str,3);
		if (type==1) log_wr(str,true);
		if (fp)
		{
			//fflush(fp);
			fclose(fp);
			fp=NULL;
		}
		if (intsocksize==intsmallsize)
		{
			checkint=true;
			if (ISFTP(this))
			{
				status=3;
				abort=true;
				readbuffi=0;
				AbortFTP();
			}
			else 
			{
				readbuffi=0;
				TimedOut();
			}
			return true;
		}
		BadFN();
		if (ISFTP(this))
		{
			status=3;
			abort=true;
			readbuffi=0;
			AbortFTP();
		}
		else 
		{
			readbuffi=0;
			TimedOut();
		}
		return true;
		//return -1;
	}
	if (i+pl==fbufsize)
	{
		checkint=false;
		wb(GetSTR(71,"Files are identical."),0);
		dds();
	}
	if (i==chk)
	{
		free(intfilebuff);
		free(intsockbuff);
		if (fp)
		{
			fflush(fp);
			fclose(fp);
			fp=NULL;
		}
		GetFN(str);
		fp=fopen(str,"ab");
		if (!fp)
		{
			doerr(11);
			return 1;
		}
		return 0;
	}
	checkint=false;
	sprintf(str,GetSTR(72,"The last %ld bytes are not identical. GetSmart will recover them."),
		fbufsize-i-pl);
	dds();
	wb(str,3);
	if (type==1) log_wr(str,true);
	dds();
	GetFN(str);
	if (fp)
	{
		fflush(fp);
		fclose(fp);
		fp=NULL;
	}
	fp=fopen(str,"r+bc");
	if (!fp)
	{
		doerr(11);
		free(intfilebuff);
		free(intsockbuff);
		return 1;
	}
	if (mdl->localbytes[splitdex]>fbufsize)
	{
		fseek(fp,mdl->localbytes[splitdex]+intsocksize-fbufsize-chk,SEEK_SET);
		mdl->localbytes[splitdex]+=intsocksize-fbufsize-chk;
		mdl->lbytes+=intsocksize-fbufsize-chk;
	}
	else
		if (intsocksize)
		{
			fseek(fp,intsocksize-chk,SEEK_SET);
			mdl->lbytes-=(mdl->localbytes[splitdex]-intsocksize+chk);
			mdl->localbytes[splitdex]=intsocksize-chk;
		}
	mdl->localbytes[splitdex]+=chk;
	fwrite(intsockbuff,1,chk,fp);
	trunc(fp,mdl->localbytes[splitdex]);
	fflush(fp);
	fclose(fp);
	free(intfilebuff);
	free(intsockbuff);
	GetFN(str);
	fp=fopen(str,"ab");
	if (!fp)
	{
		doerr(11);
		return 1;
	}
	return false;
}

void basicdl::CheckLog()
{
  unsigned char chkst;
  if ISFTP(this)
	    chkst=3;
  else
    chkst=2;
  if ((status>=chkst) && !mdl->spdone[splitdex])
    {
      mir->en=0;
      mir->ser->en=0;
      if (!logged)
	{
	  logged=true;
	  mir->ser->logged++;
	  // tell GUI to update mirror table;
	}
    }
  else
    if(logged)
      {
	logged=false;
	mir->ser->logged--;
	// tell GUI to update mirror table;
      }
  int i;
  for (i=0;i<=mdl->splitdex;i++)
    if (mdl->splitdl[i] && !mdl->spdone[i] && 
	mdl->splitdl[i]->status>=chkst)
      {
	mdl->splitdl[i]->logged=true;
	mdl->logged=true;
	break;
      }
  if (i>mdl->splitdex)
    mdl->logged=false;
  if (isdl)
    {
      isdl=false;
      mdl->isdl=false;
      if (mdl->isdl)
	for (i=0;i<=mdl->splitdex;i++)
	  if (mdl->splitdl[i] && !mdl->spdone[i] && 
	      mdl->splitdl[i]->isdl)
	    {
	      mdl->isdl=true;
	      break;
	    }
    }
}

bool basicdl::Ping()
{
#ifdef __unix__
  //pingsock=10;
  //ActOnRead(pingsock);
return false;
#endif
	if (pingsock!=INVALID_SOCKET)
	  {
	    RMSelectSock(pingsock);
	    closesocket(pingsock);
		//sock--;
	  }
	if (!ctrladdr.sin_family) return false;
	//pingsock = socket(AF_INET, SOCK_RAW, IPPROTO_ICMP);
	GETSOCK(pingsock,AF_INET,SOCK_STREAM,0);
//	int i=WSAGetLastError();
	AddSelectSock(pingsock,actpos);
	SendEchoRequest(pingsock,&ctrladdr);
	return true;
}

bool mirrors::NextPing(basicdl *bdl)
{
	if (bdl->pingsock!=INVALID_SOCKET)
	{
	  RMSelectSock(bdl->pingsock);
		closesocket(bdl->pingsock);
		//sock--;
		bdl->pingsock=INVALID_SOCKET;
	}
	((dlchk*)bdl)->mmir->pingtry++;
	if (((dlchk*)bdl)->mmir->pingtry>=PINGNUM)
	{
		if (((dlchk*)bdl)->mmir->pingcount)
			((dlchk*)bdl)->mmir->ping=((dlchk*)bdl)->mmir->pingsum/((dlchk*)bdl)->mmir->pingcount;
		else ((dlchk*)bdl)->mmir->ping=0;
		((dlchk*)bdl)->mmir->pinglost=100-((dlchk*)bdl)->mmir->pingcount*100/PINGNUM;
		bdl->KillDL();
		return false;
	}
	else
		return bdl->Ping();
}

void maindl::StartMirrorCheck()
{
	mirrors *mir=mirrorhead;
	while (mir)
	{
		mir->Ping();
		mir=mir->next;
	}
}

void mirrors::Ping()
{
	if (pmdl) return;
	isping=true;
	pingsum=0;
	pingcount=0;
	pingtry=0;
	dlnfo* dl=new dlnfo(nfo);
	pmdl=AddURL(dl,NULL,"Pinging mirror",6,9,0,cfg.resumeto,DEFPR,0,
				false,false,0,0);
	pmdl->Cr8DL(pmdl->mirrorhead,(long)mdl,(long)this,true);
	strncpy(mdl->mirstatus,GetSTR(77,"Pinging mirrors."),80);
	dds();
}

void maindl::IsStartCheck()
{
	mirrors *mir=mirrorhead;
	while (mir)
	{
		if (mir->isping) break;
		mir=mir->next;
	}
	if (mir==NULL)
		CheckNextMirror(this);
}

short ShouldUse(mirrors *mir)
{
	int i;
	mirrors *mir2;
	if ((mir->rsize!=mir->mdl->rsize) || (!mir->resume)) return -1;
	for (i=mir->mdl->splitdex;i>=0;i--)
		if (mir->mdl->splitdl[i])
		{
			mir2=mir->mdl->splitdl[i]->mir;
			if ( !mir->used && (mir2->used>1) ||
				(((signed)(mir2->used-mir->used))>1))
				return i;
		}
	for (i=mir->mdl->splitdex;i>=0;i--)
		if (mir->mdl->splitdl[i])
		{
			mir2=mir->mdl->splitdl[i]->mir;
			if ((((signed)(mir2->used-mir->used))>=0) && 
				((mir->time2dl<mir2->time2dl) || !mir2->time2dl))
				return i;
		}
	return -1;
}

void CheckNextMirror(maindl *mdl)
{
	if (mdl->mirchecks>=cfg.mirr.maxmirchecks) return;
	mirrors *mir=mdl->mirrorhead;
	mirrors *docheck=NULL;
	short good=0;
	while (mir)
	{
		if (mir->info && mir->rsize==mir->mdl->rsize && mir->time2dl)
			good++;
		if (mir->ischeck && !mir->rmdl && !mir->relocation)
		{
			docheck=mir;
			break;
		}
		mir=mir->next;
	}
	if (docheck!=NULL)
	{
		docheck->Check();
		CheckNextMirror(mdl);
		return;
	}
	if (!mdl->spliton || (good>=(mdl->splitdex+3)))
	{
		strncpy(mdl->mirstatus,GetSTR(75,"Nothing to do."),80);
		dds();
		return;
	}
	mir=mdl->mirrorhead;
	mirrors *bmir=NULL;
	unsigned long best=(unsigned)-1;
	while (mir)
	{
		if (!mir->info && !mir->rmdl && (mir!=mdl->mirrorhead) && 
			!mir->relocation)
		{
			if ((bmir==NULL) || (mir->ping*(mir->pinglost*2+100)/100<best))
			{
				bmir=mir;
				best=mir->ping*(mir->pinglost*2+100)/100;
			}
		}
		mir=mir->next;
	}
	if (bmir!=NULL)
	{
		bmir->Check();
		CheckNextMirror(mdl);
	}
	else
		if (!mdl->mirchecks)
		{
			strncpy(mdl->mirstatus,GetSTR(75,"Nothing to do."),80);
			dds();
		}
}

void mirrors::Check()
{
	ischeck=true;
	mdl->mirchecks++;
	rmdl=AddURL(new dlnfo(nfo),NULL,":Checking mirror:",6,9,0,
				cfg.resumeto,DEFPR,0,false,false,0,0);
	rmdl->Cr8DL(rmdl->mirrorhead,long(mdl),(long)this,true);
	strncpy(mdl->mirstatus,GetSTR(78,"Validating mirrors."),80);
	dds();
}

void maindl::Search4Mir()
{
	if (smdl) return;
	char str[1024];
	dlnfo *dln;
	mirsite *mirs=cfg.mirr.mirshead;
	for (int i=0;i<searchsite;i++)
	  if (mirs) mirs=mirs->next; // ALLO  CHECK @@@
	if (mirs==NULL)
	{
		searchsite=0;
		StartMirrorCheck();
		smdl=NULL;
		return;
	}
	dln=ConvertURL(mirs->url);
	if (rsize)
		sprintf(str,"%s?query=%s&doit=Search&type=Case+insensitive+substring+search&hits=%ld&sort=size&limsize1=%d&limsize2=%d",
				dln->rfn,mirrorhead->nfo->rfn,cfg.mirr.maxmirget,rsize,rsize);
	else
		sprintf(str,"%s?query=%s&doit=Search&type=Case+insensitive+substring+search&hits=%ld&sort=size",
				dln->rfn,mirrorhead->nfo->rfn,cfg.mirr.maxmirget);
	dln->rfn=ReDupString(dln->rfn,str);
	sprintf(str,":Searching mirrors for %s:",mirrorhead->nfo->rfn);
	smdl=AddURL(dln,NULL,str,4,9,0,cfg.resumeto,DEFPR,0,false,false,0,
				0);
	smdl->Cr8DL(smdl->mirrorhead,(int)this,-1,true);
	strncpy(mirstatus,GetSTR(76,"Searching for mirrors."),80);
	dds();
}

void maindl::StopAllMir()
{
	mirrors *mir=mirrorhead;
	while (mir)
	{
		mir->info=true;
		mir=mir->next;
	}
	mir=mirrorhead;
	while (mir)
	{
		if (mir->rmdl)
			mir->rmdl->KillMain();
		if (mir->pmdl)
			mir->pmdl->KillMain();
		mir=mir->next;
	}
	if (smdl)
	{
		maindl *tmp=smdl;
		smdl=NULL;
		tmp->KillMain();
	}
	strncpy(mirstatus,GetSTR(75,"Nothing to do."),80);
	dds();
}

void maindl::UpdateMirStatus()
{
	mirrors *mir=mirrorhead;
	while (mir)
	{
		if (mir->time2dl || mir->rsize)
		{
			if (!rsize)
				mir->status=ReDupString(mir->status,
					GetSTR(81,"Size of original file is still unknown. This mirror might be good."));
			else
				if (mir->rsize!=rsize)
					mir->status=ReDupString(mir->status,
						GetSTR(82,"Size mismatch, can't use this one."));
				else mir->status=ReDupString(mir->status,
						GetSTR(84,"This one is fine. It may be used."));
		}

		mir=mir->next;
	}
}
