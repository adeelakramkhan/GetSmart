
#include "Daemon.h"
#include "html2links.h"

void CDirList(char *line,char *fn,char *date,unsigned long &size,bool &dir,char *attr);

bool browsedl::ActOnFTPStatus()
{
	char str[1024];
	if (status && abort) return true;
	time(&timeout);
	if (!mdl->isdl)
		mdl->timeout=timeout;
	switch (status)
	{
	default:
		return GenActOnFTPStatus();
		break;
	case 0:
		TELLGUI(GBR_START,mdl,0);
		abort=false;
		if (!busy && (++err[9]>=11))
		{
			err[9]=0;
			mdl->ErrMsg=ReDupString(mdl->ErrMsg,GetSTR(18,"GetSmart tried to initiate a download\
10 times\nand was not successful.\nIf you are in\auto download mode, it will try again later."));
			dds();
			doerr(9);
			return false;
		}
		return GenActOnFTPStatus();
		break;
	case 4:
		strcpy(str,"TYPE A\r\n");
		wb(str,1);
		WriteFTP(str);
		break;
	case 5:
		if (btype==1)
		{
			if (!strlen(cwd)) strcpy(str,"PWD\r\n");
			else
				sprintf(str,"CWD %s\r\n",cwd);
			wb(str,1);
			WriteFTP(str);
		}
		else return GenActOnFTPStatus();
		break;
	case 7:
		status=8;
	case 8:
		TELLGUI(GBR_CLEAN,mdl,0);
		if (!mdl->info)
		{
			if (resume) 
				mdl->resume=resume;
			mdl->info=true;
			SaveURLs();
		}
		if (btype==1)
		{
			strcpy(str,"LIST\r\n");
			wb(str,1);
			WriteFTP(str);
			wstatus(GetSTR(87,"Receiving directory listing..."));
			dds();
		}
		else
		{
			sprintf(str,"RETR %s%s\r\n",mir->nfo->rdir,mir->nfo->rfn);
			wb(str,1);
			WriteFTP(str);
			strcpy(str,GetSTR(28,"Downloading file..."));
			dds();
			wstatus(str);
		}
		break;
	}
	return true;
}

int browsedl::ReadHTMLData(SOCKET readsock)
{
	clientlist cl;
	time(&timeout);
	isdl=true;
	mdl->isdl=true;
	mdl->timeout=timeout;
	int ret=0,getbytes,i;
	//r=0;
	char buf[AVGBUFSIZE*2],str[AVGBUFSIZE*2],str2[AVGBUFSIZE*2];
	err[9]=0;
	getbytes=AVGBUFSIZE;
	if ((readsock==INVALID_SOCKET) && ISHTTP(this) && (readbuffi))
	{
		memcpy(buf,readbuff,readbuffi);
		//readbuff=(char*)realloc(readbuff,AVGBUFSIZE*2);
		//memcpy(readbuff,buf,readbuffi);
		buf[readbuffi]='\0';
		ret=readbuffi;
		readbuffi=0;
	}
	else
	{
		//if (!readbuff)
			//readbuff=(char*)malloc(AVGBUFSIZE*2);
		ret=recv(readsock,buf+readbuffi,getbytes-readbuffi-1,0);
		if (ret>0)
			buf[readbuffi+ret]='\0';
	}
	pause=false;
	if (ret<=0)
		return ret;

	while (!(i=FindNextLink(buf,str,str2)))
	{
		memset(&cl,0,sizeof(cl));
		strncpy(cl.fn,str,1000);
		strncpy(cl.attr,str2,119);
		if (cl.fn[0]) STELLGUI(GBR_ADDITEM,mdl,&cl);
	}
	if (i==-1)
		readbuffi=strlen(buf);
	else readbuffi=0;

	return ret;
}
int browsedl::ReadFTPData(SOCKET readsock)
{
	char str[1000];
	clientlist cl;
	int ret=0;
	time(&timeout);
	isdl=true;
	mdl->isdl=true;
	mdl->timeout=timeout;
	err[9]=0;
	time(&timeout);
	pause=false;
	char res[AVGBUFSIZE*2];
	ret=ReadSocket(readsock,res,readbuff2,readbuffi2);
	if (ret<=0) return 0;
	GetLine(res,str);
	while (strlen(str))
	{
		CDirList(str,cl.fn,cl.date,cl.size,cl.dir,cl.attr);
		if (cl.fn[0]) STELLGUI(GBR_ADDITEM,mdl,&cl);
		GetLine(res,str);
	}
	sprintf(str,GetSTR(87,"Receiving directory listing..."));
	dds();
	wstatus(str);
	return 1;
}

void browsedl::ChDir()
{
	mdl->localbytes[0]=0;
	mdl->spe[0]=0;
	mdl->sps[0]=0;
	mdl->rsize=0;
	char str[1000];
	sprintf(str,GetSTR(88,"Changing directory to %s"),cwd);
	dds();
	wstatus(str);
	//if (!m->Cached())
	{
		Refresh();
	}
}

void browsedl::Refresh()
{
	mdl->localbytes[0]=0;
	mdl->spe[0]=0;
	mdl->sps[0]=0;
	mdl->rsize=0;
	char str[1000];
	if (ctrlsock==INVALID_SOCKET)
	{
		fireaddr.sin_addr.s_addr=0;
		QueryDNS();
	}
	else
	{
		sprintf(str,"CWD %s\r\n",cwd);
		wb(str,1);
		WriteFTP(str);
		//SendMessage(Hgui,WM_D_GETLIST,(WPARAM)mdl,0);
	}
}

void browsedl::Custom(char *str)
{
	mdl->localbytes[0]=0;
	mdl->spe[0]=0;
	mdl->sps[0]=0;
	mdl->rsize=0;
	if (ctrlsock!=INVALID_SOCKET)
	{
		wb(str,1);
		WriteFTP(str);
	}
}

int CMonth(char *t)
{
	if (!strnicmp(t,"Jan",3)) return 1;
	if (!strnicmp(t,"Feb",3)) return 2;
	if (!strnicmp(t,"Mar",3)) return 3;
	if (!strnicmp(t,"Apr",3)) return 4;
	if (!strnicmp(t,"May",3)) return 5;
	if (!strnicmp(t,"Jun",3)) return 6;
	if (!strnicmp(t,"Jul",3)) return 7;
	if (!strnicmp(t,"Aug",3)) return 8;
	if (!strnicmp(t,"Sep",3)) return 9;
	if (!strnicmp(t,"Oct",3)) return 10;
	if (!strnicmp(t,"Nov",3)) return 11;
	if (!strnicmp(t,"Dec",3)) return 12;
	return 0;
}

void GetYear(char *t)
{
#ifdef _WIN32
	char *t2;
	_strdate(t);
	t2=strrchr(t,'/');
	t2++;
	strcpy(t,t2);
#endif
#ifdef __unix__
	strcpy(t,"1999");
#endif
}

void CDirList(char *line,char *fn,char *date,unsigned long &size,bool &dir,char *attr)
{
	char d[1000];
	char *t;
	int i;
	bool link=false;
	dir=false;
	t=line;
	if (line[8]==' ')
	{
		attr[0]=0;		
		GetWord(line,4,fn,true);
		if (!fn[0] || !strcmp(fn,"."))
		{
			fn[0]=0;
			return;
		}
		GetWord(line,1,date,false);
		GetWord(line,2,d,false);
		strcat(date," ");
		strcat(date,d);
		GetWord(line,3,d,false);
		if (!strnicmp(d,"<DIR>",5))
		{
			dir=true;
			size=0;
			strcpy(attr,"d");
		}
		else
		{
			dir=false;
			size=atoi(d);
		}
		return;
	}
	GetWord(line,9,d,true);
	if (!d[0] || !strcmp(d,"."))
	{
		fn[0]=0;
		return;
	}
	if (*t=='d') 
		dir=true;
	if (*t=='l')
	{
		dir=true;
		link=true;
	}
	GetWord(line,5,d,false);
	size=atoi(d);
	GetWord(line,7,d,false);
	i=atoi(d);
	GetWord(line,6,d,false);
	sprintf(date,"%.2d-%.2d-",i,CMonth(d));
	GetWord(line,8,d,false);
	if (strchr(d,':'))
	{
		GetYear(d);
		strcat(date,d);
		strcat(date," ");
		GetWord(line,8,d,false);
		strcat(date,d);
	}
	else 
	{
		if (strlen(d)>2)
			strcat(date,&d[2]);
		else strcat(date,d);
		strcat(date," 00:00");
	}
	d[0]='a';
	GetWord(line,1,attr,false);
	GetWord(line,9,fn,true);
}
