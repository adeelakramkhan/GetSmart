
#include "Daemon.h"
#include <shlobj.h>

void upddlchk::Chk4Upd()
{
	char str[1024];
	sprintf(str,"%s/updcmp.chk",cfg.updsite);
	dlnfo *dln=ConvertURL(str);
	sprintf(str,"%s/",setupdir);
	AddURL(dln,str,0,9,9,0,cfg.resumeto,DEFPR,0,cfg.usehammer,cfg.useretry,
			cfg.checkint,cfg.checksmallint);
}

void upddlchk::GetUpdInfo(FILE *f,int &id,double &ver,char *name,char *uver,char *desc)
{
	char str[10001];
	id=-1;
	while (fgets(str,10000,f))
	{
		if (strlen(str)) str[strlen(str)-1]=0;
		if (!strlen(str))
			return;
		if (!strnicmp(str,"Id: ",4))
		{
			id=atoi(str+4);
			continue;
		}
		if (!strnicmp(str,"Ver: ",5))
		{
			ver=atof(str+5);
			continue;
		}
		if (!strnicmp(str,"Name: ",6))
		{
			strcpy(name,str+6);
			continue;
		}
		if (!strnicmp(str,"Uver: ",6))
		{
			strcpy(uver,str+6);
			continue;
		}
		if (!strnicmp(str,"Desc: ",6))
		{
			if (desc) strcpy(desc,str+6);
			continue;
		}
	}
	return;
}

void upddlchk::ProcessChk(char *lfn)
{
	char str[10001];
	sprintf(str,"%s/%s"/*updcmp.chk"*/,setupdir,lfn);
	FILE *f=fopen(str,"rt");
	if (!f) return;
	int id;
	double ver;
	char name[1024],uver[1024],desc[10001];

	for (;;)
	{
		upddlchk::GetUpdInfo(f,id,ver,name,uver,desc);
		if (id==-1) break;
		component *tmp=cmphead;
		while (tmp)
		{
			if (tmp->id==id)
			{
				if (tmp->ver<ver)
				{
					char msg[10001];
					sprintf(msg,"Component: %s version %s\n%s\n\nWould you like to download and install this component?",
							name,uver,desc);
					if (MsgBox(msg,"Update component",MB_YESNO)==IDYES)
						upddl::UpdCmp(id);
				}
				break;
			}
			tmp=tmp->next;
		}
		if (!tmp)
		{
			char msg[10001];
			sprintf(msg,"Component: %s version %s\n%s\n\nWould you like to download and install this component?",
					name,uver,desc);
			if (MsgBox(msg,"Update component",MB_YESNO)==IDYES)
				upddl::UpdCmp(id);
		}
	}
	fclose(f);
	sprintf(str,"%s/%s",setupdir,lfn);
	_unlink(str);
}

void upddl::UpdCmp(int id)
{
	char str[1024];
	sprintf(str,"%s/gscmp%d/gscmp%d.gsi",cfg.updsite,id,id);
	dlnfo *dln=ConvertURL(str);
	sprintf(str,"%s/UpdCmp%d/",setupdir,id);
	if (_access(str,0))
		CreateDirectory(str,NULL);
	AddURL(dln,str,0,10,9,0,cfg.resumeto,DEFPR,0,cfg.usehammer,cfg.useretry,
			cfg.checkint,cfg.checksmallint);
}

void upddl::ChkIfDone(int id,bool ini)
{
	char str[1024];
	char *tmp,*tmp2,*tmp3;
	bool keepdl=false;
	sprintf(str,"%s/UpdCmp%d/gscmp%d.gsi",setupdir,id,id);
	FILE *f=fopen(str,"rt");
	if (!f) return;
	
	while (fgets(str,1000,f))
	{
		char fl[1024];
		int size;
		if (strlen(str)) str[strlen(str)-1]=0;
		if (!strnicmp(str,"cp",2) || !strnicmp(str,"ex",2))
		{
			tmp=strchr(str,'\"');
			if (!tmp) continue;
			tmp++;
			tmp2=strchr(tmp,'\"');
			if (!tmp2) continue;
			tmp3=strrchr(str,'(');
			if (!tmp3) continue;
			size=atoi(tmp3+1);
			*tmp2='\0';
			strcpy(fl,tmp);
		}
		else
			continue;

		if (ini)
		{
			sprintf(str,"%s/gscmp%d/%s",cfg.updsite,id,fl);
			dlnfo *dln=ConvertURL(str);
			sprintf(str,"%s/UpdCmp%d/",setupdir,id);
			AddURL(dln,str,0,10,9,0,cfg.resumeto,DEFPR,0,cfg.usehammer,cfg.useretry,
					cfg.checkint,cfg.checksmallint);
		}
		else
		{
			sprintf(str,"%s/UpdCmp%d/%s",setupdir,id,fl);
			FILE *f2;
			int rsize;
			if (_access(str,0) || !(f2=fopen(str,"rb")))
			{
				keepdl=true;
				break;
			}
			rsize=GetFSize(f2);
			fclose(f2);
			if (rsize!=size)
			{
				keepdl=true;
				break;
			}
		}
	}
	fclose(f);
	if (!ini && !keepdl)
		upddl::DoUpdate(id);
}

void upddl::DoUpdate(int id)
{
	char str[1024],str2[1024];
	OFSTRUCT o,o2;
	int sc,dc;
	if (!id)
	{
		sprintf(str,"%s/UpdCmp%d/GetSmart.gsc",setupdir,id);
		sc=LZOpenFile(str,&o,OF_READ);
		sprintf(str2,"%s\\GetSmart.ex_",setupdir);
		dc=LZOpenFile(str2,&o2,OF_CREATE);
		LZCopy(sc,dc);
		LZClose(sc);
		LZClose(dc);
		unlink(str);
		sprintf(str,"%s/UpdCmp%d/gscmp0.gsi",setupdir,id);
		unlink(str);
		sprintf(str,"%s/UpdCmp%d",setupdir,id);
		RemoveDirectory(str);
	}
	sprintf(str,"%s/~gstmp%d",setupdir,id);
	FILE *fp=fopen(str,"wb");
	if (fp) fclose(fp);
	MsgBox("When you'll restart GetSmart the changes will occur.","Restart",MB_OK);
}

void upddl::FinishUpdate()
{
	char str[1024],str2[1024],match[1024];
	sprintf(str,"%s/~gstmp*.*",setupdir);
	sprintf(str2,"%s\\GetSmart.ex_",setupdir);
	if (FFirstFile(str,match))
		do
		{
			int id=atoi(match+6);
			if (!id)
			{
				char tfn[_MAX_PATH],*tfn0=_tempnam("\\","DELGS"),dn[_MAX_PATH];
				strcpy(tfn,tfn0);
				strcat(tfn,".BAT");
				if (!tfn)
					return;
				FILE *sf=fopen(tfn,"wt");
				if (!sf)
					return;
				GetModuleFileName(NULL,dn,1024);
				sprintf(str,":ag\ndel \"%s\"\nif exist \"%s\" goto ag\nmove \"%s\" \"%s\"\nstart \"%s\"\ndel \"%s\"\n",
					dn,dn,str2,dn,dn,tfn);
				fwrite(str,1,strlen(str),sf);
				fclose(sf);
				
				STARTUPINFO si;
				PROCESS_INFORMATION pi;
				
				memset(&si,0,sizeof(si));
				si.cb = sizeof(si);
				si.dwFlags = STARTF_USESHOWWINDOW;
				si.wShowWindow = SW_HIDE;
				
				if (CreateProcess(NULL, tfn, NULL, NULL, FALSE,
					CREATE_SUSPENDED | IDLE_PRIORITY_CLASS, NULL, "\\", &si, &pi))
				{
					SetThreadPriority(pi.hThread, THREAD_PRIORITY_IDLE);
					SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL);
					SetPriorityClass(GetCurrentProcess(), HIGH_PRIORITY_CLASS);
					CloseHandle(pi.hProcess);
					ResumeThread(pi.hThread);
					CloseHandle(pi.hThread);
				}
				sprintf(str,"%s/%s",setupdir,match);
				_unlink(str);
				ExitProcess(0);
			}

			sprintf(str,"%s/UpdCmp%d/gscmp%d.gsi",setupdir,id,id);
			FILE *f=fopen(str,"rt");
			if (!f) continue;
			
			while (fgets(str,1000,f))
			{
				char *tmp[10],str2[1024];
				if (strlen(str)) str[strlen(str)-1]=0;
				strcpy(str2,str);
				char *tmp0=str2;
				for (int i=0;i<10;i++)
				{
					char *tmp1,*tmp2;
					tmp1=strchr(tmp0,'\"');
					if (!tmp1)
					{
						tmp[i]=NULL;
						break;
					}
					tmp1++;
					tmp2=strchr(tmp1,'\"');
					if (!tmp2)
					{
						tmp[i]=NULL;
						break;
					}
					tmp0=tmp2+1;
					*tmp2='\0';
					tmp[i]=tmp1;
				}

				if (!strnicmp(str,"cp",2) || !strnicmp(str,"ex",2))
				{
					if (!tmp[0] || !tmp[1]) continue;
					char sf[1024],df[1024];
					sprintf(sf,"%s/Updcmp%d/%s",setupdir,id,tmp[0]);
					sprintf(df,"%s/%s",setupdir,tmp[1]);
					if (!strnicmp(str,"cp",2))
						CopyFile(sf,df,false);
					else
					{
						int sc,dc;
						OFSTRUCT o,o2;
						sc=LZOpenFile(sf,&o,OF_READ);
						dc=LZOpenFile(df,&o2,OF_CREATE);
						LZCopy(sc,dc);
						LZClose(sc);
						LZClose(dc);
					}
					_unlink(sf);
					continue;
				}
				if (!strnicmp(str,"md",2))
				{
					if (!tmp[0]) continue;
					char sf[1024];
					sprintf(sf,"%s/%s",setupdir,tmp[0]);
					CreateDirectory(sf,NULL);
					continue;
				}
				if (!strnicmp(str,"lng",3))
				{
					if (!tmp[0] || !tmp[1] || !tmp[2]) continue;
					char fl[1024],dn[MAX_PATH],lnk[MAX_PATH];
					sprintf(fl,"%s/%s",setupdir,tmp[2]);
					//sprintf(df,"%s/%s",setupdir,tmp[1]);
					LPITEMIDLIST sm;
					SHGetSpecialFolderLocation(NULL, CSIDL_PROGRAMS, &sm);
					SHGetPathFromIDList(sm,dn);
					sprintf(lnk,"%s\\%s\\%s",tmp[0],tmp[1]);

					IShellLink* pShellLink; 
					HRESULT hres = CoCreateInstance(CLSID_ShellLink, 
											NULL, 
											CLSCTX_INPROC_SERVER, 
											IID_IShellLink, 
											(LPVOID*)&pShellLink); 
					if (SUCCEEDED(hres)) 
					{ 
						IPersistFile* pPersistFile;
						pShellLink->SetPath(fl); 
						pShellLink->SetDescription("");
						if (tmp[3] && strlen(tmp[3]))
							pShellLink->SetArguments(tmp[3]);
						hres = pShellLink->QueryInterface(IID_IPersistFile, 
												(LPVOID*)&pPersistFile); 
						if (SUCCEEDED(hres)) 
						{ 
							WCHAR wsz[MAX_PATH]; 
							MultiByteToWideChar(CP_ACP,0,lnk,-1,wsz,MAX_PATH);
							hres = pPersistFile->Save(wsz, TRUE);
							//if(FAILED(hres))
								//MessageBox(hdwnd,"Couldn't add GetSmart to StartUp.",0,MB_OK);
							pPersistFile->Release(); 
						}
						pShellLink->Release(); 
						continue;
					}
				}
				if (!strnicmp(str,"reg",3))
				{
					if (!tmp[0] || !tmp[1] || !tmp[2]) continue;
					HKEY hkey=HKEY_CURRENT_USER,cfgkey;
					char subkey[1000]="Software\\GetSmart\\";
					strcat(subkey,tmp[0]);
					unsigned long result;
					if (RegCreateKeyEx(hkey,subkey,0, 0,REG_OPTION_NON_VOLATILE,
										KEY_ALL_ACCESS,NULL,&cfgkey,&result)==ERROR_SUCCESS)
					{
						short w;
						int i;
						double d;
						bool b;
						switch(*tmp[2])
						{
						case 'w':
							i=atoi(tmp[2]+1);
							w=(short)i;
							RegSetValueEx(cfgkey,tmp[1],0,REG_NONE,(const unsigned char *)&w,sizeof(w));
							break;
						case 'i':
							i=atoi(tmp[2]+1);
							RegSetValueEx(cfgkey,tmp[1],0,REG_DWORD,(const unsigned char *)&i,sizeof(i));
							break;
						case 'd':
							d=atof(tmp[2]+1);
							RegSetValueEx(cfgkey,tmp[1],0,REG_NONE,(const unsigned char *)&d,sizeof(d));
							break;
						case 'b':
							i=atoi(tmp[2]+1);
							i ? b=true:b=false;
							RegSetValueEx(cfgkey,tmp[1],0,REG_NONE,(const unsigned char *)&b,sizeof(b));
							break;
						case 's':
							if (!strnicmp(tmp[2]+1,"%gs%",4))
								sprintf(str,"%s%s",setupdir,tmp[2]+5);
							else
								strcpy(str,tmp[2]+1);
							RegSetValueEx(cfgkey,tmp[1],0,REG_SZ,(const unsigned char *)str,strlen(str)+1);
							break;
						}
						RegCloseKey(cfgkey);
					}
					continue;
				}
			}
			fclose(f);
			sprintf(str,"%s/UpdCmp%d/gscmp%d.gsi",setupdir,id,id);
			sprintf(str2,"%s/gscmp%d.gsi",setupdir,id);
			if (!_access(str2,0))
				_unlink(str2);
			MoveFile(str,str2);
			f=fopen(str2,"rt");
			if (f)
			{
				int id;
				double ver;
				char name[1024],uver[1024];
				upddlchk::GetUpdInfo(f,id,ver,name,uver,NULL);
				fclose(f);
				if (id!=-1)
				{
					new component(id,ver,name,uver);
					SaveConfig();
				}
			}
			sprintf(str,"%s/UpdCmp%d",setupdir,id);
			RemoveDirectory(str);
			sprintf(str,"%s/%s",setupdir,match);
			_unlink(str);
		}while (FNextFile(match));
}
