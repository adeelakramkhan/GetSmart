
void InitDefaults()
{
	char str[1024];
#ifdef _WIN32
	//GetModuleFileName
	char *t,*t3,*t2=GetCommandLine();
	t=(char *) malloc(strlen(t2)+1);
	strcpy(t,t2);
	if (t[0]=='"') //&& (t[strlen(t)-1]=='"'))
	{
		t3=strrchr(t,'\\');
		*(t3+1)='\0';
		rundir=(char *) malloc(strlen(t)+15);
		strcpy(rundir,t+1);
	}
	else
	{
		t3=strrchr(t,'\\');
		if (t3)
			*(t3+1)='\0';
		else t[0]='\0';
		if ((t[0]!='\\') && !strchr(t,':'))
		{
			GetCurrentDirectory(sizeof(str),str);
			strcat(str,"\\");
			strcat(str,t);
			rundir=(char *) malloc(strlen(str)+15);
			strcpy(rundir,str);
		}
		else
		{
			rundir=(char *) malloc(strlen(t)+15);
			strcpy(rundir,t);
		}
	}
	free(t);
	memset(&os,0,sizeof(os));
	os.dwOSVersionInfoSize=sizeof(OSVERSIONINFO);
	GetVersionEx(&os);
	sprintf(str,"%stmp\\",rundir);
	hlang=hinst;
#endif // _WIN32
#ifdef __unix__
	char*homedir;
	homedir=getenv("HOME");
	strcpy(str,homedir);
	strcat(str,"/.GetSmart/");
	rundir=DupString(str);
	chdir(rundir);
	printf("%s \n",rundir);
	memset(&findstruct,0,sizeof(findstruct));
	sprintf(str,"%stmp/",rundir);
#endif // __unix__
	cfg.tmpdir=DupString(str);
	if (_access(str,0))
			CreateDirectory(str,NULL);	
	setupdir=DupString(rundir);
	setupdir[strlen(setupdir)-1]='\0';
	lastact=-1;
	activemain=0;
	activedl=0;
	activebr=0;
	activesocks=0;
	maincount=0;
	loadurl=false;
	cfg.Proxy.HTTPP=8080;
	cfg.Proxy.HTTPT=1;
	cfg.Proxy.FTPP=21;
	cfg.Proxy.FTPT=1;
	cfg.Proxy.UseHTTP=false;
	cfg.Proxy.UseFTP=false;
	cfg.Proxy.HTTP4FTP=false;
	cfg.Proxy.OnlyProxy=false;
	cfg.Proxy.SmartProxy=false;
	cfg.Proxy.Passive=false;
	cfg.Proxy.HHost=DupString("");
	cfg.Proxy.FHost=DupString("");
	cfg.Proxy.sockshost=DupString("");
	cfg.Proxy.socksuser=DupString("");
	cfg.Proxy.socksport=1080;
	cfg.Proxy.socks=false;
	memset(cfg.Proxy.huser,0,sizeof(cfg.Proxy.huser));
	memset(cfg.Proxy.hpass,0,sizeof(cfg.Proxy.hpass));
	memset(cfg.Proxy.fuser,0,sizeof(cfg.Proxy.fuser));
	memset(cfg.Proxy.fpass,0,sizeof(cfg.Proxy.fpass));
	cfg.Proxy.nocache=true;
	cfg.Dial.Subi=-1;
	cfg.Dial.Use=false;
	cfg.Dial.Busy=0;
	cfg.Dial.Pause=2;
	cfg.Dial.TO=120;
	cfg.Dial.MaxLong=2;
	cfg.Dial.LongPause=3000;
	cfg.Dial.reconnect=false;
	cfg.Dial.pulse=false;
	strcpy(cfg.Dial.Entry,"");
	strcpy(cfg.Dial.Phone[0],"");
	strcpy(cfg.Dial.User,"");
	strcpy(cfg.Dial.Pass,"");
	memset(&cfg.Schedule,0,sizeof(schedule_tag));
	cfg.Schedule.UseDLDate=true;
	cfg.Schedule.UseHUDate=true;
	listhead=NULL;lastitem=NULL;
	serhead=NULL;serlast=NULL;
	cfg.Email=DupString("qwerty@abc.com");
	memset(actdls,0,sizeof(actdls));
	cfg.hidepass=false;
	cfg.asciiext=DupString(".txt;.cgi;.htm;.html;.cpp;.c;");
	cfg.flushsize=0x1800;
	cfg.robot=false;
	cfg.solveonfull=false;
	cfg.emdir=DupString("");
	cfg.checkint=true;
	cfg.checksmallint=true;
	cfg.intsize=0x1000;
	cfg.intsmallsize=0x100;
	cfg.keepsplit=true;
	cfg.maxhammer=4;
	cfg.usemaxbusyretry=false;
	cfg.usemaxbusytime=false;
	cfg.usemaxhammerretry=false;
	cfg.usemaxhammertime=true;
	cfg.maxbusytime=300;
	cfg.maxbusyretry=1000;

	cfg.maxhammerretry=5000;
	cfg.maxhammertime=300;
	cfg.nohammerbusydelay=5;
	cfg.usehammer=true;
	cfg.useretry=true;
	cfg.hammerfallback=true;
	cfg.resumeto=20;
	cfg.noresumeto=60;
	cfg.maxactive=5;
	cfg.catchext=DupString(".EXE;.ZIP;");
	cfg.disconnect=false;
	cfg.shutdown=false;
	cfg.defsplit=0;
	cfg.updsite=DupString("http://getsmart.hypermart.net/gsupd/");
	//cfg.updsite=DupString("ftp://127.0.0.1/gsupd/");
#ifdef _WIN32
	hwnddial=NULL;
	dialing=false;
	hras=NULL;
	cfg.runexternal=false;
	cfg.externalshow=SW_HIDE;
#endif
	cfg.startdl=true;
	cfg.startdef=false;
	cfg.externalfile=DupString("");
	cfg.externalparams=DupString("");
	cfg.speedlimit=0;
	cfg.dlspeedlimit=0;
	cfg.brspeedlimit=0;
	cfg.slonlyifbr=false;
	cfg.slonlyifdl=false;
	cfg.maxsplit=6;
	changesplit=0;
	cfg.checkonadd=false;
	cfg.mirr.autosearch=false;
	cfg.mirr.maxmirchecks=3;
	cfg.mirr.maxmirget=20;
	cfg.mirr.killtime=120;
	cfg.beproxy.use=false;
	cfg.beproxy.ip=MAKELONG(MAKEWORD(127,0),MAKEWORD(0,1));
	cfg.beproxy.port=8080;
	cfg.beproxy.to=15;
	cfg.beproxy.minsize=15000;
	cfg.beproxy.dosplit=3;
	cfg.lang=false;
	cfg.istmpdir=false;
	cfg.stamp=DupString(".Download");
	cfg.multilog=false;
	cfg.logwdl=false;
	cfg.logdir=DupString(rundir);
	cfg.logfn=DupString("GetSmart.log");
	cfg.r2l=0;
	cfg.maxsocks=25;
	cfg.rbufsize=AVGBUFSIZE;
	cfg.sdmaxcon=1000;
	cfg.sdmaxdl=1000;
	cfg.sdmaxeach=1000;
	maxrb=cfg.rbufsize;
	grbuf=(char *)malloc(cfg.rbufsize);//max(cfg.rbufsize,AVGBUFSIZE));
	lastmact=-1;
	calcid=0;
	gid=0;
	memset(actmdls,0,sizeof(actmdls));
	logday=0;
	dnshead=NULL;
	dnslast=NULL;
	exthead=NULL;
	schead=NULL;
	avsock=INVALID_SOCKET;
	avmir=NULL;
	new extlist("",rundir);
	dnscount=0;
	isGUI=false;
	dodis=false;
	gproxsock=INVALID_SOCKET;
	gsulsock=INVALID_SOCKET;
	wait4sc=false;
	gstitle=(char**)malloc(sizeof(char*));
	*gstitle=DupString("GetSmart");
	dused=0;
	dused2=0;
	cfg.langfn=DupString("");
	cfg.name=DupString("");
	cfg.usegsul=false;
	cfg.uuagent=false;
	cfg.uagent=DupString("");
	cfg.referer=false;
	cmphead=NULL;
	new component(0,SVERSION,"GetSmart",VERSION);
	LoadConfig();
	if (cfg.lang)
	{
#ifdef _WIN32
		hlang=LoadLibrary(cfg.langfn);
		if (hlang!=NULL)
		{
			strcpy(str,GetSTR(1,"NO"));
			if (!strnicmp(str,"YES",3))
				cfg.r2l=WS_EX_RIGHT;
		}
		else
			hlang=hinst;
#endif
	}
	//memset(socks,0,sizeof(socks));
}

