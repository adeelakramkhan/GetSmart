
#include "Daemon.h"

#ifdef _WIN32
#include "../resrc1.h"
BOOL CALLBACK CountDownFunc(HWND, UINT, WPARAM, LPARAM);
void ShutDown();
static HWND hcount=NULL;
#endif

server *GetSer(char *host)
{
	server *tmp=serhead;
	while (tmp)
	{
		if (!strcmp(tmp->host,host)) break;
		tmp=tmp->next;
	}
	if (tmp) return tmp;
	else
	{
		tmp=new server(host);
		// Tell GUI we have a new server;
		return tmp;
	}
}

unsigned long GetDNSFromTable(char *host)
{
	dnstable *dns=dnshead;
	while (dns)
	{
		if (!strcmp(host,dns->host))
			return dns->ip;
		dns=dns->next;
	}
	return 0;
}

void ConnectFire(SOCKET s,SOCKADDR_IN&addr)
{
 	char *firebuff=(char*)malloc(10+strlen(cfg.Proxy.socksuser));
	firebuff[0] = '\004';
	firebuff[1] = '\001';
	memcpy( firebuff+2, (char *) &(addr.sin_port), 2 );
#ifdef _WIN32
	memcpy( firebuff+4, (char *) &(addr.sin_addr.S_un.S_addr), 4);
// chk what windows did to the sockaddr_in struct...
#endif
	strcpy( firebuff+8, cfg.Proxy.socksuser);
	send( s, firebuff, 8+strlen(cfg.Proxy.socksuser)+1, 0);
	free(firebuff);
//#include <netinet/in.h>
}

bool NoMore(maindl *mdl)
{
	unsigned long k=0,r=0;int i;
	time_t tp;
	basicdl*big=NULL;
	for (i=0;i<=mdl->splitdex;i++)
	{
		if ( mdl->splitdl[i] && !mdl->spdone[i] &&
			( (mdl->spe[i]-mdl->sps[i]) > mdl->localbytes[i] ) &&
			( mdl->spe[i]-mdl->sps[i]-mdl->localbytes[i]>k))
		{
			k=mdl->spe[i]-mdl->sps[i]-mdl->localbytes[i]+1;
			big=mdl->splitdl[i];
		}
		else
			if (!mdl->splitdl[i] && !mdl->spdone[i])
				return false;
	}
	if (!big || (k<9000)) return true;
	time(&tp);
	tp-=big->starttime;
	if (tp==0) tp=1;
	if (mdl->sessionbytes[big->splitdex]/tp)
		r=k/(mdl->sessionbytes[big->splitdex]/tp);
	if (!r || (r<10)) 
		return true;
	return false;
}

void SockMan()
{
	/* scans all active maindls, calc socks for each mdl,
	 * splits=allowedsocks*mdl.pr/Sigma(pr)
	 */
	unsigned short prior=0,maxsocks;
	maxsocks=cfg.maxsocks-lastmact-1;
	sort_tag sort[1024],sort2[1024];
	bool dis[1024]; // disabled d/ls, from prev loop, or user
	memset(dis,0,sizeof(dis));
	int i,j;
	for (i=0;i<=lastmact;i++)
	{
		if (!actmdls[i].mdl) continue;
		if ((!actmdls[i].mdl->resume) || (actmdls[i].mdl->dosplit) 
			|| dis[i] || (actmdls[i].mdl->type!=1))
		{
			dis[i]=true;
			if (actmdls[i].mdl->type==1) 
				maxsocks-=actmdls[i].mdl->spliton-1;
		}
		else
			prior+=actmdls[i].mdl->prior;
	}
again:
	if (!prior || (lastmact==-1)) return;
	memset(sort,0,sizeof(sort));
	memset(sort2,0,sizeof(sort2));
	double fact=((double)maxsocks)/((double)prior);
	unsigned short given=0;
	for (i=0;i<=lastmact;i++)
		if (!dis[i])
		{
			actmdls[i].sp=((double)actmdls[i].mdl->prior)*fact;
			actmdls[i].split=(int)actmdls[i].sp;
			sort2[i].f=actmdls[i].split;
			sort2[i].i=i;
			given+=actmdls[i].split;
			sort[i].f=(unsigned short)(actmdls[i].sp-actmdls[i].split)*10000;
			sort[i].i=i;
		}
	for (i=0;i<lastmact;i++)
		for (j=i+1;j<=lastmact;j++)
			if (sort[i].f<sort[j].f)
			{
				XORSWAP(sort[i].f,sort[j].f);
				XORSWAP(sort[i].i,sort[j].i);
			}
	i=0;
	if (maxsocks>=given)
	{
		while (maxsocks-given)
		{
			actmdls[sort[i].i].split++;
			sort2[sort[i].i].f=actmdls[sort[i].i].split;
			given++;
			i++;
		}
	}

	for (i=0;i<lastmact;i++)
		for (j=i+1;j<=lastmact;j++)
			if (sort2[i].f<sort2[j].f)
			{
				XORSWAP(sort2[i].f,sort2[j].f);
				XORSWAP(sort2[i].i,sort2[j].i);
			}

	for (i=0;i<=lastmact;i++)
	{
		j=sort2[i].i;
		if (dis[j]) continue;
		if (((actmdls[j].split+1)>actmdls[j].mdl->spliton)
			&& NoMore(actmdls[j].mdl))
		{
			dis[j]=true;
			maxsocks-=actmdls[j].mdl->spliton-1;
			prior-=actmdls[j].mdl->prior;
			goto again;
		}
	}

	for (i=0;i<=lastmact;i++)
	{
		j=sort2[i].i;
		if (dis[j]) continue;
		bool quit=false;
		if ((actmdls[j].split+1)>cfg.maxsplit)
		{
			actmdls[j].split=cfg.maxsplit-1;
			quit=true;
		}
		if (((actmdls[j].split+1)<actmdls[j].mdl->spliton)
			|| !NoMore(actmdls[j].mdl))
			if ((actmdls[j].split+1)!=actmdls[j].mdl->spliton)
				actmdls[j].mdl->ChangeSplit(actmdls[j].split+1);
		if (quit || (actmdls[j].mdl->spliton!=(actmdls[j].split+1)))
		{
			dis[j]=true;
			maxsocks-=actmdls[j].mdl->spliton-1;
			prior-=actmdls[j].mdl->prior;
			goto again;
		}
	}
}

bool WakeMDL(server *ser,SOCKET &hsock)
{
	mirrors *mir=ser->mirhead;
	short prior=0;maindl*rmdl=NULL;mirrors *rmir=NULL;
	while (mir)
	{
		if ((!mir->mdl->spliton) && mir->mdl->wait && (mir->mdl->type==1))
			if ((mir->mdl->prior>prior) && MIRVALID(mir))
			{
				prior=mir->mdl->prior;
				rmdl=mir->mdl;
				rmir=mir;
			}
		mir=mir->next;
	}
	if (rmdl!=NULL)
	{
		if (avsock!=INVALID_SOCKET)
		{
			RMSelectSock(avsock);
			closesocket(avsock);
			//sock--;
		}
		avsock=hsock;
		avmir=rmir;
		rmdl->ActMain(true);
		avmir=NULL;
		return true;
	}
	return false;
}

void cs(char *str)
{
	char *str2;
	int ret;
	str2=strchr(str,'%');
	while ((str2) && (strlen(str)-(str2-str)>2))
	{
		char c;
		c=*(++str2);
		if ((c>='A') && (c<='F')) ret=(c-'A'+10)*16;
		else
			if ((c>='a') && (c<='f')) ret=(c-'a'+10)*16;
			else ret=(c-'0')*16;
		c=*(++str2);
		if ((c>='A') && (c<='F')) ret+=c-'A'+10;
		else
			if ((c>='a') && (c<='f')) ret+=c-'a'+10;
			else ret+=c-'0';
		++str2;
		*(str2-3)=ret;
		memmove(str2-2,str2,strlen(str2)+1);
		str2=strchr(str,'%');
	}
}

void rcs(char *s)
{
	char d[1024];
	d[0]='\0';
	unsigned int i;
	for (i=0;i<strlen(s);i++)
	{
		char t[10];
		if ((s[i]==';') || 
			(s[i]=='*') || (s[i]=='\'') || (s[i]=='(') || 
			(s[i]==')') || (s[i]==',') || (s[i]==' ') || 
			(s[i]=='<') || (s[i]=='>'))
			sprintf(t,"%%%x",s[i]);
		else
		{
			t[0]=s[i];
			t[1]='\0';
		}
		strcat(d,t);
	}
	strcpy(s,d);
}

void GetExtDir(char *dir,char *fn)
{
	char *c;
	extlist *tmp=exthead->next;
	c=strrchr(fn,'.');
	if ((!c) || (!*(c+1)))
	{
		strcpy(dir,exthead->dir);
		return;
	}
	c++;
	while (tmp)
	{
		if (!stricmp(c,tmp->ext))
		{
			strcpy(dir,tmp->dir);
			return;
		}
		tmp=tmp->next;
	}
	strcpy(dir,exthead->dir);
}

bool DLURL(char *url)
{
	if (strlen(url) && strrchr(url,'.') &&
		(!strnicmp(url,"HTTP://",7) || !strnicmp(url,"FTP://",6)))
	{
		char *s1,*s2,str[1024];
		sprintf(str,"%s;",strrchr(url,'.'));
		s1 = _strlwr(_strdup(str));
		s2=_strlwr(_strdup(cfg.catchext));
		if (s1 && strstr(s2,s1))
		{
			free(s1);
			free(s2);
			return true;
		}
		free(s1);
		free(s2);
	}	
	return false;
}

bool Avail(mirrors *mir)
{
	if (mir->ser->actcon<mir->ser->maxcon)
		return true;
	int must=0;
	mirrors *m=mir->ser->mirhead;
	while (m)
	{
		if ((m->mdl->spliton==1) && (m->used==1))
			must++;
		m=m->sernext;
	}
	if (must==mir->ser->actcon) return false;
	else return true;
}

void CheckAuto()
{
	if (dialing) return;
/*	if ((lastact==-1) && (maincount>0) && !IsConnected())
	{
		StartDial();
		return;
	}*/
	if (cfg.maxactive<=activemain) return;
	maindl*m=listhead;
	time_t tp;
	time(&tp);
	unsigned short p=0;
	short nact=-1;
	maindl *mrun=NULL;
	mirrors *mir;
	while (m && (mir=m->GetBestMirror()) && Avail(mir))
	{
		if (m->wait && !m->spliton && !mir->ser->en &&
			(mir->ser->maxdl>mir->ser->actdl)&& 
			!m->error.en && (m->type==1) && 
			((m->prior>p)||(m->prior==p) && 
			((mir->ser->maxcon-mir->ser->actcon)>nact) ) )
		{
			mrun=m;
			p=m->prior;
			if (p==5) break;
			nact=mir->ser->maxcon-mir->ser->actcon;
		}
		m=m->next;
	}
	if (mrun)
	{
		if (mrun->GetBestMirror()==NULL)
			mrun->mirrorhead->en=0;
		if (!mrun->ActMain(true)) return;
		CheckAuto();
		return;
	}
	m=listhead;

	while (m)
	{
		mir=m->mirrorhead;
		while (mir)
		{
			if (mir->en && (tp-mir->errtime>300))
				mir->en=0;
			mir=mir->next;
		}
		if ((mir=m->GetBestMirror()) && Avail(mir) && 
			(m->error.c[m->error.en]<=3))
		{
			if (m->wait && !m->spliton &&
				(mir->ser->maxdl>mir->ser->actdl)&& 
				(m->type==1) && 
				((m->prior>p)||(m->prior==p) && 
				((mir->ser->maxcon-mir->ser->actcon)>nact) ) )
			{
				mrun=m;
				p=m->prior;
				if (p==5) break;
				nact=mir->ser->maxcon-mir->ser->actcon;
			}
		}
		m=m->next;
	}
	if (mrun)
	{
		if (mrun->GetBestMirror()==NULL)
			mrun->mirrorhead->en=0;
		if (!mrun->ActMain(true)) return;
		CheckAuto();
		return;
	}

	if (cfg.disconnect) return;

	m=listhead;

	while (m)
	{
		mir=m->mirrorhead;
		while (mir)
		{
			if (mir->en && (tp-mir->errtime>300))
				mir->en=0;
			mir=mir->next;
		}
		if ((mir=m->GetBestMirror()) && Avail(mir))
		{
			if (m->wait && !m->spliton &&
				(mir->ser->maxdl>mir->ser->actdl)&& 
				(m->type==1) && 
				((m->prior>p)||(m->prior==p) && 
				((mir->ser->maxcon-mir->ser->actcon)>nact) ) )
			{
				mrun=m;
				p=m->prior;
				if (p==5) break;
				nact=mir->ser->maxcon-mir->ser->actcon;
			}
		}
		m=m->next;
	}
	if (mrun)
	{
		if (mrun->GetBestMirror()==NULL)
			mrun->mirrorhead->en=0;
		if (!mrun->ActMain(true)) return;
		CheckAuto();
		return;
	}
}

void InitProxy()
{
	int ret;
	int len;
	SOCKADDR_IN proxsockaddr;
	len=sizeof(struct sockaddr_in);
	if (gproxsock!=INVALID_SOCKET)
	{
		RMSelectSock(gproxsock);
		closesocket(gproxsock);
		//sock--;
	}
	//gproxsock=socket(AF_INET,SOCK_STREAM,0);
	GETSOCK(gproxsock,AF_INET,SOCK_STREAM,0);
	AddSelectSock(gproxsock,1025);
	proxsockaddr.sin_family=AF_INET;
	proxsockaddr.sin_port=htons(cfg.beproxy.port);
	proxsockaddr.sin_addr.s_addr=cfg.beproxy.ip;
	ret=bind(gproxsock,(SOCKADDR*) &proxsockaddr,
		sizeof(struct sockaddr_in));
	ret=listen(gproxsock,SOMAXCONN);
}

void ShutProxy()
{
	RMSelectSock(gproxsock);
	closesocket(gproxsock);
	//sock--;
	gproxsock=INVALID_SOCKET;
}

void InitGSUL()
{
	int len;
	SOCKADDR_IN gsulsockaddr;
	len=sizeof(struct sockaddr_in);
	if (gsulsock!=INVALID_SOCKET)
	{
		RMSelectSock(gsulsock);
		closesocket(gsulsock);
		//sock--;
	}
	//gsulsock=socket(AF_INET,SOCK_STREAM,0);
	GETSOCK(gsulsock,AF_INET,SOCK_STREAM,0);
	AddSelectSock(gsulsock,1026);
	gsulsockaddr.sin_family=AF_INET;
	gsulsockaddr.sin_port=htons(GSULPORT);
	gsulsockaddr.sin_addr.s_addr=INADDR_ANY;
	bind(gsulsock,(SOCKADDR*) &gsulsockaddr,
		sizeof(struct sockaddr_in));
	listen(gsulsock,SOMAXCONN);
}

void ShutGSUL()
{
	RMSelectSock(gsulsock);
	closesocket(gsulsock);
	//sock--;
	gsulsock=INVALID_SOCKET;
}

bool DLSchedule()
{
	if (!cfg.Schedule.EDL) return false;
	//SYSTEMTIME st;
	time_t tp;
	time(&tp);
	struct tm *st;
	st=localtime(&tp);
	if ((cfg.Schedule.StartDL.tm_hour==st->tm_hour) &&
		(cfg.Schedule.StartDL.tm_min==st->tm_min))
	{
		if (cfg.Schedule.UseDLDate &&
			(cfg.Schedule.DLDate.tm_mday==st->tm_mday) &&
			(cfg.Schedule.DLDate.tm_mon==st->tm_mon) &&
			(cfg.Schedule.DLDate.tm_year==st->tm_year))
			return true;
		if (!cfg.Schedule.UseDLDate && cfg.Schedule.DOW[st->tm_wday])
			return true;
	}
	return false;
}

bool HUSchedule()
{
	if (!cfg.Schedule.EHU) return false;
	time_t tp;
	time(&tp);
	struct tm *st;
	st=localtime(&tp);
	if ((cfg.Schedule.StartHU.tm_hour==st->tm_hour) && 
		(cfg.Schedule.StartHU.tm_min==st->tm_min))
	{
		if (cfg.Schedule.UseHUDate &&
			(cfg.Schedule.HUDate.tm_mday==st->tm_mday) &&
			(cfg.Schedule.HUDate.tm_mon==st->tm_mon) &&
			(cfg.Schedule.HUDate.tm_year==st->tm_year))
			return true;
		if (!cfg.Schedule.UseHUDate) return true;
	}
	return false;
}

void ManagerFunc()
{

/*	if (actmdls[0].mdl && (actmdls[0].mdl->spliton==100))
	{
		maindl *mdl=actmdls[0].mdl;
		actmdls[0].mdl->KillMain();
//		mdl->ActMain();
		return;
	}*/

#ifdef _WIN32
	static long deathmsgshown=0;

	if (deathmsgshown){
		if (isGUI)
			PostMessage(Hgui,WM_COMMAND,IDM_EXIT,0);
		else
			DestroyWindow(hwndg);
	}
#endif

	if (dialing) return;
	int r;
	unsigned long tc=GetTickCount();
	calcid++;
	globalcpsinfo=0;
	gdlcpsinfo=0;
	gbrcpsinfo=0;
	for (r=0;r<=lastact;r++)
		if (actdls[r] && (actdls[r]->hamdex==-1))
			actdls[r]->CalcCps(tc);
	globalcps=globalcpsinfo;
	gdlcps=gdlcpsinfo;
	gbrcps=gbrcpsinfo;

/*	time_t tm;
	time(&tm);
	if (lastmact<0) return;
	maindl *mdl=actmdls[lastmact].mdl;
			if (tm-mdl->starttime==10)
				if (mdl->splitdl[3]) mdl->splitdl[3]->KillDL();
				//TELLDAEMON(STOP_BDL,mdl,MAKELONG(3,-1));
			if (tm-mdl->starttime==13)
				//TELLDAEMON(STOP_BDL,mdl,MAKELONG(5,-1));
				if (mdl->splitdl[5]) mdl->splitdl[5]->KillDL();
			if (tm-mdl->starttime==18)
			{
				if (mdl->GetBestMirror()==NULL)
					mdl->mirrorhead->en=0;
				mdl->ChangeSplit(30);
			}
			if ((tm-mdl->starttime>20) && !((tm-mdl->starttime)%15))
			{
				srand( (unsigned)time( NULL ) );
				if (mdl->GetBestMirror()==NULL)
					mdl->mirrorhead->en=0;
				mdl->ChangeSplit(rand()%100);
			}
			if ((tm-mdl->starttime>20) && !((tm-mdl->starttime)%35))
			{
				srand( (unsigned)time( NULL ) );
				if (rand()%2)
					mdl->KillMain();
				else
				{
					mdl->guiparam=(void *)1;
					mdl->KillMain();
					mdl->delmdl();

		AddURL(new dlnfo(1,"127.0.0.1",21,"anonymous","qwerty@host.com","/pub/","icq99a.exe"),
			"d:\\",0,1,9,0,20,3,0,true,true,false,false);				}
			};*/
	time_t tp;
	time(&tp);
	int i,logstatus;
#define f actdls[i]
	for (i=0;i<=lastact;i++)
	{
		if (actdls[i])
		{
			logstatus=3;
			if (ISHTTP(f)) logstatus=1;
			if (!f->pause)
			{
				if (ISFTP(f) && f->hammerpause)
				{
					if (tp-f->lastbusyretry>cfg.nohammerbusydelay)
					{
						f->hammerpause=false;
						f->TimedOut();
						goto onegotoonly;
					}
				}
				else
					if ((f->resume || (f->hamdex>-1) || (f==f->mdl->busydl) || (f->status<=logstatus)) && 
						(tp-f->timeout>f->mdl->maxresumetimeout) ||
						(tp-f->timeout>cfg.noresumeto) ||
						(f->type==5) && (tp-f->timeout>cfg.beproxy.to))
					{
						//if ((f->type!=5) || (ISHTTP(f)) || !((httpproxy*)f)->post)
							f->TimedOut();
						goto onegotoonly;
					}
					if ((f->type==6) && (((dlchk*)f)->mmir->rmdl==f->mdl) &&
						(tp-f->time2dl>=cfg.mirr.killtime))
					{
						f->KillDL();
						goto onegotoonly;
					}
					if ((f->type!=6) && (tp-f->timeout) && 
						!((tp-f->timeout)%8))
						f->Ping();
					if ((f->type==6) && (((dlchk*)f)->mmir->pmdl==f->mdl) &&
						(tp-f->timeout>4))
					{
						time(&f->timeout);
						if (!f->mir->NextPing(f))
							goto onegotoonly;
					}
			}
		}
		if (f && f->read)
		{
			if (!f->speedlimit ||  (f->cps<f->speedlimit))
				if (!f->mdl->speedlimit || (f->mdl->cps<f->mdl->speedlimit))
					if (!cfg.speedlimit || (globalcps<cfg.speedlimit))
						if ((f->type!=5) || !cfg.brspeedlimit || (gbrcps<cfg.brspeedlimit) || cfg.slonlyifbr && !activebr)
							if ((f->type==5) || !cfg.dlspeedlimit || (gdlcps<cfg.dlspeedlimit)||cfg.slonlyifdl && !activedl)
								if ISFTP(f) f->ActOnRead(f->datasock);
								else f->ActOnRead(f->ctrlsock);
		}
		else
			if (f && (f->type==1) && f->pause)
				f->pause=false;
onegotoonly:;
	}
#undef f

	if ((activemain<cfg.maxactive) && (activemain<=maincount) && !wait4sc)
		CheckAuto();
	if (cfg.robot && !(tp%4))
		SockMan();
	if ((lastact==-1) && cfg.Schedule.EDL && DLSchedule())
	{
		maindl *mdl=listhead;
		while (mdl)
		{
			if (mdl->wait && (mdl->type==1))
				break;
			mdl=mdl->next;
		}
		wait4sc=true;
		if (!mdl)
		{
			mdl=listhead;
			while (mdl)
			{
				if (mdl->type==1)
					mdl->wait=true;
				mdl=mdl->next;
			}
		}

		if (!dialing)
			StartDial();
		wait4sc=false;
/*		if (cfg.Schedule.HangFinish && !cfg.disconnect)
		{
			cfg.disconnect=true;
			TELLGUI(UPDATE_BAR,0,0);
		}
		if (cfg.Schedule.Redial && !cfg.Dial.reconnect)
		{
			cfg.Dial.reconnect=true;
			TELLGUI(UPDATE_BAR,0,0);
		}*/
	}
	if (cfg.Schedule.EHU && HUSchedule())
	{
		/*if (cfg.robot)
		{
			cfg.robot=false;
			SendMessage(hwndg,WM_D_ROBOT,0,0);
		}*/
		Hangup();
	}

#ifdef _WIN32
	if (lastact==-1)
	{
		if (dodis)
		{
			dodis=false;
			if (!cfg.disconnect && !cfg.shutdown)
				return;
			if (!DialogBox(hlang,"COUNTDOWN",HWND_DESKTOP,
						(DLGPROC) CountDownFunc))
					return;
			if (cfg.disconnect)
			{
				cfg.disconnect=false;
				TELLGUI(UPDATE_BAR,0,0);
				Hangup();
			}
			if (cfg.shutdown)
				ShutDown();
		}
	}
	else
		if (!dodis)
		{
			if (hcount)
			{
				EndDialog(hcount,0);
				hcount=NULL;
			}
			dodis=true;
		}
#endif

}

#ifdef _WIN32
BOOL CALLBACK CountDownFunc(HWND hdwnd, UINT message,
								WPARAM wParam, LPARAM lParam)
{
	char str[1024];
	static time_t ct,tp;
	switch(message)
	{
	case WM_INITDIALOG:
		hcount=hdwnd;
		strcpy(str,GetSTR(90,"Count down..."));
		SetWindowText(hdwnd,str);
		if (cfg.disconnect && cfg.shutdown)
			strcpy(str,GetSTR(91,"Disconnect and shut down your computer."));
		else
			if (cfg.disconnect)
				strcpy(str,GetSTR(92,"Disconnect your computer."));
			else
				if (cfg.shutdown)
					strcpy(str,GetSTR(93,"Shutdown your computer."));
		SetDlgItemText(hdwnd,IDD_ACTION,str);
		if (cfg.shutdown)
			ShowWindow(GetDlgItem(hdwnd,IDD_WARNING),SW_SHOW);
		time(&tp);
		tp+=120;
		SetTimer(hdwnd,1,1000,0);
		return 1;
	case WM_TIMER:
		time(&ct);
		SetDlgItemInt(hdwnd,IDD_COUNT,tp-ct,true);
		if ((tp-ct)<=0)
		{
			EndDialog(hdwnd,1);
			hcount=NULL;
			return 1;
		}
		break;

	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDCANCEL:
			EndDialog(hdwnd, 0);
			hcount=NULL;
			return 1;
		case IDOK:
			EndDialog(hdwnd, 1);
			hcount=NULL;
			return 1;
		}
		return 0;
	}
	return 0;
}
#endif

/*int AddSock(SOCKET s)
{
	if (socks[s])
	{
		int jh=4;
	}
	socks[s]=1;
	return 1;
}

int RMSock(SOCKET s)
{
#ifdef closesocket
#undef closesocket
#endif
	if (!socks[s])
	{
		int jh=4;
	}
	socks[s]=0;
	closesocket(s);
	return 1;
}
*/
