
#include "Daemon.h"

#ifdef _WIN32
#include "../resrc1.h"
BOOL CALLBACK CatchBPFunc(HWND, UINT, WPARAM, LPARAM);
#endif

void dlproxy::ActOnRead(SOCKET sock)
{
	if (sock==ctrlsock)
	{
		if (firectrl)
			if (ChkFire(ctrlsock))
				firectrl=false;
			else
				return;
		ReadCtrl();
		return;
	}
	if (sock==datasock)
	{
		if (firedata)
			if (ChkFire(datasock))
				firedata=false;
			else
				return;
		ReadData(datasock);
		return;
	}
	if (sock==mdl->proxsock)
	{
		char buf[60001];
		memset(buf,0,sizeof(buf));
		int ret=recv(mdl->proxsock,buf,60000,0);
		if (ret==-1)
		{
		  if (status>=1)
		    {
			CloseSock(mdl->proxsock,false);
			RideOn();
		    }
		  return;
		}
		if (post && (ctrlsock!=INVALID_SOCKET))
		{
			if (status>=1)
				send(ctrlsock,buf,ret,0);
			else
			{
				char tmp[60000];
				strcpy(tmp,mdl->reqbuf);
				strcat(tmp,buf);
				mdl->reqbuf=(char *) realloc(mdl->reqbuf,strlen(tmp)+100);
				strcpy(mdl->reqbuf,tmp);
			}
			return;
		}
		if (!strnicmp(buf,"POST ",5))
		{
		}
		if (mdl->proxbuf!=NULL)
		{
			int jk;
			jk=0;
		}
		if (mdl->proxbuf)
			mdl->proxbuf=(char*)realloc(mdl->proxbuf,strlen(buf)+500);
		else mdl->proxbuf=(char*)malloc(strlen(buf)+500);
		strcpy(mdl->proxbuf,buf);
		//if (!strstr(mdl->proxbuf,"\r\n\r\n") && !strstr(mdl->proxbuf,"\n\n"))
		//	strcat(mdl->proxbuf,"\r\n");
		if (ctrlsock==INVALID_SOCKET)
			SendNext();
	}
}

void dlproxy::SendNext()
{
	char str[5024],url[5024];
	char str2[100];
	maindl *tmp=mdl;
	dlnfo *bn,*bn2;
	if (!mdl->proxbuf)
	{
		CloseSockets();
		RMSelectSock(mdl->proxsock);
		SockNBlock(mdl->proxsock);
		LINGER linger;
		linger.l_onoff=1;
		linger.l_linger=5;
		setsockopt(mdl->proxsock,SOL_SOCKET,SO_LINGER,(char *)&linger,
				sizeof(linger));
		shutdown(mdl->proxsock,2);
		if (sentbytes<mdl->rsize)
		{
			int jk;
			jk=2;
		}
		//RMSelectSock(mdl->proxsock);
		closesocket(mdl->proxsock);
		//sock--;
		mdl->proxsock=INVALID_SOCKET;
		RideOn();
		return;
	}
	mdl->istmpdir=false;
	CloseSockets();
	mdl->splitdex=0;
	GetWord(mdl->proxbuf,2,str,false);
	bn=ConvertURL(str);
	if (!strchr(bn->host,'.') && !strcmp(bn->rdir,"/") && !strlen(bn->rfn))
	{
//		char *tmp;
		sclist *sl=schead;
		while (sl)
			if (!stricmp(sl->sc,bn->host)) break;
			else sl=sl->next;
		if (sl!=NULL)
		{
			sprintf(url,"Location: %s\r\n",sl->url);
			strcpy(str,"HTTP/1.0 302 GetSmart shortcut\r\n");
			strcat(str,"Server: GetSmart "VERSION" acting as proxy server\r\n");
			strcat(str,url);
			strcat(str,"Proxy-Connection: close\r\n\r\n");
			send(mdl->proxsock,str,strlen(str),0);
			sentbytes=strlen(str);
			delete bn;
			RideOn();
			return;
		}
	}
	if (!strnicmp(bn->rfn,"updcmp",6) && strstr(bn->rfn,".chk"))
	{
		sprintf(str,"%s/",setupdir);
		AddURL(bn,str,0/*"gscmp.chk"*/,9,9,0,cfg.resumeto,DEFPR,0,cfg.usehammer,cfg.useretry,
				cfg.checkint,cfg.checksmallint);
		KillDL();
		return;
	}
	GetWord(mdl->proxbuf,2,str,false);
	if (DLURL(str))
	{
#ifdef _WIN32
		char *tmp;
		bool delbn=true;
		maindl *dmdl=CheckDup(bn);
		if (dmdl)
		{
			char str[5024];
			AddMirror(dmdl,bn);
			sprintf(str,GetSTR(94,"Detected a new mirror for %s"),dmdl->lfn);
			STELLGUI(SHOW_TIP,str,0);
			KillDL();
			delete bn;
			return;
		}
		mdl->mirrorhead->nfo->rfn=ReDupString(mdl->mirrorhead->nfo->rfn,
												bn->rfn);
		int r=DialogBoxParam(hlang,"CATCHBPDB",HWND_DESKTOP,
				(DLGPROC) CatchBPFunc,(long)mdl);
		mdl->hcatch=NULL;
		switch (r)
		{
		case 0:
			//sentbytes=1;
			//RideOn();
			KillDL();
			delete bn;
			return;
			break;
		case 1:
			//sentbytes=1;
			tmp=DupString(str);
			TELLGUI(GOT_URL,tmp,0);
			else
			{
				AddDefURL(bn,1);
				delbn=false;
			}
			if (delbn) delete bn;
			KillDL();
			return;
		}
#endif // win32
	}
	strcpy(url,str);
	mdl->ldir=ReDupString(mdl->ldir,cfg.tmpdir);
	char fl[_MAX_PATH];
	strncpy(fl,bn->rfn,_MAX_PATH-15);
	fl[_MAX_PATH-15]='\0';	
	sprintf(str,"%s - as proxy",fl);
	FilterFN(str);
	mdl->lfn=ReDupString(mdl->lfn,str);
	bn2=mdl->mirrorhead->nfo;
	mdl->mirrorhead->nfo=new dlnfo(bn);
	delete bn2;
	useproxy=GetProxy(bn->prot,5);
	if (splitdex)
	{
		SOCKET s=mdl->proxsock;
		mdl->proxsock=INVALID_SOCKET;
		type=-2;
		KillDL();
		tmp->Cr8DL(mdl->mirrorhead,0,-1,false);
		((dlproxy*)tmp->splitdl[0])->senddata=true;
		mdl->proxsock=s;
	}
	delete bn;
	GetWord(tmp->proxbuf,1,str,false);
	if (!strnicmp(str,"POST",4))
		post=true;
	tmp->reqbuf=(char *) realloc(tmp->reqbuf,strlen(tmp->proxbuf)+100);
	if (useproxy==2)
	{
		strcpy(str2,str);
		//GetWord(tmp->proxbuf,2,str,false);
		sprintf(tmp->reqbuf,"%s %s HTTP/1.0",str2,url);
		if (strlen(cfg.Proxy.huser))
		{
			char str3[5000];
			sprintf(str2,"%s:%s",cfg.Proxy.huser,cfg.Proxy.hpass);
			Base64(str2,str3);
			sprintf(str2,"\r\nProxy-Authorization: Basic %s",str3);
			strcat(tmp->reqbuf,str2);
		}
		strcat(tmp->reqbuf,strchr(tmp->proxbuf,13));
	}
	else
	{
		sprintf(tmp->reqbuf,"%s %s%s HTTP/1.0%s",str,
			tmp->mirrorhead->nfo->rdir,tmp->mirrorhead->nfo->rfn,
					strchr(tmp->proxbuf,13));
	}
	free(tmp->proxbuf);
	tmp->proxbuf=NULL;
	tmp->splitdl[0]->fireaddr.sin_addr.s_addr=0;
	tmp->splitdl[0]->QueryDNS();
}

bool dlproxy::ActOnHTTPStatus()
{
	unsigned int result;
	char str[60000];
	time(&timeout);
	if (!mdl->isdl)
		mdl->timeout=timeout;
	switch (status)
	{
	case 0:
		return GenActOnHTTPStatus();
		break;
	case 1:
		firstread=true;
		result=0;
		readbuffi=0;
		relocation=false;
		GetFN(str);
		if (fp)
		{
			fflush(fp);
			fclose(fp);
			fp=NULL;
		}
		result=0;
		checkint=false;
		countbytes=0;
		if (mdl->splitdex) result+=mdl->sps[splitdex];
		char st0[1250],*tmp,*tmp2;
		if (!mdl->reqbuf)
		{
			SendNext();
			break;
		}
		//if (!mdl->sps[splitdex] && !mdl->rsize)
		{
			strcpy(str,mdl->reqbuf);
			if (post)
			{
			wb(str,1);
			//debug=ReDupString(debug,str);
			send(ctrlsock,str,strlen(str),0);
			break;
			}
 			if (str[strlen(str)-1]==10)
				str[strlen(str)-1]='\0';
			if (str[strlen(str)-1]==13)
				str[strlen(str)-1]='\0';
			if (strstr(str,"Range: ") || strstr(str,"range: "))
			{
				ownrange=true;
				tmp=strstr(str,"Range: ");
				if (!tmp) tmp=strstr(str,"range: ");
				if (mdl->localbytes[splitdex] || mdl->sps[splitdex])
				{
					char str2[AVGBUFSIZE*3],str3[AVGBUFSIZE*3];
					memset(str2,0,sizeof(str2));
					strncpy(str2,str,tmp-str);
					tmp=strchr(tmp,'\n');
					if (strstr(tmp,"Range"))
						tmp=strstr(tmp,"Range");
					else
						if (strstr(tmp,"range"))
							tmp=strstr(tmp,"range");
					if (tmp[0]!='\n')
						tmp=strchr(tmp,'\n');
					if (mdl->spe[splitdex])
						sprintf(str3,"%sRange: bytes=%ld-%ld\r\nRequest-Range: bytes=%ld-%ld\r\n",str2,
									mdl->localbytes[splitdex]+mdl->sps[splitdex],mdl->spe[splitdex],
									mdl->localbytes[splitdex]+mdl->sps[splitdex],mdl->spe[splitdex]);
					else
						sprintf(str3,"%sRange: bytes=%ld-\r\nRequest-Range: bytes=%ld-\r\n",str2,
									mdl->localbytes[splitdex]+mdl->sps[splitdex],
									mdl->localbytes[splitdex]+mdl->sps[splitdex]);
					strcpy(str2,tmp+1);
					sprintf(str,"%s%s",str3,str2);
				}
				else
				{
					tmp2=strchr(tmp,'=')+1;
					mdl->localbytes[splitdex]=atoi(tmp2);
				}
			}
			else
				if (!errnf || mdl->localbytes[splitdex] || mdl->splitdex)
				{
					if (mdl->spe[splitdex])
						sprintf(st0,"Range: bytes=%ld-%ld\r\nRequest-Range: bytes=%ld-%ld\r\n",
									mdl->localbytes[splitdex]+mdl->sps[splitdex],mdl->spe[splitdex],
									mdl->localbytes[splitdex]+mdl->sps[splitdex],mdl->spe[splitdex]);
					else
						sprintf(st0,"Range: bytes=%ld-\r\nRequest-Range: bytes=%ld-\r\n",
									mdl->localbytes[splitdex]+mdl->sps[splitdex],
									mdl->localbytes[splitdex]+mdl->sps[splitdex]);
					strcat(str,st0);
				}
			
			strcat(str,"Connection: Keep-Alive\r\n\r\n");
			
			//m->write=true;
			if (mdl->rsize && (strstr(str,"Referer") || strstr(str,"referer")))
			{
				tmp=strstr(str,"Referer");
				if (!tmp) tmp=strstr(str,"referer");
				strncpy(tmp,"GS-ignore: ",11);
			}
			if (strstr(str,"Pragma") || strstr(str,"pragma"))
			{
				tmp=strstr(str,"Pragma");
				if (!tmp) tmp=strstr(str,"pragma");
				strncpy(tmp,"GS-ignore: ",11);
			}
			if (strstr(str,"Proxy") || strstr(str,"proxy"))
				if (strnicmp(str,"GET",3))
				{
					tmp=strstr(str,"Proxy");
					if (!tmp) tmp=strstr(str,"proxy");
					strncpy(tmp,"GS-ignore: ",11);
				}
			wb(str,1);
			//debug=ReDupString(debug,str);
			send(ctrlsock,str,strlen(str),0);
			break;
		}
		result=mdl->localbytes[splitdex]+mdl->sps[splitdex];
		char str2[1000];
		if (useproxy==2)
		{
			ConstURL(mir->nfo,str2);
			rcs(str2);
			sprintf(str,"GET %s HTTP/1.0\r\nHost: %s\r\n",str2,mir->nfo->host);
			if (strlen(cfg.Proxy.huser))
			{
				char str3[1000];
				sprintf(str2,"%s:%s",cfg.Proxy.huser,cfg.Proxy.hpass);
				Base64(str2,str3);
				sprintf(str2,"Proxy-Authorization: Basic %s\r\n",str3);
				strcat(str,str2);
			}
		}
		else
		{
			sprintf(str2,"%s%s",mir->nfo->rdir,mir->nfo->rfn);
			rcs(str2);
			sprintf(str,"GET %s HTTP/1.0\r\nHost: %s\r\n",str2,
				mir->nfo->host);
		}
		strcat(str,"Range: bytes=");
		strcpy(str2,str);
		if (mdl->spe[splitdex])
		{
			if (checkint) 
				sprintf(str,"%s%ld-%ld\r\nRequest-Range: bytes=%ld-%ld\r\n",str2,
				result-fbufsize,mdl->spe[splitdex],result-fbufsize,mdl->spe[splitdex]);
			else 
				sprintf(str,"%s%ld-%ld\r\nRequest-Range: bytes=%ld-%ld\r\n",str2,
				result,mdl->spe[splitdex],result,mdl->spe[splitdex]);
		}
		else
		{
			if (checkint) 
				sprintf(str,"%s%ld-\r\nRequest-Range: bytes=%ld-\r\n",str2,
				result-fbufsize,result-fbufsize);
			else 
				sprintf(str,"%s%ld-\r\nRequest-Range: bytes=%ld-\r\n",str2,
				result,result);
		}
		if (cfg.referer)
		{
			char pr[100];
			if (mir->nfo->prot==1)
				strcpy(pr,"ftp://");
			else
				strcpy(pr,"http://");
			sprintf(str2,"Referer: %s%s/index.html\r\n",pr,mir->nfo->host);
			strcat(str,str2);
		}
		if (!cfg.uuagent)
			strcat(str,"User-agent: GetSmart/"VERSION"\r\n");
		else
		{
			sprintf(str2,"User-agent: %s\r\n",cfg.uagent);
			strcat(str,str2);
		}
		strcat(str,"Accept: *.*, */*\r\nConnection: Keep-Alive\r\n\r\n");
		wb(str,1);
		//debug=ReDupString(debug,str);
		send(ctrlsock,str,strlen(str),0);
		break;
	}
	return true;
}

int dlproxy::ReadHTTPCtrl()
{
	if (!write)
	{
		writereq=true;
		return 0;
	}
	if (status==3) return ReadData(ctrlsock);
	time(&timeout);
	if (!mdl->isdl)
		mdl->timeout=timeout;
	int ret=0;
	unsigned int localbytes0;
	char res[AVGBUFSIZE*2],str[AVGBUFSIZE*2],buf3[AVGBUFSIZE*2];
	if (mdl->spe[splitdex] && 
		((mdl->localbytes[splitdex]+mdl->sps[splitdex])>=(mdl->spe[splitdex]+1)))
	{
		if (senddata)
			PassSendData();
		else
			RideOn();
		return 0;
	}
	ret=ReadSocket(ctrlsock,res,readbuff,readbuffi);
	if (ret<=0) return 0;

	if ((status==2) && !strnicmp(res,"HTTP",4) && !httpres)
	{
		CloseSockets();
		status=0;
		ActOnStatus();
		return 0;
	}
	//debug=ReDupString(debug,res);
	countbytes+=ret;
	if (!gotheader && !mdl->sps[splitdex])
		if (countbytes>sentbytes)
		{
			bool resch=false;
			char *tmp=NULL;
			if ((status!=2) && !strnicmp(res,"HTTP",4))
			{
				tmp=strchr(res,32)+1;
				if ((tmp!=NULL) && !strncmp(tmp,"206",3) && !ownrange)
				{
					resch=true;
					tmp[2]='0';
				}
				if ((tmp!=NULL) && !strncmp(tmp,"40",2) && !errnf)
				{
					errnf=true;
					status=0;
					ActOnStatus();
					return 0;
				}
			}
			if (tmp=strstr(res,"ength: 0"))
			{
				*tmp='r';
			}
			int j=send(mdl->proxsock,&res[ret-(countbytes-sentbytes)],
					countbytes-sentbytes,0);
			if ((j==SOCKET_ERROR) || (j<(signed)(countbytes-sentbytes)))
			{
				pause=true;
				write=false;
#ifdef __unix__
				FD_SET(mdl->proxsock,&wrsocks);
#endif
				if (j==SOCKET_ERROR) j=0;
				writebuffi=countbytes-sentbytes-j+readbuffi;
				if (writebuff==NULL)
					writebuff=(char *)malloc(writebuffi+1);
				else writebuff=(char *)realloc(writebuff,writebuffi+1);
				memcpy(writebuff,&res[ret-(writebuffi-readbuffi)],writebuffi-readbuffi);
				if (readbuffi)
					memcpy(writebuff+writebuffi-readbuffi,readbuff,readbuffi);
			}
			if (resch && (tmp!=NULL))
				tmp[2]='6';
			if (ownrange)
				ownrange=false;
			sentbytes=countbytes;
		}
	GetLine(res,str);
	while (strlen(str))
	{
		while (strlen(str)&& (*(str)==' '))
		{
			wb(str,4);
			GetLine(res,str);
		}
		if (!strlen(str))
			return ret;
		wb(str,2);
		strcpy(buf3,str);
		
		switch (GenHTTPCtrl(buf3))
		{
		case -1:
			return 0;
			break;
		case 0:
			resume=false;
			switch (httpres)
			{
			case 200:
			case 206:
				if (httpres==206)
				{
					resume=true;
					if (!mdl->resume)
						mdl->resume=true;
					err[3]=0;
				}
				else resume=false;
				status=2;
				mdl->MainFunc(1,this);
				break;
			case 302:
			case 301:
				//status=2;
				mdl->localbytes[splitdex]=1;
				break;
			default:
				if (httpres>399)
				{
					//MsgBox(hwndg,str,"Error!",MB_OK);
					if (mdl->rsize)
					{
						status=0;
						ActOnStatus();
						return 0;
					}
					if (!errnf)
					{
						errnf=true;
						status=0;
						ActOnStatus();
						return 0;
					}
					status=2;
					mdl->localbytes[splitdex]=1;
				}
			}
			if (!resume)
			{
				if (mdl->localbytes[splitdex]>1)
				{
					mdl->lbytes-=mdl->localbytes[splitdex];
					mdl->localbytes[splitdex]=0;
				}
			}
			break;

		case 2:
			if (!resume && mdl->rsize)
			{
				checkint=false;
				if (mdl->splitdex) localbytes0=mdl->localbytes[splitdex]+mdl->sps[splitdex];
				else localbytes0=mdl->localbytes[splitdex];
				if (mdl->rsize<=localbytes0)
				{
					mdl->spdone[splitdex]=true;
					if (senddata)
						PassSendData();
					else
						RideOn();
					return 0;
				}
			}
			break;

		case 8:
			countbytes=0;
			if (!gotheader && !mdl->sps[splitdex])
			{
				gotheader=true;
				sentbytes=0;
			}
			if (status!=2)
			{
				SendNext();
				return 0;
			}

			status=3;
			if (!mdl->info)
			{
				if (resume) 
					mdl->resume=resume;
				mdl->info=true;
			}
			if (resume)	countbytes=sentbytes;
			if (resume && !mdl->splitdex && 
				(mdl->rsize>=cfg.beproxy.minsize))
				mdl->ChangeSplit(cfg.beproxy.dosplit);
					
			if (!resume && mdl->splitdex)
			{
				doerr(3);
				return 0;
			}
			GetFN(str);
			if (fp)
			{
				fflush(fp);
				fclose(fp);
				fp=NULL;
			}
			if (!senddata)
			{
#ifdef OPEN1
				fp=fopen(str,"a+bc");
				if (!fp)
				{
					doerr(11);
					return 0;
				}
				//setvbuf(fp,NULL,cfg.flushsize,_IOFBF);
#endif
			}
			if (readbuffi>0)
				if (ReadData(INVALID_SOCKET)==-2)
					return 0;
			readbuffi=0;
			strcpy(str,GetSTR(28,"Downloading file."));
			wb(str,0);
			wstatus(str);
			dds();
			return ret;
		}
		GetLine(res,str);
	}
	return ret;
}

int dlproxy::ReadData(SOCKET readsock)
{
	if (!write)
	{
		writereq=true;
		return 0;
	}
	time(&timeout);
	isdl=true;
	mdl->isdl=true;
	mdl->timeout=timeout;
	if (!mir->info)
	{
		time_t tp;
		time(&tp);
		mir->resume=resume;
		mir->rsize=mdl->rsize;
		mir->time2dl=tp-time2dl;
		mir->info=true;
		mir->status=ReDupString(mir->status,
			GetSTR(86,"This is the main mirror. It works fine."));
		mdl->UpdateMirStatus();
	}
	int ret=0,r;
	char str[1024];	

	if (ISFTP(this) && !mdl->sps[splitdex] && !sentheader)
	{
		char str2[60000];
		if (mdl->localbytes[splitdex])
			strcpy(str,"HTTP/1.0 206 partial content\r\n");
		else
			strcpy(str,"HTTP/1.0 200 OK\r\n");
		strcat(str,"Server: GetSmart "VERSION" acting as proxy server\r\n");
		strcat(str,"Content-Type: application/octet-stream\r\n");
		if (mdl->localbytes[splitdex])
		{
			sprintf(str2,"Content-Range: bytes %ld-%ld/%ld\r\nContent-Length: %ld\r\n",
						mdl->localbytes[splitdex],mdl->rsize-1,mdl->rsize,
						mdl->rsize-mdl->localbytes[splitdex]);
			strcat(str,str2);
		}
		else
			if (mdl->rsize)
			{
				sprintf(str2,"Content-Length: %ld\r\n",mdl->rsize);
				strcat(str,str2);
			}
		if (mdl->resume)
			strcat(str,"Accept Ranges: bytes\r\n");
		strcat(str,"Proxy-Connection: close\r\n\r\n");
		send(mdl->proxsock,str,strlen(str),0);
		sentheader=true;
	}

//	** calc cps
#ifndef gsdbg
	unsigned long tc=GetTickCount();
	calcid++;
	globalcpsinfo=0;
	gdlcpsinfo=0;
	gbrcpsinfo=0;
	for (r=0;r<=lastact;r++)
		if (actdls[r] && (actdls[r]->hamdex==-1))
			actdls[r]->CalcCps(tc);
	globalcps=globalcpsinfo;
	gdlcps=gdlcpsinfo;
	gbrcps=gbrcpsinfo;
#endif
		

		
//		  ** speed limit
	if (readsock!=INVALID_SOCKET)
	if (speedlimit && (cps>speedlimit) || 
		mdl->speedlimit && (mdl->cps>mdl->speedlimit) ||
		cfg.speedlimit && (globalcps>cfg.speedlimit) ||
		cfg.brspeedlimit && (gbrcps>cfg.brspeedlimit) &&
		(!cfg.slonlyifdl || activedl))
		{
			read=true;
			pause=true;
			return 0;
		}
		//r=0;
		err[9]=0;
		/*
		tc=BUFSIZE;
		if (speedlimit && (speedlimit/2<tc)) tc=speedlimit/4;
		if (mdl->speedlimit && (mdl->speedlimit/2<tc)) tc=mdl->speedlimit/4;
		if (cfg.speedlimit && (cfg.speedlimit/2<tc)) tc=cfg.speedlimit/4;
		if (!tc) tc=1;
		*/
		read=false;
		pause=false;

		GetFN(str);
		if (!senddata)
		{
			fp=fopen(str,"ab");
			if (!fp)
			{
				doerr(11);
				return -2;
			}
		}
		char buf[50100];
		unsigned long cr,getbytes;
		if (readsock!=INVALID_SOCKET)
		{
#ifdef _WIN32
			ioctlsocket(readsock,FIONREAD,&cr);
#endif // win
#ifdef __unix__
			cr=2920;
#endif
			if (cr<=0) return cr;
			cr+=100;
			if (cr>50000) cr=50000;
			getbytes=cr;///2+1;
			if (maxrb<getbytes)
			{
				//grbuf=(char *)realloc(grbuf,getbytes);
				maxrb=getbytes;
			}
		}
		else getbytes=cfg.rbufsize/2;
		//buf=grbuf;

			if ((readsock==INVALID_SOCKET) && ISHTTP(this) && (readbuffi))
			{
				ret=readbuffi;
				memcpy(buf,readbuff,readbuffi);
				readbuffi=0;
			}
			else
				ret=recv(readsock,buf,getbytes,0);
			pause=false;
			if ((ret<=0))
			{
				if (fp) fclose(fp);
				fp=NULL;
				//free(buf);
				return ret;
			}
			if (checkint)
				cr=fbufsize-intsocksize;
			else cr=0;
			if (mdl->spe[splitdex] && 
				((mdl->localbytes[splitdex]+mdl->sps[splitdex]+ret-cr)>(mdl->spe[splitdex]+1)))
				ret=mdl->spe[splitdex]-mdl->sps[splitdex]+1-mdl->localbytes[splitdex]+cr;
			
			if (!mdl->sessionbytes[splitdex])
			{
				time(&starttime);
				if (!mdl->starttime) mdl->starttime=starttime;
			}
			
			
			readcount+=ret;
			if (ret>0)
			{
/*			char dbuf[10000];
			fseek(gfp,mdl->sps[splitdex]+mdl->localbytes[splitdex],SEEK_SET);
			fread(dbuf,1,ret,gfp);
			if (memcmp(dbuf,buf,ret))
			{
				int hg;
				hg=1;
				//MsgBox("ERROR - NOT compare - small",0,MB_OK);
			}*/
				countbytes+=ret;
				if ((countbytes>sentbytes) && senddata)
				{
					if (mdl->splitdex && 
						((countbytes-sentbytes+mdl->localbytes[splitdex]+mdl->sps[splitdex])>(mdl->spe[splitdex]+1)))
					{
						countbytes=sentbytes+(mdl->spe[splitdex]+1)-(ret-(countbytes-sentbytes)+mdl->localbytes[splitdex]+mdl->sps[splitdex]);
						ret=countbytes-sentbytes;
					}
					int i=send(mdl->proxsock,&buf[ret-(countbytes-sentbytes)],
						countbytes-sentbytes,0);
						/*			char st1[300];
						sprintf(st1,"%s%s - debug",cfg.tmpdir,nfo->rfn);
						gfp=fopen(st1,"a+b");
						if (gfp)
						{
						fwrite(&buf[ret-(countbytes-sentbytes)],1,i,gfp);
						fclose(gfp);
				}*/
					if ((i==SOCKET_ERROR) || (i<(signed)(countbytes-sentbytes)))
					{
						pause=true;
						write=false;
#ifdef __unix__
						FD_SET(mdl->proxsock,&wrsocks);
#endif
						if (i==SOCKET_ERROR) i=0;
						writebuffi=countbytes-sentbytes-i;
						if (writebuff==NULL)
							writebuff=(char *)malloc(writebuffi+1);
						else writebuff=(char *)realloc(writebuff,writebuffi+1);
						memcpy(writebuff,&buf[ret-(countbytes-sentbytes-i)],
							writebuffi);
					}
					sentbytes=countbytes;
				}
				else
					if (!senddata)
					{
						r=fwrite(buf,sizeof(char),ret, fp);
						/*				fclose(fp);
						GetFN(str);
						fc2(str,mdl->sps[splitdex]);
						fp=fopen(str,"a+bc");*/
					}
			}
			/*if (readcount>=cfg.flushsize)
			{
			fflush(fp);
			readcount=0;
			}
			//fclose(fp);*/
			mdl->localbytes[splitdex]+=ret;
			mdl->lbytes+=ret;
			mdl->sessionbytes[splitdex]+=ret;
			mdl->sbytes+=ret;
			
			/*	if (mdl->splitdex &&
			((mdl->localbytes[splitdex]+mdl->sps[splitdex])>=mdl->spe[splitdex]) &&
			(mdl->spe[splitdex]!=mdl->rsize-1))*/
			if (mdl->spe[splitdex] && 
				((mdl->localbytes[splitdex]+mdl->sps[splitdex])>=(mdl->spe[splitdex]+1)))
				//(mdl->spe[splitdex]!=mdl->rsize-1))
			{
				mdl->spdone[splitdex]=true;
				if (fp) fclose(fp);
				fp=NULL;
				if (senddata)
					PassSendData();
				else
					RideOn();
				//SendNext();
					return -2;
			}
		if (fp) fclose(fp);
		fp=NULL;
	return ret;
}

void dlproxy::ActOnClose(SOCKET sock)
{
	if (sock==ctrlsock)
	{
		if (ISFTP(this) &&  (pause || hammerpause))
		{
			wb(GetSTR(31,"Server closed control connection."),0);
			CloseSock(ctrlsock,false);
			dds();
		}
		else
			if (ISHTTP(this) && mdl->localbytes[splitdex])
			{
				CloseSock(ctrlsock,true);
				if (!mdl->rsize || (httpres>=300))
				{
					mdl->spdone[splitdex]=true;
					if (senddata)
						PassSendData();
					else
						RideOn();
				}
				else
					CloseData();
				return;
			}
			else
			{
				wb(GetSTR(32,"Server closed control connection, reconnecting."),3);
				status=0;
				ActOnStatus();
				dds();
			}
			return;
	}
	if (sock==datasock)
	{
		CloseSock(datasock,true);
		if (!mdl->rsize)
		{
			mdl->spdone[splitdex]=true;
			if (senddata)
				PassSendData();
			else
				RideOn();
		}
		else
			CloseData();
	}
	if (sock==mdl->proxsock)
	{
		CloseSock(mdl->proxsock,false);
		for (int i=0;i<=mdl->splitdex;i++)
			if (mdl->splitdl[i] && ((dlproxy*)mdl->splitdl[i])->senddata)
					((dlproxy*)mdl->splitdl[i])->senddata=false;
		mdl->KillMain();
	}
}

void dlproxy::PassSendData()
{
  printf("in PassSendData\n");
	RMSelectSock(mdl->proxsock);
	SockNBlock(mdl->proxsock);
	if ((mdl->spe[splitdex]+1)>=mdl->rsize)
	{
		SendNext();
		return;
	}
	char str[1024],buf[2000],match[1024],qmarks[]="?????";
	short sp;
	unsigned long st,en;
	long c,i;

	en=mdl->spe[splitdex];

	for(;;)
	{
		for (i=strlen(qmarks)-1;i>=0;i--)
		{
			sprintf(str,"%s%s (%s) %d-*",mdl->ldir,mdl->lfn,
									&qmarks[i],en+1);
			if (FFirstFile(str,match))
			{
				while (strstr(match,".Incomplete"))
					if (!FNextFile(match))
						goto nfile;
				break;
			}
nfile:;
		}
		if (i==-1)
			break;
		char *tmp,*tmp2;
		FILE *fp0;
		tmp=strrchr(match,')');
		sp=atoi(tmp-1);
		st=atoi(tmp+2);
		tmp2=strrchr(match,'-');
		en=atoi(tmp2+1);
		if (mdl->splitdl[sp] && (mdl->sps[sp]==st) ||
			!mdl->splitdl[sp] && !mdl->spdone[sp])
		{
			bool norideon=false;
			if (!mdl->splitdl[sp])
			{
				norideon=true;
				avmir=mir;
				if (avsock!=INVALID_SOCKET)
				{
					RMSelectSock(avsock);
					closesocket(avsock);
					//sock--;
				}
				avsock=ctrlsock;
				ctrlsock=INVALID_SOCKET;
				mdl->Cr8DL(mdl->GetBestMirror(),sp,-1,false);
				if (avmir!=NULL)
				{
					avmir=NULL;
					RMSelectSock(avsock);
					closesocket(avsock);
					//sock--;
					avsock=INVALID_SOCKET;
				}
			}
			if (mdl->splitdl[sp]->fp)
			{
				fclose(mdl->splitdl[sp]->fp);
				mdl->splitdl[sp]->fp=NULL;
			}
			mdl->splitdl[sp]->GetFN(str);
/*				fc();
			fc2(str,mdl->sps[sp]);*/
			fp0=fopen(str,"rb");
			do
			{
				c=fread(buf,1,sizeof(buf),fp0);
				if ((sentbytes+c)>(en+1))
					c=(en+1-sentbytes);
				sentbytes+=c;
				i=send(mdl->proxsock,buf,c,0);
/*					char st1[300];
				bool chk=true;
				sprintf(st1,"%s%s - debug",cfg.tmpdir,nfo->rfn);
				gfp=fopen(st1,"a+b");
				if (gfp)
				{
					fwrite(buf,1,i,gfp);
					fclose(gfp);
					if (chk)
					{
						fc();
						chk=false;
					}
				}*/
			} while (!feof(fp0) && !ferror(fp0) && (sentbytes<(en+1)));
			fclose(fp0);
//				fc();
			_unlink(str);
			((dlproxy*)mdl->splitdl[sp])->sentbytes=sentbytes;
			((dlproxy*)mdl->splitdl[sp])->countbytes=sentbytes;
			((dlproxy*)mdl->splitdl[sp])->senddata=true;
			//((dlproxy*)mdl->splitdl[sp])->proxsock=proxsock;
			senddata=false;
#ifdef _WIN32
			AddSelectSock(mdl->proxsock,mdl->splitdl[sp]->actpos);
#endif
			/*			WSAAsyncSelect(mdl->proxsock,hwndg,
						WM_USER+1+mdl->splitdl[sp]->actpos,*/
			//(/*FD_READ |*/ FD_WRITE | FD_CLOSE));*
			//proxsock=INVALID_SOCKET;
			if (norideon)
			{
				if (mdl->splitdl[sp]->ctrlsock!=INVALID_SOCKET)
				{
					mdl->splitdl[sp]->status=1;
					if ISHTTP(mdl->splitdl[sp])
						mdl->splitdl[sp]->ActOnStatus();
					else mdl->MainFunc(1,mdl->splitdl[sp]);
				}
				else mdl->splitdl[sp]->QueryDNS();
				KillDL();
			}
			else
				RideOn();
			break;
		}
		else
		{
//#ifdef _WIN32
		  sprintf(str,"%s%s",mdl->ldir,match);
//#endif
//#ifdef __unix__
//		  strcpy(str,match);
//#endif
/*				fc();
			fc2(str,mdl->sps[sp]);*/
			fp0=fopen(str,"rb");
			do
			{
				c=fread(buf,1,sizeof(buf),fp0);
				if ((sentbytes+c)>(en+1))
					c=(en+1-sentbytes);
				sentbytes+=c;
				i=send(mdl->proxsock,buf,c,0);
/*					char st1[300];
				bool chk=true;
				sprintf(st1,"%s%s - debug",cfg.tmpdir,nfo->rfn);
				gfp=fopen(st1,"a+b");
				if (gfp)
				{
					fwrite(buf,1,i,gfp);
					fclose(gfp);
					if (chk)
					{
						fc();
						chk=false;
					}
				}*/
			} while (!feof(fp0) && !ferror(fp0) && (sentbytes<(en+1)));
			fclose(fp0);
//				fc();
			_unlink(str);
		}
		if ((en+1)==mdl->rsize)
		{
			//CloseSock(proxsock,false);
			//proxsock=INVALID_SOCKET;
			SendNext();
			break;
		}
			//sprintf(str,"%s%s (?) %ld*",mir->nfo->ldir,mir->nfo->lfn,en+1);
	}
}

bool dlproxy::ActOnFTPStatus()
{
	unsigned int result;
	char str[1024];
	if (status && abort) return true;
	//abort=false;
	time(&timeout);
	if (!mdl->isdl)
		mdl->timeout=timeout;
	switch (status)
	{
	default:
		return GenActOnFTPStatus();
		break;

	case 0:
		abort=false;
		if (!busy && (++err[9]>=11))
		{
			err[9]=0;
			mdl->ErrMsg=ReDupString(mdl->ErrMsg,GetSTR(18,"GetSmart tried to initiate a download\
10 times\nand was not successful.\nIf you are in\auto download mode, it will try again later."));
			dds();
			doerr(9);
			return false;
		}
		return GenActOnFTPStatus();
		break;

	case 7:		
		if (fp)
		{
			fflush(fp);
			fclose(fp);
			fp=NULL;
		}
		result=0;
		GetFN(str);
		fp=fopen(str,"rb");
		result=mdl->localbytes[splitdex];
		checkint=false;
		if (mdl->splitdex) 
		{
			result+=mdl->sps[splitdex];
			if (result>=mdl->spe[splitdex])
			{
				mdl->spdone[splitdex]=true;
				if (senddata)
					PassSendData();
				else
					RideOn();
				return false;
			}
		}
		else 
			if (mdl->rsize && (result>=mdl->rsize))
			{
				if (senddata)
					PassSendData();
				else
					RideOn();
				return false;
			}
		return GenActOnFTPStatus();
		break;
	case 8:
		if (resume && mdl->localbytes[splitdex] || mdl->sps[splitdex])
		{
			if (!checkint || checkint && (mdl->sps[splitdex]+mdl->localbytes[splitdex]-fbufsize))
				if (/*(lastcmd[1]!=200) || */(lastcmd[0]!=350))
				{
					status++;
					TimedOut();
					return false;
				}
		}
		mdl->retries++;
		if (!mdl->info)
		{
			if (resume)
				mdl->resume=resume;
			mdl->info=true;
			SaveURLs();
		}
		if (resume && !mdl->splitdex && 
			(mdl->rsize>=cfg.beproxy.minsize))
			mdl->ChangeSplit(cfg.beproxy.dosplit);

		if (!resume && mdl->splitdex)
		{
			doerr(3);
			return 0;
		}
		if (mdl->localbytes[splitdex] && !resume)
		{
			if ((mdl->resume) || mdl->splitdex)
				if (++err[3]>=5)
				{
					err[3]=0;
					strcpy(mdl->ErrMsg,GetSTR(44,"This server supported \
resuming when first initiated.\nIt probably uses different server \
types \nbecause it can't Resume now.\nIf you are in auto download \
mode, GetSmart will try again later."));
					dds();
					doerr(3);
					return false;
				}
				else
				{
					status=0;
					return ActOnStatus();
				}
				if (mdl->localbytes[splitdex]>1)
				{
					mdl->lbytes-=mdl->localbytes[splitdex];
					mdl->localbytes[splitdex]=0;
				}
				countbytes=0;
				//SendMessage(Hgui,WM_D_INFO,(WPARAM) this->actpos,7);
				//Tell GUI starting file all over.
		}
		GetFN(str);
		if (fp)
		{
			fflush(fp);
			fclose(fp);
			fp=NULL;
		}
		if (!senddata)
		{
#ifdef OPEN1
			fp=fopen(str,"a+bc");
			if (!fp)
			{
				doerr(11);
				return false;
			}
			//setvbuf(fp,NULL,cfg.flushsize,_IOFBF);
#endif
		}
		sprintf(str,"RETR %s%s\r\n",mir->nfo->rdir,mir->nfo->rfn);
		wb(str,1);
		WriteFTP(str);
		strcpy(str,GetSTR(28,"Downloading file..."));
		dds();
		wstatus(str);
		break;
	}
	return true;
}

void dlproxy::ActOnWrite(SOCKET sock)
{
	if (sock==mdl->proxsock)
	{
		if (!write)
		{
			int i=0;
			if (writebuffi) i=send(mdl->proxsock,writebuff,writebuffi,0);
/*			extern FILE *gfp;
			char st1[300];
			sprintf(st1,"%s%s - debug",cfg.tmpdir,nfo->rfn);
			gfp=fopen(st1,"a+b");
			if (gfp)
			{
				fwrite(f->writebuff,1,i,gfp);
				fclose(gfp);
			}*/
			if (writebuffi && ((i==SOCKET_ERROR) || (i<writebuffi)))
			{
				write=false;
#ifdef __unix__
				FD_SET(mdl->proxsock,&wrsocks);
#endif
				if (i==SOCKET_ERROR) i=0;
				writebuffi-=i;
				memmove(writebuff,writebuff+i,writebuffi-i);
			}
			else
			{
				time(&timeout);
				pause=false;
				write=true;
				writebuffi=0;
				free(writebuff);
				writebuff=NULL;
			}
		}
#ifdef __unix__
		if (write)  FD_CLR(mdl->proxsock,&wrsocks);
#endif
		if (write && writereq)
		{
			writereq=false;
			if ISHTTP(this)
				ActOnRead(ctrlsock);
			else ActOnRead(datasock);
		}
	}
}

#ifdef _WIN32
extern HWND hgdlg;
BOOL CALLBACK CatchBPFunc(HWND hdwnd, UINT message,
                         WPARAM wParam, LPARAM lParam)
{
	char str[1024];
	maindl *mdl=(maindl *)GetWindowLong(hdwnd,GWL_USERDATA);
	time_t tp;

	switch(message)
	{
	case WM_INITDIALOG:
		mdl=(maindl *)lParam;
		mdl->splitdl[0]->pause=false;
		time(&mdl->starttime);
		mdl->starttime+=7;
		mdl->hcatch=hdwnd;
		SetWindowLong(hdwnd,GWL_USERDATA,(LONG) mdl);
		sprintf(str,GetSTR(95,"Detected file: %s"),mdl->mirrorhead->nfo->rfn);
		SetWindowText(hdwnd,str);
		SetTimer(hdwnd,1,1000,NULL);
		SendMessage(hdwnd,WM_TIMER,0,0);
		SetWindowPos(hdwnd,
				HWND_TOPMOST,
				0,
				0,
				0,0,SWP_NOSIZE|SWP_SHOWWINDOW|SWP_NOMOVE);
		return 1;
	case WM_ACTIVATE:
		if	(LOWORD(wParam) == WA_INACTIVE)
			hgdlg=NULL;
		else
			hgdlg=hdwnd;
		return 1;
	case WM_TIMER:
		time(&tp);
		SetDlgItemInt(hdwnd,IDD_COUNT,mdl->starttime-tp,true);
		if ((mdl->starttime-tp)<=0)
		{
			mdl->starttime=0;
			KillTimer(hdwnd,1);
			EndDialog(hdwnd, 2);
			return 1;
		}
		break;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDCANCEL:
			mdl->starttime=0;
			KillTimer(hdwnd,1);
			EndDialog(hdwnd, 0);
			return 1;
		case IDD_CATCH:
			mdl->starttime=0;
			KillTimer(hdwnd,1);
			EndDialog(hdwnd, 1);
			return 1;
		case IDD_CATCH2:
			mdl->starttime=0;
			KillTimer(hdwnd,1);
			EndDialog(hdwnd, 2);
			return 1;
		}
		return 0;
	}
	return 0;
}
#endif //win32
