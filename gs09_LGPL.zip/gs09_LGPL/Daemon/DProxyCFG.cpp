/*
#include "Daemon.h"
#include <Wininet.h>

void ProxyOn()
{
	INTERNET_PROXY_INFO ipi;
	memset(&ipi,0,sizeof(ipi));
	ipi.dwAccessType=INTERNET_OPEN_TYPE_PROXY;
	ipi.lpszProxy="ftp=127.0.0.1:8080;http=127.0.0.1:8080";
	InternetSetOption(NULL,INTERNET_OPTION_PROXY,&ipi,sizeof(INTERNET_PROXY_INFO));
}

void ProxyOff()
{
	static bool ch;
	if (!ch)
	{
		ch=true;
		ProxyOn();
		return;
	}
	ch=false;
	INTERNET_PROXY_INFO ipi;
	memset(&ipi,0,sizeof(ipi));
	ipi.dwAccessType=INTERNET_OPEN_TYPE_DIRECT;
	//ipi.lpszProxy="ftp=127.0.0.1:8080;http=127.0.0.1:8080";
	InternetSetOption(NULL,INTERNET_OPTION_PROXY,&ipi,sizeof(INTERNET_PROXY_INFO));
}*/