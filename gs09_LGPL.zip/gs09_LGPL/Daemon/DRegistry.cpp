
#include "Daemon.h"

extern bool saveurl;

void SetReg(char *k,LPVOID d,unsigned long ds)
{
	int i;
	if (ds==4)
		i=RegSetValueEx(regkey,k,0,REG_DWORD,(const unsigned char *)d,ds);
	else
		i=RegSetValueEx(regkey,k,0,REG_NONE,(const unsigned char *)d,ds);
	if (i!=ERROR_SUCCESS)
		i=i;
}

void SetReg(char *k,char *d)
{
	RegSetValueEx(regkey,k,0,REG_SZ,(const unsigned char *)d,strlen(d)+1);
}

void GetReg(char *k,LPVOID d,unsigned long ds)
{
	RegQueryValueEx(regkey,k,0,0,(unsigned char *)d,&ds);
}

void GetReg(char *k,char *d)
{
	DWORD ds=1000;
	RegQueryValueEx(regkey,k,0,0,(unsigned char *) d,&ds);
}

char* GetReg(char *k,char *d, int i)
{
	DWORD ds=0;
	char* st=0;
	RegQueryValueEx(regkey,k,0,0,0,&ds);
	if (ds)
	{
		char str[1024];
		ds=1024;
		if (RegQueryValueEx(regkey,k,0,0,(unsigned char *) str,&ds)==
														ERROR_SUCCESS)
			st=ReDupString(d,str);
		if (st) return st;
	}
	return d;
}

int LoadConfig()
{
	HKEY hkey=HKEY_CURRENT_USER;
	char subkey[80]="Software\\GetSmart\\Config";
	char str[1024];
	DWORD result,r;
	r=RegCreateKeyEx(hkey,subkey,0, 0,REG_OPTION_NON_VOLATILE,
		KEY_ALL_ACCESS,NULL,&cfgkey,&result);
	if (r!=ERROR_SUCCESS)
	{
		MsgBox(GetSTR(96,"Error reading configuration!"),0,MB_OK);
		return 0;
	}
	if (result==REG_CREATED_NEW_KEY)
	{
		time_t tp;
		struct tm*t;
		time(&tp);
		t=localtime(&tp);
//		cfg.mirr.d=(char)t->tm_mday^241;
	//	cfg.mirr.m=(char)t->tm_mon^24;
//		cfg.mirr.y=t->tm_year^0x4177;

		MsgBox("Welcome to GetSmart.\nThis \
GetSmart is now under GNU-GPL.\n","Welcome to GetSmart!",MB_OK);
		RegCloseKey(cfgkey);
		SaveConfig();
		return 1;
	}
	regkey=cfgkey;
	cfg.mirr.killtime=0;
	GetReg("MaxActive",&cfg.maxactive,sizeof(cfg.maxactive));
	GetReg("Robot",&cfg.robot,sizeof(cfg.robot));
	GetReg("disconnect",&cfg.disconnect,sizeof(cfg.disconnect));
	GetReg("KeepSplit",&cfg.keepsplit,sizeof(cfg.keepsplit));
	cfg.catchext=GetReg("CatchEXT",cfg.catchext,0);
	cfg.asciiext=GetReg("ASCIIEXT",cfg.asciiext,0);
	GetReg("DefaultDLDir",str);
	if (strlen(str))
		exthead->dir=ReDupString(exthead->dir,str);
	cfg.Email=GetReg("EMail",cfg.Email,0);
	cfg.emdir=GetReg("Emergency",cfg.emdir,0);
	GetReg("FlushSize",&cfg.flushsize,sizeof(cfg.flushsize));
	GetReg("ResumeTimeout",&cfg.resumeto,sizeof(cfg.resumeto));
	GetReg("NoResumeTimeout",&cfg.noresumeto,sizeof(cfg.noresumeto));
	GetReg("HidePass",&cfg.hidepass,sizeof(cfg.hidepass));
	GetReg("SolveOnFull",&cfg.solveonfull,sizeof(cfg.solveonfull));
	GetReg("IntegrityCheck",&cfg.checkint,sizeof(cfg.checkint));
	GetReg("SmallIntegrityCheck",&cfg.checksmallint,sizeof(cfg.checksmallint));
	GetReg("UseMaxBusyTime",&cfg.usemaxbusytime,sizeof(cfg.usemaxbusytime));
	GetReg("UseMaxBusyRetry",&cfg.usemaxbusyretry,sizeof(cfg.usemaxbusyretry));
	GetReg("HammerFallback",&cfg.hammerfallback,sizeof(cfg.hammerfallback));
	GetReg("UseHammer",&cfg.usehammer,sizeof(cfg.usehammer));
	GetReg("UseMaxHammerTime",&cfg.usemaxhammertime,sizeof(cfg.usemaxhammertime));
	GetReg("UseMaxHammerRetry",&cfg.usemaxhammerretry,sizeof(cfg.usemaxhammerretry));
	GetReg("UseRetry",&cfg.useretry,sizeof(cfg.useretry));
	//GetReg("DefaultSplit",&cfg.defsplit,sizeof(cfg.defsplit));
	GetReg("SmallIntSize",&cfg.intsmallsize,sizeof(cfg.intsmallsize));
	GetReg("IntegritySize",&cfg.intsize,sizeof(cfg.intsize));
	GetReg("MaxBusyRetry",&cfg.maxbusyretry,sizeof(cfg.maxbusyretry));
	GetReg("MaxHammer",&cfg.maxhammer,sizeof(cfg.maxhammer));
	GetReg("MaxSplit",&cfg.maxsplit,sizeof(cfg.maxsplit));
	GetReg("SLOnlyIfDL",&cfg.slonlyifdl,sizeof(cfg.slonlyifdl));
	GetReg("SLOnlyIfBR",&cfg.slonlyifbr,sizeof(cfg.slonlyifbr));
	GetReg("SerMaxDL",&cfg.sdmaxdl,sizeof(cfg.sdmaxdl));
	GetReg("SerMaxCon",&cfg.sdmaxcon,sizeof(cfg.sdmaxcon));
	GetReg("SerMaxEach",&cfg.sdmaxeach,sizeof(cfg.sdmaxeach));
	GetReg("BusyDelay",&cfg.nohammerbusydelay,sizeof(cfg.nohammerbusydelay));
	GetReg("MaxBusyTime",&cfg.maxbusytime,sizeof(cfg.maxbusytime));
	GetReg("StartDL",&cfg.startdl,sizeof(cfg.startdl));
	GetReg("StartDefault",&cfg.startdef,sizeof(cfg.startdef));
	GetReg("RunExternal",&cfg.runexternal,sizeof(cfg.runexternal));
	GetReg("ShowExternal",&cfg.externalshow,sizeof(cfg.externalshow));
	cfg.externalfile=GetReg("ExternalFile",cfg.externalfile,0);
	cfg.externalparams=GetReg("ExternalParams",cfg.externalparams,0);
	cfg.tmpdir=GetReg("TMPDir",cfg.tmpdir,0);
	cfg.name=GetReg("NickName",cfg.name,0);
	GetReg("UseGSUL",&cfg.usegsul,sizeof(cfg.usegsul));
	GetReg("CheckOnAdd",&cfg.checkonadd,sizeof(cfg.checkonadd));
	GetReg("Mirrors",&cfg.mirr,sizeof(cfg.mirr));
	cfg.mirr.mirshead=NULL;
	GetReg("ActAsProxy",&cfg.beproxy,sizeof(cfg.beproxy));
	GetReg("Schedule",&cfg.Schedule,sizeof(cfg.Schedule));
	GetReg("Dialer",&cfg.Dial,sizeof(cfg.Dial));
	cfg.Proxy.HHost=GetReg("Proxy_HHost",cfg.Proxy.HHost,0);
	cfg.Proxy.FHost=GetReg("Proxy_FHost",cfg.Proxy.FHost,0);
	cfg.Proxy.sockshost=GetReg("Proxy_sockshost",cfg.Proxy.sockshost,0);
	cfg.Proxy.socksuser=GetReg("Proxy_socksuser",cfg.Proxy.socksuser,0);
	GetReg("Proxy_HPort",&cfg.Proxy.HTTPP,sizeof(cfg.Proxy.HTTPP));
	GetReg("Proxy_HType",&cfg.Proxy.HTTPT,sizeof(cfg.Proxy.HTTPT));
	GetReg("Proxy_FPort",&cfg.Proxy.FTPP,sizeof(cfg.Proxy.FTPP));
	GetReg("Proxy_FType",&cfg.Proxy.FTPT,sizeof(cfg.Proxy.FTPT));
	GetReg("Proxy_SPort",&cfg.Proxy.socksport,sizeof(cfg.Proxy.socksport));
	GetReg("Proxy_UseHTTP",&cfg.Proxy.UseHTTP,sizeof(cfg.Proxy.UseHTTP));
	GetReg("Proxy_UseFTP",&cfg.Proxy.UseFTP,sizeof(cfg.Proxy.UseFTP));
	GetReg("Proxy_OnlyProxy",&cfg.Proxy.OnlyProxy,sizeof(cfg.Proxy.OnlyProxy));
	GetReg("Proxy_HTTP4FTP",&cfg.Proxy.HTTP4FTP,sizeof(cfg.Proxy.HTTP4FTP));
	GetReg("Proxy_SmartProxy",&cfg.Proxy.SmartProxy,sizeof(cfg.Proxy.SmartProxy));
	GetReg("Proxy_UsePassive",&cfg.Proxy.Passive,sizeof(cfg.Proxy.Passive));
	GetReg("Proxy_UseSocks",&cfg.Proxy.socks,sizeof(cfg.Proxy.socks));
	GetReg("Proxy_HTTPuser",cfg.Proxy.huser);//,sizeof(cfg.Proxy.huser));
	GetReg("Proxy_HTTPpass",cfg.Proxy.hpass);//,sizeof(cfg.Proxy.hpass));
	GetReg("Proxy_FTPuser",cfg.Proxy.fuser);//,sizeof(cfg.Proxy.fuser));
	GetReg("Proxy_FTPpass",cfg.Proxy.fpass);//,sizeof(cfg.Proxy.fpass));
	GetReg("Proxy_NoCache",&cfg.Proxy.nocache,sizeof(cfg.Proxy.nocache));
	GetReg("ForeignLang",&cfg.lang,sizeof(cfg.lang));
	cfg.langfn=GetReg("LangFile",cfg.langfn,0);
	GetReg("UseTMPDir",&cfg.istmpdir,sizeof(cfg.istmpdir));
	GetReg("MultiLOG",&cfg.multilog,sizeof(cfg.multilog));
	GetReg("LogwDL",&cfg.logwdl,sizeof(cfg.logwdl));
	GetReg("RecvBuffer",&cfg.rbufsize,sizeof(cfg.rbufsize));
	GetReg("MaxSocks",&cfg.maxsocks,sizeof(cfg.maxsocks));
	cfg.stamp=GetReg("Stamp",cfg.stamp,0);
	cfg.logdir=GetReg("LOGdir",cfg.logdir,0);
	cfg.logfn=GetReg("LOGfn",cfg.logfn,0);
	GetReg("UseUAgent",&cfg.uuagent,sizeof(cfg.uuagent));
	cfg.uagent=GetReg("UAgent",cfg.uagent,0);
	GetReg("Referer",&cfg.referer,sizeof(cfg.referer));
	//cfg.updsite=GetReg("UpdateSite",cfg.updsite,0);
	RegCloseKey(cfgkey);

	// check for old vers before date chk
	if (!cfg.mirr.killtime)
	{
		time_t tp;
		struct tm*t;
		time(&tp);
		t=localtime(&tp);
		cfg.mirr.d=(char)t->tm_mday^241;
		cfg.mirr.m=(char)t->tm_mon^24;
		cfg.mirr.y=t->tm_year^0x4177;
		cfg.mirr.killtime=120;
	}

	int j=0;
	sprintf(subkey,"Software\\GetSmart\\Config\\DLDir%ld",j);
	while (RegOpenKeyEx(hkey,subkey,0,KEY_ALL_ACCESS,
		&regkey)==ERROR_SUCCESS)
	{
		char dir[1024],ext[1024];
		GetReg("EXT",ext);
		GetReg("Dir",dir);
		new extlist(ext,dir);
		RegCloseKey(regkey);
		j++;
		sprintf(subkey,"Software\\GetSmart\\Config\\DLDir%ld",j);
	}

	j=0;
	sprintf(subkey,"Software\\GetSmart\\Config\\Short%ld",j);
	while (RegOpenKeyEx(hkey,subkey,0,KEY_ALL_ACCESS,
		&regkey)==ERROR_SUCCESS)
	{
		char sc[1024],url[1024];
		GetReg("Short",sc);
		GetReg("URL",url);
		new sclist(sc,url);
		RegCloseKey(regkey);
		j++;
		sprintf(subkey,"Software\\GetSmart\\Config\\Short%ld",j);
	}

	j=0;
	sprintf(subkey,"Software\\GetSmart\\Config\\SearchSite%ld",j);
	while (RegOpenKeyEx(hkey,subkey,0,KEY_ALL_ACCESS,
		&regkey)==ERROR_SUCCESS)
	{
		char url[1024];
		bool norm;
		GetReg("URL",url);
		GetReg("Normal",&norm,sizeof(norm));
		mirsite *mirs=new mirsite(url,norm);
		GetReg("Use",&mirs->use,sizeof(mirs->use));
		RegCloseKey(regkey);
		j++;
		sprintf(subkey,"Software\\GetSmart\\Config\\SearchSite%ld",j);
	}

	j=0;
	sprintf(subkey,"Software\\GetSmart\\Config\\Server%ld",j);
	while (RegOpenKeyEx(hkey,subkey,0,KEY_ALL_ACCESS,
		&regkey)==ERROR_SUCCESS)
	{
		char host[1024];
		GetReg("Host",host);
		server *ser=new server(host);
		GetReg("MaxDL",&ser->maxdl,sizeof(ser->maxdl));
		GetReg("MaxCon",&ser->maxcon,sizeof(ser->maxcon));
		GetReg("MaxEach",&ser->maxeach,sizeof(ser->maxeach));
		GetReg("Permanent",&ser->perm,sizeof(ser->perm));
		GetReg("ONLY1IP",&ser->only1ip,sizeof(ser->only1ip));
		RegCloseKey(regkey);
		j++;
		sprintf(subkey,"Software\\GetSmart\\Config\\Server%ld",j);
	}

	j=0;
	sprintf(subkey,"Software\\GetSmart\\Config\\Component%ld",j);
	while (RegOpenKeyEx(hkey,subkey,0,KEY_ALL_ACCESS,&regkey)==ERROR_SUCCESS)
	{
		int id;
		double ver;
		char name[1024],uver[1024];
		GetReg("Id",&id,sizeof(id));
		GetReg("Version",&ver,sizeof(ver));
		GetReg("Name",name);
		GetReg("UVersion",uver);
		new component(id,ver,name,uver);
		RegCloseKey(regkey);
		j++;
		sprintf(subkey,"Software\\GetSmart\\Config\\Component%ld",j);
	}


	hkey=HKEY_LOCAL_MACHINE;
	strcpy(subkey,"Software\\GetSmart");
	if (RegOpenKeyEx(hkey,subkey,0,KEY_ALL_ACCESS,&regkey)==ERROR_SUCCESS)
	{
		setupdir=GetReg("Path",setupdir,0);
		RegCloseKey(regkey);
	}
	return 1;
}

int LoadURLs()
{
	char user[1024],pass[1024],addr[1024],sdir[1024],
		sfn[1024],ldir[1024],lfn[1024];
	loadurl=true;
	int j,j2;
	unsigned short prot,type=0;
	unsigned short port;
	HKEY hkey=HKEY_CURRENT_USER,urlkey;
	char subkey[50]="Software\\GetSmart\\URLs",szurl[50];
	j=0;
	sprintf(szurl,"%s\\URL%ld",subkey,j);		
	while (RegOpenKeyEx(hkey,szurl,0,KEY_ALL_ACCESS,&urlkey)==ERROR_SUCCESS)
	{
		regkey=urlkey;
		GetReg("Protocol",&prot,sizeof(prot));
		GetReg("Host",addr);
		GetReg("Port",&port,sizeof(port));
		GetReg("UserName",user);
		GetReg("Password",pass);
		GetReg("RDirectory",sdir);
		GetReg("RFileName",sfn);
		GetReg("LocalDLDir",ldir);
		GetReg("LocalFileName",lfn);
		GetReg("DownloadType",&type,sizeof(type));
		dlnfo *nfo=new dlnfo(prot,addr,port, user,
							 pass,sdir,sfn);
		maindl *m=new maindl(nfo,ldir,lfn,type);
		GetReg("UseTMPDir",&m->istmpdir,sizeof(m->istmpdir));
		GetReg("TimeOut",&m->maxresumetimeout,sizeof(m->maxresumetimeout));
		GetReg("Proxy",&m->useproxy,sizeof(m->useproxy));
		GetReg("DoSplit",&m->dosplit,sizeof(m->dosplit));
		GetReg("FTPMode",&m->ftpmode,sizeof(m->ftpmode));
		GetReg("Priority",&m->prior,sizeof(m->prior));
		GetReg("UseHammer",&m->usehammer,sizeof(m->usehammer));
		GetReg("UseRetry",&m->useretry,sizeof(m->useretry));
		m->usemaxbusytime=cfg.usemaxbusytime;
		m->usemaxbusyretry=cfg.usemaxbusyretry;
		m->usemaxhammertime=cfg.usemaxhammertime;
		m->usemaxhammerretry=cfg.usemaxhammerretry;
		GetReg("Size",&m->rsize,sizeof(m->rsize));
		GetReg("Resume",&m->resume,sizeof(m->resume));
		GetReg("Info",&m->info,sizeof(m->info));
		GetReg("LocalDone",&m->locallost,sizeof(m->locallost));
		GetReg("TotalTime",&m->totaltime,sizeof(m->totaltime));
		GetReg("Retries",&m->retries,sizeof(m->retries));
		GetReg("Split",&m->splitdex,sizeof(m->splitdex));
		if (m->splitdex)
		{
			//GetReg("SplitOn",&m->spliton,sizeof(m->spliton));
			GetReg("SpDone",m->spdone,sizeof(m->spdone));
			GetReg("SpStart",m->sps,sizeof(m->sps));
			GetReg("SpEnd",m->spe,sizeof(m->spe));
		}
		if (type==1)
		{
//			m->AddSer();
			m->CheckExist();
		}
		RegCloseKey(urlkey);
		if (type!=6)
		{
			j2=0;
			sprintf(szurl,"%s\\URL%ld\\Mirror%ld",subkey,j,j2);
			while (RegOpenKeyEx(hkey,szurl,0,KEY_ALL_ACCESS,
						&urlkey)==ERROR_SUCCESS)
			{
				regkey=urlkey;
				GetReg("Protocol",&prot,sizeof(prot));
				GetReg("Host",addr);
				GetReg("Port",&port,sizeof(port));
				GetReg("UserName",user);
				GetReg("Password",pass);
				GetReg("RDirectory",sdir);
				GetReg("RFileName",sfn);
				nfo=new dlnfo(prot,addr,port, user,
							 pass,sdir,sfn);
				AddMirror(m,nfo);				
				delete nfo;
				RegCloseKey(urlkey);
				j2++;
				sprintf(szurl,"%s\\URL%ld\\Mirror%ld",subkey,j,j2);
			}
		}
		j++;
		sprintf(szurl,"%s\\URL%ld",subkey,j);
//		return 1;
	}
	loadurl=false;
	return 1;
}

int SaveConfig()
{
#ifdef gsdbg
	return 0;
#endif
	char str[1024];
	HKEY hkey=HKEY_CURRENT_USER;
	char subkey[80]="Software\\GetSmart\\Config";
	DWORD result,r;
	r=RegCreateKeyEx(hkey,subkey,0, 0,REG_OPTION_NON_VOLATILE,
		KEY_ALL_ACCESS,NULL,&cfgkey,&result);
	if (r!=ERROR_SUCCESS)
	{
		MsgBox(GetSTR(97,"Error saving configuration!"),0,MB_OK);
		return 0;
	}	
	regkey=cfgkey;
	SetReg("MaxActive",&cfg.maxactive,sizeof(cfg.maxactive));
	SetReg("Robot",&cfg.robot,sizeof(cfg.robot));
	SetReg("Disconnect",&cfg.disconnect,sizeof(cfg.disconnect));
	SetReg("KeepSplit",&cfg.keepsplit,sizeof(cfg.keepsplit));
	SetReg("CatchEXT",cfg.catchext);
	SetReg("ASCIIEXT",cfg.asciiext);
	GetExtDir(str,"");
	SetReg("DefaultDLDir",str);
	SetReg("EMail",cfg.Email);
	SetReg("Emergency",cfg.emdir);
	SetReg("FlushSize",&cfg.flushsize,sizeof(cfg.flushsize));
	SetReg("ResumeTimeout",&cfg.resumeto,sizeof(cfg.resumeto));
	SetReg("NoResumeTimeout",&cfg.noresumeto,sizeof(cfg.noresumeto));
	SetReg("HidePass",&cfg.hidepass,sizeof(cfg.hidepass));
	SetReg("SolveOnFull",&cfg.solveonfull,sizeof(cfg.solveonfull));
	SetReg("IntegrityCheck",&cfg.checkint,sizeof(cfg.checkint));
	SetReg("SmallIntegrityCheck",&cfg.checksmallint,sizeof(cfg.checksmallint));
	SetReg("UseMaxBusyTime",&cfg.usemaxbusytime,sizeof(cfg.usemaxbusytime));
	SetReg("UseMaxBusyRetry",&cfg.usemaxbusyretry,sizeof(cfg.usemaxbusyretry));
	SetReg("HammerFallback",&cfg.hammerfallback,sizeof(cfg.hammerfallback));
	SetReg("UseHammer",&cfg.usehammer,sizeof(cfg.usehammer));
	SetReg("UseMaxHammerTime",&cfg.usemaxhammertime,sizeof(cfg.usemaxhammertime));
	SetReg("MaxSplit",&cfg.maxsplit,sizeof(cfg.maxsplit));
	SetReg("UseMaxHammerRetry",&cfg.usemaxhammerretry,sizeof(cfg.usemaxhammerretry));
	SetReg("UseRetry",&cfg.useretry,sizeof(cfg.useretry));
	SetReg("DefaultSplit",&cfg.defsplit,sizeof(cfg.defsplit));
	SetReg("SmallIntSize",&cfg.intsmallsize,sizeof(cfg.intsmallsize));
	SetReg("IntegritySize",&cfg.intsize,sizeof(cfg.intsize));
	SetReg("MaxBusyRetry",&cfg.maxbusyretry,sizeof(cfg.maxbusyretry));
	SetReg("MaxHammer",&cfg.maxhammer,sizeof(cfg.maxhammer));
	SetReg("SLOnlyIfDL",&cfg.slonlyifdl,sizeof(cfg.slonlyifdl));
	SetReg("SLOnlyIfBR",&cfg.slonlyifbr,sizeof(cfg.slonlyifbr));
	SetReg("SerMaxDL",&cfg.sdmaxdl,sizeof(cfg.sdmaxdl));
	SetReg("SerMaxCon",&cfg.sdmaxcon,sizeof(cfg.sdmaxcon));
	SetReg("SerMaxEach",&cfg.sdmaxeach,sizeof(cfg.sdmaxeach));
	SetReg("BusyDelay",&cfg.nohammerbusydelay,sizeof(cfg.nohammerbusydelay));
	SetReg("MaxBusyTime",&cfg.maxbusytime,sizeof(cfg.maxbusytime));
	SetReg("StartDL",&cfg.startdl,sizeof(cfg.startdl));
	SetReg("StartDefault",&cfg.startdef,sizeof(cfg.startdef));
	SetReg("RunExternal",&cfg.runexternal,sizeof(cfg.runexternal));
	SetReg("ShowExternal",&cfg.externalshow,sizeof(cfg.externalshow));
	SetReg("ExternalFile",cfg.externalfile);
	SetReg("ExternalParams",cfg.externalparams);
	SetReg("TMPDir",cfg.tmpdir);
	SetReg("NickName",cfg.name);
	SetReg("UseGSUL",&cfg.usegsul,sizeof(cfg.usegsul));
	SetReg("CheckOnAdd",&cfg.checkonadd,sizeof(cfg.checkonadd));
	SetReg("Mirrors",&cfg.mirr,sizeof(cfg.mirr));
	SetReg("ActAsProxy",&cfg.beproxy,sizeof(cfg.beproxy));
	SetReg("Schedule",&cfg.Schedule,sizeof(cfg.Schedule));
	SetReg("Dialer",&cfg.Dial,sizeof(cfg.Dial));
	SetReg("Proxy_HHost",cfg.Proxy.HHost);
	SetReg("Proxy_FHost",cfg.Proxy.FHost);
	SetReg("Proxy_sockshost",cfg.Proxy.sockshost);
	SetReg("Proxy_socksuser",cfg.Proxy.socksuser);
	SetReg("Proxy_HPort",&cfg.Proxy.HTTPP,sizeof(cfg.Proxy.HTTPP));
	SetReg("Proxy_HType",&cfg.Proxy.HTTPT,sizeof(cfg.Proxy.HTTPT));
	SetReg("Proxy_FPort",&cfg.Proxy.FTPP,sizeof(cfg.Proxy.FTPP));
	SetReg("Proxy_FType",&cfg.Proxy.FTPT,sizeof(cfg.Proxy.FTPT));
	SetReg("Proxy_SPort",&cfg.Proxy.socksport,sizeof(cfg.Proxy.socksport));
	SetReg("Proxy_UseHTTP",&cfg.Proxy.UseHTTP,sizeof(cfg.Proxy.UseHTTP));
	SetReg("Proxy_UseFTP",&cfg.Proxy.UseFTP,sizeof(cfg.Proxy.UseFTP));
	SetReg("Proxy_OnlyProxy",&cfg.Proxy.OnlyProxy,sizeof(cfg.Proxy.OnlyProxy));
	SetReg("Proxy_HTTP4FTP",&cfg.Proxy.HTTP4FTP,sizeof(cfg.Proxy.HTTP4FTP));
	SetReg("Proxy_SmartProxy",&cfg.Proxy.SmartProxy,sizeof(cfg.Proxy.SmartProxy));
	SetReg("Proxy_UsePassive",&cfg.Proxy.Passive,sizeof(cfg.Proxy.Passive));
	SetReg("Proxy_UseSocks",&cfg.Proxy.socks,sizeof(cfg.Proxy.socks));
	SetReg("Proxy_HTTPuser",cfg.Proxy.huser);//,sizeof(cfg.Proxy.huser));
	SetReg("Proxy_HTTPpass",cfg.Proxy.hpass);//,sizeof(cfg.Proxy.hpass));
	SetReg("Proxy_FTPuser",cfg.Proxy.fuser);//,sizeof(cfg.Proxy.fuser));
	SetReg("Proxy_FTPpass",cfg.Proxy.fpass);//,sizeof(cfg.Proxy.fpass));
	SetReg("Proxy_NoCache",&cfg.Proxy.nocache,sizeof(cfg.Proxy.nocache));
	SetReg("ForeignLang",&cfg.lang,sizeof(cfg.lang));
	SetReg("LangFile",cfg.langfn);
	SetReg("UseTMPDir",&cfg.istmpdir,sizeof(cfg.istmpdir));
	SetReg("MultiLOG",&cfg.multilog,sizeof(cfg.multilog));
	SetReg("LogwDL",&cfg.logwdl,sizeof(cfg.logwdl));
	//SetReg("Right2Left",&cfg.r2l,sizeof(cfg.r2l));
	SetReg("RecvBuffer",&cfg.rbufsize,sizeof(cfg.rbufsize));
	SetReg("MaxSocks",&cfg.maxsocks,sizeof(cfg.maxsocks));
	SetReg("Stamp",cfg.stamp);
	SetReg("LOGdir",cfg.logdir);
	SetReg("LOGfn",cfg.logfn);
	SetReg("UseUAgent",&cfg.uuagent,sizeof(cfg.uuagent));
	SetReg("UAgent",cfg.uagent);
	SetReg("Referer",&cfg.referer,sizeof(cfg.referer));
	SetReg("UpdateSite",cfg.updsite);
	RegCloseKey(cfgkey);
	extlist *el=exthead->next;
	int j=0;
	while (el)
	{
		sprintf(subkey,"Software\\GetSmart\\Config\\DLDir%ld",j);
		r=RegCreateKeyEx(hkey,subkey,0, 0,REG_OPTION_NON_VOLATILE,
			KEY_ALL_ACCESS,NULL,&regkey,&result);
		if (r==ERROR_SUCCESS)
		{
			SetReg("EXT",el->ext);
			SetReg("Dir",el->dir);
			RegCloseKey(regkey);
		}
		j++;
		el=el->next;
	}
	sprintf(subkey,"Software\\GetSmart\\Config\\DLDir%ld",j);
	while (RegOpenKeyEx(hkey,subkey,0,KEY_ALL_ACCESS,
		&regkey)==ERROR_SUCCESS)
	{
		RegCloseKey(regkey);
		RegDeleteKey(hkey,subkey);
		j++;
		sprintf(subkey,"Software\\GetSmart\\Config\\DLDir%ld",j);
	}

	if (schead==NULL)
		new sclist("gs","http://getsmart.hypermart.net");

	sclist *sl=schead;
	j=0;
	while (sl)
	{
		sprintf(subkey,"Software\\GetSmart\\Config\\Short%ld",j);
		r=RegCreateKeyEx(hkey,subkey,0, 0,REG_OPTION_NON_VOLATILE,
			KEY_ALL_ACCESS,NULL,&regkey,&result);
		if (r==ERROR_SUCCESS)
		{
			SetReg("Short",sl->sc);
			SetReg("URL",sl->url);
			RegCloseKey(regkey);
		}
		j++;
		sl=sl->next;
	}
	sprintf(subkey,"Software\\GetSmart\\Config\\Short%ld",j);
	while (RegOpenKeyEx(hkey,subkey,0,KEY_ALL_ACCESS,
		&regkey)==ERROR_SUCCESS)
	{
		RegCloseKey(regkey);
		RegDeleteKey(hkey,subkey);
		j++;
		sprintf(subkey,"Software\\GetSmart\\Config\\Short%ld",j);
	}

	if (cfg.mirr.mirshead==NULL)
	{
		new mirsite("http://ftpsearch.lycos.com/cgi-bin/search",true);
		new mirsite("http://shin.belnet.be:8000/ftpsearch",true);
		new mirsite("http://destroyer.filez.com/ftpsearch",true);
	}

	mirsite *mirs=cfg.mirr.mirshead;
	j=0;
	while (mirs)
	{
		sprintf(subkey,"Software\\GetSmart\\Config\\SearchSite%ld",j);
		r=RegCreateKeyEx(hkey,subkey,0, 0,REG_OPTION_NON_VOLATILE,
			KEY_ALL_ACCESS,NULL,&regkey,&result);
		if (r==ERROR_SUCCESS)
		{
			SetReg("URL",mirs->url);
			SetReg("Normal",&mirs->normal,sizeof(mirs->normal));
			SetReg("Use",&mirs->use,sizeof(mirs->use));
			RegCloseKey(regkey);
		}
		j++;
		mirs=mirs->next;
	}
	sprintf(subkey,"Software\\GetSmart\\Config\\SearchSite%ld",j);
	while (RegOpenKeyEx(hkey,subkey,0,KEY_ALL_ACCESS,
		&regkey)==ERROR_SUCCESS)
	{
		RegCloseKey(regkey);
		RegDeleteKey(hkey,subkey);
		j++;
		sprintf(subkey,"Software\\GetSmart\\Config\\SearchSite%ld",j);
	}
	
	server *ser=serhead;
	j=0;
	while (ser)
	{
		sprintf(subkey,"Software\\GetSmart\\Config\\Server%ld",j);
		r=RegCreateKeyEx(hkey,subkey,0, 0,REG_OPTION_NON_VOLATILE,
			KEY_ALL_ACCESS,NULL,&regkey,&result);
		if (r==ERROR_SUCCESS)
		{
			SetReg("Host",ser->host);
			SetReg("MaxDL",&ser->maxdl,sizeof(ser->maxdl));
			SetReg("MaxCon",&ser->maxcon,sizeof(ser->maxcon));
			SetReg("MaxEach",&ser->maxeach,sizeof(ser->maxeach));
			SetReg("Permanent",&ser->perm,sizeof(ser->perm));
			SetReg("ONLY1IP",&ser->only1ip,sizeof(ser->only1ip));
			RegCloseKey(regkey);
		}
		j++;
		ser=ser->next;
	}
	sprintf(subkey,"Software\\GetSmart\\Config\\Server%ld",j);
	while (RegOpenKeyEx(hkey,subkey,0,KEY_ALL_ACCESS,
		&regkey)==ERROR_SUCCESS)
	{
		RegCloseKey(regkey);
		RegDeleteKey(hkey,subkey);
		j++;
		sprintf(subkey,"Software\\GetSmart\\Config\\Server%ld",j);
	}

	component *cmp=cmphead->next;
	j=0;
	while (cmp)
	{
		sprintf(subkey,"Software\\GetSmart\\Config\\Component%ld",j);
		r=RegCreateKeyEx(hkey,subkey,0, 0,REG_OPTION_NON_VOLATILE,
			KEY_ALL_ACCESS,NULL,&regkey,&result);
		if (r==ERROR_SUCCESS)
		{
			SetReg("Id",&cmp->id,sizeof(cmp->id));
			SetReg("Version",&cmp->ver,sizeof(cmp->ver));
			SetReg("Name",cmp->name);
			SetReg("UVersion",cmp->uver);
			RegCloseKey(regkey);
		}
		j++;
		cmp=cmp->next;
	}

	sprintf(subkey,"Software\\GetSmart\\Config\\Component%ld",j);
	while (RegOpenKeyEx(hkey,subkey,0,KEY_ALL_ACCESS,
		&regkey)==ERROR_SUCCESS)
	{
		RegCloseKey(regkey);
		RegDeleteKey(hkey,subkey);
		j++;
		sprintf(subkey,"Software\\GetSmart\\Config\\Component%ld",j);
	}
	return 1;
}

int SaveURLs()
{
#ifdef gsdbg
	return 0;
#endif
	if (!saveurl) return 0;
	int j,j2,r;
	HKEY hkey=HKEY_CURRENT_USER,urlkey;
	char subkey[50]="Software\\GetSmart\\URLs",szurl[70];
	maindl*m=listhead;
	mirrors *mir;
	j=0;
	while (m)
	{
		if ((m->type!=5) && (m->type!=4) && (m->type!=6) && (m->type!=8) && (m->type!=9) && 
			(m->type!=10))
		{
			sprintf(szurl,"%s\\URL%ld",subkey,j);
			r=RegCreateKeyEx(hkey,szurl,0, 0,REG_OPTION_NON_VOLATILE,
				KEY_ALL_ACCESS,NULL,&urlkey,0);
			if (r==ERROR_SUCCESS)
			{
				regkey=urlkey;
				SetReg("Protocol",&m->mirrorhead->nfo->prot,sizeof(m->mirrorhead->nfo->prot));
				SetReg("Host",m->mirrorhead->nfo->host);
				SetReg("Port",&m->mirrorhead->nfo->port,sizeof(m->mirrorhead->nfo->port));
				SetReg("UserName",m->mirrorhead->nfo->user);
				SetReg("Password",m->mirrorhead->nfo->pass);
				SetReg("RDirectory",m->mirrorhead->nfo->rdir);
				SetReg("RFileName",m->mirrorhead->nfo->rfn);
				SetReg("LocalDLDir",m->ldir);
				SetReg("LocalFileName",m->lfn);
				SetReg("FTPMode",&m->ftpmode,sizeof(m->ftpmode));
				SetReg("UseHammer",&m->usehammer,sizeof(m->usehammer));
				SetReg("UseRetry",&m->useretry,sizeof(m->useretry));
				SetReg("Size",&m->rsize,sizeof(m->rsize));
				SetReg("Resume",&m->resume,sizeof(m->resume));
				SetReg("Proxy",&m->useproxy,sizeof(m->useproxy));
				SetReg("Priority",&m->prior,sizeof(m->prior));
				SetReg("UseTMPDir",&m->istmpdir,sizeof(m->istmpdir));
				SetReg("TimeOut",&m->maxresumetimeout,sizeof(m->maxresumetimeout));
				SetReg("Info",&m->info,sizeof(m->info));
				SetReg("LocalDone",&m->locallost,sizeof(m->locallost));
				SetReg("TotalTime",&m->totaltime,sizeof(m->totaltime));
				SetReg("Retries",&m->retries,sizeof(m->retries));
				SetReg("Split",&m->splitdex,sizeof(m->splitdex));
				SetReg("DownloadType",&m->type,sizeof(m->type));
				SetReg("DoSplit",&m->dosplit,sizeof(m->dosplit));
				if (m->splitdex)
				{
					//SetReg("SplitOn",&m->spliton,sizeof(m->spliton));
					SetReg("SpDone",m->spdone,sizeof(m->spdone));
					SetReg("SpStart",m->sps,sizeof(m->sps));
					SetReg("SpEnd",m->spe,sizeof(m->spe));
				}
				RegCloseKey(urlkey);
				mir=m->mirrorhead->next;
				j2=0;
				while (mir)
				{
					if (!mir->relocation)
					{
						sprintf(szurl,"%s\\URL%ld\\Mirror%ld",subkey,j,j2);
						r=RegCreateKeyEx(hkey,szurl,0, 0,REG_OPTION_NON_VOLATILE,
							KEY_ALL_ACCESS,NULL,&urlkey,0);
						if (r==ERROR_SUCCESS)
						{
							regkey=urlkey;
							SetReg("Protocol",&mir->nfo->prot,sizeof(mir->nfo->prot));
							SetReg("Host",mir->nfo->host);
							SetReg("Port",&mir->nfo->port,sizeof(mir->nfo->port));
							SetReg("UserName",mir->nfo->user);
							SetReg("Password",mir->nfo->pass);
							SetReg("RDirectory",mir->nfo->rdir);
							SetReg("RFileName",mir->nfo->rfn);
							RegCloseKey(urlkey);
							j2++;
						}
					}
					mir=mir->next;
				}
				sprintf(szurl,"%s\\URL%ld\\Mirror%ld",subkey,j,j2);
				while (RegOpenKeyEx(hkey,szurl,0,KEY_ALL_ACCESS,
							&urlkey)==ERROR_SUCCESS)
				{
					RegCloseKey(urlkey);
					RegDeleteKey(hkey,szurl);
					j2++;
					sprintf(szurl,"%s\\URL%ld\\Mirror%ld",subkey,j,j2);
				}
			}
		}
		m=m->next;
		j++;
	}
	sprintf(szurl,"%s\\URL%ld",subkey,j);
	while (RegOpenKeyEx(hkey,szurl,0,KEY_ALL_ACCESS,&urlkey)==ERROR_SUCCESS)
	{
		RegCloseKey(urlkey);
		j2=0;
		sprintf(szurl,"%s\\URL%ld\\Mirror%ld",subkey,j,j2);
		while (RegOpenKeyEx(hkey,szurl,0,KEY_ALL_ACCESS,
					&urlkey)==ERROR_SUCCESS)
		{
			RegCloseKey(urlkey);
			RegDeleteKey(hkey,szurl);
			j2++;
			sprintf(szurl,"%s\\URL%ld\\Mirror%ld",subkey,j,j2);
		}
		sprintf(szurl,"%s\\URL%ld",subkey,j);
		RegDeleteKey(hkey,szurl);
		j++;
		sprintf(szurl,"%s\\URL%ld",subkey,j);
	}
	return 1;
}

int DelReg()
{
	HKEY hkey=HKEY_CURRENT_USER,urlkey;
	char subkey[50]="Software\\GetSmart\\URLs",szurl[50];
	int j=0,j2;
	sprintf(szurl,"%s\\URL%ld",subkey,j);
	while (RegOpenKeyEx(hkey,szurl,0,KEY_ALL_ACCESS,&urlkey)==ERROR_SUCCESS)
	{
		RegCloseKey(urlkey);
		j2=0;
		sprintf(szurl,"%s\\URL%ld\\Mirror%ld",subkey,j,j2);
		while (RegOpenKeyEx(hkey,szurl,0,KEY_ALL_ACCESS,
					&urlkey)==ERROR_SUCCESS)
		{
			RegCloseKey(urlkey);
			RegDeleteKey(hkey,szurl);
			j2++;
			sprintf(szurl,"%s\\URL%ld\\Mirror%ld",subkey,j,j2);
		}
		sprintf(szurl,"%s\\URL%ld",subkey,j);
		RegDeleteKey(hkey,szurl);
		j++;
		sprintf(szurl,"%s\\URL%ld",subkey,j);		
	}
	RegDeleteKey(hkey,subkey);
	strcpy(subkey,"Software\\GetSmart\\Config\\GSgui");
	j=0;
	sprintf(szurl,"%s\\LastDL%ld",subkey,j);
	while (RegOpenKeyEx(hkey,szurl,0,KEY_ALL_ACCESS,&urlkey)==ERROR_SUCCESS)
	{
		RegCloseKey(urlkey);
		RegDeleteKey(hkey,szurl);
		j++;
		sprintf(szurl,"%s\\LastDL%ld",subkey,j);		
	}
	RegDeleteKey(hkey,subkey);

	j=0;
	sprintf(subkey,"Software\\GetSmart\\Config\\DLDir%ld",j);
	while (RegOpenKeyEx(hkey,subkey,0,KEY_ALL_ACCESS,&regkey)==ERROR_SUCCESS)
	{
		RegCloseKey(regkey);
		RegDeleteKey(hkey,subkey);
		j++;
		sprintf(subkey,"Software\\GetSmart\\Config\\DLDir%ld",j);
	}

	j=0;
	sprintf(subkey,"Software\\GetSmart\\Config\\Short%ld",j);
	while (RegOpenKeyEx(hkey,subkey,0,KEY_ALL_ACCESS,&regkey)==ERROR_SUCCESS)
	{
		RegCloseKey(regkey);
		RegDeleteKey(hkey,subkey);
		j++;
		sprintf(subkey,"Software\\GetSmart\\Config\\Short%ld",j);
	}

	j=0;
	sprintf(subkey,"Software\\GetSmart\\Config\\SearchSite%ld",j);
	while (RegOpenKeyEx(hkey,subkey,0,KEY_ALL_ACCESS,&regkey)==ERROR_SUCCESS)
	{
		RegCloseKey(regkey);
		RegDeleteKey(hkey,subkey);
		j++;
		sprintf(subkey,"Software\\GetSmart\\Config\\SearchSite%ld",j);
	}

	j=0;
	sprintf(subkey,"Software\\GetSmart\\Config\\Server%ld",j);
	while (RegOpenKeyEx(hkey,subkey,0,KEY_ALL_ACCESS,
		&regkey)==ERROR_SUCCESS)
	{
		RegCloseKey(regkey);
		RegDeleteKey(hkey,subkey);
		j++;
		sprintf(subkey,"Software\\GetSmart\\Config\\Server%ld",j);
	}

	RegDeleteKey(hkey,"Software\\GetSmart\\Config");
	RegDeleteKey(hkey,"Software\\GetSmart");
	return 1;
}

