
#include "Daemon.h"

int LoadConfig()
{
	return 0;
}

int SaveConfig()
{
	return 0;
}

int DelReg()
{
	return 0;
}

int SaveURLs()
{
	return 0;
}




