
#include "Daemon.h"

#ifdef _WIN32
#include "..\resrc1.h"
BOOL CALLBACK AcceptGSDL(HWND, UINT, WPARAM, LPARAM);
#endif

bool gsdl::ActOnStatus()
{
	unsigned int result;
	char str[1024];
	time(&timeout);
	switch (status)
	{
	case 0:
		return GenActOnHTTPStatus();
		break;
	case 1:
		firstread=true;
		CheckLog();
		char str2[AVGBUFSIZE],str3[AVGBUFSIZE];
		if (table!=NULL)
		{
			sprintf(str,"OFFER %s GS/"GSULVER"\r\nUser: %s\r\n\r\n",table->showfn,cfg.name);
			wb(str,1);
			send(ctrlsock,str,strlen(str),0);
			break;
		}
		result=0;
		mdl->retries++;
		readbuffi=0;
		relocation=false;
		GetFN(str);
		if (fp)
		{
			fflush(fp);
			fclose(fp);
			fp=NULL;
		}
		fp=fopen(str,"rb");
		if (fp) 
		{
			result=GetFSize(fp);
			InitIntCheck(result);
			fclose(fp);
			fp=NULL;
		}
		else 
		{
			checkint=false;
			result=0;
		}
		mdl->localbytes[splitdex]=result;
		if (mdl->splitdex) result+=mdl->sps[splitdex];
		if (result && mdl->spe[splitdex] && ((mdl->spe[splitdex]+1)<=result))
		{
			mdl->spdone[splitdex]=true;
			RideOn();
			return false;
		}
/*		if (useproxy==2)
		{
			//char str2[1000];
			ConstURL(mir->nfo,str2);
			rcs(str2);
			sprintf(str,"GET %s HTTP/1.0\r\nHost: %s\r\n",str2,mir->nfo->host);
			if (strlen(cfg.Proxy.huser))
			{
				sprintf(str2,"%s:%s",cfg.Proxy.huser,cfg.Proxy.hpass);
				Base64(str2,str3);
				sprintf(str2,"Proxy-Authorization: Basic %s\r\n",str3);
				strcat(str,str2);
			}
		}
		else*/
		{
			sprintf(str2,"%s%s",mir->nfo->rdir,mir->nfo->rfn);
			rcs(str2);
			sprintf(str,"SEND %s GS/"GSULVER"\r\n",str2);
		}
		strcat(str,"Range: ");
		strcpy(str2,str);
		if (mdl->spe[splitdex])
		{
			if (checkint) 
				sprintf(str,"%s%ld-%ld\r\n",str2,result-fbufsize,mdl->spe[splitdex]);
			else
				sprintf(str,"%s%ld-%ld\r\n",str2,result,mdl->spe[splitdex]);
		}
		else
		{
			if (checkint) 
				sprintf(str,"%s%ld-\r\n",str2,result-fbufsize);
			else
				sprintf(str,"%s%ld-\r\n",str2,result);
		}
		sprintf(str2,"User: %s\r\n",cfg.name);
		strcat(str,str2);
		strcat(str,"User-agent: GetSmart/"VERSION"\r\n");
		sprintf(str2,"Progress: %ld\r\n",checkint ? mdl->lbytes-fbufsize:mdl->lbytes);
		strcat(str,str2);
		if (strcmp("anonymous",mir->nfo->user)||
			strcmp(cfg.Email,mir->nfo->pass))
		{
			sprintf(str2,"%s:%s",mir->nfo->user,mir->nfo->pass);
			Base64(str2,str3);
			sprintf(str2,"Identification: %s\r\n",str3);
			strcat(str,str2);
		}
		strcat(str,"\r\n");
		wb(str,1);
		send(ctrlsock,str,strlen(str),0);
		break;
	}
	return true;
}

int gsdl::ReadCtrl()
{
	if (status==3) return ReadData(ctrlsock);
	time(&timeout);
	if (!mdl->isdl)
		mdl->timeout=timeout;
	int ret=0;
	char res[AVGBUFSIZE*2],str[AVGBUFSIZE*2],buf3[AVGBUFSIZE*2],*tmp;
	if (mdl->spe[splitdex] && 
		((mdl->localbytes[splitdex]+mdl->sps[splitdex])>=(mdl->spe[splitdex]+1)))
	{
		RideOn();
		return 0;
	}
	ret=ReadSocket(ctrlsock,res,readbuff,readbuffi);
	if (ret<=0) return 0;
	GetLine(res,str);
	while (strlen(str))
	{
		while (*str==' ')
		{
			wb(str,4);
			GetLine(res,str);
		}
		if (!strlen(str))
			return ret;
		wb(str,2);
		strcpy(buf3,str);
		
		if ((status!=1) && !strnicmp(buf3,"GS/",3) && !httpres)
		{
			CloseSockets();
			status=0;
			ActOnStatus();
			return 0;
		}
		
		if ((status==1) && !strnicmp(buf3,"GS/",3))
		{
			char *tmp2;
			tmp2=strchr(buf3,32)+1;
			httpres=atoi(tmp2);
			
			resume=false;
			switch (httpres)
			{
			case 200:
				resume=true;
				if (!mdl->resume)
					mdl->resume=true;
				err[3]=0;
				status=2;
				mdl->MainFunc(1,this);
				break;
			case 302:
			case 301:
				status=2;
				//if (m->proxsock) logged=true;
				break;
			default:
				mdl->ErrMsg=ReDupString(mdl->ErrMsg,buf3);
				doerr(8);
				return 1;
			}
		}
		
		strcpy(str,"Send-range: ");
		if (!strnicmp(buf3,str,strlen(str)))
		{
			strcpy(str,buf3);
			tmp=strrchr(str,'-');
			*tmp='\0';
			unsigned cr=0;
			if (checkint) cr=fbufsize;
			if ((mdl->sps[splitdex]+mdl->localbytes[splitdex]-cr)!=(unsigned)atoi(strrchr(str,' ')+1))
			{
				TimedOut();
				return 0;
			}
			
			if (!mdl->rsize || !resume)
			{
				tmp=strchr(buf3,'/');
				if (tmp)
				{
					tmp++;
					if (!mdl->rsize)
					{
						mdl->rsize=atoi(tmp);
						log_size();
					}
					if (!mdl->spe[splitdex])
						mdl->spe[splitdex]=mdl->rsize-1;
				}
			}
		}
		
		if (!strncmp(buf3,"\r\n",2))
		{
			if (status!=2)
			{
				status=0;
				ActOnStatus();
				return 0;
			}
			status=3;
			if (!mdl->info)
			{
				if (resume) 
					mdl->resume=resume;
				mdl->info=true;
				SaveURLs();
			}
			if (resume && (!mdl->splitdex ||
				(mdl->dosplit>mdl->splitdex+1)))
				if (mdl->dosplit>1)
					mdl->ChangeSplit(mdl->dosplit);
				
			GetFN(str);
			if (fp)
			{
				fflush(fp);
				fclose(fp);
				fp=NULL;
			}
			if (readbuffi>0)
				if (ReadData(INVALID_SOCKET)==-2)
					return 0;
			readbuffi=0;
			strcpy(str,GetSTR(28,"Downloading file."));
			wb(str,0);
			wstatus(str);
			dds();
			return ret;
		}
		GetLine(res,str);
	}
	return ret;
}

void DoOffer(char *str,char *ip)
{
	char *tmp;
	char fn[2048],name[1024];
	tmp=strchr(str,'\r');
	if (!tmp) return;
	strncpy(fn,str+6,tmp-str-6);
	fn[tmp-str-6]='\0';
	tmp=strrchr(fn,' ');
	if (!tmp) return;
	*tmp='\0';
	memset(name,0,sizeof(name));
	tmp=strstr(str,"User: ");
	if (tmp)
		strncpy(name,tmp+6,strchr(tmp,'\r')-tmp-6);
	tmp=fn+strlen(fn)+1;
	strcpy(tmp,name);
	tmp+=strlen(tmp)+1;
	strcpy(tmp,ip);
#ifdef _WIN32
	DialogBoxParam(hinst,"GSDLACCEPT",Hgui,(DLGPROC)AcceptGSDL,(LPARAM)fn);
#endif
}


bool ChkAccess(SOCKET &sock,int sp)
{
	char str[10000],fn[10000],*tmp;
	int i,ret=recv(sock,str,sizeof(str),0);
	if (ret<=0) return false;
	str[ret]='\0';
	if (!strnicmp(str,"Update: ",8))
		return false;
	if (!strnicmp(str,"OFFER ",6))
	{
		char ip[100];
		unsigned char *d;
		SOCKADDR_IN sa;
		int ret=sizeof(SOCKADDR_IN);
		getpeername(sock,(SOCKADDR*)&sa,(OSsign int*)&ret);
		RMSelectSock(sock);
		closesocket(sock);
		//sock--;
		sock=INVALID_SOCKET;
		d=(unsigned char*)&sa.sin_addr.s_addr;
		sprintf(ip,"%d.%d.%d.%d",d[0],d[1],d[2],d[3]);
		DoOffer(str,ip);
		return false;
	}
	
	SOCKADDR_IN saddr;
	unsigned long fsize=0,fsps=0,fspe=0,progress=0;
	ret=sizeof(SOCKADDR_IN);
	memset(&saddr,0,sizeof(saddr));
	fn[0]='\0';
	getpeername(sock,(SOCKADDR*)&saddr,(OSsign int *)&ret);
	if (!strnicmp(str,"SEND ",5))
	{
		strcpy(fn,strchr(str,' ')+1);
		*strchr(fn,'\r')='\0';
		*strrchr(fn,' ')='\0';
	}

	gsdltable *dltmp=gsdlhead;
	while (dltmp)
	{
		if ((dltmp->ip==saddr.sin_addr.s_addr) && !strcmp(fn,dltmp->showfn))
			break;
		dltmp=dltmp->next;
	}
	if (dltmp)
	{
		sprintf(fn,"%s%s",dltmp->rdir,dltmp->rfn);
		FILE *fp0;
		fp0=fopen(fn,"rb");
		if (fp0)
		{
			fsize=GetFSize(fp0);
			fclose(fp0);
		}
	}
	if (!fsize)
		dltmp=NULL;
	if (!dltmp)
	{
		strcpy(str,"GS/"GSULVER" 400 Error\r\n\r\n");
		send(sock,str,strlen(str),0);
		RMSelectSock(sock);
		SockNBlock(sock);
		LINGER linger;
		linger.l_onoff=1;
		linger.l_linger=5;
		setsockopt(sock,SOL_SOCKET,SO_LINGER,(char *)&linger,sizeof(linger));
		shutdown(sock,2);
		closesocket(sock);
		//sock--;
		return false;
	}

	tmp=strstr(str,"Range: ");
	if (tmp)
	{
		tmp+=7;
		fsps=atoi(tmp);
		tmp=strchr(tmp,'-');
		if (tmp)
		{
			tmp++;
			fspe=atoi(tmp);
		}
	}

	tmp=strstr(str,"Progress: ");
	if (tmp)
		progress=atoi(tmp+10);

	if (!fspe)
		fspe=fsize-1;

	if (!dltmp->mdl)
	{
		char ip[20],bfn[1024];
		strcpy(bfn,fn);
		if (strstr(str,"User: "))
		{
			strcpy(fn,strstr(str,"User: ")+6);
			*strchr(fn,'\r')='\0';
			if (!strlen(fn))
				strcpy(fn,"Unknown");
		}
		else strcpy(fn,"Unknown");
		strcat(fn," <- ");
		strcat(fn,bfn);
		sprintf(ip,"%d.%d.%d.%d",(saddr.sin_addr.s_addr&0xff),
			(saddr.sin_addr.s_addr&0xff00)>>8,(saddr.sin_addr.s_addr&0xff0000)>>16,
			(saddr.sin_addr.s_addr&0xff000000)>>24);
		dltmp->mdl=AddURL(new dlnfo(2,ip,80,"anonymous",
		cfg.Email,dltmp->rdir,dltmp->rfn),"",
		fn,8,9,0,cfg.resumeto,DEFPR,0,false,false,0,0);
	}
	if (sp==-1)
	{
		for (i=0;i<=dltmp->mdl->splitdex+1;i++)
			if ((i==cfg.maxsplit) || (dltmp->mdl->splitdl[i]==NULL))
			{
				if ((i==cfg.maxsplit) || !dltmp->mdl->Cr8DL(dltmp->mdl->mirrorhead,i,-1,false))
				{
					strcpy(str,"GS/"GSULVER" 400 Error\r\n\r\n");
					send(sock,str,strlen(str),0);
					RMSelectSock(sock);
					SockNBlock(sock);
					LINGER linger;
					linger.l_onoff=1;
					linger.l_linger=5;
					setsockopt(sock,SOL_SOCKET,SO_LINGER,(char *)&linger,sizeof(linger));
					shutdown(sock,2);
					closesocket(sock);
					//sock--;
					return false;
				}
				((gsul*)dltmp->mdl->splitdl[i])->table=dltmp;
				break;
			}
	}
	else i=sp;

	sprintf(str,"GS/"GSULVER" 200 OK\r\nSend-range: %ld-%ld/%ld\r\n\r\n",fsps,fspe,fsize);
	send(sock,str,strlen(str),0);

	memcpy(&dltmp->mdl->splitdl[i]->ctrladdr,&saddr,sizeof(SOCKADDR_IN));
	if (!dltmp->mdl->rsize)
		dltmp->mdl->rsize=fsize;
	dltmp->mdl->sps[i]=fsps;
	dltmp->mdl->spe[i]=fspe;
	dltmp->mdl->localbytes[i]=0;
	dltmp->mdl->spdone[i]=0;
	dltmp->mdl->lbytes=progress;
	dltmp->mdl->splitdl[i]->ctrlsock=sock;
	dltmp->mdl->splitdl[i]->status=3;
	dltmp->mdl->logged=true;
	AddSelectSock(sock,dltmp->mdl->splitdl[i]->actpos);
	//WSAAsyncSelect(sock,hwndg,WM_USER+1+dltmp->mdl->splitdl[i]->actpos,(FD_READ|FD_WRITE|FD_CLOSE));
	dltmp->mdl->splitdl[i]->wstatus(GetSTR(345,"Sending file.."));
	((gsul*)dltmp->mdl->splitdl[i])->SendData(sock);
	return true;
}

void gsul::ChkReq(SOCKET sock)
{
	ChkAccess(sock,-1);
}

int gsul::ReadCtrl()
{
	time(&timeout);
	if (!mdl->isdl)
		mdl->timeout=timeout;
	if (mdl->spdone[splitdex])
	{
		ChkAccess(ctrlsock,splitdex);
		return 0;
	}
	int ret;
	char res[AVGBUFSIZE*2],str[AVGBUFSIZE*2],*tmp;
	ret=ReadSocket(ctrlsock,res,readbuff,readbuffi);
	if (ret<=0) return 0;
	GetLine(res,str);
	while (strlen(str))
	{
		if (strstr(str,"Update: "))
		{
			tmp=str+8;
			mdl->spe[splitdex]=atoi(tmp);
		}
		GetLine(res,str);
	}
	return ret;
}

bool gsul::ActOnStatus()
{
	return 0;
}

void gsul::ActOnClose(SOCKET sock)
{
	KillDL();
}

void gsul::ActOnWrite(SOCKET sock)
{
	if (status==3) SendData(ctrlsock);
}

int gsul::SendData(SOCKET sock)
{
	time(&timeout);
	isdl=true;
	mdl->isdl=true;
	mdl->timeout=timeout;
	if (!mir->info)
	{
		time_t tp;
		time(&tp);
		mir->resume=resume;
		mir->rsize=mdl->rsize;
		mir->time2dl=tp-time2dl;
		mir->info=true;
		mir->status=ReDupString(mir->status,
			GetSTR(86,"This is the main mirror. It works fine."));
		dds();
		mdl->UpdateMirStatus();
	}
	int ret=0,r;

//	** calc cps 
	unsigned long tc=GetTickCount();
	calcid++;
	globalcpsinfo=0;
	gdlcpsinfo=0;
	gbrcpsinfo=0;
	for (r=0;r<=lastact;r++)
		if (actdls[r] && (actdls[r]->hamdex==-1))
			actdls[r]->CalcCps(tc);
	globalcps=globalcpsinfo;
	gdlcps=gdlcpsinfo;
	gbrcps=gbrcpsinfo;

//	** speed limit
	if (sock!=INVALID_SOCKET)
		if (speedlimit && (cps>speedlimit) ||
			mdl->speedlimit && (mdl->cps>mdl->speedlimit) ||
			cfg.speedlimit && (globalcps>cfg.speedlimit) ||
			cfg.dlspeedlimit && (gdlcps>cfg.dlspeedlimit) && 
			(!cfg.slonlyifbr || activebr))

		{
			read=true;
			pause=true;
			return 0;
		}
	r=0;
	char str[1024];
	err[9]=0;
	//char *buf;
	/*
	tc=BUFSIZE;
	if (speedlimit && (speedlimit/2<tc)) tc=speedlimit/4;
	if (mdl->speedlimit && (mdl->speedlimit/2<tc)) tc=mdl->speedlimit/4;
	if (cfg.speedlimit && (cfg.speedlimit/2<tc)) tc=cfg.speedlimit/4;
	if (!tc) tc=1;
	*/
	read=false;
	pause=false;
	sprintf(str,"%s%s",mir->nfo->rdir,mir->nfo->rfn);
	char buf[50010];
	unsigned long cr,getbytes;
#ifdef _WIN32
		cr=1460;
#endif // win
#ifdef __unix__
		cr=1460;
#endif
		if (cr<=0) return cr;
		cr+=100;
		if (cr>50000) cr=50000;
		getbytes=cr;///2+1;
		if (maxrb<getbytes)
		{
	//		grbuf=(char *)realloc(grbuf,getbytes);
			maxrb=getbytes;
		}
	else getbytes=cfg.rbufsize/2;
	//buf=grbuf;

	for(;;)
	{
		if (mdl->spe[splitdex] && 
			((mdl->localbytes[splitdex]+mdl->sps[splitdex]+getbytes)>(mdl->spe[splitdex]+1)))
			getbytes=mdl->spe[splitdex]-mdl->sps[splitdex]+1-mdl->localbytes[splitdex];
		fp=fopen(str,"rb");
		if (!fp)
		{
			doerr(11);
			return 0;
		}

		fseek(fp,mdl->sps[splitdex]+mdl->localbytes[splitdex],SEEK_SET);
		fread(buf,1,getbytes,fp);	
		ret=send(sock,buf,getbytes,0);
		fclose(fp);
		fp=NULL;
		pause=false;
		if ((ret<=0))
		{
			if (fp) fclose(fp);
			fp=NULL;
			//free(buf);
			return ret;
		}
			
		if (!mdl->sessionbytes[splitdex])
		{
			time(&starttime);
			if (!mdl->starttime) mdl->starttime=starttime;
		}
		readcount+=ret;
		mdl->localbytes[splitdex]+=ret;
		mdl->lbytes+=ret;
		mdl->sessionbytes[splitdex]+=ret;
		mdl->sbytes+=ret;
		if (mdl->localbytes[splitdex] && mdl->spe[splitdex] && 
			((mdl->localbytes[splitdex]+mdl->sps[splitdex])>=(mdl->spe[splitdex]+1)))
		{
			GetFN(str);
			/*		fp=fopen(str,"rb");
			if (mdl->localbytes[splitdex]!=GetFSize(fp))
			{
			int dg;
			dg=1;
			}
			fclose(fp);
			fp=NULL;*/
			mdl->spdone[splitdex]=true;
			//mdl->lbytes+=mdl->spe[splitdex]-mdl->sps[splitdex]+1-mdl->localbytes[splitdex];
			//mdl->localbytes[splitdex]=mdl->spe[splitdex]-mdl->sps[splitdex]+1;
			//if (ISFTP(this) && mdl->spe && ((mdl->spe[splitdex]+1)<mdl->rsize))
			//AbortFTP();
			if (fp) fclose(fp);
			fp=NULL;
			//free(buf);
			//RideOn();
			return -2;
		}
		if (fp) fclose(fp);
		fp=NULL;
	}
	//free(buf);
	return ret;
}

#ifdef _WIN32
BOOL CALLBACK AcceptGSDL(HWND hdwnd, UINT message,
                         WPARAM wParam, LPARAM lParam)
{
	char str[1024];
	switch(message)
	{
	case WM_INITDIALOG:
		if (lParam)
		{
			char *tmp;
			tmp=(char*)lParam;
			SetDlgItemText(hdwnd,IDD_REQ,tmp);
			tmp+=strlen(tmp)+1;
			SetDlgItemText(hdwnd,IDD_NAME,tmp);
			tmp+=strlen(tmp)+1;
			SetDlgItemText(hdwnd,IDD_IP,tmp);
		}
		GetExtDir(str,"");
		strcat(str,(char*)lParam);
		SetDlgItemText(hdwnd,IDD_FILE,str);
		return 1;

	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDD_BROWSE:
			OPENFILENAME ofn;
			char dh[MAX_PATH], *tmp;
			GetDlgItemText(hdwnd,IDD_FILE,str,1000);
			tmp=strrchr(str,'\\');
			if (tmp) tmp++;
			sprintf(dh,"%s",tmp);
			if (tmp) tmp[0]=0;
			else str[0]='\0';
			memset(&ofn,0,sizeof(ofn));
			ofn.lStructSize=sizeof(ofn);
			ofn.hwndOwner=hdwnd;
			ofn.hInstance=hinst;
			ofn.lpstrFile=dh;
			ofn.nMaxFile=MAX_PATH;
			ofn.lpstrInitialDir=str;
			ofn.Flags=OFN_PATHMUSTEXIST;
			//ofn.lpstrDefExt="";
			if (GetSaveFileName(&ofn))
			{
				SetDlgItemText(hdwnd,IDD_FILE,ofn.lpstrFile);
			}
			return 1;
		case IDCANCEL:
			EndDialog(hdwnd, 0);
			return 1;
		case IDOK:
			char reqname[1024],dir[1024],fn[1024];
			GetDlgItemText(hdwnd,IDD_REQ,reqname,1024);
			GetDlgItemText(hdwnd,IDD_FILE,str,1024);

			tmp=strrchr(str,'\\');
			if (tmp)
			{
				tmp++;
				strcpy(fn,tmp);
				*tmp='\0';
				strcpy(dir,str);
			}
			else
			{
				strcpy(fn,str);
				dir[0]='\0';
			}
			GetDlgItemText(hdwnd,IDD_IP,str,1000);
			maindl *mdl;
			mdl=AddURL(new dlnfo(2,str,GSULPORT,"anonymous",
				cfg.Email,"",reqname),dir,
				fn,7,9,0,cfg.resumeto,DEFPR,0,false,false,0,0);
			if (mdl!=NULL)
				mdl->ActMain(true);
			EndDialog(hdwnd, 1);
			return 1;
		}
		return 0;
	}
	return 0;
}
#endif
