
#ifdef _WIN32

#ifndef _WINSOCKAPI_
#define _WINSOCKAPI_   /* Prevent inclusion of winsock.h in windows.h */ 
#endif 
#include <windows.h>
#include <winsock2.h>
#include <ras.h>
#include <raserror.h>
//#include <winsock.h>
#include <crtdbg.h>
// Macros for setting or clearing bits in the CRT debug flag 
#ifdef _DEBUG
#define _CRTDBG_MAP_ALLOC
#define  SET_CRT_DEBUG_FIELD(a)   _CrtSetDbgFlag((a) | _CrtSetDbgFlag(_CRTDBG_REPORT_FLAG))
#define  CLEAR_CRT_DEBUG_FIELD(a) _CrtSetDbgFlag(~(a) & _CrtSetDbgFlag(_CRTDBG_REPORT_FLAG)
#define malloc(recSize) _malloc_dbg(recSize, _NORMAL_BLOCK, __FILE__, __LINE__)
#define _new_dbg new(_NORMAL_BLOCK, __FILE__, __LINE__)
#define new _new_dbg
/*#else
#define  SET_CRT_DEBUG_FIELD(a)   ((void) 0)
#define  CLEAR_CRT_DEBUG_FIELD(a) ((void) 0)*/
#endif
#include <io.h>
#endif // _WIN32
#ifdef __unix__
#ifndef __linux__
#warning __ Only tested on Linux systems! __
#endif // __linux__
#include <stdlib.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <netinet/in.h>
#include <errno.h>
#include <signal.h>
#include <glob.h>
//#include <sys/un.h>
//#include <string.h>
#include <sys/time.h>

#include <unistd.h>
#include <sys/stat.h>

#include "../UnixWin32defs.h"
#endif // __unix__
#include <time.h>
#include <stdio.h>
#include <string.h>
#include "../DiffOS.h"

#ifndef _Dmain_H
#define _Dmain_H

//#define gsdbg
//#define time(a) {}

#define VERSION "0.9 Build 08"
#define SVERSION 0.90008
#define GSULVER "0.11"
#define GSULPORT 9027

#ifdef _this_is_main_
#define EXTERN
#else
#define EXTERN extern
#endif

#define DEFPR 3

#define TOPMAXSPLIT 100
#define MAXHAMMER 4
#define MAXERROR 15
#define AVGBUFSIZE 1460
#define MAXDNSTABLE 500
#define PINGNUM 10
#define MAXSTATUS 80
#define TOPMAXBUFFER 75

EXTERN bool isGUI;
EXTERN short gid;

#ifdef _WIN32
EXTERN HWND Hgui,Hserv;
#define WM_G_HWND WM_USER+3000
#define TELLGUI(msg,p1,p2)\
if (isGUI) PostMessage(Hgui,msg+WM_USER+3000,(WPARAM) p1,(LPARAM) p2)
#define STELLGUI(msg,p1,p2)\
if (isGUI) SendMessage(Hgui,msg+WM_USER+3000,(WPARAM) p1,(LPARAM) p2)
#define TELLDAEMON(msg,p1,p2)\
PostMessage(Hserv,msg+WM_USER+3000,(WPARAM) p1,(LPARAM) p2)
#define STELLDAEMON(msg,p1,p2)\
SendMessage(Hserv,msg+WM_USER+3000,(WPARAM) p1,(LPARAM) p2)
#endif

#ifdef __unix__
     //EXTERN HWND Hgui,Hserv;
     //#define WM_G_HWND WM_USER+3000
#define TELLGUI(msg,p1,p2)\
     if (isGUI) printf("not imp\n")
#define TELLDAEMON(msg,p1,p2)\
     if (isGUI) printf("not imp\n")
//PostMessage(Hgui,msg+WM_USER+3000,(WPARAM) p1,(LPARAM) p2)
#define STELLGUI(msg,p1,p2)\
if (isGUI) printf("not imp\n")
//SendMessage(Hgui,msg+WM_USER+3000,(WPARAM) p1,(LPARAM) p2)
//#define TELLDAEMON(msg,p1,p2)\
//PostMessage(Hserv,msg+WM_USER+3000,(WPARAM) p1,(LPARAM) p2)
//#define STELLDAEMON(msg,p1,p2)\
//SendMessage(Hserv,msg+WM_USER+3000,(WPARAM) p1,(LPARAM) p2)
#endif


#define MDL_ADD 1 // mdl
#define MDL_START 2 // mdl
#define MDL_STOP 3 // mdl
#define MDL_RM 4 // bdl
#define BDL_START 5 // bdl
#define BDL_STOP 6 // bdl
#define BUFF_ADD 7 // bdl
#define BUFF_RM 8 // bdl
// GOT_URL 10
#define UPDATE_MDL 11 //mdl
#define SERVER_RM 12 //mdl
#define MIRROR_RM 13 //mdl
#define SHOW_TIP 14 //string
#define GBR_CLEAN 15 //mdl
#define GBR_START 16 //mdl
#define GBR_END 17 //mdl
#define GBR_ADDITEM 18 //mdl, list
#define GBR_UPDATE 19
#define TASK_CRASH 20 
#define UPDATE_BAR 21
#define MK_NEW_BOX 22


#define CHANGE_SPLIT 1 // mdl , new split
#define START_MDL 2 // mdl
#define STOP_MDL 3 // mdl
#define START_BDL 4 // mdl , split / ham
#define STOP_BDL 5 // mdl , split / ham
#define STOP_ALL 6
#define RM_MDL 7 // mdl
#define ROBOT_ST 9 // mdl , 0 - off / 1 - on / 2 - set wait on mdl
#define GOT_URL 10 // url as a malloc
#define SEARCH_MIR 11 //mdl
#define CHECK_MIR 12 // mir
#define STOPALL_MIR 13 //mdl
#define STOP_MIR 14 // mir
#define REMOVE_MIR 15 // mir
#define REMOVEBAD_MIR 16 // mir
#define INCREASE_MIR 17 //mir
#define DECREASE_MIR 18 //mir
#define ADD_MIR 19 //mdl,url
#define BR_CONNECT 20 // mdl
#define BR_DISCONNECT 21 // mdl
#define BR_KILL 22 // mdl
#define BR_CHDIR 23 // mdl
#define BR_REFRESH 24 // mdl
#define BR_CUSTOM 25 // mdl
#define DIAL 26
#define GOT_IP 27 // ip string as a malloc
#define OFFER_FILE 28 // ptr to gsdltbale, user name

#define WM_G_DESTROYGUI WM_USER+3054
#define WM_G_DESTROY    WM_USER+3055
#define WM_D_DESTROY    WM_USER+3056

// prototypes:
char *DupString(char *lpsz
#ifdef _DEBUG
               , const char *srcFile, int srcLine
#endif				
);
#ifdef _DEBUG
#define  DupString(s)\
         DupString(s,__FILE__, __LINE__)
#endif
//char* DupString(char *lpsz);
char* ReDupString(char *s,char *lpsz);
void GetLangSTR(int n,char *str);
char *GetSTR(int n,char*s);
void dds();
char *GetSTR2(int n,char*s);
void dds2();
int SaveURLs();


#define XORSWAP(a,b) {(a)^=(b);(b)^=(a);(a)^=(b);}

#define MIRVALID(mir)\
	(((mir==mir->mdl->mirrorhead) || (mir->rsize && (mir->rsize==mir->mdl->rsize) && mir->resume)) && \
	!mir->en && mir->active && !mir->relocation)
#define ISHTTP(bdl) ((bdl->mir->nfo->prot==2) || (bdl->useproxy==2))
#define ISFTP(bdl) (!ISHTTP(bdl))

struct TimeStruct{
	//unsigned short Y,M,DOW,D,h,min,sec,msec;
	int sec,min,h,D,M,Y,DOW,DOY,isdst;
	void Init()
	{
		time_t td;
		time(&td);
		struct tm *tt;
		if (tt=localtime(&td))
		{
			sec=tt->tm_sec;min=tt->tm_min;h=tt->tm_hour;D=tt->tm_mday;
			M=tt->tm_mon;Y=tt->tm_year;DOW=tt->tm_wday;DOY=tt->tm_yday;
			isdst=tt->tm_isdst;
		}
		
	}
	unsigned long DayDiff()
	{
		time_t beg,td;
		//struct  tm tmbeg;
		time(&td);
/*		tmbeg.tm_sec=sec;
		tmbeg.tm_min=min;
		tmbeg.tm_hour=h;
		tmbeg.tm_mday=D;
		tmbeg.tm_mon=M;
		tmbeg.tm_year=Y;
		tmbeg.tm_wday=DOW;
		tmbeg.tm_yday=0;
		tmbeg.tm_isdst=0;*/
		beg=mktime((struct tm*)this);
		return (td-beg)/86400;
	}
};

class dlnfo
{
public:
	char*host,*rdir,*rfn,*user,*pass,prot;
	unsigned short port;
	dlnfo(int prot0,char *addr0,int port0, char *user0,
		   char *pass0,char *rdir0,char *rfn0)
	{
		prot=prot0;
		user=DupString(user0);
		pass=DupString(pass0);
		host=DupString(addr0);
		port=port0;
		rdir=DupString(rdir0);
		rfn=DupString(rfn0);
	}
	dlnfo(dlnfo*n)
	{
		prot=n->prot;
		user=DupString(n->user);
		pass=DupString(n->pass);
		host=DupString(n->host);
		port=n->port;
		rdir=DupString(n->rdir);
		rfn=DupString(n->rfn);
	}
	~dlnfo()
	{
		free(host);free(rdir);
		free(rfn);free(user);free(pass);
	}
};

//EXTERN dlnfo *gnfo;

struct cpsinfo_tag
{
	unsigned long tick;
	unsigned long bytes;
};

struct maincpsinfo_tag
{
	unsigned long tick;
	unsigned char sp;
	unsigned long cps;
};

struct proxy_tag
{
	char*HHost,*FHost,*sockshost,*socksuser;
	unsigned short HTTPP,HTTPT,FTPP,FTPT,socksport;
	bool UseHTTP,UseFTP,OnlyProxy,HTTP4FTP,SmartProxy,Passive,socks;
	char huser[100],hpass[100],fuser[100],fpass[100];
	bool nocache;
};

#ifdef __unix__
#define RAS_MaxEntryName 1
#define RAS_MaxPhoneNumber 1
#define UNLEN 1
#define PWLEN 1
#endif // __unix__
struct dial_tag
{
	char Entry[RAS_MaxEntryName+1],Phone[15][RAS_MaxPhoneNumber+1],
		User[UNLEN+1],Pass[PWLEN+1];
	int Subi,TO,Busy,Pause,LongPause,MaxLong;
	bool Use,reconnect,pulse;
};

//#ifdef __unix__
//#define SYSTEMTIME long
//#endif
struct schedule_tag
{
	bool EDL,UseDLDate,DOW[7],HangFinish,Redial;
	tm StartDL,DLDate;
	bool EHU,UseHUDate;
	tm StartHU,HUDate;
};

struct beproxy_tag
{
	bool use;
	unsigned long ip;
	unsigned short port,to,dosplit;
	unsigned long minsize;
};

struct errors
{
	time_t t;
	int en,c[100];
};

struct mirsite;

struct mirr_tag
{
	bool autosearch;
	short maxmirchecks,maxmirget;
	unsigned char d,m;unsigned short y;
	mirsite *mirshead;
	time_t killtime;
	mirr_tag()
	{
		mirshead=NULL;
	}
};

struct cfg_tag
{
  bool hidepass,robot,solveonfull,checkint,checksmallint,keepsplit,
	usemaxbusytime,usemaxbusyretry,usemaxhammertime,usemaxhammerretry,
	hammerfallback,usehammer,runexternal,useretry,disconnect,startdl,
	startdef,checkonadd,lang,istmpdir,multilog,logwdl,
	slonlyifdl,slonlyifbr,shutdown,usegsul,referer,uuagent;
	unsigned long intsmallsize,flushsize,intsize,maxbusyretry,
					maxhammerretry,maxactive,externalshow,
					speedlimit,dlspeedlimit,brspeedlimit,r2l,rbufsize;
	unsigned short maxhammer,defsplit,maxsplit,maxsocks,sdmaxdl,
					sdmaxcon,sdmaxeach;
	proxy_tag Proxy;
    dial_tag Dial;
    schedule_tag Schedule;
	beproxy_tag beproxy;
	mirr_tag mirr;
	char*Email,*emdir,*asciiext,*catchext,*externalfile,
			*externalparams,*tmpdir,*stamp,*logdir,*logfn,
			*langfn,*name,*uagent,*updsite;
	time_t nohammerbusydelay,maxbusytime,resumeto,noresumeto,
			maxhammertime;
};

class maindl;
class basicdl;
class mirrors;
class server;
class buffer;

struct actmdls_tag{
	unsigned short split;
	double sp;
	maindl*mdl;
};
EXTERN actmdls_tag actmdls[1024];
EXTERN short lastmact;

EXTERN cfg_tag cfg;
server *GetSer(char *host);

struct mirsite
{
	char *url;
	bool normal,use;
	mirsite *next;
	mirsite(char *url0,bool norm)
	{
		url=DupString(url0);
		normal=norm;
		use=true;
		next=NULL;
		if (cfg.mirr.mirshead==NULL)
			cfg.mirr.mirshead=this;
		else
		{
			mirsite *tmp=cfg.mirr.mirshead;
			while (tmp->next)
				tmp=tmp->next;
			tmp->next=this;
		}
	}
	~mirsite()
	{
		free(url);
		if (cfg.mirr.mirshead==this)
			cfg.mirr.mirshead=next;
		else
		{
			mirsite *tmp=cfg.mirr.mirshead;
			while (tmp->next!=this)
				tmp=tmp->next;
			tmp->next=this->next;
		}
	}
};

struct sort_tag
{
	unsigned short f,i;
};

class server
{
private:
	void AddItem();
	void RMItem();
public:
	server *next,*prev;
	char *host,*busymsg;
	unsigned long dls;
	unsigned short actdl,actcon,maxdl,maxcon,logged,en,maxeach;
	basicdl *bdlhead,*bdllast;
	mirrors *mirhead,*mirlast;
	bool only1ip,perm;
	time_t errtime;
	void *guiparam;
	server(char *host0)
	{
		host=DupString(host0);
		next=NULL;
		prev=NULL;
		busymsg=NULL;
		mirhead=NULL;
		mirlast=NULL;
		bdlhead=NULL;
		bdllast=NULL;
		logged=0;
		dls=0;
		actdl=0;
		actcon=0;
		maxdl=cfg.sdmaxdl;
		maxcon=cfg.sdmaxcon;
		maxeach=cfg.sdmaxeach;
		en=0;
		errtime=0;
		guiparam=NULL;
		only1ip=false;
		perm=false;
		AddItem();
	}
	~server()
	{
		free(host);
	}
	void DelSer()
	{
		RMItem();
		STELLGUI(SERVER_RM,this,0);
		else delete this;
	}
};

class mirrors
{
private:
	void AddItem(maindl *mdl);
	void RMItem(maindl *mdl);
public:
	maindl *mdl,*rmdl,*pmdl;
	mirrors *next,*prev;
	mirrors *sernext,*serprev;
	server *ser;
	dlnfo *nfo;
	bool info,resume,only1ip,ischeck,isping,active,relocation;
	void *guiparam;
	unsigned long rsize,pingsum,ping;
	time_t time2dl,update,errtime;
	unsigned short pinglost,pingcount,used,en,pingtry;
	char *status;
	mirrors(dlnfo *nfo0,maindl* mdl0)
	{
		nfo=new dlnfo(nfo0);
		ser=GetSer(nfo0->host);
		next=NULL;
		prev=NULL;
		guiparam=NULL;
		active=true;
		rsize=0;
		mdl=mdl0;
		info=false;
		ischeck=false;
		isping=false;
		resume=false;
		time2dl=0;
		update=0;
		ping=0;
		pinglost=0;
		used=0;
		only1ip=false;
		rmdl=NULL;
		pmdl=NULL;
		en=0;
		errtime=0;
		pingcount=0;
		pingsum=0;
		pingtry=0;
		status=DupString(GetSTR(79,"Not verified yet"));
		dds();
		Add2Ser();
		relocation=false;
		AddItem(mdl0);
	}
	~mirrors()
	{
		free(status);
		delete nfo;
	}
	void DelMir()
	{
		RMfSer();
		RMItem(mdl);
		STELLGUI(MIRROR_RM,this,0);
		else delete this;
	}
	void Check();
	void Ping();
	bool NextPing(basicdl *bdl);
	void Add2Ser();
	void RMfSer();
};

struct component;

EXTERN component *cmphead;

struct component
{
	int id;
	double ver;
	char *name,*uver;
	component *next;
	component(int id0,double ver0,char *name0,char *uver0)
	{
		id=id0;
		ver=ver0;
		name=DupString(name0);
		uver=DupString(uver0);
		next=NULL;
		if (cmphead==NULL)
			cmphead=this;
		else
		{
			component *tmp=cmphead;
			while (tmp->next)
				tmp=tmp->next;
			tmp->next=this;
		}
	}
	~component()
	{
		free(name);
		free(uver);
		if (cmphead==this)
			cmphead=next;
		else
		{
			component *tmp=cmphead;
			while (tmp->next!=this)
				tmp=tmp->next;
			tmp->next=next;
		}
	}
};

class server;

class maindl
{
private:
	void AddItem();
	void RMItem();
public:
	maindl*next,*prev,*smdl;
	mirrors *mirrorhead,*mirrorlast;
	short type,splitdex,spliton,hamdex,hamon,dosplit,
			useproxy,ftpmode,prior,mirchecks,actpos,id,searchsite,reschk;
	char *ErrMsg,*stamp,*lfn,*ldir,mstxt[MAXSTATUS],
		*bstxt[TOPMAXSPLIT+MAXHAMMER],mirstatus[80],*proxbuf,*reqbuf;
	basicdl*splitdl[TOPMAXSPLIT],*hamdl[MAXHAMMER],*busydl;
	unsigned long rsize,sps[TOPMAXSPLIT],spe[TOPMAXSPLIT],
				   sessionbytes[TOPMAXSPLIT],localbytes[TOPMAXSPLIT],
				   sessionlost,locallost,retries,lbytes,sbytes,
				   cps,pingtime,speedlimit;
	bool resume,busysite,spdone[TOPMAXSPLIT],info,logged,
			wasactive,usehammer,useretry,usemaxhammerretry,
			usemaxhammertime,usemaxbusyretry,usemaxbusytime,
			mirsearch,istmpdir,checkint,smallint,wait,isdl,done,killonstop;
	time_t starttime,timeout,maxresumetimeout,busytimestarted,
			totaltime;
	void*guiparam;
	errors error;
	TimeStruct instime,begtime;
	maincpsinfo_tag cpsinfo;
	buffer *buffhead,*bufflast;
	SOCKET proxsock;
#ifdef _WIN32
	HWND hcatch;
#endif
	maindl(dlnfo*nfo0,char *ldir0,char *lfn0,short type0)
	{
		ldir=DupString(ldir0);
		lfn=DupString(lfn0);
		memset(&begtime,0,sizeof(TimeStruct));
		instime.Init();
		istmpdir=cfg.istmpdir;
		stamp=DupString(cfg.stamp);
#ifdef _WIN32
		hcatch=NULL;
#endif
		retries=0;
		cps=0;
		speedlimit=0;
		memset(&cpsinfo,0,sizeof(cpsinfo));
		memset(&error,0,sizeof(errors));
		mirrorhead=NULL;				
		mirrorlast=NULL;
		type=type0;
		splitdex=0;spliton=0;hamdex=-1;hamon=0;dosplit=0;
		useproxy=0;
		ftpmode=0;
		lbytes=0;
		sbytes=0;
		wait=false;
		killonstop=false;
		proxsock=INVALID_SOCKET;
		memset(splitdl,0,sizeof(splitdl));
		memset(hamdl,0,sizeof(hamdl));
		busydl=NULL;
		buffhead=NULL;
		bufflast=NULL;
		proxbuf=NULL;
		smdl=NULL;
		rsize=0;
		reschk=0;
		memset(sps,0,sizeof(sps));memset(spe,0,sizeof(spe));
		memset(sessionbytes,0,sizeof(sessionbytes));
		memset(localbytes,0,sizeof(localbytes));
		sessionlost=0,locallost=0;
		resume=false,busysite=false,
		memset(spdone,false,sizeof(spdone));
		info=false,logged=false;
		starttime=0;
		totaltime=0;
		ErrMsg=DupString("");
		guiparam=NULL;
		prior=DEFPR;
		timeout=0;
		isdl=false;
		maxresumetimeout=0;
		wasactive=false;
		busytimestarted=0;
		usehammer=false;
		useretry=false;
		usemaxbusytime=false;
		usemaxbusyretry=false;
		usemaxhammertime=false;
		usemaxhammerretry=false;
		mirchecks=0;
		mirsearch=false;
		pingtime=0;
		searchsite=0;
		strncpy(mstxt,GetSTR(65,"Paused"),MAXSTATUS);
		strncpy(mirstatus,GetSTR(75,"Nothing to do."),80);
		dds();
		reqbuf=DupString("");
		id=gid++;
		for (int i=0;i<TOPMAXSPLIT+MAXHAMMER;i++)
			bstxt[i]=NULL;
		done=false;
		new mirrors(nfo0,this);
		if (type==1) mirrorhead->ser->dls++;
		AddItem();
		delete nfo0;
		STELLGUI(MDL_ADD,this,0);
	}
	void Clear()
	{
		memset(&begtime,0,sizeof(TimeStruct));
		istmpdir=cfg.istmpdir;
		retries=0;
		cps=0;
		memset(&cpsinfo,0,sizeof(cpsinfo));
		memset(&error,0,sizeof(errors));
		splitdex=0;spliton=0;hamdex=-1;hamon=0;dosplit=0;
		useproxy=0;
		ftpmode=0;
		lbytes=0;
		sbytes=0;
		wait=false;
		memset(splitdl,0,sizeof(splitdl));
		memset(hamdl,0,sizeof(hamdl));
		busydl=NULL;
		rsize=0;
		memset(sps,0,sizeof(sps));memset(spe,0,sizeof(spe));
		memset(sessionbytes,0,sizeof(sessionbytes));
		memset(localbytes,0,sizeof(localbytes));
		sessionlost=0,locallost=0;
		resume=false,busysite=false,
		memset(spdone,false,sizeof(spdone));
		info=false,logged=false;
		starttime=0;
		prior=DEFPR;
		timeout=0;
		isdl=false;
		maxresumetimeout=0;
		wasactive=false;
		busytimestarted=0;
		usehammer=false;
		useretry=false;
		usemaxbusytime=false;
		usemaxbusyretry=false;
		usemaxhammertime=false;
		usemaxhammerretry=false;
		mirchecks=0;
		pingtime=0;
		mirsearch=false;
		done=false;
	}
	void delmdl()
	{
		StopAllMir();
		if (type==1) mirrorhead->ser->dls--;
		mirrors *tmp=mirrorhead;
		while (tmp)
		{
			tmp->RMfSer();
			tmp=tmp->next;
		}
		RMItem();
		SaveURLs();
		strncpy(mstxt,GetSTR(66,"Download complete."),MAXSTATUS);
		dds();
		STELLGUI(MDL_RM,this,0);
		else delete this;
		// tell gui we killed mdl
	}
	void DelBuffer();
	~maindl()
	{
		mirrors *tmp=mirrorhead,*tmp2;
		while (tmp)
		{
			tmp2=tmp;
			tmp=tmp->next;
			tmp2->DelMir();
		}
		for (int i=0;i<TOPMAXSPLIT+MAXHAMMER;i++)
			if (bstxt[i]!=NULL)
				free(bstxt[i]);
		DelBuffer();
		free(ldir);
		free(lfn);
		free(stamp);
		free(ErrMsg);
		free(reqbuf);
		if (proxbuf!=NULL)
			free(proxbuf);
	}
	void MainFunc(int tp,basicdl *dl);
	void log_start();
	void log_end();
	void log_wr(char*s,bool iser);
	void DoSplit(int sp);
	bool ActMain(bool start);
	bool Cr8DL(mirrors *mir,int sp,int hm,bool start);
	void RideOnSplit(int sp,SOCKET &hsock,mirrors* mir);
	void BuildSplit();
	bool DoKeepSplit(basicdl *bdl,SOCKET &hsock,bool force);
	int ChangeSplit(int newsp);
	void CheckExist();
	void KillMain();
	mirrors *GetBestMirror();
	void Search4Mir();
	basicdl *FindLSS(mirrors *mir);
	void StopAllMir();
	void StartMirrorCheck();
	void IsStartCheck();
	void UpdateMirStatus();
	short GetMirProxy(mirrors *mir,short type);
	bool Chk4Del();
};

class basicdl
{
public:
	maindl*mdl;
	basicdl *sernext,*serprev;
	unsigned short httpres,lastcmd[2];
	short useproxy,status,type,splitdex,hamdex,actpos,id;
	unsigned long contretry,busyretry,fbufsize,readbuffi,readcount,
		intsmallsize,intsocksize,err[MAXERROR],cps,txtpos,buffcount,
		pingtime,speedlimit;
	bool resume,pause,read,firectrl,firedata,checkint,abort,
		hammerpause,busy,relocation,multipart,keepalive,logged,isdl,
		firstread,killonstop;
#ifdef _WIN32
	HANDLE gethosthnd;
#endif
#ifdef __unix__
	int gethosthnd; // pipe input?
#endif
	FILE*fp;
	char*readbuff,*gethostbuff,que[10][40],*cwd, *boundary;
	SOCKET ctrlsock,datasock,pingsock,listensock;
	SOCKADDR_IN ctrladdr,fireaddr,pasvaddr;
	void*guiparam;
	time_t timeout,starttime,time2dl,lastbusyretry;
	mirrors *mir;
	long quedex;
	cpsinfo_tag cpsinfo[500];
	buffer *buffhead,*bufflast;
	basicdl()
	{
		memset(err,0,sizeof(err));
		sernext=NULL;
		serprev=NULL;
		mdl=NULL;
		status=0;
		cps=0;
		speedlimit=0;
		memset(cpsinfo,0,sizeof(cpsinfo));
		isdl=false;
		id=gid++;
		logged=false;
		killonstop=false;
		splitdex=-1;
		hamdex=-1;
		contretry=0;
		httpres=0;
		busyretry=0;
		useproxy=0;
		resume=false;
		firstread=true;
		pause=true;
		fp=NULL;
		readbuff=NULL;
		readbuffi=0;
		guiparam=NULL;
		ctrlsock=INVALID_SOCKET;
		pingsock=INVALID_SOCKET;
		listensock=INVALID_SOCKET;
		memset(&ctrladdr,0,sizeof(ctrladdr));
		memset(&fireaddr,0,sizeof(fireaddr));
		memset(&pasvaddr,0,sizeof(pasvaddr));
		gethosthnd=0;
		readcount=0;
		read=false;
		gethostbuff=NULL;
		firectrl=false;
		fbufsize=0;
		abort=false;
		time2dl=0;
		memset(lastcmd,0,sizeof(lastcmd));
		mir=NULL;
		pingtime=0;
		quedex=-1;
		memset(que,0,sizeof(que));
		datasock=INVALID_SOCKET;
		cwd=DupString("");
		firedata=false;
		hammerpause=false;
		busy=false;
		lastbusyretry=0;
		relocation=false;
		multipart=false;
		boundary=NULL;
		keepalive=false;
		buffcount=0;
		buffhead=NULL;
		bufflast=NULL;
	}
	void delbdl()
	{
		// tell gui to upd mir table.
		if (!mdl->spliton)
		{
			if (mdl->buffhead!=NULL)
				mdl->DelBuffer();
			mdl->buffhead=buffhead;
			mdl->bufflast=bufflast;
			buffhead=NULL;
			bufflast=NULL;
		}
		if (mir->ser!=NULL) RMfSer();
		if (readbuff) free(readbuff);
		if (gethostbuff) free(gethostbuff);
		STELLGUI(BDL_STOP,this,0);
		else delete this;
	}
	void DelBuffer();
	virtual ~basicdl()
	{
		if (cwd) free(cwd);
		if (boundary) free(boundary);
		DelBuffer();
	}
	void Clear()
	{
		memset(err,0,sizeof(err));
		status=0;
		logged=false;
		contretry=0;
		httpres=0;
		busyretry=0;
		//useproxy=0;
		resume=false;
		pause=false;
		read=false;
		readbuffi=0;
		memset(&ctrladdr,0,sizeof(ctrladdr));
		memset(&fireaddr,0,sizeof(fireaddr));
		memset(&pasvaddr,0,sizeof(pasvaddr));
		gethosthnd=0;
		readcount=0;
		firectrl=false;
		fbufsize=0;
		abort=false;
		time2dl=0;
		quedex=-1;
		memset(que,0,sizeof(que));
		firedata=false;
		hammerpause=false;
		busy=false;
		lastbusyretry=0;
		relocation=false;
		multipart=false;
		keepalive=false;
		mdl->sessionbytes[splitdex]=0;
		mdl->localbytes[splitdex]=0;
		mdl->spdone[splitdex]=false;
		cps=0;
		memset(cpsinfo,0,sizeof(cpsinfo));
	}
	virtual void ActOnRead(SOCKET sock);
	virtual void ActOnWrite(SOCKET sock);
	bool GenActOnFTPStatus();
	virtual bool ActOnFTPStatus();
	bool GenActOnHTTPStatus();
	virtual bool ActOnHTTPStatus();
	virtual bool ActOnStatus() 
	{
		if ISFTP(this)
			return ActOnFTPStatus();
		else
			return ActOnHTTPStatus();
	}
	virtual void ActOnConnect(SOCKET sock,LPARAM lParam) ;
	virtual void ActOnAccept(SOCKET sock);
	virtual void ActOnClose(SOCKET sock);
	bool ConnectErr(LPARAM lParam);
	void CloseSockets();
	void CloseData();
	bool InitCtrl();
	bool QueryDNS();
	void CallResDNS(char*tmp2);
	void GotDNS(LPARAM lParam);	
	void wstatus(char*str);
	void wb(char*str,unsigned short c);
	int CloseSock(SOCKET &hSock,bool read);
	void GetFN(char *str);
	int ReadSocket(SOCKET readsock,char *res,char *&readbuff,unsigned long &readbuffi);
	virtual int ReadFTPCtrl();
	int GenHTTPCtrl(char *buf3);
	virtual int ReadHTTPCtrl();
	virtual int ReadCtrl()
	{
		if ISFTP(this)
			return ReadFTPCtrl();
		else
			return ReadHTTPCtrl();
	}
	virtual int ReadData(SOCKET readsock);
	void ConnectCtrl(LPARAM lParam);
	void CheckLog();
	bool ChkFire(SOCKET s);
	void KillDL();
	void SendSock(SOCKET &hsock);
	bool DoThing(SOCKET &hsock);
	bool RideOn();
	void BadFN();
	void log_start();
	void log_end();
	void log_wr(char*s,bool iser);
	void log_size();
	void doerr(int en);
	bool TimedOut();

	bool DoCheckInt(char *buf,int &ret);
	void InitIntCheck(unsigned int result);
	void CalcCps(unsigned long tick);
	void Add2Ser();
	void RMfSer();
	void MoveMirr(mirrors *newm);
	bool Ping();
	int WriteFTP(char *str);
	void dq();
	void repq();
	void InitData();
	void ConnectPASV(LPARAM lParam);
	void AbortFTP();
	bool StealSock();
};

class buffer
{
public:
	char *txt;
	buffer *next;
	buffer(basicdl *bdl,char *str,unsigned short c)
	{
		next=NULL;
		txt=(char *)malloc(strlen(str)+5);
		strcpy(txt,str);
		txt[strlen(str)+1]=(char)c;
		if (bdl->buffhead==NULL)
		{
			bdl->buffhead=this;
			bdl->bufflast=this;
		}
		else
		{
			bdl->bufflast->next=this;
			bdl->bufflast=this;
		}
		bdl->buffcount++;
/*		char *tmpstr;
		tmpstr=(char *)malloc(strlen(str)+5);
		strcpy(tmpstr,str);
		tmpstr[strlen(tmpstr)+1]=(char)c;*/
		STELLGUI(BUFF_ADD,bdl,txt);
	}
	~buffer()
	{
		free(txt);
	}
};

class dl:public basicdl
{
public:
	dl(mirrors*mir0,short type0)
	{
		mir=mir0;
		type=type0;
		Add2Ser();
	}
};

class upddlchk:public basicdl
{
public:
	upddlchk(mirrors*mir0)
	{
		killonstop=true;
		mir=mir0;
		type=9;
		Add2Ser();
	}
	static void ProcessChk(char *lfn);
	static void Chk4Upd();
	static void GetUpdInfo(FILE *f,int &id,double &ver,char *name,char *uver,char *desc);
};

class upddl:public basicdl
{
public:
	upddl(mirrors*mir0)
	{
		killonstop=true;
		mir=mir0;
		type=10;
		Add2Ser();
	}
	static void ChkIfDone(int id,bool ini);
	static void UpdCmp(int id);
	static void DoUpdate(int id);
	static void FinishUpdate();
};

class dlchk:public basicdl
{
public:
	maindl *mmdl;
	mirrors *mmir;
	dlchk(mirrors*mir0,short type0,maindl *mdl0)
	{
		killonstop=true;
		mir=mir0;
		type=type0;
		mmdl=mdl0;
		Add2Ser();
	}
};

class mirrsearch:public basicdl
{
public:
	maindl *mmdl;
	mirrsearch(mirrors *mir0,maindl* mmdl0)
	{
		killonstop=true;
		mir=mir0;
		mmdl=mmdl0;
		type=4;
		Add2Ser();
	}
	bool ActOnStatus();
	int ReadCtrl();
	void ActOnClose(SOCKET sock);
};

struct gsdltable;

class gsdl:public basicdl
{
public:
	gsdltable *table;
	gsdl(mirrors *mir0)
	{
		mir=mir0;
		type=7;
		keepalive=true;
		table=NULL;
		Add2Ser();
	}
	bool ActOnStatus();
	int ReadCtrl();
};

class gsul:public basicdl
{
public:
	gsdltable *table;
	gsul(mirrors *mir0)
	{
		mir=mir0;
		type=8;
		keepalive=true;
		table=NULL;
		Add2Ser();
	}
	static void ChkReq(SOCKET sock);
	bool ActOnStatus();
	int ReadCtrl();
	void ActOnWrite(SOCKET sock);
	void ActOnClose(SOCKET sock);
	int SendData(SOCKET sock);
};

class dlproxy:public basicdl
{
public:
	char *writebuff,*debug;
	unsigned long sentbytes,countbytes;
	long writebuffi;
	bool sentheader,gotheader,write,writereq,ownrange,senddata,errnf,post;
	dlproxy(mirrors*mir0)
	{
		mir=mir0;
		Add2Ser();

		errnf=false;
		write=true;
		writereq=false;
		writebuffi=0;
		writebuff=NULL;
		countbytes=0;
		sentbytes=0;
		type=5;
		gotheader=false;
		ownrange=false;
		senddata=false;
		post=false;
		sentheader=false;
		debug=(char *)malloc(1);
	}
	~dlproxy()
	{
		free(debug);
		if (writebuff!=NULL)
			free(writebuff);
	}

	bool ActOnFTPStatus();
	bool ActOnHTTPStatus();
	void ActOnRead(SOCKET sock);
	int ReadHTTPCtrl();
	int ReadData(SOCKET readsock);
	void SendNext();
	void ActOnClose(SOCKET sock);
	void PassSendData();
	void ActOnWrite(SOCKET sock);
};


class browsedl:public basicdl
{
public:
	char *readbuff2;
	short btype;
	unsigned long readbuffi2;
	bool startdl;
	browsedl(mirrors *mir0)
	{
		startdl=true;
		readbuff2=NULL;
		readbuffi2=0;
		mir=mir0;
		if ISHTTP(this)
			btype=2;
		else
			if (!strlen(mir->nfo->rfn) || strchr(mir->nfo->rfn,'*'))
				btype=1;
			else btype=2;
		type=2;
		Add2Ser();
	}
	~browsedl()
	{
		if (readbuff2)
			free(readbuff2);
	}
	void ChDir();
	void Refresh();
	void Custom(char *str);
	bool ActOnFTPStatus();
	int ReadFTPData(SOCKET readsock);
	int ReadHTMLData(SOCKET readsock);
	int ReadData(SOCKET readsock)
	{
		if (btype==1)
			return ReadFTPData(readsock);
		else
			return ReadHTMLData(readsock);
	}
};

struct clientlist
{
	char fn[1000],date[120],attr[120];
	unsigned long size;
	bool dir;
};


struct dnstable
{
private:
	void AddItem();
	void RMItem();
public:
	dnstable *next,*prev;
	char *host;
	unsigned long ip;
	dnstable(char *host0,unsigned long ip0)
	{
		host=DupString(host0);
		ip=ip0;
		next=NULL;
		prev=NULL;
		AddItem();
	}
	~dnstable()
	{
		free(host);
		RMItem();
	}
};

EXTERN gsdltable *gsdlhead,*gsdllast;

struct gsdltable
{
private:
	void AddItem();
	void RMItem();
public:
	gsdltable *next,*prev;
	unsigned long ip;
	short ignore;
	char *showfn,*rdir,*rfn;
	maindl *mdl;
	gsdltable(unsigned long ip0,short ignore0,char *showfn0,char *rdir0,char *rfn0,
				char *name0,bool offer)
	{
		ip=ip0;
		ignore=ignore0;
		showfn=DupString(showfn0);
		rdir=DupString(rdir0);
		rfn=DupString(rfn0);
		mdl=NULL;
		next=NULL;
		prev=NULL;
		gsdltable *tmp=gsdlhead;
		while (tmp)
		{
			if ((ip==tmp->ip) && !strcmp(showfn,tmp->showfn))
			{
				delete tmp;
				break;
			}
			tmp=tmp->next;
		}
		AddItem();
		if (offer)
			TELLDAEMON(OFFER_FILE,this,name0);
	}
	~gsdltable()
	{
		free(showfn);
		free(rdir);
		free(rfn);
		RMItem();
	}
};

EXTERN char*rundir,*setupdir;
EXTERN mirrors *avmir;
EXTERN SOCKET avsock;
// mirror n socket for first cr8dl()s
#ifdef  _WIN32
EXTERN OSVERSIONINFO os;
EXTERN char *LClip[500];
EXTERN HINSTANCE hinst,hras,hlang;
EXTERN HWND hwndg,hwnddial;
EXTERN bool starttray;
EXTERN int swstart;
EXTERN HKEY regkey,cfgkey;
EXTERN DWORD (STDAPICALLTYPE* RasEnumConnectionsx)(HRASCONN rc, LPDWORD sb, LPDWORD nc);
EXTERN DWORD (STDAPICALLTYPE* RasGetConnectStatusx)(HRASCONN rc, LPRASCONNSTATUS rs);
EXTERN DWORD (STDAPICALLTYPE* RasHangUpx)(HRASCONN rc);
EXTERN DWORD (STDAPICALLTYPE* RasDialx)(
			LPRASDIALEXTENSIONS lpRasDialExtensions,
			LPTSTR lpszPhonebook, 
			LPRASDIALPARAMS lpRasDialParams, 
			DWORD dwNotifierType, 
			LPVOID lpvNotifier, 
			LPHRASCONN lphRasConn);
EXTERN DWORD (STDAPICALLTYPE* RasEnumEntriesx)(
			LPTSTR reserved,
			LPTSTR lpszPhonebook,
			LPRASENTRYNAME lprasentryname,
			LPDWORD lpcb,
			LPDWORD lpcEntries); 
EXTERN DWORD (STDAPICALLTYPE* RasGetEntryPropertiesx)(
			LPTSTR lpszPhonebook,
			LPTSTR lpszEntry,
			LPRASENTRY lpRasEntry,
			LPDWORD lpdwEntryInfoSize,
			LPBYTE lpbDeviceInfo,
			LPDWORD lpdwDeviceInfoSize);
EXTERN DWORD (STDAPICALLTYPE* RasGetEntryDialParamsx)(
			LPTSTR lpszPhonebook,
			LPRASDIALPARAMS lprasdialparams,
			LPBOOL lpfPassword);
EXTERN WIN32_FIND_DATA findstruct;
EXTERN HANDLE findhandle;
#endif

#ifdef __unix__
EXTERN glob_t findstruct;
EXTERN unsigned int findcount;
#endif
EXTERN maindl *listhead,*lastitem;
EXTERN server *serhead,*serlast;
EXTERN dnstable *dnshead,*dnslast;
EXTERN basicdl *actdls[1024];
EXTERN bool checkint,loadurl,dialing,dodis,wait4sc;
EXTERN short lastact,changesplit,logday;
EXTERN unsigned long maincount,activemain,activedl,activebr,dnscount,
			globalcps,globalcpsinfo,gdlcps,gdlcpsinfo,gbrcps,
			gbrcpsinfo,calcid,activesocks,maxrb;
EXTERN char *grbuf,**gstitle;
EXTERN SOCKET gproxsock,gsulsock;
EXTERN FILE *gfp;
// prototypes:
// general.cpp

dlnfo* ConvertURL(char *str);
maindl*AddURL(dlnfo*newdl,char *ldir,char *lfn,short type,short proxy,short dosp,time_t to,
			  short prior,short mode,bool usehammer,bool useretry,bool checkint,bool smallint);
#define AddDefURL(nfo,t) \
 AddURL(nfo,NULL,NULL,t,9,cfg.defsplit,cfg.resumeto,DEFPR,0,cfg.usehammer,cfg.useretry,\
 cfg.checkint,cfg.checksmallint)
void GetLine(char*buff,char*str);
void ConstURL(dlnfo *d,char *str);
void log_gen(char*s,bool iser);
bool wrlog(maindl*m,char*str);
long MsgBox(char*txt,char*title,unsigned int how);
void FilterFN(char *fn);
bool WakeMDL(server *ser,SOCKET &hsock);
void GetExtDir(char *dir,char *fn);
bool WhoNeedsSock(SOCKET &hsock,server *ser,bool ftp,maindl *mdl);
basicdl* FindLSS(short mprior);
//bool DLSchedule();
//bool HUSchedule();
bool DLURL(char *url);
#ifdef _WIN32
LRESULT CALLBACK DropboxFunc(HWND hdwnd, UINT message,
                         WPARAM wParam, LPARAM lParam);
HDDEDATA CALLBACK DdeCallback(UINT uType,UINT uFmt,HCONV hconv,
							  HSZ hsz1,HSZ hsz2,HDDEDATA hdata,
							  DWORD dwData1,DWORD dwData2);
//void RegisterNS();
//void UnregisterNS();
//void RegisterOP();
// Registry funcs
void SetReg(char *k,LPVOID d,unsigned long ds);
void SetReg(char *k,char *d);
void GetReg(char *k,LPVOID d,unsigned long ds);
void GetReg(char *k,char *d);
char* GetReg(char *k,char *d, int i);
int DelReg();
// RAS funcs1
BOOL CALLBACK DialFunc(HWND hdwnd, UINT message,WPARAM wParam, LPARAM lParam);
DWORD WINAPI InitGUI(DWORD d);
#endif // _WIN32
void Hangup();
void LoadRas();
bool IsConnected();
void DetectedHangup();
void StartDial();

//void CDirList(char *line,char *fn,char *date,unsigned long &size,
//			  bool &dir,char *attr);
void GetWord(char *t,int i,char *d, bool en);
void DoRunExternal(maindl *mdl);
mirrors* AddMirror(maindl *mdl,dlnfo *nfo);
maindl *CheckDup(dlnfo *nfo);
short ShouldUse(mirrors *mir);
void CheckNextMirror(maindl *mdl);
unsigned long GetDNSFromTable(char *host);
short GetProxy(short prot,short type);
void Base64(char *s,char *d);
void SockMan();
void cs(char *str);
void rcs(char *str);

bool FFirstFile(char *ffn,char *match);
bool FNextFile(char *match);

struct extlist;
EXTERN extlist*exthead;
EXTERN TimeStruct regtime;
EXTERN unsigned long dused,dused2;

struct extlist
{
	char *ext;
	char *dir;
	extlist *next;
	extlist(char *ext0,char *dir0)
	{
		extlist *t=exthead;
		while (t && t->next)
			t=t->next;			
		if (!t) exthead=this;			
		else t->next=this;
		ext=DupString(ext0);
		dir=DupString(dir0);
		next=NULL;
	}
	~extlist()
	{
		extlist *tmp=exthead;
		while ((tmp->next!=this) && (tmp->next!=NULL))
			tmp=tmp->next;
		if (tmp->next!=NULL)
			tmp->next=next;
		free(ext);
		free(dir);
	}
};

struct sclist;
EXTERN sclist*schead;

struct sclist
{
	char *sc;
	char *url;
	sclist *next;
	sclist(char *sc0,char *url0)
	{
		sclist *t=schead;
		while (t && t->next)
			t=t->next;			
		if (!t) schead=this;			
		else t->next=this;
		sc=DupString(sc0);
		url=DupString(url0);
		next=NULL;
	}
	~sclist()
	{
		if (schead==this)
			schead=next;
		else
		{
			sclist *tmp=schead;
			while ((tmp->next!=this) && (tmp->next!=NULL))
				tmp=tmp->next;
			if (tmp->next!=NULL)
				tmp->next=next;
		}
		free(sc);
		free(url);
	}
};

struct StringLST;
struct StringLST2;
EXTERN StringLST *Dstrhead;
EXTERN StringLST2*Dstrhead2;

struct StringLST{
	char*str;
	StringLST*next;

	StringLST(char*in)
	{
		StringLST *t=Dstrhead;
		while (t && t->next)
			t=t->next;
		if (!t) Dstrhead=this;			
		else t->next=this;
		str=DupString(in);
		next=NULL;
	}
	~StringLST()
	{
		free(str);
	}
};

struct StringLST2{
	char*str;
	StringLST2*next;

	StringLST2(char*in)
	{
		StringLST2 *t=Dstrhead2;
		while (t && t->next)
			t=t->next;
		if (!t) Dstrhead2=this;			
		else t->next=this;
		str=DupString(in);
		next=NULL;
	}
	~StringLST2()
	{
		free(str);
	}
};


char *GlobStr(const char*in);
char *GetLangSTR(int n);

// comm funcs
void ConnectFire(SOCKET s,SOCKADDR_IN&addr);

int LoadURLs();
int SaveConfig();
int LoadConfig();

// endof prototypes

void InitProxy();
void ShutProxy();
void InitGSUL();
void ShutGSUL();

// Portability section::::::
#ifdef _WIN32
#define RMSelectSock(sock) WSAAsyncSelect(sock, hwndg, 0, 0)
#define AddSelectSock(sock,actpos) WSAAsyncSelect(sock,hwndg,WM_USER+1+actpos,\
			     (FD_ACCEPT|FD_CONNECT | FD_READ | FD_WRITE | FD_CLOSE))
#define SockNBlock(sock)\
u_long u=0;\
ioctlsocket(sock,FIONBIO,&u)
EXTERN long sock;
EXTERN int socks[1000];
int AddSock(SOCKET s);
int RMSock(SOCKET s);
#define GETSOCK(s,a,b,c) s=socket(a,b,c)//;sock++;AddSock(s)
//#define closesocket(s) RMSock(s)
#endif // _WIN32

#ifdef __unix__
EXTERN fd_set rdsocks,wrsocks;
EXTERN int maxfd;
//#define MAX(a,b) ((a>b)? (a) : (b))
//#define MAX(a,b) ((((a)+(b))+abs((a)-(b)))>>1)
#define max(a,b) ((((a)+(b))+abs((a)-(b)))>>1)
#define MAX(a,b) 60000
#define RMSelectSock(sock) if (sock!=-1) {FD_CLR(sock,&rdsocks);FD_CLR(sock,&wrsocks);}
#define AddSelectSock(sock,actpos)  fcntl(sock,F_SETFL,O_NONBLOCK);\
FD_SET(sock,&rdsocks);FD_SET(sock,&wrsocks)
#define SockNBlock(sock)  fcntl(sock,F_SETFL,0)
#define GETSOCK(s,a,b,c) s=socket(a,b,c);maxfd=MAX(maxfd,s)
#endif // __unix__

#endif // EOF


