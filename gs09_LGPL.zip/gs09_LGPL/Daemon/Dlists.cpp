
#include "Daemon.h"

void maindl::AddItem()
{
	maincount++;
	this->next=NULL;
	if (listhead==NULL)
	{
		listhead=this;
		this->prev=NULL;
	}
	else
	{
		lastitem->next=this;
		this->prev=lastitem;
	}
	lastitem=this;
}

void maindl::RMItem()
{
	maincount--;
	if (listhead==lastitem)
	{
		listhead=NULL;
		lastitem=NULL;
		return;
	}
	if (this==listhead)
	{
		this->next->prev=NULL;
		listhead=this->next;
	}
	else
		if (this->next) this->next->prev=this->prev;
	
	if (this==lastitem)
	{
		this->prev->next=NULL;
		lastitem=this->prev;
	}
	else
		if (this->prev) this->prev->next=this->next;
}


void mirrors::AddItem(maindl *mdl)
{
	next=NULL;
	if (mdl->mirrorhead==NULL)
	{
		mdl->mirrorhead=this;
		prev=NULL;
	}
	else
	{
		mdl->mirrorlast->next=this;
		prev=mdl->mirrorlast;
	}
	mdl->mirrorlast=this;
	if (mdl->mirrorlast!=mdl->mirrorhead)
		if (mdl->spliton)
			if (mdl->type==1) Ping();

	if ((mdl->mirrorlast==mdl->mirrorhead) &&
		cfg.checkonadd && (mdl->type==1) && !loadurl)
	{
		if (mdl->mirchecks<cfg.mirr.maxmirchecks)
			Check();
		else ischeck=true;
	}
}

void mirrors::RMItem(maindl* mdl)
{
	if (mdl->mirrorhead==mdl->mirrorlast)
	{
		mdl->mirrorhead=NULL;
		mdl->mirrorlast=NULL;
		return;
	}
	if (this==mdl->mirrorhead)
	{
		this->next->prev=NULL;
		mdl->mirrorhead=this->next;
	}
	else
		if (this->next) this->next->prev=this->prev;
	
	if (this==mdl->mirrorlast)
	{
		this->prev->next=NULL;
		mdl->mirrorlast=this->prev;
	}
	else
		if (this->prev) this->prev->next=this->next;
}

void mirrors::Add2Ser()
{
	sernext=NULL;
	if (ser->mirhead==NULL)
	{
		ser->mirhead=this;
		serprev=NULL;
	}
	else
	{
		ser->mirlast->sernext=this;
		serprev=ser->mirlast;
	}
	ser->mirlast=this;
}

void mirrors::RMfSer()
{
	if (ser==NULL) return;
	if (ser->mirhead==ser->mirlast)
	{
		ser->mirhead=NULL;
		ser->mirlast=NULL;
		if (!ser->perm)
		{
			// tell gui to remove server
			ser->DelSer();
			ser=NULL;
		}
		return;
	}
	if (this==ser->mirhead)
	{
		sernext->serprev=NULL;
		ser->mirhead=sernext;
	}
	else
		if (sernext!=NULL) sernext->serprev=serprev;
	
	if (this==ser->mirlast)
	{
		serprev->sernext=NULL;
		ser->mirlast=serprev;
	}
	else
		if (serprev!=NULL) serprev->sernext=sernext;
	ser=NULL;
}

void basicdl::Add2Ser()
{
	sernext=NULL;
	if (mir->ser->bdlhead==NULL)
	{
		mir->ser->bdlhead=this;
		serprev=NULL;
	}
	else
	{
		mir->ser->bdllast->sernext=this;
		serprev=mir->ser->bdllast;
	}
	mir->ser->bdllast=this;
	mir->ser->actcon++;
	mir->used++;
	if (type==1) activesocks++;
	//tell gui to update mir table & ser.
}

void basicdl::RMfSer()
{
	if ((serprev==sernext) && (mir->ser->bdlhead!=this)) return;
	if (mir->ser->bdlhead==mir->ser->bdllast)
	{
		mir->ser->bdlhead=NULL;
		mir->ser->bdllast=NULL;
		if (splitdex!=-1)
		{
			mir->ser->actcon--;
			mir->used--;
			if (type==1) activesocks--;
		}
		return;
	}
	if (this==mir->ser->bdlhead)
	{
		sernext->serprev=NULL;
		mir->ser->bdlhead=sernext;
	}
	else
		if (sernext!=NULL) sernext->serprev=serprev;
	
	if (this==mir->ser->bdllast)
	{
		serprev->sernext=NULL;
		mir->ser->bdllast=serprev;
	}
	else
		if (serprev!=NULL) serprev->sernext=sernext;
	if (splitdex!=-1)
	{
		mir->ser->actcon--;
		mir->used--;
		if (type==1) activesocks--;
	}
}

void server::AddItem()
{
	this->next=NULL;
	if (serhead==NULL)
	{
		serhead=this;
		this->prev=NULL;
	}
	else
	{
		serlast->next=this;
		this->prev=serlast;
	}
	serlast=this;
}

void server::RMItem()
{
	if (serhead==serlast)
	{
		serhead=NULL;
		serlast=NULL;
		return;
	}
	if (this==serhead)
	{
		this->next->prev=NULL;
		serhead=this->next;
	}
	else
		if (this->next) this->next->prev=this->prev;
	
	if (this==serlast)
	{
		this->prev->next=NULL;
		serlast=this->prev;
	}
	else
		if (this->prev) this->prev->next=this->next;
}

void dnstable::AddItem()
{
	if ((dnscount>=MAXDNSTABLE) && dnshead)
		delete dnshead;
	this->next=NULL;
	if (dnshead==NULL)
	{
		dnshead=this;
		this->prev=NULL;
	}
	else
	{
		dnslast->next=this;
		this->prev=dnslast;
	}
	dnslast=this;
	dnscount++;
}

void dnstable::RMItem()
{
	if (dnshead==dnslast)
	{
		dnshead=NULL;
		dnslast=NULL;
		dnscount=0;
		return;
	}
	if (this==dnshead)
	{
		this->next->prev=NULL;
		dnshead=this->next;
	}
	else
		if (this->next) this->next->prev=this->prev;
	
	if (this==dnslast)
	{
		this->prev->next=NULL;
		dnslast=this->prev;
	}
	else
		if (this->prev) this->prev->next=this->next;
	dnscount--;
}

void gsdltable::AddItem()
{
	next=NULL;
	if (gsdlhead==NULL)
	{
		gsdlhead=this;
		prev=NULL;
	}
	else
	{
		gsdllast->next=this;
		prev=gsdllast;
	}
	gsdllast=this;
}

void gsdltable::RMItem()
{
	if (gsdlhead==gsdllast)
	{
		gsdlhead=NULL;
		gsdllast=NULL;
		return;
	}
	if (this==gsdlhead)
	{
		next->prev=NULL;
		gsdlhead=next;
	}
	else
		if (next) next->prev=prev;
	
	if (this==gsdllast)
	{
		prev->next=NULL;
		gsdllast=prev;
	}
	else
		if (prev) prev->next=next;
}


