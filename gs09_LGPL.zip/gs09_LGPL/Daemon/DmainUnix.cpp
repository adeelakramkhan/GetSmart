
#define _this_is_main_
#include "Daemon.h"

#include "DDefaults.cpp"
#include "SigH.cpp"
#include "tst.h"

#define Pin "dPipe.in"
#define gslock "gsD_lock"

void ManagerFunc();

int main(int cmdc,char**cmdline)
{
  int pipein;
  InitDefaults();
  InstHandlers();
  char str[1024],pidstr[10];
  sprintf(pidstr,"%u",getpid());
  symlink(pidstr,gslock);
  mkfifo(Pin,0644);
  pipein=open(Pin,O_RDONLY|O_NONBLOCK);
  FD_ZERO(&rdsocks);
  FD_SET(pipein,&rdsocks);
  FD_ZERO(&wrsocks);
  maxfd=pipein;
  bphead=NULL;
  cfg.beproxy.use=true;
  cfg.beproxy.minsize=15000;
  cfg.beproxy.dosplit=4;
  cfg.robot=true;
  new sclist("gs","http://getsmart.hypermart.net");

  if (cfg.beproxy.use)
    InitProxy();

  // Main loop:
  for/*ever*/(;;){
    timeval tv;
    fd_set rdchk,wrchk;
    int s;

    tv.tv_sec=1; //set timeout
    tv.tv_usec=0;
    rdchk=rdsocks;
    wrchk=wrsocks;
    s=select(maxfd+1,&rdchk,&wrchk,NULL,&tv);
    bpsock *tmp=bphead;
    if (s==-1){
      perror("select():");
      exit(1);
    }
    if (s==0){
      ManagerFunc();
     // printf("TimeOuted\n");
      goto After;
    }
   else
      {
	if FD_ISSET(pipein,&rdchk){
	  s--;
  /* Chking what's in pipe... */
	  char pmess[0x100];
	  unsigned short pbytes;
	  pbytes=read(pipein,pmess,sizeof(pmess));
	  printf("data in pipe!\n");
	  printf("(%d bytes)",pbytes);
	  if (pbytes)
	    {
	      int dPipe_id;
	      dPipe_id=*((unsigned short*)(pmess+1));
	      dPipe_id&=0xff;
	      switch (pmess[0]){
	      case '?': /* identify */
		printf("not implemented yet...\n");
		break;
	      case 'p': /* print dls */
		break;
	      case 'j': /* just actives */
		printf("Active:\n");

		break;
	      case 'w': /* write to file */
		break;
	      case 'e': /* echo d/l stat */
		break;
	      case 'a': /* activ8 d/l */
		break;
	      case 'q': /* query active list */
		break;
	      case 's': /* stop dl */
		/* pauseDL(dPipe_id) */
	      _Pipe_chk_Skip:
		break;
	      case 'r': /* remove dl */
		break;
	      case 't':
		printf("starting url..\n");
		maindl *mdl;
		mdl=AddDefURL(new dlnfo(1,"127.0.0.1"/*localhost.localdomain"*/,21,"anonymous","moshes@getsmart.com","/pub/","icq99a.exe"),1);
		mdl->dosplit=3;
		break;
	      case 'u': /* url ahoy! */
		printf("getting URL from pipe!\n");
                pmess[pbytes-1]=0;
                printf("URL:: %s\n",(pmess+1));
                AddDefURL(ConvertURL(pmess+1),1);
                break;                                
	      default:
		printf("unknown command!\n%c,%d,%d,%d\n"
		       ,pmess[0],pmess[1],pmess[2],pmess[3]);
	      }
	      printf("\n______\n");
	    }
	  else{
	    //	    printf("0 data in pipe\npipe handle: %d\n",pipein);
	    close(pipein);
	    pipein=open(Pin,O_RDONLY|O_NONBLOCK);
	    //	    printf("now pipe handle:%d\n",pipein);
	  }
	}

	/* some fd is set, but it's not the pipe... */
	
	// check for act as proxy accept
	if FD_ISSET(gproxsock,&rdchk)
	  {
	    int tmpsock=accept(gproxsock,0,0);
	    if (tmpsock!=INVALID_SOCKET)
	      {
		new bpsock(tmpsock);
		AddSelectSock(tmpsock,0);
		FD_CLR(tmpsock,&wrsocks);
		printf("Got a request to the proxy\n");
		s--;
		if (!s) goto After;
	      }
	  }
	// check for act as proxy read

	while (tmp)
	  {
	    if FD_ISSET(tmp->sock,&rdchk)
	      {
		bpsock *tmp2=tmp->next;
		maindl *mdl=AddURL(new dlnfo(2,"127.0.0.1",80,"anonymous",
		     cfg.Email,"/","File for browser"),"/",
		    "Download for browser.",5,9,0,cfg.resumeto,DEFPR,
		     0,false,false,0,0);
		mdl->proxsock=tmp->sock;
		if (mdl->Cr8DL(mdl->mirrorhead,0,-1,false))
		  if (mdl->splitdl[0])
		    {
		      ((dlproxy*)mdl->splitdl[0])->senddata=true;
		      FD_CLR(tmp->sock,&rdchk);
		      FD_CLR(tmp->sock,&wrsocks);
		      mdl->splitdl[0]->ActOnRead(tmp->sock);
		    }
		delete tmp;
		tmp=tmp2;
		s--;
		if (!s) goto After;
	      }
	    else
	      tmp=tmp->next;
	  }
		
	int j;
	// check for prox sock (read | write | close)
	for (j=0;j<=lastmact;j++)
	  if (actmdls[j].mdl->type==5)
	    {
	      if FD_ISSET(actmdls[j].mdl->proxsock,&wrchk)
		{
		  int k;
		  for (k=0;k<=actmdls[j].mdl->splitdex;k++)
		    if ((actmdls[j].mdl->type==5) && actmdls[j].mdl->splitdl[k] && 
			((dlproxy*)actmdls[j].mdl->splitdl[k])->senddata)
		      break;
		  actmdls[j].mdl->splitdl[k]->ActOnWrite(actmdls[j].mdl->proxsock);
		  s--;
		  if (!s) goto After;
		}
  
	      if FD_ISSET(actmdls[j].mdl->proxsock,&rdchk)
		{
		  char q;
		  int k;
		  for (k=0;k<=actmdls[j].mdl->splitdex;k++)
		    if ((actmdls[j].mdl->type==5) && actmdls[j].mdl->splitdl[k] && 
			((dlproxy*)actmdls[j].mdl->splitdl[k])->senddata)
		      break;
		  if (recv(actmdls[j].mdl->proxsock,&q,1,MSG_PEEK)<=0)
		    actmdls[j].mdl->splitdl[k]->ActOnClose(actmdls[j].mdl->proxsock);
		  else
		    actmdls[j].mdl->splitdl[k]->ActOnRead(actmdls[j].mdl->proxsock);
		      s--;
		      if (!s) goto After;
		}
	    }

	for (int i=0;i<=lastact;i++)
	  if (actdls[i]!=NULL)
	    {
	      unsigned int retsz=sizeof(int);
	      int err;
	      char q1;
	      if (actdls[i]->ctrlsock!=INVALID_SOCKET){
		if FD_ISSET(actdls[i]->ctrlsock,&wrchk)
		  {
		  s--;
		  //printf("wr_con\n");
		  err=0;
		  //FD_CLR(actdls[i]->ctrlsock,&wrsocks);
		  if (!actdls[i]->status)
		    {
		      FD_CLR(actdls[i]->ctrlsock,&wrsocks);
		      //q1=0;
		      //int t=send(actdls[i]->ctrlsock,&q1,0,0);
		      getsockopt(actdls[i]->ctrlsock,SOL_SOCKET,SO_ERROR,&err,&retsz);
		      actdls[i]->ActOnConnect(actdls[i]->ctrlsock,err);
		    }
		  else
		    actdls[i]->ActOnWrite(actdls[i]->ctrlsock);
		  if (!s) goto After;
		  if (!actdls[i]) continue;
		}
		if FD_ISSET(actdls[i]->ctrlsock,&rdchk)
		{
		  s--;
		  printf("rd_co\n");
		  if (recv(actdls[i]->ctrlsock,&q1,1,MSG_PEEK)<=0)
		    actdls[i]->ActOnClose(actdls[i]->ctrlsock);
		  else
		    actdls[i]->ActOnRead(actdls[i]->ctrlsock);
		  if (!s) goto After;
		  if (!actdls[i]) continue;
		}
	      }
	      if (actdls[i]->datasock!=INVALID_SOCKET){
		if FD_ISSET(actdls[i]->datasock,&wrchk)
		  {
		    s--;
		    err=0;
		    //printf("wr_da\n");
		    if (actdls[i]->status==6)
		      {
			getsockopt(actdls[i]->datasock,SOL_SOCKET,SO_ERROR,&err,&retsz);
			FD_CLR(actdls[i]->datasock,&wrsocks);
			actdls[i]->ActOnConnect(actdls[i]->datasock,err);
		      }
		    else
		      actdls[i]->ActOnWrite(actdls[i]->datasock);
		    if (!s) goto After;
		    if (!actdls[i]) continue;
		  }
		
		if FD_ISSET(actdls[i]->datasock,&rdchk)
		  {
		    s--;
		    printf("read data split:%d  _ %d,st:%d\n",actdls[i]->splitdex,actdls[i]->mdl->localbytes[actdls[i]->splitdex],actdls[i]->status);
		    if (!actdls[i]->status)
		      {
			if (actdls[i]->gethosthnd){
			  printf("___bout to get DNS from! pid %d\n",actdls[i]->gethosthnd);
			  if (actdls[i]->gethostbuff==NULL)
			    actdls[i]->gethostbuff=(char*)malloc(4);
			  int n=read(actdls[i]->datasock,actdls[i]->gethostbuff,4);
			  if (!n){
			    printf("got 0 data from child..\n");
			    break;
			  }
			  close(actdls[i]->datasock);
			  FD_CLR(actdls[i]->datasock,&rdsocks);
			  actdls[i]->datasock=INVALID_SOCKET;
			  actdls[i]->gethosthnd=0;
			  unsigned char*IPp=(unsigned char*)actdls[i]->gethostbuff;
			  printf("__got %d bytes, : %d.%d.%d.%d\n",n,IPp[0],IPp[1],IPp[2],IPp[3]);
			  actdls[i]->GotDNS(n);
			}else
			  printf("we're should ___NEVER__ be here... wierd...\n");
		      }
		    else
		      if (recv(actdls[i]->datasock,&q1,1,MSG_PEEK)<=0)
			{
			  actdls[i]->ActOnClose(actdls[i]->datasock);
			  printf("moshe\n");
			}
		      else
			//if (actdls[i]->status<=9)
			//actdls[i]->ActOnAccept(actdls[i]->datasock);
			//else
			{
			  actdls[i]->ActOnRead(actdls[i]->datasock);
			}
		    if (!s) goto After;
		    if (!actdls[i]) continue;
		  }
	      }
	      if (actdls[i]->listensock!=INVALID_SOCKET)
		{
		  if FD_ISSET(actdls[i]->listensock,&rdchk)
		    {
		      s--;
		      printf("rd_co\n");
		      // if (!recv(actdls[i]->ctrlsock,&q1,1,MSG_PEEK))
		      //actdls[i]->ActOnClose(actdls[i]->ctrlsock);
		      //else
		      //actdls[i]->ActOnRead(actdls[i]->ctrlsock);
		      actdls[i]->ActOnAccept(actdls[i]->listensock);
		      if (actdls[i] && (actdls[i]->datasock!=INVALID_SOCKET))
			FD_CLR(actdls[i]->datasock,&wrsocks);
		      if (!s) goto After;
		      if (!actdls[i]) continue;
		    }
		}
	    }
      After:
	if (1==2)
	  {}
      }
  }
 }
