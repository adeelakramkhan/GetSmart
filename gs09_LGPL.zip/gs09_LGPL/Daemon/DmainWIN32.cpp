
#define _this_is_main_
#include "Daemon.h"

#include "DDefaults.cpp"
#include "../resrc1.h"
#include <shlobj.h>

LRESULT CALLBACK WindowFunc(HWND, UINT, WPARAM, LPARAM);

void ManagerFunc();
bool UnInstall();
//void CheckAuto();
//bool DLSchedule();
//bool HUSchedule();

bool saveurl=true,douninstall=false;

bool CMDLine(char *cl)
{
	if (strchr(cl,'t'))
	{
		starttray=true;
		return false;
	}
	
	if (strchr(cl,'r'))
	{
		if (MsgBox("Are you sure you want to delete the registry info of GetSmart?",
			"Uninstall GetSmart",MB_YESNO|cfg.r2l)==IDNO)
			return true;
		DelReg();
		return true;
	}

	if (strchr(cl,'u'))
	{
		return UnInstall();
	}
	return false;
}

int WINAPI WinMain(HINSTANCE hThisInst, HINSTANCE hPrevInst,
                   char* cl, int nWinMode)
{
#ifdef _DEBUG
	SET_CRT_DEBUG_FIELD( _CRTDBG_ALLOC_MEM_DF|_CRTDBG_LEAK_CHECK_DF);// | _CRTDBG_DELAY_FREE_MEM_DF);// |_CRTDBG_CHECK_ALWAYS_DF);
   _CrtSetReportMode(_CRT_WARN, _CRTDBG_MODE_FILE|_CRTDBG_MODE_WNDW);
   _CrtSetReportMode(_CRT_ERROR, _CRTDBG_MODE_FILE|_CRTDBG_MODE_WNDW);
   _CrtSetReportMode(_CRT_ASSERT, _CRTDBG_MODE_FILE|_CRTDBG_MODE_WNDW);
#endif
char szWinName[]="GetDaemon";

HANDLE hMutex = CreateMutex(NULL, FALSE, "GSInstanceCHK" );
#ifndef _DEBUG
if ((hMutex==NULL) || (GetLastError()==ERROR_ALREADY_EXISTS))
{
	HWND hWndApp;//,hWndPopup;
	if (hWndApp = FindWindow(szWinName, NULL))
	{
		//char *cl0=DupString(cl);
		if (strrchr(cl,'u'))
			SendMessage(hWndApp,WM_USER+1031,1,0);
		//free(cl0);
		//hWndPopup = GetLastActivePopup(hWndApp);
		//BringWindowToTop(hWndApp);
		//ShowWindow(hWndPopup,SW_SHOW);
		//ShowWindow(hWndPopup,SW_RESTORE);
		//SetForegroundWindow(hWndPopup);

//	    if (IsIconic(hWndPopup) )
//			ShowWindow(hWndPopup, SW_RESTORE);
//		else
//			SetForegroundWindow(hWndPopup);
	}
    return 0;
}
#endif

	WSADATA stWSAData;
	hinst=hThisInst;
	InitDefaults();

	upddl::FinishUpdate();

	if (CMDLine(cl)) return 0;

	swstart=nWinMode;

	HWND hwnd;
	MSG msg;

    WNDCLASSEX wcx;

	memset(&wcx,0,sizeof(wcx));
	wcx.cbSize = sizeof(wcx);
	wcx.style = 0;
	wcx.lpfnWndProc = WindowFunc;
	wcx.cbClsExtra = 0;
	wcx.cbWndExtra = 0;
	wcx.hInstance = hinst;
	wcx.hIcon = LoadIcon(hinst, "AAAA");
	wcx.hCursor = LoadCursor(NULL, IDC_ARROW);
	wcx.hbrBackground = (HBRUSH) GetStockObject(WHITE_BRUSH);
	wcx.lpszMenuName =  NULL;
	wcx.lpszClassName = szWinName;
	wcx.hIconSm = NULL;
	if (!RegisterClassEx(&wcx))
	{
		ReleaseMutex(hMutex);
		CloseHandle(hMutex);
		return 0;
	}

	if (WSAStartup(0x0002, &stWSAData))
	{
		MsgBox(GetSTR(1,"Can't find a usable WINSOCK.DLL, try getting that file."),0,MB_OK);
		dds();
		ReleaseMutex(hMutex);
		CloseHandle(hMutex);
		return 1;
	}
	if (cfg.Dial.Use) LoadRas();
//	DdeInitialize(&ddeinst, (PFNCALLBACK) DdeCallback,NULL,0);

	LoadURLs();
	sock=0;
/*	char tmp[1024];
	sprintf(tmp,"%s\\debug.log",rundir);
	gfp=fopen(tmp,"at");
	strcpy(tmp,"\nSession started\n");
	fwrite(tmp,1,strlen(tmp),gfp);*/
	hwnd=CreateWindow(szWinName,
		"GetSmart - Daemon",
		0,
		CW_USEDEFAULT,
		CW_USEDEFAULT,
		CW_USEDEFAULT,
		CW_USEDEFAULT,
		HWND_DESKTOP,
		NULL,
		hinst,
		NULL);
    hwndg=hwnd;
	HACCEL hAccel;
	hAccel=LoadAccelerators(hlang,"MYMENU");

	SetTimer(hwnd,999,1000,NULL);

	while(GetMessage(&msg, NULL, 0, 0))
		if (!TranslateAccelerator(hwnd,hAccel,&msg))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	if (cfg.beproxy.use) ShutProxy();
	if (cfg.usegsul) ShutGSUL();
	if (hras) FreeLibrary(hras);
//	DdeUninitialize(ddeinst);
	KillTimer(hwnd,999);
	WSACleanup();
	saveurl=false;
	while (listhead)
		listhead->delmdl();
	while (serhead)
		serhead->DelSer();
	while (dnshead)
		delete dnshead;
	while (gsdlhead)
		delete gsdlhead;
	while (schead)
		delete (schead);
	free(cfg.updsite);
	free(setupdir);
	free(rundir);
	free(cfg.uagent);
	free(cfg.name);
	free(cfg.tmpdir);
	free(cfg.Proxy.HHost);
	free(cfg.Proxy.FHost);
	free(cfg.Proxy.sockshost);
	free(cfg.Proxy.socksuser);
	free(cfg.Email);
	free(cfg.asciiext);
	free(cfg.emdir);
	free(cfg.catchext);
	free(cfg.externalfile);
	free(cfg.externalparams);
	free(cfg.stamp);
	free(cfg.logdir);
	free(cfg.logfn);
	free(cfg.langfn);
	free(grbuf);
	free(*gstitle);
	free(gstitle);
	while (exthead->next)
		delete exthead->next;
	while (cfg.mirr.mirshead!=NULL)
		delete cfg.mirr.mirshead;
	delete exthead;
	ReleaseMutex(hMutex);
	CloseHandle(hMutex);
	while (cmphead)
		delete cmphead;
	if (douninstall)
		UnInstall();
	return msg.wParam;
}

VOID APIENTRY DisplayDaemonTrayMenu(HWND hwnd,POINT pt);

LRESULT CALLBACK WindowFunc(HWND hwnd, UINT message,
                            WPARAM wParam, LPARAM lParam)
{
	basicdl *bdl;
	maindl *mdl;
	mirrors *mir;
	short type;
	char str[1024];
	int i;
	unsigned char tID[4];
	NOTIFYICONDATA pnid;

	static UINT s_uTaskbarRestart;

	if (message>WM_USER+3000)
	{
		switch (message-WM_USER-3000)
		{
		case CHANGE_SPLIT:
			mdl=(maindl*)wParam;
			if (!mdl->done && mdl->mirrorhead)
			{
				if (mdl->GetBestMirror()==NULL)
					mdl->mirrorhead->en=0;
				mdl->dosplit=(short)lParam;
				mdl->ChangeSplit(lParam);
			}
			break;
		case START_MDL:
			mdl=(maindl*)wParam;
			if (!mdl->done && !mdl->spliton)
			{
				if (dialing)
				{
					mdl->wasactive=true;
					break;
				}
				if ((lastact==-1) && (maincount>0) && !IsConnected() && (!wait4sc||mdl->wait))
				{
					mdl->wasactive=true;
					StartDial();
					break;
				}
				if (mdl->GetBestMirror()==NULL)
					mdl->mirrorhead->en=0;
				if ((activemain<cfg.maxactive) && !wait4sc || mdl->wait)
				{
					if (!mdl->ActMain(true))
					{
						mdl->wait=true;
						TELLGUI(UPDATE_MDL,mdl,0);
					}
				}
				else
				{
					mdl->wait=true;
					TELLGUI(UPDATE_MDL,mdl,0);
				}
			}
			break;
		case STOP_MDL:
			mdl=(maindl*)wParam;
			mdl->wait=false;
			type=mdl->type;
			if (!mdl->done && mdl->spliton)
			{
				strncpy(mdl->mstxt,GetSTR(65,"Paused"),80);
				dds();
				mdl->KillMain();
			}
			if (type==1) TELLGUI(UPDATE_MDL,mdl,0);
			break;
		case RM_MDL:
			mdl=(maindl*)wParam;
			if (mdl->done) break;
			if (mdl->spliton)
			{
				int t=mdl->type;
				mdl->KillMain();
				if ((t==2) || (t==4) || (t==5) || (t==6))
					break;
			}
			if (lParam==1)
			{
				HANDLE hf;
				WIN32_FIND_DATA ff;
				if (mdl->istmpdir)
					strcpy(str,cfg.tmpdir);
				else strcpy(str,mdl->ldir);
				strcat(str,mdl->lfn);
				if (cfg.stamp)
					strcat(str,cfg.stamp);
				_unlink(str);
				if (mdl->splitdex)
					for (i=0;i<=mdl->splitdex;i++)
					{
						if (mdl->istmpdir)
							sprintf(str,"%s%s (%ld)*",cfg.tmpdir,
							mdl->lfn,i);
						else sprintf(str,"%s%s (%ld)*",mdl->ldir,
							mdl->lfn,i);
						if ((hf=FindFirstFile(str,&ff))!=INVALID_HANDLE_VALUE)
							do
							{
								if (mdl->istmpdir)
									sprintf(str,"%s%s",cfg.tmpdir,
									ff.cFileName);
								else
									sprintf(str,"%s%s",mdl->ldir,
									ff.cFileName);
								_unlink(str);
							} while (FindNextFile(hf,&ff));
					}
			}
			mdl->delmdl();
			break;
		case STOP_ALL:
			mdl=listhead;
			while (mdl)
			{
				if (mdl->type==1)
				{
					mdl->wait=false;
					type=mdl->type;
					if (mdl->spliton)
					{
						strncpy(mdl->mstxt,GetSTR(65,"Paused"),80);
						dds();
						mdl->KillMain();
					}
					if ((type==1) || (type==2)) 
						TELLGUI(UPDATE_MDL,mdl,0);
				}
				mdl=mdl->next;
			}
			break;
		case START_BDL:
			mdl=(maindl*)wParam;
			if (mdl->done) break;
			if (((short)LOWORD(lParam)!=-1) && mdl->splitdl[LOWORD(lParam)])
				break;
			if (((short)HIWORD(lParam)!=-1) && mdl->hamdl[HIWORD(lParam)])
				break;
			if (mdl->GetBestMirror()==NULL)
				mdl->mirrorhead->en=0;
			mdl->Cr8DL(mdl->GetBestMirror(),(int)(short)LOWORD(lParam),
				(int)(short)HIWORD(lParam),true);
			break;
		case STOP_BDL:
			mdl=(maindl*)wParam;
			if (mdl->done) break;
			if ((short)LOWORD(lParam)!=-1)
				bdl=mdl->splitdl[LOWORD(lParam)];
			else
				bdl=mdl->hamdl[HIWORD(lParam)];
			if (!mdl->done && (bdl!=NULL))
			{
				strncpy(mdl->bstxt[bdl->txtpos],GetSTR(65,"Paused"),80);
				dds();
				bdl->KillDL();
			}
			break;
		case SEARCH_MIR:
			mdl=(maindl*)wParam;
			if (mdl->done) break;
			mdl->Search4Mir();
			break;
		case CHECK_MIR:
			mir=(mirrors*)wParam;
			if (mir->mdl->done) break;
			mir->ischeck=true;
			if (mir->mdl->mirchecks<cfg.mirr.maxmirchecks)
				mir->Check();
			break;
		case STOPALL_MIR:
			mdl=(maindl*)wParam;
			if (mdl->done) break;
			mdl->StopAllMir();
			break;
		case STOP_MIR:
			mir=(mirrors*)wParam;
			if (mir->mdl->done) break;
			if (mir->rmdl)
				mir->rmdl->KillMain();
			if (mir->pmdl)
				mir->pmdl->KillMain();
			break;
		case REMOVE_MIR:
			mir=(mirrors*)wParam;
			if (mir->mdl->done) break;
			if (!mir->used && (mir!=mir->mdl->mirrorhead))
			{
				if (mir->rmdl)
					mir->rmdl->KillMain();
				if (mir->pmdl)
					mir->pmdl->KillMain();
				mir->DelMir();
			}
			break;
		case REMOVEBAD_MIR:
			mdl=(maindl*)wParam;
			if (mdl->done) break;
			mir=mdl->mirrorhead;
			while (mir)
			{
				mirrors *mirb=mir->next;
				if (mir->info && (mir->rsize!=mir->mdl->rsize) &&
					!mir->rmdl && !mir->pmdl && (mir!=mdl->mirrorhead))
					mir->DelMir();
				mir=mirb;
			}
			break;

		case INCREASE_MIR:
			mir=(mirrors*)wParam;
			if (mir->mdl->spliton)
			{
				bdl=mir->mdl->FindLSS(mir);
				if (bdl==NULL)
					break;
				bdl->MoveMirr(mir);
				bdl->status=0;
				bdl->ActOnStatus();
			}
			break;

		case DECREASE_MIR:
			mir=(mirrors*)wParam;
			if (mir->mdl->spliton && mir->used)
			{
				bool act=false;
				if (mir->active)
				{
					act=true;
					mir->active=false;
				}
				mirrors *mir0=mir->mdl->GetBestMirror();
				if (!mir0) break;
				if ((mir0->ser->actcon<mir0->ser->maxcon) &&
					(mir0->used<mir0->ser->maxeach))
				{
					bdl=NULL;
					for (i=0;i<=mir->mdl->splitdex;i++)
						if (mir->mdl->splitdl[i] &&
							(mir->mdl->splitdl[i]->mir==mir))
						{
							bdl=mir->mdl->splitdl[i];
							break;
						}
					if (bdl!=NULL)
					{
						bdl->MoveMirr(mir0);
						bdl->status=0;
						bdl->ActOnStatus();
					}
				}
			}
			break;

		case ADD_MIR:
			if (strlen((char*)lParam))
			{
				mdl=(maindl*)wParam;
				if (mdl->done) break;
				char *tmp=(char*)lParam;
				dlnfo *dln=ConvertURL(tmp);
				if (strlen(dln->host))
				{
					if (!strlen(dln->rfn))
						dln->rfn=ReDupString(dln->rfn,mdl->mirrorhead->nfo->rfn);
					if (!stricmp(dln->rfn,mdl->mirrorhead->nfo->rfn))
						AddMirror(mdl,dln);
				}
				delete dln;
			}
			break;

		case BR_CONNECT:
			break;
		
		case BR_DISCONNECT:
			mdl=(maindl*)wParam;
			mdl->splitdl[0]->wb(GetSTR(89,"Disconnected from server."),0);
			if (mdl->splitdl[0] && 
				(mdl->splitdl[0]->ctrlsock!=INVALID_SOCKET))
				mdl->splitdl[0]->RideOn();
			break;

		case BR_KILL:
			mdl=(maindl*)wParam;
			if (mdl->splitdl[0] && 
				(mdl->splitdl[0]->ctrlsock!=INVALID_SOCKET))
				mdl->splitdl[0]->RideOn();
			mdl->KillMain();
			break;

		case BR_CHDIR:
			mdl=(maindl*)wParam;
			if (mdl->splitdl[0])
			{
				if ISHTTP(mdl->splitdl[0])
					((browsedl*)mdl->splitdl[0])->btype=2;
				else
					if (!strlen(mdl->mirrorhead->nfo->rfn)||
						strchr(mdl->mirrorhead->nfo->rfn,'*'))
						((browsedl*)mdl->splitdl[0])->btype=1;
					else ((browsedl*)mdl->splitdl[0])->btype=2;
				mdl->spdone[0]=false;
				((browsedl*)mdl->splitdl[0])->ChDir();
			}
			break;

		case BR_REFRESH:
			mdl=(maindl*)wParam;
			if (mdl->splitdl[0])
				((browsedl*)mdl->splitdl[0])->Refresh();
			break;

		case BR_CUSTOM:
			mdl=(maindl*)wParam;
			if (mdl->splitdl[0])
				((browsedl*)mdl->splitdl[0])->Custom((char*)lParam);
			break;

		case DIAL:
			if (!dialing) StartDial();
			break;

		case OFFER_FILE:
			gsdltable *table;
			table=(gsdltable*)wParam;
			BYTE *d;
			d=(unsigned char *)&table->ip;
			char ip[100];
			sprintf(ip,"%d.%d.%d.%d",d[0],d[1],d[2],d[3]);
			sprintf(str,"%s <- Offering %s",(char*)lParam,table->showfn);
			mdl=AddURL(new dlnfo(2,ip,GSULPORT,"anonymous",
				cfg.Email,"",table->showfn),"",str,7,9,0,cfg.resumeto,DEFPR,0,false,false,0,0);
			if (mdl)
				if (mdl->Cr8DL(mdl->GetBestMirror(),0,-1,false))
				{
					((gsdl*)mdl->splitdl[0])->table=table;
					mdl->splitdl[0]->QueryDNS();
				}
			break;

		case ROBOT_ST:
			switch (lParam)
			{
			case 0:
				cfg.robot=false;
				break;
			case 1:
				cfg.robot=true;
/*				mdl=listhead;
				while (mdl)
					if ((mdl->type==1) && mdl->wait) break;
					else mdl=mdl->next;
				if (mdl==NULL)
				{
					mdl=listhead;
					while (mdl)
					{
						if (mdl->type==1)
						{
							mdl->wait=true;
							TELLGUI(UPDATE_MDL,mdl,0);
						}
						mdl=mdl->next;
					}
				}
				break;
			case 2:
				mdl=(maindl*)wParam;
				mdl->wait=true;
				break;
			case 3:
				cfg.robot=true;*/
				break;
			}
			break;
		default:
			goto out;
		}
		return 0;
	}
out:
	switch(message)
	{
	case WM_CREATE:
		hwndg=hwnd;
		tID[3]=255;
		if (cfg.beproxy.use)
			InitProxy();
		if (cfg.usegsul)
			InitGSUL();
		s_uTaskbarRestart = RegisterWindowMessage(TEXT("TaskbarCreated"));
		/*if (cfg.catchns)
			RegisterNS();*/

		DWORD tid;
		CreateThread(0,0,(LPTHREAD_START_ROUTINE) InitGUI,(void*)hwnd,0,&tid);
		break;
	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case IDM_LOADGUI:
			PostMessage(hwnd,WM_USER+1032,0,(LPARAM)WM_LBUTTONDBLCLK);
			break;
		case IDM_EXIT:
			pnid.cbSize=sizeof(NOTIFYICONDATA);
			pnid.hWnd=hwnd;
			pnid.uID=-1;
			pnid.uFlags=NIF_ICON|NIF_MESSAGE|NIF_TIP;
			pnid.uCallbackMessage=WM_USER+1032;
			pnid.hIcon=LoadIcon(hinst,"AAAA");
			strcpy(pnid.szTip,"GetSmart - The Smartest Download Manager");
			Shell_NotifyIcon (NIM_DELETE, &pnid );
			DestroyWindow(hwnd);
			break;
		}
		break;
	case WM_USER+1030:
		DestroyWindow(hwnd);
		break;
	case WM_USER+1031:
		switch(wParam)
		{
		case 1:
			douninstall=true;
			PostMessage((isGUI ? Hgui : hwnd),WM_COMMAND,IDM_EXIT,0);
			break;
		}
		//MsgBox(NULL,cl,"Command line",MB_OK);
		break;
	case WM_USER+1032:
		if (lParam==WM_RBUTTONDOWN)
		{ 
			POINT pt;
			GetCursorPos(&pt);
			//BringWindowToTop(hwndg);
			//SetForegroundWindow(hwndg);
			DisplayDaemonTrayMenu(hwnd,pt);
			break;
		}
		if (lParam==WM_LBUTTONDBLCLK)
		{
			pnid.cbSize=sizeof(NOTIFYICONDATA);
			pnid.hWnd=hwnd;
			pnid.uID=-1;
			pnid.uFlags=NIF_ICON|NIF_MESSAGE|NIF_TIP;
			pnid.uCallbackMessage=WM_USER+1032;
			pnid.hIcon=LoadIcon(hinst,"AAAA");
			strcpy(pnid.szTip,"GetSmart - The Smartest Download Manager");
			Shell_NotifyIcon (NIM_DELETE, &pnid );
			DWORD tid;
			CreateThread(0,0,(LPTHREAD_START_ROUTINE) InitGUI,
				(void*)hwnd,0,&tid);
		}
		break;
	case WM_G_HWND:
		Hgui=(HWND)wParam;
		isGUI=true;
		mdl=listhead;
		i=0;
		while (mdl)
		{
			//i++;
			//if (i==56) break;
			STELLGUI(MDL_ADD,mdl,0);
			mdl=mdl->next;
		}
		for (i=0;i<=lastmact;i++)
			STELLGUI(MDL_START,actmdls[i].mdl,0);
		for (i=0;i<=lastact;i++)
			STELLGUI(BDL_START,actdls[i],0);
		break;
	case WM_G_DESTROYGUI:
		isGUI=false;
		SendMessage(Hgui,WM_D_DESTROY,0,0);
		Hgui=NULL;
		pnid.cbSize=sizeof(NOTIFYICONDATA);
		pnid.hWnd=hwnd;
		pnid.uID=-1;
		pnid.uFlags=NIF_ICON|NIF_MESSAGE|NIF_TIP;
		pnid.uCallbackMessage=WM_USER+1032;
		pnid.hIcon=LoadIcon(hinst,"AAAA");
		strcpy(pnid.szTip,"GetSmart - The Smartest Download Manager - Daemon");
		Shell_NotifyIcon (NIM_ADD, &pnid );
		break;
	case WM_G_DESTROY:
		isGUI=false;
		SendMessage(Hgui,WM_D_DESTROY,0,0);
		DestroyWindow(hwnd);
		break;
/*	case WM_G_CATCHNS:
		if (cfg.catchns)
			RegisterNS();
		else UnregisterNS();
	case WM_D_DDE:
		switch (wParam)
		{
		case 1:
			p=(char*) lParam;
			if (cfg.startdef)
				AddDefURL(p);
			else
				SendMessage(Hgui,WM_D_URLDETECT,(WPARAM) p,0);
			free(p);
			break;
		case 2:
			RegisterNS();
			break;
		}
		break;
	case WM_G_BROWSE:
		mdl=(maindl*)(void*)wParam;
		if (!mdl) break;
		switch(LOWORD(lParam))
		{
		case 0:
			if (mdl->splitdl[0] && 
				(mdl->splitdl[0]->ctrlsock!=INVALID_SOCKET))
				mdl->splitdl[0]->RideOn();
			break;
		case 1:
			if (mdl->splitdl[0] && 
				(mdl->splitdl[0]->ctrlsock!=INVALID_SOCKET))
				mdl->splitdl[0]->RideOn();
			mdl->KillMain();
			SendMessage(Hgui,WM_D_MAIN,(WPARAM) mdl,3);
			delete mdl;
			break;
		case 2:
			if (mdl->splitdl[0])
				((browseftp*)mdl->splitdl[0])->ChDir();
			break;
		case 3:
			if (mdl->splitdl[0])
				((browseftp*)mdl->splitdl[0])->Refresh();
			break;
		case 4:
			if (mdl->splitdl[0])
				((browseftp*)mdl->splitdl[0])->Custom(mdl->ErrMsg);
			mdl->ErrMsg=ReDupString(mdl->ErrMsg,"");
			break;
		}
		break;*/
	case WM_TIMER:
		memcpy(tID,&wParam,sizeof(tID));
		if (tID[3]==0xff)
		{
			KillTimer(hwnd,wParam);
		}
		break;
		ManagerFunc();
		break;

	case WM_DESTROY: 
		if (lastact!=-1)
			for (int i=0;i<=lastact;i++)
				if (actdls[i]) actdls[i]->mdl->KillMain();
		if ((changesplit>1) && (changesplit!=cfg.maxsplit))
			cfg.maxsplit=changesplit;
		SaveConfig();
		PostQuitMessage(0);
		break;

	case WM_USER+1026:
		if ((LOWORD(lParam) & FD_ACCEPT) == FD_ACCEPT)
		{
			//AddSock(
			accept((SOCKET) wParam,NULL,NULL);
			//sock++;
			return 1;
		}
		if ((LOWORD(lParam) & FD_READ) == FD_READ)
		{
			mdl=AddURL(new dlnfo(2,"127.0.0.1",80,"anonymous",
				cfg.Email,"/","File for browser"),"/",
				"Download for browser.",5,9,0,cfg.resumeto,DEFPR,0,false,
				false,0,0);
			mdl->proxsock=(SOCKET) wParam;
			if (mdl->Cr8DL(mdl->mirrorhead,0,-1,false))
				if (mdl->splitdl[0])
				{
					((dlproxy*)mdl->splitdl[0])->senddata=true;
					WSAAsyncSelect((SOCKET) wParam,hwndg,
						WM_USER+1+mdl->splitdl[0]->actpos,
					(FD_READ | FD_WRITE | FD_CLOSE));
					mdl->splitdl[0]->ActOnRead((SOCKET)wParam);
				}
			return 1;
		}
		if ((LOWORD(lParam) & FD_CLOSE) == FD_CLOSE)
		{
			closesocket((SOCKET)wParam);
			//sock--;
			return 1;
		}
		break;

	case WM_USER+1027:
		if ((LOWORD(lParam) & FD_ACCEPT) == FD_ACCEPT)
		{
			//AddSock(
			accept((SOCKET) wParam,NULL,NULL);
			//sock++;
			return 1;
		}
		if ((LOWORD(lParam) & FD_READ) == FD_READ)
		{
			gsul::ChkReq((SOCKET)wParam);
			return 1;
		}
		if ((LOWORD(lParam) & FD_CLOSE) == FD_CLOSE)
		{
			int hg=3;
			return 1;
		}
		break;

    default:
		if (message==s_uTaskbarRestart)
		{
			TELLGUI(TASK_CRASH,0,0);
			else
			{
				pnid.cbSize=sizeof(NOTIFYICONDATA);
				pnid.hWnd=hwnd;
				pnid.uID=-1;
				pnid.uFlags=NIF_ICON|NIF_MESSAGE|NIF_TIP;
				pnid.uCallbackMessage=WM_USER+1032;
				pnid.hIcon=LoadIcon(hinst,"AAAA");
				strcpy(pnid.szTip,"GetSmart - The Smartest Download Manager - Daemon");
				Shell_NotifyIcon (NIM_ADD, &pnid );
			}
			break;
		}
		if ((message>WM_USER)&&(message<WM_USER+1025))
		{
			if (!actdls[message-WM_USER-1])	break;
			if ((LOWORD(lParam) & FD_CONNECT) == FD_CONNECT)
			{
				actdls[message-WM_USER-1]->ActOnConnect(wParam,lParam);
				if (!actdls[message-WM_USER-1])	break;
			}
			if ((LOWORD(lParam) & FD_ACCEPT) == FD_ACCEPT)
			{
				actdls[message-WM_USER-1]->ActOnAccept(wParam);
				if (!actdls[message-WM_USER-1])	break;
			}
			if ((LOWORD(lParam) & FD_READ) == FD_READ)
			{
				actdls[message-WM_USER-1]->ActOnRead(wParam);
				if (!actdls[message-WM_USER-1])	break;
			}
			if ((LOWORD(lParam) & FD_WRITE) == FD_WRITE)
			{
				actdls[message-WM_USER-1]->ActOnWrite(wParam);
				if (!actdls[message-WM_USER-1])	break;
			}
			if ((LOWORD(lParam) & FD_CLOSE) == FD_CLOSE)
			{
				actdls[message-WM_USER-1]->ActOnClose(wParam);
				if (!actdls[message-WM_USER-1])	break;
			}
			if (actdls[message-WM_USER-1]->gethosthnd==(HANDLE)wParam)
			{
				actdls[message-WM_USER-1]->GotDNS(lParam);
			}
			break;
		}
        return DefWindowProc(hwnd, message, wParam, lParam);
	}
  return 0;
}

VOID APIENTRY DisplayDaemonTrayMenu(HWND hwnd,POINT pt)
{
	HMENU hmenu,hmenuTrackPopup;
	int r2l=0;
	if (cfg.r2l)
		r2l=MFT_RIGHTJUSTIFY|MFT_RIGHTORDER;

	hmenu=CreateMenu();
	hmenuTrackPopup=CreateMenu();

	MENUITEMINFO mi;
	memset(&mi,0,sizeof(MENUITEMINFO));
	mi.cbSize=sizeof(MENUITEMINFO);
	mi.fMask=MIIM_SUBMENU|MIIM_TYPE;
	mi.fType=r2l|MFT_STRING;
	mi.hSubMenu=hmenuTrackPopup;
	InsertMenuItem(hmenu,0,true,&mi);

	mi.fMask=MIIM_DATA|MIIM_ID|MIIM_TYPE;
	mi.hSubMenu=NULL;
	mi.wID=IDM_LOADGUI;
	mi.dwTypeData=GetSTR(316,"Load GUI");
	InsertMenuItem(hmenuTrackPopup,0,true,&mi);

	mi.fType=r2l|MFT_SEPARATOR;
	InsertMenuItem(hmenuTrackPopup,1,true,&mi);

	mi.wID=IDM_EXIT;
	mi.fType=r2l|MFT_STRING;
	mi.dwTypeData=GetSTR(317,"Quit");
	InsertMenuItem(hmenuTrackPopup,2,true,&mi);

	TrackPopupMenuEx(hmenuTrackPopup,TPM_LEFTALIGN|TPM_LEFTBUTTON, 
		pt.x, pt.y,hwnd, NULL);
	DestroyMenu(hmenuTrackPopup);
	DestroyMenu(hmenu);
}

bool UnInstall()
{
	if (MsgBox(
		"Are you sure you want to uninstall GetSmart?",
		"Uninstall GetSmart",MB_YESNO)==IDNO)
		return true;
	LPITEMIDLIST sm;
	HKEY hkey=HKEY_LOCAL_MACHINE,cfgkey;
	char subkey[100]="Software\\GetSmart",windir[MAX_PATH];
	DWORD r;
	r=RegOpenKeyEx(hkey,subkey,0,KEY_ALL_ACCESS,&cfgkey);
	if (r!=ERROR_SUCCESS)
	{
		MsgBox("Error reading configuration!",0,MB_OK);
		return true;
	}
	r=MAX_PATH;
	RegQueryValueEx(cfgkey,"Path",0,0,(unsigned char *)windir,&r);
	RegCloseKey(cfgkey);

	char dn[1024],str[1024];
	SHGetSpecialFolderLocation(NULL, CSIDL_PROGRAMS, &sm);
	SHGetPathFromIDList(sm,dn);
	strcat(dn,"\\GetSmart");
	if (!_access(dn,0))
	{
		sprintf(str,"%s\\GetSmart.lnk",dn);
		DeleteFile(str);
		sprintf(str,"%s\\Help.lnk",dn);
		DeleteFile(str);
		sprintf(str,"%s\\License.lnk",dn);
		DeleteFile(str);
		sprintf(str,"%s\\UnInstall.lnk",dn);
		DeleteFile(str);
		RemoveDirectory(dn);
		SHChangeNotify(SHCNE_RMDIR,SHCNF_PATH,dn,0);
	}

	SHGetSpecialFolderLocation(NULL,CSIDL_STARTUP,&sm);
	SHGetPathFromIDList(sm,dn);
	sprintf(str,"%s\\GetSmart.lnk",dn);
	if (!_access(str,0))
	{
		DeleteFile(str);
		SHChangeNotify(SHCNE_DELETE,SHCNF_PATH,str,0);
	}

	hkey=HKEY_LOCAL_MACHINE,cfgkey;
	strcpy(subkey,"Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\GetSmart");

	if (RegOpenKeyEx(hkey,subkey,0,KEY_ALL_ACCESS,&cfgkey)==ERROR_SUCCESS)
	{
		RegDeleteKey(cfgkey,"DisplayName");
		RegDeleteKey(cfgkey,"UninstallString");
		RegCloseKey(cfgkey);
		RegDeleteKey(hkey,subkey);
	}

	sprintf(str,"%s\\tmp",windir);
	if (!_access(str,0))
	{
		char ffn[1024],match[1024];
		sprintf(ffn,"%s\\*.*",str);
		if ((FFirstFile(ffn,match)))
			do
			{
				sprintf(ffn,"%s\\%s",str,match);
				_unlink(ffn);
			} while (FNextFile(match));
			RemoveDirectory(str);
	}

	sprintf(str,"%s\\Skins",windir);
	RemoveDirectory(str);

	sprintf(str,"%s\\GetSmart.hlp",windir);
	_unlink(str);

	sprintf(str,"%s\\GetSmart.cnt",windir);
	_unlink(str);

	sprintf(str,"%s\\GetSmart.log",windir);
	_unlink(str);

	sprintf(str,"%s\\License.txt",windir);
	_unlink(str);

	DelReg();

	char tfn[_MAX_PATH],*tfn0=_tempnam("\\","DELGS");
	strcpy(tfn,tfn0);
	strcat(tfn,".BAT");
	if (!tfn)
		return false;
	FILE *sf=fopen(tfn,"wt");
	if (!sf)
		return false;
	GetModuleFileName(NULL,dn,1024);
	sprintf(str,":ag\ndel \"%s\\GetSmart.exe\"\ndel \"%s\"\nif exist \"%s\" goto ag\nrd \"%s\"\ndel \"%s\"\n",
		windir,dn,dn,windir,tfn);
	fwrite(str,1,strlen(str),sf);
	fclose(sf);

	STARTUPINFO si;
	PROCESS_INFORMATION pi;

	memset(&si,0,sizeof(si));
	si.cb = sizeof(si);

	si.dwFlags = STARTF_USESHOWWINDOW;
	si.wShowWindow = SW_HIDE;

	if (CreateProcess(NULL, tfn, NULL, NULL, FALSE,
		CREATE_SUSPENDED | IDLE_PRIORITY_CLASS, NULL, "\\", &si, &pi))
	{

		SetThreadPriority(pi.hThread, THREAD_PRIORITY_IDLE);

		SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL);
		SetPriorityClass(GetCurrentProcess(), HIGH_PRIORITY_CLASS);

		CloseHandle(pi.hProcess);
		ResumeThread(pi.hThread);

		CloseHandle(pi.hThread);
	}
	MessageBox(NULL,"Done.","UnInstall",MB_OK);
	ExitProcess(0);
	return true;
}
