
#include "Daemon.h"
#include "html2links.h"

void mirrsearch::ActOnClose(SOCKET sock)
{
	if (sock==ctrlsock)
	{
		CloseSock(ctrlsock,true);
		CloseData();
	}
}

bool mirrsearch::ActOnStatus()
{
	int result;
	char str[1024];
	time(&timeout);
	switch (status)
	{
	case 0:
		return GenActOnHTTPStatus();
		break;
	case 1:
		firstread=true;
		result=0;
		readbuffi=0;
		relocation=false;
		char str2[1024],str3[1024];
		if (useproxy==2)
		{
			ConstURL(mir->nfo,str2);
			rcs(str2);
			sprintf(str,"GET %s HTTP/1.0\r\nHost: %s\r\n",str2,
					mir->nfo->host);
			if (strlen(cfg.Proxy.huser))
			{
				sprintf(str2,"%s:%s",cfg.Proxy.huser,cfg.Proxy.hpass);
				Base64(str2,str3);
				sprintf(str2,"Proxy-Authorization: Basic %s\r\n",str3);
				strcat(str,str2);
			}
			if (cfg.Proxy.nocache)
				strcat(str,"Pragma: no-cache\r\nCache-Control: no-cache\r\n");
		}			
		else
		{
			sprintf(str2,"%s%s",mir->nfo->rdir,mir->nfo->rfn);
			rcs(str2);
			sprintf(str,"GET %s HTTP/1.0\r\nHost: %s\r\n",str2,
					mir->nfo->host);
		}
		result=0;
		strcat(str,"Range: bytes=");
		strcpy(str2,str);
		sprintf(str,"%s%ld-\r\nRequest-Range: bytes=%ld-\r\n",str2,
			result,result);
		if (cfg.referer)
		{
			char pr[100];
			if (mir->nfo->prot==1)
				strcpy(pr,"ftp://");
			else
				strcpy(pr,"http://");
			sprintf(str2,"Referer: %s%s/index.html\r\n",pr,mir->nfo->host);
			strcat(str,str2);
		}
		if (!cfg.uuagent)
			strcat(str,"User-agent: GetSmart/"VERSION"\r\n");
		else
		{
			sprintf(str2,"User-agent: %s\r\n",cfg.uagent);
			strcat(str,str2);
		}
		if (strcmp("anonymous",mir->nfo->user)||
			strcmp(cfg.Email,mir->nfo->pass))
		{
			sprintf(str2,"%s:%s",mir->nfo->user,mir->nfo->pass);
			Base64(str2,str3);
			sprintf(str2,"Authorization: Basic %s\r\n",str3);
			strcat(str,str2);
		}
		strcat(str,"Accept: *.*, */*\r\nConnection: Keep-Alive\r\n\r\n");
		wb(str,1);
		send(ctrlsock,str,strlen(str),0);
		break;
	}
	return true;
}

int mirrsearch::ReadCtrl()
{
	time(&timeout);
	if (!mdl->isdl)
		mdl->timeout=timeout;
	int ret=0,i;
	unsigned int localbytes0;
	char res[AVGBUFSIZE*2],str[AVGBUFSIZE*2],buf3[AVGBUFSIZE*2];
	if (mdl->spe[splitdex] && 
		((mdl->localbytes[splitdex]+mdl->sps[splitdex])>=(mdl->spe[splitdex]+1)))
	{
		RideOn();
		return 0;
	}
	if (status<3)
		ret=ReadSocket(ctrlsock,res,readbuff,readbuffi);
	else
	{
		ret=recv(ctrlsock,readbuff+readbuffi,AVGBUFSIZE-readbuffi-1,0);
		if (ret>0)
			readbuff[readbuffi+ret]='\0';
	}
	if (ret<=0) return 0;
	if (status<3) GetLine(res,str);
	else strcpy(str,"ttt");
	while (strlen(str))
	{
		if (status<3)
			while (strlen(str)&&((*(str+3) == '-') || (*(str)==' ')))
			{
				wb(str,4);
				GetLine(res,str);
			}
		if (!strlen(str))
			return ret;
		if (status<3)
		{
			wb(str,2);
			strcpy(buf3,str);
		}
		//else wb(readbuff,2);
		if (status==3)
		{
			while (!(i=FindNextLink(readbuff,buf3,NULL)))
			{
				char *s1,*s2;
				dlnfo *nfo0=ConvertURL(buf3);
				s1=_strlwr(_strdup(nfo0->rfn));
				s2=_strlwr(_strdup(mmdl->mirrorhead->nfo->rfn));
				if (!strcmp(s1,s2)) //&& strstr(s1,"://"))
					AddMirror(mmdl,nfo0);
				delete nfo0;
				free(s1);
				free(s2);
			}
			if (i==-1)
				readbuffi=strlen(readbuff);
			else readbuffi=0;
			return ret;
		}
		else
		switch (GenHTTPCtrl(buf3))
		{
		case -1:
			return 0;
			break;
		case 0:
			resume=false;
			switch (httpres)
			{
			case 200:
			case 206:
				if (httpres==206)
				{
					resume=true;
					if (type==6)
						mir->resume=true;
					if (!mdl->resume)
						mdl->resume=true;
					err[3]=0;
				}
				else resume=false;
				status=2;
				mdl->MainFunc(1,this);
				break;
			case 302:
			case 301:
				//if (m->proxsock) logged=true;
				break;
			default:
				mdl->ErrMsg=ReDupString(mdl->ErrMsg,buf3);
				doerr(8);
				return 1;
			}
			break;
			case 2:
				if (!mdl->spe[splitdex])
					mdl->spe[splitdex]=mdl->rsize-1;
				if (!resume && mdl->rsize)
				{
					checkint=false;
					if (mdl->splitdex) localbytes0=mdl->localbytes[splitdex]+mdl->sps[splitdex];
					else localbytes0=mdl->localbytes[splitdex];
					if (mdl->rsize<=localbytes0)
					{
						mdl->spdone[splitdex]=true;
						RideOn();
						return 0;
					}
				}
				//Tell GUI we've got size.
				break;
			case 5:
				if (relocation)
				{
					char *location=DupString(buf3+10);
					if (location[strlen(location)-2]=='\r')
						location[strlen(location)-2]='\0';
					else
						if (location[strlen(location)-1]=='\n')
							location[strlen(location)-1]='\0';
						
					// add relocation support.
					dlnfo *n=ConvertURL(location);
					MoveMirr(AddMirror(mdl,n));
					mir->relocation=true;
					delete n;
					CloseSockets();
					QueryDNS();
					free(location);
					return false;
				}
				break;
			case 8:
				if (status!=2)
				{
					status=0;
					ActOnStatus();
					return 0;
				}
				status=3;
				if (!mdl->info)
				{
					if (resume) 
						mdl->resume=resume;
					mdl->info=true;
				}
				strcpy(str,GetSTR(28,"Downloading file."));
				wb(str,0);
				wstatus(str);
				if (!readbuffi)
				{
					if (readbuff)
						readbuff=(char*)realloc(readbuff,AVGBUFSIZE*2);
					else readbuff=(char*)malloc(AVGBUFSIZE*2);
					return ret;
				}
				else
				{
					memcpy(buf3,readbuff,readbuffi);
					readbuff=(char*)realloc(readbuff,AVGBUFSIZE*2);
					memcpy(readbuff,buf3,readbuffi);
					readbuff[readbuffi]='\0';
				}
				break;
		}
		if (status<3)
			GetLine(res,str);
		else strcpy(str,"ttt");
	}
	return ret;
}
