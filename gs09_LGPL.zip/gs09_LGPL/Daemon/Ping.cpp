
// PING.C -- Ping program using ICMP and RAW Sockets
//

#include <stdio.h>
#include <stdlib.h>
#include "../DiffOS.h"
#ifdef _WIN32
#include <winsock2.h>
#endif
#ifdef __unix__
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include "../UnixWin32defs.h"
#endif

#include "Ping.h"

// Internal Functions
u_short in_cksum(u_short *addr, int len);

// ICMP Echo Request/Reply functions
//int	SendEchoRequest(SOCKET, LPSOCKADDR_IN);
//DWORD RecvEchoReply(SOCKET, LPSOCKADDR_IN, u_char *);

// SendEchoRequest()
// Fill in echo request header
// and send to destination
int SendEchoRequest(SOCKET s,SOCKADDR_IN *ctrladdr) 
{
	static ECHOREQUEST echoReq;
	static nId = 1;
	static nSeq = 1;
	int nRet;
	SOCKADDR_IN stToAddr;

	stToAddr.sin_addr.s_addr = ctrladdr->sin_addr.s_addr ;
	stToAddr.sin_family = AF_INET;
	stToAddr.sin_port = 0;

	// Fill in echo request
	echoReq.icmpHdr.Type		= ICMP_ECHOREQ;
	echoReq.icmpHdr.Code		= 0;
	echoReq.icmpHdr.Checksum	= 0;
	echoReq.icmpHdr.ID			= nId++;
	echoReq.icmpHdr.Seq			= nSeq++;

	// Fill in some data to send
	for (nRet = 0; nRet < REQ_DATASIZE; nRet++)
		echoReq.cData[nRet] = ' '+nRet;

	// Save tick count when sent
#ifndef gsdbg
	echoReq.dwTime				= GetTickCount();
#else
	echoReq.dwTime=1;
#endif


	// Put data in packet and compute checksum
	echoReq.icmpHdr.Checksum = in_cksum((u_short *)&echoReq, sizeof(ECHOREQUEST));

	// Send the echo request  								  
	nRet = sendto(s,						/* socket */
				 (char*)&echoReq,			/* buffer */
				 sizeof(ECHOREQUEST),
				 0,							/* flags */
				 (SOCKADDR*)&stToAddr, /* destination */
				 sizeof(SOCKADDR_IN));   /* address length */

	return (nRet);
}


// RecvEchoReply()
// Receive incoming data
// and parse out fields
unsigned long RecvEchoReply(SOCKET s, SOCKADDR_IN *lpsaFrom, u_char *pTTL) 
{
	ECHOREPLY echoReply;
	int nRet;
	int nAddrLen = sizeof(struct sockaddr_in);

	// Receive the echo reply	
	nRet = recvfrom(s,					// socket
					(char*)&echoReply,	// buffer
					sizeof(ECHOREPLY),	// size of buffer
					0,					// flags
					(SOCKADDR*)lpsaFrom,	// From address
					(OSsign int*)&nAddrLen);			// pointer to address len

	// Check return value
	if ((nRet==SOCKET_ERROR)||(nRet!=65))
		return 0;

	// return time sent and IP TTL
	*pTTL = echoReply.ipHdr.TTL;
	return(GetTickCount()-echoReply.echoRequest.dwTime);   		
}

//
// Mike Muuss' in_cksum() function
// and his comments from the original
// ping program
//
// * Author -
// *	Mike Muuss
// *	U. S. Army Ballistic Research Laboratory
// *	December, 1983

/*
 *			I N _ C K S U M
 *
 * Checksum routine for Internet Protocol family headers (C Version)
 *
 */
u_short in_cksum(u_short *addr, int len)
{
	register int nleft = len;
	register u_short *w = addr;
	register u_short answer;
	register int sum = 0;

	/*
	 *  Our algorithm is simple, using a 32 bit accumulator (sum),
	 *  we add sequential 16 bit words to it, and at the end, fold
	 *  back all the carry bits from the top 16 bits into the lower
	 *  16 bits.
	 */
	while( nleft > 1 )  {
		sum += *w++;
		nleft -= 2;
	}

	/* mop up an odd byte, if necessary */
	if( nleft == 1 ) {
		u_short	u = 0;

		*(u_char *)(&u) = *(u_char *)w ;
		sum += u;
	}

	/*
	 * add back carry outs from top 16 bits to low 16 bits
	 */
	sum = (sum >> 16) + (sum & 0xffff);	/* add hi 16 to low 16 */
	sum += (sum >> 16);			/* add carry */
	answer = ~sum;				/* truncate to 16 bits */
	return (answer);
}
