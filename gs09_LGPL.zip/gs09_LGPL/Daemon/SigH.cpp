#include <signal.h>

void InstHandlers()
{
return;
  struct sigaction sigH;
  sigemptyset(&sigH.sa_mask);
  sigH.sa_handler=SIG_IGN;
  sigaction(SIGHUP,&sigH,NULL);
  sigaction(SIGCHLD,&sigH,NULL);
  sigH.sa_flags=/*SA_ONESHOT|*/SA_RESETHAND;
  sigaddset(&sigH.sa_mask,SIGTERM);
  sigaddset(&sigH.sa_mask,SIGQUIT);
  sigaddset(&sigH.sa_mask,SIGPWR);
  //sigH.sa_handler=&WrHandler;
  //  sigaction(SIGQUIT, &sigH,NULL);
  // i'll do it l8r....
}






