
#include "html2links.h"


// !TODO!:: handle html comments
long FindNextLink(char *bf,char *link,char *desc)
{
	int i;
	// look for a tag
	char*sc=bf;
SeekNextTag:
	while (sc[0] && sc[0]!='<')
		sc++;
ChkNextLetter:
	if (!sc[0]){	link[0]=0;	return 1;}
	sc++;
/*	while (sc[0] && sc[0]!='>' && sc[0]!='/' && sc[0]!='=' && sc[0]!='\"' && 
				 sc[0]!='a' && sc[0]!='A' && sc[0]!='s' && sc[0]!='S')*/
	while (sc[0] && (NULL==strchr(">/=\"aAsS",sc[0])))
		sc++;
	if (!sc[0]){	link[0]=0;	return 1; }
	if (sc[0]=='/' // this is a closing tag, seek next tag.
		|| sc[0]=='>') // tag over.
		goto SeekNextTag;
	if (sc[0]=='='){
		while (sc[0] && (sc[0]!='>'))
			sc++;
		goto SeekNextTag;
	}
	if (sc[0]=='\"'){ //  seek end of "
		if (SkipTheseQuetes(sc)==-1)
			return 1;
		goto ChkNextLetter;
	}
	if (sc[0]=='a' || sc[0]=='A'){
		memmove(bf+1,sc,strlen(sc)+1);
		sc=bf+1;
		bf[0]='<';//for next scan if the buffer is too small
		sc++;
		if (sc[0] && !ISWHITESP(sc[0]))
			goto ChkNextLetter;
		if (!sc[0])
			return -1;
		// look for "HREF"
ChkMoreH:
//		while (sc[0] && sc[0]!='\"' && sc[0]!='=' && sc[0]!='>' && sc[0]!='h' && sc[0]!='H')
		while (sc[0] && (NULL==strchr("\"=>hH",sc[0])))
			sc++;
		if (!sc[0]) return -1;
		if (sc[0]=='>') goto SeekNextTag;
		if (sc[0]=='='){
			while (sc[0] && ISWHITESP(sc[0]))
				sc++;
			if (!sc[0]) return -1;
			sc++;
			if (sc[0]!='\"'){
				if (SkipTheseQuetes(sc)==-1)
					return -1;
/*				while (sc[0] && sc[0]!='\"')
					sc++;
				if (sc[0]=='\"')*/
					goto ChkMoreH;
/*				else
					return -1;*/
			}
		}
		if (sc[0]=='\"'){
			sc++;
			if (SkipTheseQuetes(sc)==-1){
				link[0]=0;	return 1; }
/*			while (sc[0] && sc[0]!='\"')
				sc++;
			if (!sc[0]){	link[0]=0;	return 1; }
			sc++;*/
			goto ChkMoreH;
		}
		if (sc[0]!='h' && sc[0]!='H') goto ChkMoreH;
		sc++;
		if (sc[0]!='r' && sc[0]!='R') goto ChkMoreH;
		sc++;
		if (sc[0]!='e' && sc[0]!='E') goto ChkMoreH;
		sc++;
		if (sc[0]!='f' && sc[0]!='F') goto ChkMoreH;
		sc++;
		while (sc[0] && sc[0]!='=')
			sc++;
		if (!sc[0])	return -1;
		sc++;
		while (sc[0] && ISWHITESP(sc[0]))
			sc++;
		if (!sc[0]) return -1;
		if (sc[0]=='\"')
			sc++;
		i=0;
		while (sc[0] && sc[0]!='>' && sc[0]!='\"')
			link[i++]=sc++[0];
		link[i]=0;
		if (!sc[0])
			return -1;
		if (sc[0]=='\"'){
			while (sc[0] && sc[0]!='>')
				sc++;
			if (!sc[0]) 
				return -1;
		}
	} // end of A HREF scanning.
	else{ // scan SRC= thingies.
				// ^^ later
		while (sc[0] && sc[0]!='>')
			sc++;
		goto SeekNextTag;
	}
	// we're here only if a full link was found and allocated
	memmove(bf,sc,strlen(sc)+1);
	if (!desc) { return 0;} // no desc requested.
	sc=bf;
	//now fill the desc.
	while (sc[0] && sc[0]!='>')
		sc++;
	if (!sc[0])
		return 2;
	i=0;
	// or here??
	sc++;
MoreDescScan:
	while (sc[0] && sc[0]!='<')
		desc[i++]=sc++[0];
	if (!sc[0]) return 2;
	char*begtag=&desc[i];
	while (sc[0] && sc[0]!='/' && sc[0]!='>' && sc[0]!='\"')
		desc[i++]=sc++[0];
	if (!sc[0]) return 2;
	if (sc[0]=='>') // a non '/' tag
		goto MoreDescScan;
	if (sc[0]=='\"'){
		desc[i++]=sc++[0];
		while (sc[0] && sc[0]!='\"')
			desc[i++]=sc++[0];
		goto MoreDescScan;
	}
	desc[i++]=sc++[0];
	if (!sc[0]) return 2;
	if (sc[0]=='A' || sc[0]=='a'){
		*begtag=0;
		return 0;
	}
	else
		goto MoreDescScan;
}

void NullifyTags(char *bf)
{
	char*beg;
	for (;;){
		while (bf[0] && bf[0]!='<')
			bf++;
		if (!bf[0]) return;
		beg=bf;
		while (bf[0] && bf[0]!='>')
			bf++;
		if (bf[0]){
			bf++;
			memmove(beg,bf,strlen(bf)+1);
		}
		else{
			*beg=0; // a non ending tag, just tag the EndOfString here
			return;
		}
	}
}

// TODO:: handle escapes or such things....
char SkipTheseQuetes(char*&bf)
{
	bf++;
	while (bf[0] && bf[0]!='\"')
                bf++;
	if (!bf[0]) return -1;
	bf++;
	return 0;
}
