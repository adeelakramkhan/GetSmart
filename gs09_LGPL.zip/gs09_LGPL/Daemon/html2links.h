
#ifndef _HTML2LINKS_H
#define _HTML2LINKS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define ISWHITESP(c) (c==' ' || c=='\n' || c=='\r' || c=='\t')
/* link and desc are assumed same size of buff, desc==NULL => no desc scan
 * returns: 0=> link, 1=> no link found, -1=> in middle of tag, 2=> middle of desc
 */
long FindNextLink(char *buff,char *link,char *desc);

// nullfies html tags<>....
void NullifyTags(char *buff);

char SkipTheseQuetes(char*&bf);

#endif // 3OF