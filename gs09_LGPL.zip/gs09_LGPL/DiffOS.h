

unsigned long GetFSize(FILE*fp);

#ifdef _WIN32
#define OSsign signed
#define trunc(a,b)\
_chsize(_fileno(a),b)
#endif // win32
#ifdef __unix__
#define OSsign unsigned
char *_strlwr(char*s);
int CreateDirectory(char*q,void* r);
int MoveFile(char*f,char*t);
unsigned long GetTickCount();
#define trunc(a,b)\
ftruncate(fileno(a),b)
#ifndef SD_BOTH
#define SD_BOTH 2
#endif

#endif // unix


