
#include "GUI.h"

//HWND CreateTB2(HWND hwndp);
void UpdateClient(HWND hdwnd,maindl *mdl);
void AddItem2(HWND hwndLV2, mainftp *m);
BOOL CALLBACK EnterURLFunc(HWND, UINT, WPARAM, LPARAM);
BOOL CALLBACK CustomDL(HWND, UINT, WPARAM, LPARAM);
BOOL CALLBACK CustomFunc(HWND, UINT, WPARAM, LPARAM);
BOOL CALLBACK DLorBRFunc(HWND, UINT, WPARAM, LPARAM);
int CALLBACK WildCompareFunc(LPARAM, LPARAM, LPARAM);
LRESULT WINAPI NewListProc(HWND, UINT, WPARAM, LPARAM);
int CALLBACK StatusCmpFunc(LPARAM, LPARAM, LPARAM);
void GetMainLVIcon(HICON &hIcon3,STATUSITEM *pitem,int&ic);

void RemoveWildLV(HWND hwndLV2)
{
	for (int i=0;i<ListView_GetItemCount(hwndLV2);i++)
	{
		STATUSITEM *pitem = (STATUSITEM *) GetLVlParam(hwndLV2,i);
		for (int j=0;j<50;j++)
			if (((mainftp*)pitem->mdl->guiparam)->itempos[j].hwndU==hwndLV2)
			{
				((mainftp*)pitem->mdl->guiparam)->itempos[j].hwndU=NULL;
				break;
			}
	}
	ListView_DeleteAllItems(hwndLV2);
}
/*
void RemoveCache(mainftp *m)
{
	for (int i=0;i<100;i++)
		if (m->cache[i].item)
		{
			LocalFree(m->cache[i].cwd);
			LocalFree(m->cache[i].item);
		}
	m->cachei=-1;
	for (i=0;i<ListView_GetItemCount(m->hwndWV);i++)
	{
		WILDITEM *pitem = (WILDITEM *) GetLVlParam(m->hwndWV,i);
		for (int j=0;j<4;j++)
			LocalFree(pitem->c[j]);
		LocalFree(pitem);
	}
	ListView_DeleteAllItems(m->hwndWV);
}
*/
LRESULT CALLBACK BrowseFunc(HWND hwnd, UINT message,
                            WPARAM wParam, LPARAM lParam)
{
	SkinWinNfo *skbrowse=(SkinWinNfo*)GetWindowLong(hwnd,GWL_USERDATA);
	maindl *mdl;
	browsedl *bdl;
	mainftp *m;
	WILDITEM *pitem;
	char str[1000],*tmp,str2[1000];
	char htxt[10][50];
	int j,j1,y,i,mode;
	static int ls;
	static int s[4]={0,1,1,1};
	static char sktxt[4][80];
	static int sortd[10]={1,0,0,0,0,0,0,1,1},lsortd=-1;
	strcpy(sktxt[0],GetSTR2(98,"Host:"));
	strcpy(sktxt[1],GetSTR2(99,"Port:"));
	strcpy(sktxt[2],GetSTR2(100,"User:"));
	strcpy(sktxt[3],GetSTR2(101,"Pass:"));
	dds2();
	char c;
    LPMEASUREITEMSTRUCT lpmis;
    LPDRAWITEMSTRUCT lpdis;
	TEXTMETRIC tm;
	RECT re;
	static COLORREF clr[5]={RGB(0,0,255), RGB(0,255,0), RGB(60,200,60),
		RGB(255,0,0), RGB(255,255,255) };
	dlnfo *dln;

	if (skbrowse)
	{
		mdl=(maindl*)skbrowse->data;
		m=(mainftp*) mdl->guiparam;
		if (m->lv2.LVFunc(hwnd,message,wParam,lParam))
			return 0;
		if (m->wlv.LVFunc(hwnd,message,wParam,lParam))
			return 0;
		bdl=(browsedl*) mdl->splitdl[0];
	}
	LRESULT ret=browseskin.fn(hwnd,message,wParam,lParam);
	static DWORD aIds[] = 
	{
		IDD_HOST,IDH_FCHOS,
		IDD_PORT,IDH_FCPOR,
		IDD_USER,IDH_FCUSE,
		IDD_PASS,IDH_FCPAS,
//		IDD_PINGTEXT,IDH_FCPIN,
//		IDD_TOTEXT,IDH_FCTO,
//		IDD_CONSOLE,IDH_FCCNS,
		IDD_LDIR,IDH_FCLOC,
		IDD_RDIR,IDH_FCREM,
		IDD_BROWSE,IDH_FCBRO,
//		IDD_BUFFER,IDH_FCCNS,
			0,0
	};
	switch(message)
	{
    case WM_HELP:
		if (((LPHELPINFO) lParam)->hItemHandle==m->hwndWV)
		{
			WinHelp(hwnd, HelpFile, HELP_CONTEXTPOPUP,IDH_FCLIS);
			break;
		}
		if (((LPHELPINFO) lParam)->hItemHandle==m->hwndLV2)
		{
			WinHelp(hwnd, HelpFile, HELP_CONTEXTPOPUP,IDH_FCQUE);
			break;
		}		
		if (((LPHELPINFO) lParam)->hItemHandle==m->mftp->hwndBB)
		{
			WinHelp(hwnd, HelpFile, HELP_CONTEXTPOPUP,IDH_FCCNS);
			break;
		}		
		WinHelp(((LPHELPINFO) lParam)->hItemHandle, HelpFile, 
			HELP_WM_HELP, (DWORD) (LPSTR) aIds);
		break;
	case WM_CONTEXTMENU: 
		if ((HWND) wParam==m->hwndWV)
		{
			WinHelp(hwnd, HelpFile, HELP_CONTEXTPOPUP,IDH_FCLIS);
			break;
		}
		if ((HWND) wParam==m->hwndLV2)
		{
			WinHelp(hwnd, HelpFile, HELP_CONTEXTPOPUP,IDH_FCQUE);
			break;
		}
		if ((HWND) wParam==m->mftp->hwndBB)
		{
			WinHelp(hwnd, HelpFile, HELP_CONTEXTPOPUP,IDH_FCCNS);
			break;
		}
		WinHelp((HWND) wParam, HelpFile, HELP_CONTEXTMENU,
				(DWORD) (LPVOID) aIds);
		break;
	case WM_RBUTTONUP:
		if (m->mftp->sksmall.bover!=-1)
			WinHelp(hwnd, HelpFile,HELP_CONTEXTPOPUP,m->mftp->sksmall.bover+15);
		break;

	case WM_CREATE:
		skbrowse=(SkinWinNfo*)(((LPCREATESTRUCT) lParam)->lpCreateParams); 
		mdl=(maindl*)skbrowse->data;
		m=(mainftp*) mdl->guiparam;
		bdl=(browsedl*) mdl->splitdl[0];
		m->hwild=hwnd;
		ls=-1;
		// creating wild listview
		strcpy(htxt[0],GetSTR2(102,"File Name"));
		strcpy(htxt[1],GetSTR2(103,"Size"));
		strcpy(htxt[2],GetSTR2(104,"Date"));
		strcpy(htxt[3],GetSTR2(105,"Attributes"));
		dds2();
		m->wlv.pos.top=199;
		m->wlv.pos.bottom=158;
		m->wlv.fixedh=true;
		m->wlv.Init(hwnd,&htxt[0][0],&WildCol[0],4);
		m->hwndWV=m->wlv.hwndLV;
		//m->hwndWV=DoCreateList(hwnd,&htxt[0][0],&WildCol[0],4,false,0);
		HICON hiconItem;
		HIMAGELIST himlSmall;
		himlSmall = ImageList_Create(GetSystemMetrics(SM_CXSMICON), 
			GetSystemMetrics(SM_CYSMICON), ILC_COLOR8 | ILC_MASK, 4, 4);
		hiconItem = LoadIcon(hlang, "FOLDERICON"); 
		ImageList_AddIcon(himlSmall, hiconItem);
		DeleteObject(hiconItem);  
		hiconItem = LoadIcon(hlang, "LINKICON"); 
		ImageList_AddIcon(himlSmall, hiconItem);
		DeleteObject(hiconItem);  
		hiconItem = LoadIcon(hlang, "FILEICON"); 
		ImageList_AddIcon(himlSmall, hiconItem);
		DeleteObject(hiconItem);
		ListView_SetImageList(m->hwndWV, himlSmall, LVSIL_SMALL);
		m->wlv.il=himlSmall;

		// creating status listview
		strcpy(htxt[0],GetSTR2(102,"File Name"));
		strcpy(htxt[1],GetSTR2(103,"Size"));
		strcpy(htxt[2],GetSTR2(106,"Progress"));
		strcpy(htxt[3],GetSTR2(107,"Current speed"));
		strcpy(htxt[4],GetSTR2(108,"Est. Time Left"));
		strcpy(htxt[5],GetSTR2(109,"Resume"));
		strcpy(htxt[6],GetSTR2(110,"Timeout"));
		strcpy(htxt[7],GetSTR2(111,"Priority"));
		strcpy(htxt[8],GetSTR2(112,"URL"));
		strcpy(htxt[9],GetSTR2(113,"Status"));
		dds2();
		m->lv2.pos.top=357;
		m->lv2.pos.bottom=-357;
		m->lv2.msg=2;
		m->lv2.Init(hwnd,&htxt[0][0],&StatusCol[0],10);
		m->hwndLV2=m->lv2.hwndLV;
		ListView_SetImageList(m->hwndLV2, hlvicons, LVSIL_SMALL);
/*		m->hwndLV2=DoCreateList(hwnd,&htxt[0][0],&StatusCol[0],10,
			false,0);
		hlvicons = ImageList_Create(GetSystemMetrics(SM_CXSMICON),
			GetSystemMetrics(SM_CYSMICON),ILC_COLOR8|ILC_MASK,7,1);
		hiconItem = LoadIcon(hlang, "MAIN1ICON");
		ImageList_AddIcon(hlvicons, hiconItem);
		DeleteObject(hiconItem);
		hiconItem = LoadIcon(hlang, "MAIN2ICON");
		ImageList_AddIcon(hlvicons, hiconItem);
		DeleteObject(hiconItem);
		hiconItem = LoadIcon(hlang, "MAIN3ICON");
		ImageList_AddIcon(hlvicons, hiconItem);
		DeleteObject(hiconItem);
		hiconItem = LoadIcon(hlang, "MAIN4ICON");
		ImageList_AddIcon(hlvicons, hiconItem);
		DeleteObject(hiconItem);
		hiconItem = LoadIcon(hlang, "ROBOTICON");
		ImageList_AddIcon(hlvicons, hiconItem);
		DeleteObject(hiconItem);
		hiconItem = LoadIcon(hlang, "SUCCESSICON");
		ImageList_AddIcon(hlvicons, hiconItem);
		DeleteObject(hiconItem);
		hiconItem = LoadIcon(hlang, "ERRORICON");
		ImageList_AddIcon(hlvicons, hiconItem);
		DeleteObject(hiconItem);
		ListView_SetImageList(m->hwndLV2, hlvicons, LVSIL_SMALL);*/

		// creating console
		m->mftp->hwndBB = CreateWindowEx(WS_EX_DLGMODALFRAME,
			"LISTBOX", "",WS_CHILD |WS_VSCROLL | LBS_HASSTRINGS|LBS_NOSEL|LBS_OWNERDRAWFIXED|LBS_NOINTEGRALHEIGHT,
							0, 0, 0, 0, hwnd, NULL, hinst, NULL);
		((smallftp*)bdl->guiparam)->hwndBB=m->mftp->hwndBB;
		SetProp(m->mftp->hwndBB, "OldProc", (HANDLE)GetWindowLong(m->mftp->hwndBB, GWL_WNDPROC));
		SetWindowLong(m->mftp->hwndBB, GWL_WNDPROC, (DWORD)NewListProc);

		CreateWindowEx(WS_EX_DLGMODALFRAME,
			"EDIT", "",WS_CHILD|WS_VISIBLE|WS_TABSTOP|ES_AUTOHSCROLL,
				50, 52, 155, 20, hwnd, (void*)IDD_HOST, hinst, NULL);
		SendDlgItemMessage(hwnd,IDD_HOST,WM_SETFONT,(WPARAM)gfont,0);
		CreateWindowEx(WS_EX_DLGMODALFRAME,
			"EDIT", "",WS_CHILD|WS_VISIBLE|WS_TABSTOP|ES_AUTOHSCROLL|ES_NUMBER,
				260,52,60,20,hwnd, (void*)IDD_PORT, hinst, NULL);
		SendDlgItemMessage(hwnd,IDD_PORT,WM_SETFONT,(WPARAM)gfont,0);
		CreateWindowEx(WS_EX_DLGMODALFRAME,
			"EDIT", "",WS_CHILD|WS_VISIBLE|WS_TABSTOP|ES_AUTOHSCROLL,
				365,52,120,20,hwnd, (void*)IDD_USER, hinst, NULL);
		SendDlgItemMessage(hwnd,IDD_USER,WM_SETFONT,(WPARAM)gfont,0);
		CreateWindowEx(WS_EX_DLGMODALFRAME,
			"EDIT", "",WS_CHILD|WS_VISIBLE|WS_TABSTOP|ES_AUTOHSCROLL,
				525,52,140,20,hwnd, (void*)IDD_PASS, hinst, NULL);
		SendDlgItemMessage(hwnd,IDD_PASS,WM_SETFONT,(WPARAM)gfont,0);
		CreateWindowEx(WS_EX_DLGMODALFRAME,
			"EDIT", "",WS_CHILD|WS_VISIBLE|WS_TABSTOP|ES_AUTOHSCROLL,
				7,136,199,14,hwnd, (void*)IDD_LDIR, hinst, NULL);
		SendDlgItemMessage(hwnd,IDD_LDIR,WM_SETFONT,(WPARAM)gfont,0);
		CreateWindowEx(WS_EX_STATICEDGE,
			"COMBOBOX", "",WS_CHILD|WS_VISIBLE|WS_TABSTOP|CBS_DROPDOWN|CBS_AUTOHSCROLL|CBS_SORT | WS_VSCROLL,
				254,137,225,65,hwnd, (void*)IDD_RDIR, hinst, NULL);
		CreateWindowEx(0,
			"BUTTON", GetSTR2(114,"Browse"),WS_CHILD|WS_VISIBLE|WS_TABSTOP,
				210,137,248,65,hwnd, (void*)IDD_BROWSE, hinst, NULL);
		dds2();
		SendDlgItemMessage(hwnd,IDD_BROWSE,WM_SETFONT,(WPARAM)gfont,0);

		SetDlgItemText(hwnd,IDD_HOST,mdl->mirrorhead->nfo->host);
		SetDlgItemInt(hwnd,IDD_PORT,mdl->mirrorhead->nfo->port,false);
		SetDlgItemText(hwnd,IDD_USER,mdl->mirrorhead->nfo->user);
		SetDlgItemText(hwnd,IDD_PASS,mdl->mirrorhead->nfo->pass);
		SetDlgItemText(hwnd,IDD_RDIR,mdl->mirrorhead->nfo->rdir);
		SetDlgItemText(hwnd,IDD_LDIR,mdl->ldir);
		sprintf(str,GetSTR2(26,"Browsing %s%s"),mdl->mirrorhead->nfo->host,
				mdl->mirrorhead->nfo->rdir);
		dds2();
		mdl->lfn=ReDupString(mdl->lfn,str);
		SetWindowText(hwnd,str);
		j1=ListView_GetItemCount(hwndLV);
		for (j=0;j<j1;j++)
		{
			STATUSITEM *pitem = (STATUSITEM *) GetLVlParam(hwndLV,j);
			maindl *mb=pitem->mdl;
			if (!stricmp(mdl->mirrorhead->nfo->host,mb->mirrorhead->nfo->host)&&(mb->type!=2))
				AddItem2(m->hwndLV2,(mainftp*)mb->guiparam);
		}
		PostMessage(hwnd,_SKN_BTSET,MAKELONG(7,0),1);
		for (i=0;i<4;i++)
			PostMessage(hwnd,_SKN_TXT,MAKELONG(i,0),(LPARAM)sktxt[i]);
		if (BrowseRect.top || BrowseRect.left || BrowseRect.right ||
													BrowseRect.bottom)
			MoveWindow(hwnd,BrowseRect.left,BrowseRect.top,
				BrowseRect.right-BrowseRect.left,
				BrowseRect.bottom-BrowseRect.top,true);
		SetMenu(hwnd,Hmenu2);
		SendMessage(hwnd,WM_SIZE,0,0);
		ShowWindow(hwnd,SW_SHOW);
		SetFocus(m->hwndLV2);
		SetForegroundWindow(hwnd);
		break;

	case WM_ACTIVATE:
		if	(LOWORD(wParam) == WA_INACTIVE)
			hgdlg=NULL;
		else
			hgdlg=hwnd;
		break;

	case WM_SIZE:
		RECT rc;
        GetClientRect(hwnd, &rc);
        int tp;
		tp=73;
		SetWindowPos(m->mftp->hwndBB, HWND_TOP, rc.left, rc.top+tp,
				rc.right , 86, SWP_SHOWWINDOW);
		SetWindowPos(GetDlgItem(hwnd,IDD_LDIR), HWND_TOP, rc.left, rc.top+tp+102,
				rc.right/2-70 , 22, SWP_SHOWWINDOW);
		SetWindowPos(GetDlgItem(hwnd,IDD_BROWSE), HWND_TOP, rc.right/2-70, rc.top+tp+102,
				50 , 22, SWP_SHOWWINDOW);
		SetWindowPos(GetDlgItem(hwnd,IDD_RDIR), HWND_TOP, rc.right/2+1, rc.top+tp+102,
				rc.right/2-1 , 122, SWP_SHOWWINDOW);
/*		SetWindowPos(m->hwndWV, HWND_TOP, rc.left, rc.top+tp+126,
				rc.right , 158, SWP_SHOWWINDOW);
		SetWindowPos(m->hwndLV2, HWND_TOP, rc.left, rc.top+tp+284,
				rc.right , rc.bottom-284-tp, SWP_SHOWWINDOW);*/
		if (wParam==SIZE_MINIMIZED) break;
		GetWindowRect(hwnd,&BrowseRect);
		SendMessage(hwnd,_SKN_RESIZE,0,0);
		break;
	case WM_MOVE:
		GetClientRect(hwnd,&rc);
		if (!rc.bottom && !rc.right) break;
		GetWindowRect(hwnd,&BrowseRect);
		break;

	case WM_MEASUREITEM: 
		lpmis = (LPMEASUREITEMSTRUCT) lParam;
		break;

	case WM_DRAWITEM: 
		lpdis = (LPDRAWITEMSTRUCT) lParam; 
		if (lpdis->itemID == -1)
			break;
		switch (lpdis->itemAction)
		{
		case ODA_SELECT: 
		case ODA_DRAWENTIRE: 
			SendMessage(lpdis->hwndItem,
						LB_GETTEXT, lpdis->itemID, (LPARAM) str);
			GetTextMetrics(lpdis->hDC, &tm);
			y = (lpdis->rcItem.bottom + lpdis->rcItem.top-tm.tmHeight) / 2;
			//c=txt[strlen(txt)+1];
			c=(char)SendMessage(lpdis->hwndItem,LB_GETITEMDATA,
					lpdis->itemID, (LPARAM) 0);
			if (c>4) c=4;
			SendMessage(lpdis->hwndItem, LB_GETITEMRECT,
				lpdis->itemID, (LPARAM)&re);
			HBRUSH hb;
			hb = CreateSolidBrush(0);
			FillRect(lpdis->hDC, &re, hb);            //  Paint item background area
			DeleteObject(hb);

			SetTextColor(lpdis->hDC,clr[c]);
			SetBkMode(lpdis->hDC,TRANSPARENT);
			TextOut(lpdis->hDC,
						0,
						y,
						str,
						strlen(str));
			break;
		case ODA_FOCUS:
                     /*
                     * Do not process focus changes. The focus caret
                     * (outline rectangle) indicates the selection.
                     * The Which one? (IDOK) button indicates the final
                     * selection.
                     */
                     break;
		}
		break;
	case WM_NOTIFY:
		if (((LPNMHDR) lParam)->code==TTN_NEEDTEXT)
		{
			LPTOOLTIPTEXT lpttt;
			lpttt = (LPTOOLTIPTEXT) lParam;
			lpttt->hinst = hinst;
			int idButton = lpttt->hdr.idFrom;
			switch (idButton)
			{
				case 0:
					strcpy(str,GetSTR2(115,"Connect"));
					lpttt->lpszText = str;
					break;
				case 1:
					strcpy(str,GetSTR2(116,"Disconnect"));
					lpttt->lpszText = str;
					break;
				case 2:
					strcpy(str,GetSTR2(117,"Enter a URL manually"));
					lpttt->lpszText = str;
					break;
				case 3:
					strcpy(str,GetSTR2(118,"Abort current action"));
				    lpttt->lpszText = str;
					break;
				case 4:
					strcpy(str,GetSTR2(119,"Refresh remote listing"));
				    lpttt->lpszText = str;
					break;
				case 5:
					strcpy(str,GetSTR2(120,"Enter custom command"));
				    lpttt->lpszText = str;
					break;
				case 6:
					strcpy(str,GetSTR2(121,"Add selected files into GetSmart's queue"));
				    lpttt->lpszText = str;
					break;
				case 7:
					strcpy(str,GetSTR2(122,"Let GetSmart set the mode automatically"));
					lpttt->lpszText = str;
					break;
				case 8:
					strcpy(str,GetSTR2(123,"Set transfer to Ascii mode"));
				    lpttt->lpszText = str;
					break;
				case 9:
					strcpy(str,GetSTR2(124,"Set transfer to Binary mode"));
					lpttt->lpszText = str;
					break;
				case 10:
					strcpy(str,GetSTR2(125,"Start downloads as they are added to the queue"));
				    lpttt->lpszText = str;
					break;
				case 11:
					strcpy(str,GetSTR2(126,"Show tasks manager (only enabled when hammering a site)"));
					lpttt->lpszText = str;
					break;
			}
			dds2();
		}
		if (((LPNMHDR) lParam)->hwndFrom==m->hwndWV)
			switch (((LPNMHDR) lParam)->code)
			{
			case LVN_DELETEALLITEMS:
				i=ListView_GetItemCount(m->hwndWV);
				for (j=i-1;j>=0;j--)
					ListView_DeleteItem(m->hwndWV,j);
				break;
			case LVN_DELETEITEM:
				NM_LISTVIEW *p;
		 		p = (NM_LISTVIEW FAR *) lParam;
				pitem = (WILDITEM *) p->lParam;
				for (j=0;j<4;j++)
					free(pitem->c[j]);
				free(pitem);
				break;

/*			case LVN_COLUMNCLICK:
#define pnm ((NM_LISTVIEW *) lParam)
				if (pnm->iSubItem==ls)
				{
					if (s[pnm->iSubItem]) s[pnm->iSubItem]=0;
					else s[pnm->iSubItem]=1;
				}
				else ls=pnm->iSubItem;
				ListView_SortItems(pnm->hdr.hwndFrom,WildCompareFunc,
					(LPARAM) MAKELONG(pnm->iSubItem,s[pnm->iSubItem]));
#undef pnm
				break;*/
/*			case LVN_GETDISPINFO:
				LV_DISPINFO *pnmv;
				pnmv=(LV_DISPINFO *) lParam;
				if (pnmv->item.mask & LVIF_TEXT) 
				{
					WILDITEM *pitem = (WILDITEM *) (pnmv->item.lParam);
					lstrcpy(pnmv->item.pszText,
						pitem->c[pnmv->item.iSubItem]);
				}*/
				break;
			case NM_DBLCLK:
				SendMessage(hwnd,WM_COMMAND,IDM_DOWNLOAD,0);
				break;
			}
		if (((LPNMHDR) lParam)->hwndFrom==m->hwndLV2)
			switch (((LPNMHDR) lParam)->code)
			{
			case LVN_DELETEALLITEMS:
				i=ListView_GetItemCount(m->hwndLV2);
				for (j=i-1;j>=0;j--)
					ListView_DeleteItem(m->hwndLV2,j);
				break;
			case LVN_DELETEITEM:
				NM_LISTVIEW *p;
		 		p = (NM_LISTVIEW FAR *) lParam;
				j1=ListView_GetItemCount(m->hwndLV2)-1;
				if (j1>p->iItem)
					for (j=p->iItem+1;j<=j1;j++)
					{
						STATUSITEM *pitem = (STATUSITEM *) GetLVlParam(m->hwndLV2,j);
						for (i=0;i<50;i++)
							if (((mainftp*)pitem->mdl->guiparam)->itempos[i].hwndU==m->hwndLV2)
								((mainftp*)pitem->mdl->guiparam)->itempos[i].pos--;
					}
				break;
/*			case LVN_COLUMNCLICK:
#define pnm ((NM_LISTVIEW *) lParam)
				if (pnm->iSubItem==lsortd)
				{
					if (sortd[pnm->iSubItem]) sortd[pnm->iSubItem]=0;
					else sortd[pnm->iSubItem]=1;
				}
				else lsortd=pnm->iSubItem;
				ListView_SortItems(pnm->hdr.hwndFrom,StatusCmpFunc,
					(LPARAM) MAKELONG(pnm->iSubItem,sortd[pnm->iSubItem]));
				for (j=0;j<ListView_GetItemCount(m->hwndLV2);j++)
				{
					STATUSITEM *pitem = (STATUSITEM *) GetLVlParam(m->hwndLV2,j);
					pitem->pos=j;
				}
				break;
#undef pnm*/
/*			case LVN_GETDISPINFO:
				LV_DISPINFO *pnmv;
				pnmv=(LV_DISPINFO *) lParam;
				if (pnmv->item.mask & LVIF_TEXT) 
				{
					STATUSITEM *pitem = (STATUSITEM *)(pnmv->item.lParam);
					if (!pnmv->item.iSubItem) pitem->c[0]=pitem->mdl->lfn;
					lstrcpy(pnmv->item.pszText,pitem->c[pnmv->item.iSubItem]);
				}
				if (pnmv->item.mask & LVIF_IMAGE)
				{
					STATUSITEM *pitem = (STATUSITEM *)(pnmv->item.lParam);
					if (pitem->mdl->spliton)
					{
						switch (pitem->mdl->type)
						{
						case 2:
							pnmv->item.iImage=2;
							break;
						case 5:
							pnmv->item.iImage=3;
							break;
						default:
							pnmv->item.iImage=1;
						}
					}
					else
						if (pitem->mdl->done)
						{
							pnmv->item.iImage=5;
						}
						else
							if (pitem->mdl->error.en)
							{
								pnmv->item.iImage=6;
							}
							else
								if (pitem->mdl->wait)
									pnmv->item.iImage=4;
								else
								{
									pnmv->item.iImage=0;
								}
				}
				break;*/
			case NM_DBLCLK:
				j=ListView_GetNextItem(m->hwndLV2,-1,
							LVNI_ALL|LVNI_SELECTED);
				while (j!=-1)
				{
					STATUSITEM *pitem=(STATUSITEM*)GetLVlParam(m->hwndLV2,j);
					if (!pitem->mdl->spliton)
					{
						if (((mainftp*)pitem->mdl->guiparam)->blink)
						{
							PostMessage(hwndgui,TRAY_MSG,(WPARAM)pitem->mdl,(LPARAM) WM_LBUTTONDBLCLK);
							break;
						}
						else
						{
							TELLDAEMON(START_MDL,pitem->mdl,0);
							UpdateMDL(pitem->mdl);
						}
					}
					else 
					{
						((mainftp*)pitem->mdl->guiparam)->mftp->SmallWin();
					}
					j=ListView_GetNextItem(m->hwndLV2,j,LVNI_ALL|LVNI_SELECTED);
				}
				break;

			case LVN_KEYDOWN:
				LV_KEYDOWN *k;
				k= (LV_KEYDOWN FAR *) lParam;
				switch (k->wVKey)
				{
				case 65:
					break;
				}
			}
		break;

	case WM_USER+10:
		WILDITEM *pitem;
		int dx;
		pitem= (WILDITEM *) ((DRAWITEMSTRUCT *)wParam)->itemData;
		if (lParam==0)
		{
			LVITEM it;
			memset(&it,0,sizeof(it));
			it.mask = LVIF_IMAGE; 
			it.iItem=((DRAWITEMSTRUCT *)wParam)->itemID;
			it.iSubItem=0;
			ListView_GetItem(m->hwndWV,&it);
			ImageList_Draw(m->wlv.il,it.iImage,m->wlv.tmpdc,0,0,ILD_TRANSPARENT);
			dx=20;
		}
		else dx=2;
		m->wlv.PutTXT(dx,pitem->c[m->wlv.colorder[lParam]]);
		break;

	case WM_USER+11:
		if ((signed)wParam==ls)
		{
			if (s[wParam]) s[wParam]=0;
			else s[wParam]=1;
		}
		else ls=wParam;
		ListView_SortItems(m->hwndWV,WildCompareFunc,
			(LPARAM) MAKELONG(wParam,s[wParam]));
		break;

	case WM_USER+12:
		STATUSITEM *pitem2;
		pitem2= (STATUSITEM *) ((DRAWITEMSTRUCT *)wParam)->itemData;
		if (lParam==0)
		{
			int ic;
			HICON hIcon3=NULL;
			GetMainLVIcon(hIcon3,pitem2,ic);
			if (hIcon3)
			{
				DrawIconEx(m->lv2.tmpdc,0,0,hIcon3,15,15,0,0,DI_NORMAL);
				DeleteObject(hIcon3);
			}
			else ImageList_Draw(m->lv2.il,ic,m->lv2.tmpdc,0,0,ILD_TRANSPARENT);
			dx=20;
		}
		else dx=2;
		m->lv2.PutTXT(dx,pitem2->c[m->lv2.colorder[lParam]]);
		break;

	case WM_USER+13:
		if (((signed)wParam)==lsortd)
		{
			if (sortd[wParam]) sortd[wParam]=0;
			else sortd[wParam]=1;
		}
		else lsortd=wParam;
		ListView_SortItems(m->hwndLV2,StatusCmpFunc,
			(LPARAM) MAKELONG(wParam,sortd[wParam]));
		for (j=0;j<ListView_GetItemCount(m->hwndLV2);j++)
		{
			STATUSITEM *pitem2 = (STATUSITEM *) GetLVlParam(m->hwndLV2,j);
			pitem2->pos=j;
		}
		break;

	case WM_COMMAND:
		if (HIWORD(wParam)==EN_CHANGE)
		{
			if (LOWORD(wParam)==IDD_HOST)
			{
				GetDlgItemText(hwnd,IDD_HOST,str,1000);
				if (strlen(str)==1) 
					SetDlgItemInt(hwnd,IDD_PORT,21,false);
				break;
			}
			
			if (LOWORD(wParam)==IDD_USER)
			{
				GetDlgItemText(hwnd,IDD_USER,str,1000);
				GetDlgItemText(hwnd,IDD_PASS,str2,1000);
				if (strlen(str))
					if (!strncmp(str,str2,strlen(str2)) || 
						!strcmp(str2,cfg.Email))
						SetDlgItemText(hwnd,IDD_PASS,str);
				break;
			}
			break;
		}
		switch (LOWORD(wParam))
		{	
		case IDM_SELECTALL:
			for (j=0;j<ListView_GetItemCount(m->hwndWV);j++)
				ListView_SetItemState(m->hwndWV,j,
				LVIS_SELECTED,LVIS_SELECTED);
			break;
		case IDM_UNMARKALL:
			for (j=0;j<ListView_GetItemCount(m->hwndWV);j++)
				ListView_SetItemState(m->hwndWV,j,0, LVIS_SELECTED);
			break;
		case IDM_DOWNLOAD:
			i=ListView_GetSelectedCount(m->hwndWV);
			j=ListView_GetNextItem(m->hwndWV,-1,
				LVNI_ALL|LVNI_SELECTED);
			while (j!=-1)
			{
				pitem=(WILDITEM *) GetLVlParam(m->hwndWV,j);
				if ((bdl->btype==1) && (i==1) &&
					((pitem->c[3][0]=='d') || (pitem->c[3][0]=='l')
					|| (pitem->c[0][0]=='.')))
				{
					if (pitem->c[0][0]=='.')
					{
						tmp=strrchr(bdl->cwd,'/');
						*tmp=0;
						tmp=strrchr(bdl->cwd,'/');
						if (tmp) *tmp=0;
						else strcpy(bdl->cwd,"/");
						if (!strlen(bdl->cwd))
							strcpy(bdl->cwd,"/");
						if (bdl->cwd[strlen(bdl->cwd)-1]!='/')
							strcat(bdl->cwd,"/");
					}
					else 
					{
						if (pitem->c[3][0]=='l')
						{
							strcpy(str,pitem->c[0]);
							tmp=strstr(str," ->");
							if (tmp)
								tmp[0]='\0';
							else
								break;
							if (pitem->c[0][strlen(pitem->c[0])-1]=='/')
								bdl->cwd=ReDupString(bdl->cwd,str);
							else
							{
								bool uh=cfg.usehammer,ur=cfg.useretry;
								if (uh)
									if (cfg.hammerfallback) ur=true;
								else ur=false;
								mode=0;
								if (skbrowse->stbt[8].i==1)
									mode=1;
								else 
									if (skbrowse->stbt[9].i==1)
										mode=2;
								dln=new dlnfo(bdl->mir->nfo->prot,
									bdl->mir->nfo->host,bdl->mir->nfo->port,
									bdl->mir->nfo->user,bdl->mir->nfo->pass,
									bdl->mir->nfo->rdir,str);
								GetDlgItemText(hwnd,IDD_LDIR,str,1000);
								if (str[strlen(str)-1]!='\\')
								{
									strcat(str,"\\");
									SetDlgItemText(hwnd,IDD_LDIR,str);
								}
								SendURL(dln,str,0,cfg.defsplit,false,
									9,mode,cfg.resumeto,DEFPR,uh,ur,
									cfg.checkint,cfg.checksmallint);
								break;
							}
						}
						else
						{
							sprintf(str,"%s%s/",bdl->cwd,pitem->c[0]);
							bdl->cwd=ReDupString(bdl->cwd,str);
						}
					}
					SetDlgItemText(hwnd,IDD_RDIR,bdl->cwd);
					TELLDAEMON(BR_CHDIR,mdl,0);
					break;
				}
				else 
				{
					bool uh=cfg.usehammer,ur=cfg.useretry;
					if (uh)
						if (cfg.hammerfallback) ur=true;
						else ur=false;
					GetDlgItemText(hwnd,IDD_LDIR,str,1000);
					if (str[strlen(str)-1]!='\\')
					{
						strcat(str,"\\");
						SetDlgItemText(hwnd,IDD_LDIR,str);
					}
					mode=0;
					if (skbrowse->stbt[8].i==1)
							mode=1;
					else 
						if (skbrowse->stbt[9].i==1)
								mode=2;
					if ((bdl->btype==1)||
						!strstr(pitem->c[0],"://"))
					{
						dln=new dlnfo(bdl->mir->nfo->prot,
							bdl->mir->nfo->host,bdl->mir->nfo->port,
							bdl->mir->nfo->user,bdl->mir->nfo->pass,
							bdl->mir->nfo->rdir,pitem->c[0]);
					}
					else
						dln=ConvertURL(pitem->c[0]);
					if ((bdl->btype==2) && (i==1) && strstr(dln->rfn,".htm"))
						if (DialogBoxParam(hlang,"DLORBR",hwnd,
								(DLGPROC)DLorBRFunc,(LPARAM)dln->rfn))
						{
							sprintf(str,"%s%s",dln->rdir,dln->rfn);
							SetDlgItemText(hwnd,IDD_RDIR,str);
							SetDlgItemText(hwnd,IDD_HOST,dln->host);
							SetDlgItemInt(hwnd,IDD_PORT,dln->port,false);
							SetDlgItemText(hwnd,IDD_USER,dln->user);
							SetDlgItemText(hwnd,IDD_PASS,dln->pass);
							delete dln;
							PostMessage(hwnd,WM_COMMAND,IDOK,0);
							break;
						}
					SendURL(dln,str,0,cfg.defsplit,false,
							9,mode,cfg.resumeto,DEFPR,uh,ur,
							cfg.checkint,cfg.checksmallint);
				}
				j=ListView_GetNextItem(m->hwndWV,j,
							LVNI_ALL|LVNI_SELECTED);
			}
			SetForegroundWindow(hwnd);
			break;
		case IDD_TASKSI:
			m->TaskWin();
			break;

		case IDD_BROWSE:
			GetDlgItemText(hwnd,IDD_LDIR,str,1000);
			BROWSEINFO bi;
			LPITEMIDLIST id;
			//SHGetFileInfo(str,0,
			bi.hwndOwner=hwnd;
			bi.pidlRoot=0;
			bi.pszDisplayName=str;
			char stmp[1024];
			strcpy(stmp,GetSTR2(127,"Choose a directory"));
			bi.lpszTitle=stmp;
			bi.ulFlags=BIF_RETURNONLYFSDIRS;
			bi.lpfn=0;
			if (id=SHBrowseForFolder(&bi))
			{
				SHGetPathFromIDList(id,str);
				strcat(str,"\\");
				SetDlgItemText(hwnd,IDD_LDIR,str);
			}
			dds2();
			break;

		case IDM_REFRESH:
			if (mdl->splitdl[0]->status<3)
			{
				MsgBox(GetSTR2(128,"You must first login to the FTP."),
					0,MB_OK);
				dds2();
				return 1;
			}
			//ShowWindow(GetDlgItem(m->hwild,IDD_TIMEOUT),SW_SHOW);
			TELLDAEMON(BR_REFRESH,mdl,0);
			return 1;
		case IDM_ABORT:
			if (mdl->splitdl[0]->ctrlsock!=INVALID_SOCKET)
				mdl->splitdl[0]->TimedOut();
			return 1;
		case IDM_CONNECT:
			GetDlgItemText(hwnd,IDD_HOST,str,1000);
			if (!strlen(str)) break;
			mdl->splitdl[0]->Clear();
			mdl->spe[0]=0;
			mdl->sps[0]=0;
			mdl->rsize=0;
			if (bdl->ctrlsock!=INVALID_SOCKET)
				SendMessage(hwnd,WM_COMMAND,IDM_DISCONNECT,0);
			UpdateClient(hwnd,mdl);
			if ISHTTP(bdl)
				bdl->btype=2;
			else
				if (!strlen(mdl->mirrorhead->nfo->rfn)||
					strchr(mdl->mirrorhead->nfo->rfn,'*'))
					bdl->btype=1;
				else bdl->btype=2;
			if (mdl->mirrorhead->nfo->port==80)
				mdl->mirrorhead->nfo->prot=2;
			else mdl->mirrorhead->nfo->prot=1;
			if (ISHTTP(bdl) &&
				!strlen(mdl->mirrorhead->nfo->rdir) &&
				!strlen(mdl->mirrorhead->nfo->rfn))
				mdl->mirrorhead->nfo->rdir=ReDupString(mdl->mirrorhead->nfo->rdir,"/");
			//ShowWindow(GetDlgItem(hwnd,IDD_TIMEOUT),SW_SHOW);
			//ShowWindow(GetDlgItem(hwnd,IDD_PING),SW_SHOW);
			if (stricmp(str,bdl->mir->nfo->host) || (lParam==999) || 
				!bdl->ctrladdr.sin_addr.s_addr)
			{
				bdl->mir->nfo->host=ReDupString(bdl->mir->nfo->host,str);
				sprintf(str,GetSTR2(26,"Browsing %s%s"),bdl->mir->nfo->host
							,bdl->mir->nfo->rdir);
				dds2();
				SetWindowText(hwnd,str);
				RemoveWildLV(m->hwndLV2);
				//RemoveCache(m);
				j1=ListView_GetItemCount(hwndLV);
				for (j=0;j<j1;j++)
				{
					STATUSITEM *pitem = (STATUSITEM *) GetLVlParam(hwndLV,j);
					maindl *mb=pitem->mdl;
					if (!stricmp(mdl->mirrorhead->nfo->host,mb->mirrorhead->nfo->host)&&(mb->type!=2))
						AddItem2(m->hwndLV2,(mainftp*)mb->guiparam);
				}
				TELLDAEMON(BR_CHDIR,mdl,0);
			}
			else
				TELLDAEMON(BR_CHDIR,mdl,0);
			break;
		
		case IDM_DISCONNECT:
			//SendMessage(m->hwndTB,TB_HIDEBUTTON,(WPARAM) IDD_TASKSI,
			//					(LPARAM) MAKELONG(true, 0));
			//ShowWindow(GetDlgItem(hdwnd,IDD_TIMEOUT),SW_HIDE);
			//ShowWindow(GetDlgItem(hdwnd,IDD_PING),SW_HIDE);
			TELLDAEMON(BR_DISCONNECT,mdl,0);
			break;

		case IDM_CUSTOM:
			DialogBoxParam(hlang,"CUSTOMDB",hwnd,
				(DLGPROC) CustomFunc,(long) mdl);
			return 1;

		case IDM_CUSTOMDL:
			if (bdl->status<3)
			{
				MsgBox(GetSTR2(128,"You must first login to the FTP."),
					0,MB_OK);
				dds2();
				break;
			}
			if (DialogBoxParam(hlang,"CUSTOMDB",hwnd,
					(DLGPROC) CustomDL,(long) str))
			{
				mode=0;
				if (skbrowse->stbt[8].i==1)
						mode=1;
				else 
					if (skbrowse->stbt[9].i==1)
							mode=2;
				GetDlgItemText(hwnd,IDD_LDIR,str2,1000);
				dln=new dlnfo(bdl->mir->nfo->prot,bdl->mir->nfo->host,
						bdl->mir->nfo->port,bdl->mir->nfo->user,
						bdl->mir->nfo->pass,bdl->cwd,
						str);
				bool uh=cfg.usehammer,ur=cfg.useretry;
				if (uh)
					if (cfg.hammerfallback) ur=true;
					else ur=false;
				SendURL(dln,str2,str,cfg.defsplit,false,9,mode,
							cfg.resumeto,DEFPR,uh,ur,cfg.checkint,
							cfg.checksmallint);
				SetForegroundWindow(hwnd);
			}
			break;

		case IDM_ENTERURL:
			if (DialogBoxParam(hlang,"ENTERURL",hwnd,
							(DLGPROC) EnterURLFunc,(long) m))
				UpdateClient(hwnd,mdl);
			else
			{
				SetDlgItemText(hwnd,IDD_HOST,bdl->mir->nfo->host);
				SetDlgItemInt(hwnd,IDD_PORT,bdl->mir->nfo->port,false);
				SetDlgItemText(hwnd,IDD_USER,bdl->mir->nfo->user);
				SetDlgItemText(hwnd,IDD_PASS,bdl->mir->nfo->pass);
				SetDlgItemText(hwnd,IDD_RDIR,bdl->mir->nfo->rdir);
			}
			break;

		case IDOK:
			if (bdl->ctrlsock==INVALID_SOCKET)
				SendMessage(hwnd,WM_COMMAND,IDM_CONNECT,0);
			else
			{
				GetDlgItemText(hwnd,IDD_HOST,str,1000);
				if (strcmp(str,mdl->mirrorhead->nfo->host))
				{
					SendMessage(hwnd,WM_COMMAND,IDM_CONNECT,0);
					break;
				}
				GetDlgItemText(hwnd,IDD_RDIR,str,1000);
				if (strlen(str))
					if (str[strlen(str)-1]!='/') strcat(str,"/");
				bdl->cwd=ReDupString(bdl->cwd,str);
				TELLDAEMON(BR_CHDIR,mdl,0);
			}
			break;
		case IDM_QUIT:
			STELLDAEMON(BR_KILL,mdl,0);
			break;
		}
		break;

	case WM_CLOSE:
		STELLDAEMON(BR_KILL,mdl,0);	
		break;
	case WM_DESTROY:
		//RemoveCache(m);
		SetMenu(hwnd,NULL);
		SaveGUIConfig();
		ListView_DeleteAllItems(m->hwndWV);
		hlvicons=ListView_SetImageList(m->hwndWV, NULL, LVSIL_SMALL);
		DestroyWindow(m->hwndWV);
		m->wlv.kill();
		i=ImageList_RemoveAll(hlvicons);
		i=ImageList_Destroy(hlvicons);
		ListView_DeleteAllItems(m->hwndLV2);
		ListView_SetImageList(m->hwndLV2, NULL, LVSIL_SMALL);
		DestroyWindow(m->hwndLV2);
		m->hwild=NULL;
		m->lv2.kill();
		break;

	case SKN_BTUP:
        switch (LOWORD(wParam)){
        case 0:
			PostMessage(hwnd,WM_COMMAND,IDM_CONNECT,0);
			break;
        case 1:
			PostMessage(hwnd,WM_COMMAND,IDM_DISCONNECT,0);
			break;
        case 2:
			PostMessage(hwnd,WM_COMMAND,IDM_ENTERURL,0);
			break;
        case 3:
			PostMessage(hwnd,WM_COMMAND,IDM_ABORT,0);
			break;
        case 4:
			PostMessage(hwnd,WM_COMMAND,IDM_REFRESH,0);
			break;
        case 5:
			PostMessage(hwnd,WM_COMMAND,IDM_CUSTOM,0);
			break;
        case 6:
			PostMessage(hwnd,WM_COMMAND,IDM_DOWNLOAD,0);
			break;
        case 7:
			PostMessage(hwnd,_SKN_BTSET,MAKELONG(7,0),1);
			PostMessage(hwnd,_SKN_BTSET,MAKELONG(8,0),0);
			PostMessage(hwnd,_SKN_BTSET,MAKELONG(9,0),0);
			break;
        case 8:
			PostMessage(hwnd,_SKN_BTSET,MAKELONG(7,0),0);
			PostMessage(hwnd,_SKN_BTSET,MAKELONG(8,0),1);
			PostMessage(hwnd,_SKN_BTSET,MAKELONG(9,0),0);
			break;
        case 9:
			PostMessage(hwnd,_SKN_BTSET,MAKELONG(7,0),0);
			PostMessage(hwnd,_SKN_BTSET,MAKELONG(8,0),0);
			PostMessage(hwnd,_SKN_BTSET,MAKELONG(9,0),1);
			break;
		}
        break;
		
	default:
		if (ret==-1)
			return DefWindowProc(hwnd, message, wParam, lParam);
	}
	return 0;
}
/*
BOOL CALLBACK BrowserFunc(HWND hdwnd, UINT message,
							WPARAM wParam, LPARAM lParam)
{
	LV_ITEM it;
	char str[1000],str2[1000], *tmp;
	char htxt[10][50];
	int j,j1,i,mode;
	static int ls;
	static int s[4]={0,1,1,1};
	maindl *mb,*mdl=(maindl *)GetWindowLong(hdwnd,GWL_USERDATA);
	mainftp* m;
	browsedl *bdl;
	dlnfo *dln;
    int y; 
    LPMEASUREITEMSTRUCT lpmis;
    LPDRAWITEMSTRUCT lpdis;
	TEXTMETRIC tm;
	if (mdl)
	{
		m=(mainftp*) mdl->guiparam;
		bdl=(browsedl*) mdl->splitdl[0];
	}
	static DWORD aIds[] = 
	{
		IDD_HOST,IDH_FCHOS,
		IDD_PORT,IDH_FCPOR,
		IDD_USER,IDH_FCUSE,
		IDD_PASS,IDH_FCPAS,
		IDD_PINGTEXT,IDH_FCPIN,
		IDD_TOTEXT,IDH_FCTO,
		IDD_CONSOLE,IDH_FCCNS,
		IDD_LDIR,IDH_FCLOC,
		IDD_RDIR,IDH_FCREM,
		IDD_BROWSE,IDH_FCBRO,
		IDD_BUFFER,IDH_FCCNS,
			0,0
	};
	switch(message)
	{
    case WM_HELP:
		if (((LPHELPINFO) lParam)->hItemHandle==m->hwndWV)
		{
			WinHelp(hdwnd, HelpFile, HELP_CONTEXTPOPUP,IDH_FCLIS);
			return 1;
		}
		if (((LPHELPINFO) lParam)->hItemHandle==m->hwndLV2)
		{
			WinHelp(hdwnd, HelpFile, HELP_CONTEXTPOPUP,IDH_FCQUE);
			return 1;
		}		
		WinHelp(((LPHELPINFO) lParam)->hItemHandle, HelpFile, 
			HELP_WM_HELP, (DWORD) (LPSTR) aIds);
		return 1;
	case WM_CONTEXTMENU: 
		if ((HWND) wParam==m->hwndWV)
		{
			WinHelp(hdwnd, HelpFile, HELP_CONTEXTPOPUP,IDH_FCLIS);
			return 1;
		}
		if ((HWND) wParam==m->hwndLV2)
		{
			WinHelp(hdwnd, HelpFile, HELP_CONTEXTPOPUP,IDH_FCQUE);
			return 1;
		}
		if ((HWND) wParam==m->hwndTB)
		{
			RECT r,r2;
			GetWindowRect(m->hwndTB,&r2);
			POINT pt = {LOWORD(lParam),HIWORD(lParam)};
			for (i=0;i<24;i++)
			{
				SendMessage(m->hwndTB,TB_GETITEMRECT,i,(LPARAM) (LPRECT) &r);
				r.top+=r2.top;
				r.bottom+=r2.top;
				r.left+=r2.left;
				r.right+=r2.left;
				if (PtInRect(&r,pt))
				{
					j=0;
					switch (i)
					{
					case 0:
						j=15;
						break;
					case 1:
						j=16;
						break;
					case 2:
						j=17;
						break;
					case 5:
						j=18;
						break;
					case 6:
						j=19;
						break;
					case 7:
						j=20;
						break;
					case 10:
						j=21;
						break;
					case 13:
						j=22;
						break;
					case 14:
						j=23;
						break;
					case 15:
						j=24;
						break;
					case 19:
						j=25;
						break;
					case 23:
						j=26;
						break;
					}
					if (j)
						WinHelp(hdwnd, HelpFile, 
							HELP_CONTEXTPOPUP,j);
					return 1;
				}
			}
		}
		else
			WinHelp((HWND) wParam, HelpFile, HELP_CONTEXTMENU,
				(DWORD) (LPVOID) aIds);
		return 1;
	case WM_INITDIALOG:
		AddDlg(hdwnd);
		mdl=(maindl *)lParam;
		m=(mainftp*) mdl->guiparam;
		bdl=(browsedl*) mdl->splitdl[0];
		m->hwild=hdwnd;
		SetWindowLong(hdwnd,GWL_USERDATA,(LONG)mdl);
		ls=-1;
#if defined(HEBREW)
		strcpy(htxt[0],"�� �����");
		strcpy(htxt[1],"����");
		strcpy(htxt[2],"�����");
		strcpy(htxt[3],"������");
#else
		strcpy(htxt[0],"File Name");
		strcpy(htxt[1],"Size");
		strcpy(htxt[2],"Date");
		strcpy(htxt[3],"Attributes");
#endif
		m->hwndWV=DoCreateList(hdwnd,&htxt[0][0],&WildCol[0],4,false);
		HICON hiconItem;
		HIMAGELIST himlSmall;
		himlSmall = ImageList_Create(GetSystemMetrics(SM_CXSMICON), 
			GetSystemMetrics(SM_CYSMICON), ILC_COLOR8 | ILC_MASK, 3, 1);
		hiconItem = LoadIcon(hinst, "FOLDERICON"); 
		ImageList_AddIcon(himlSmall, hiconItem);
		hiconItem = LoadIcon(hinst, "LINKICON"); 
		ImageList_AddIcon(himlSmall, hiconItem);
		hiconItem = LoadIcon(hinst, "FILEICON"); 
		ImageList_AddIcon(himlSmall, hiconItem);
		DeleteObject(hiconItem);  
		ListView_SetImageList(m->hwndWV, himlSmall, LVSIL_SMALL);
#if defined(HEBREW)
		strcpy(htxt[0],"�� ����");
		strcpy(htxt[1],"����");
		strcpy(htxt[2],"�������");
		strcpy(htxt[3],"��� ����� �����");
		strcpy(htxt[4],"���� �����");
		strcpy(htxt[5],"��� ���");
		strcpy(htxt[6],"���");
#else
		strcpy(htxt[0],"File Name");
		strcpy(htxt[1],"Size");
		strcpy(htxt[2],"Progress");
		strcpy(htxt[3],"Current speed");
		strcpy(htxt[4],"Est. Time Left");
		strcpy(htxt[5],"Resume");
		strcpy(htxt[6],"Timeout");
		strcpy(htxt[7],"Priority");
		strcpy(htxt[8],"URL");
		strcpy(htxt[9],"Status");
#endif
		m->hwndLV2=DoCreateList(hdwnd,&htxt[0][0],&StatusCol[0],7,
			false);
		m->hwndTB=CreateTB2(hdwnd);
		SendMessage(m->hwndTB,TB_HIDEBUTTON,(WPARAM) IDD_TASKSI,
									(LPARAM) MAKELONG(true, 0));
		SendMessage(m->hwndTB,TB_CHECKBUTTON,IDM_AUTOMODE,
						(LPARAM) MAKELONG(true, 0));
		if (bdl->startdl) SendMessage(m->hwndTB,TB_CHECKBUTTON,
							IDM_STARTDL,(LPARAM) MAKELONG(true, 0));
		m->hwildcon = CreateWindowEx(0,
										"LISTBOX", "",WS_CHILD |WS_VSCROLL | LBS_HASSTRINGS|LBS_NOSEL|LBS_OWNERDRAWFIXED,
										0, 0, 0, 0, hdwnd, NULL, hinst, NULL);
		SendMessage(hdwnd,WM_SIZE,0,0);
		SetDlgItemText(hdwnd,IDD_HOST,mdl->nfo->host);
		SetDlgItemInt(hdwnd,IDD_PORT,mdl->nfo->port,false);
		SetDlgItemText(hdwnd,IDD_USER,mdl->nfo->user);
		SetDlgItemText(hdwnd,IDD_PASS,mdl->nfo->pass);
		SetDlgItemText(hdwnd,IDD_RDIR,mdl->nfo->rdir);
		SetDlgItemText(hdwnd,IDD_LDIR,mdl->nfo->ldir);
		sprintf(str,"Browsing %s%s",mdl->nfo->host,mdl->nfo->rdir);
		SetWindowText(hdwnd,str);
		j1=ListView_GetItemCount(hwndLV);
		for (j=0;j<j1;j++)
		{
			STATUSITEM *pitem = (STATUSITEM *) GetLVlParam(hwndLV,j);
			mb=pitem->mdl;
			if (!stricmp(mdl->nfo->host,mb->nfo->host)&&(mb->type!=2))
				AddItem2(m->hwndLV2,(mainftp*)mb->guiparam);
		}
		SetFocus(m->hwndLV2);
		SetForegroundWindow(hdwnd);
		return 1;
	case WM_MEASUREITEM: 
		lpmis = (LPMEASUREITEMSTRUCT) lParam;
		//GetTextMetrics(lpmis->hDC, &tm);
		//lpmis->itemHeight = tm.tmHeight;
		return TRUE;
	case WM_DRAWITEM: 
		lpdis = (LPDRAWITEMSTRUCT) lParam; 
		if (lpdis->itemID == -1)
			return 1;
		switch (lpdis->itemAction)
		{
		case ODA_SELECT: 
		case ODA_DRAWENTIRE: 
			SendMessage(lpdis->hwndItem, LB_GETTEXT, 
				lpdis->itemID, (LPARAM) str); 
			GetTextMetrics(lpdis->hDC, &tm);
			y = (lpdis->rcItem.bottom + lpdis->rcItem.top - 
				tm.tmHeight) / 2; 
			SetTextColor(lpdis->hDC,SendMessage(lpdis->hwndItem,
								LB_GETITEMDATA, lpdis->itemID, (LPARAM) 0));
			TextOut(lpdis->hDC,
						0,
						y,
						str,
						strlen(str));
			break;
		case ODA_FOCUS: 
                     break; 
		} 
		return TRUE; 
	case WM_SIZE:
		RECT rc;
        GetClientRect(hdwnd, &rc);
        int tp;
		tp=73;
		SetWindowPos(m->hwildcon, HWND_TOP, rc.left, rc.top+tp,
				rc.right , 100, SWP_SHOWWINDOW);
		SetWindowPos(GetDlgItem(hdwnd,IDD_LDIR), HWND_TOP, rc.left, rc.top+tp+102,
				rc.right/2-70 , 22, SWP_SHOWWINDOW);
		SetWindowPos(GetDlgItem(hdwnd,IDD_BROWSE), HWND_TOP, rc.right/2-70, rc.top+tp+102,
				50 , 22, SWP_SHOWWINDOW);
		SetWindowPos(GetDlgItem(hdwnd,IDD_RDIR), HWND_TOP, rc.right/2+1, rc.top+tp+102,
				rc.right/2-1 , 122, SWP_SHOWWINDOW);
		SetWindowPos(m->hwndWV, HWND_TOP, rc.left, rc.top+tp+128,
				rc.right , 150, SWP_SHOWWINDOW);
		SetWindowPos(m->hwndLV2, HWND_TOP, rc.left, rc.top+tp+284,
				rc.right , rc.bottom-284-tp, SWP_SHOWWINDOW);
		return 1;
	case WM_NOTIFY:
		if (((LPNMHDR) lParam)->code==TTN_NEEDTEXT)
		{
			LPTOOLTIPTEXT lpttt;
			lpttt = (LPTOOLTIPTEXT) lParam;
			lpttt->hinst = hinst;
			int idButton = lpttt->hdr.idFrom;
#if defined(HEBREW)
			switch (idButton)
			{
				case IDM_CONNECT: 
					lpttt->lpszText = "�����";
					break;
				case IDM_DISCONNECT: 
					lpttt->lpszText = "���";
					break;
				case IDM_ENTERURL: 
					lpttt->lpszText = "���� ����� �� ���� �����";
					break;
				case IDM_ABORT:
				    lpttt->lpszText = "��� �����"; 
					break;
				case IDM_REFRESH:
				    lpttt->lpszText = "���� �� ����� ������ �� ����"; 
					break;
				case IDM_CUSTOM:
				    lpttt->lpszText = "��� ���� ����� ����";
					break;
				case IDM_DOWNLOAD:
				    lpttt->lpszText = "���� �� ������ �������� ������ �������";
					break;
				case IDM_BINARY:
				    lpttt->lpszText = "��� ��� ������";
					break;
				case IDM_ASCII:
				    lpttt->lpszText = "ASCII ��� ���";
					break;
				case IDM_AUTOMODE:
				    lpttt->lpszText = "��� �������";
					break;
				case IDM_STARTDL:
				    lpttt->lpszText = "���� ������ ���";
					break;
				case IDD_TASKSI: 
					lpttt->lpszText = "(���� �� ���� ������ (����� ���� ���� ����";
					break;
			}
#else
			switch (idButton)
			{
				case IDM_CONNECT: 
					lpttt->lpszText = "Connect";
					break;
				case IDM_DISCONNECT: 
					lpttt->lpszText = "Disconnect";
					break;
				case IDM_ENTERURL: 
					lpttt->lpszText = "Enter a URL manually";
					break;
				case IDM_ABORT:
				    lpttt->lpszText = "Abort current action"; 
					break;
				case IDM_REFRESH:
				    lpttt->lpszText = "Refresh remote listing"; 
					break;
				case IDM_CUSTOM:
				    lpttt->lpszText = "Enter custom command";
					break;
				case IDM_DOWNLOAD:
				    lpttt->lpszText = "Add selected files into GetSmart's queue";
					break;
				case IDM_BINARY:
				    lpttt->lpszText = "Set transfer to Binary mode";
					break;
				case IDM_ASCII:
				    lpttt->lpszText = "Set transfer to Ascii mode";
					break;
				case IDM_AUTOMODE:
				    lpttt->lpszText = "Let GetSmart set the mode automatically";
					break;
				case IDM_STARTDL:
				    lpttt->lpszText = "Start downloads as they are added to the queue";
					break;
				case IDD_TASKSI: 
					lpttt->lpszText = "Show tasks manager (only enabled when hammering a site)";
					break;
			}
#endif
			return 1;
		}
		if (((LPNMHDR) lParam)->hwndFrom==m->hwndWV)
			switch (((LPNMHDR) lParam)->code)
			{
			case LVN_DELETEALLITEMS:
				int jm;
				jm=ListView_GetItemCount(m->hwndWV);
				for (j=0;j<jm;j++)
				{
					it.mask = LVIF_PARAM;
					it.iItem=j;
					it.iSubItem=0;
					ListView_GetItem(m->hwndWV,&it);
					WILDITEM *pitem = (WILDITEM *) it.lParam;
					int j0;
					for (j0=0;j0<4;j0++)
						LocalFree(pitem->c[j0]);
					LocalFree(pitem);
				
			return 1;
		case LVN_COLUMNCLICK:
#define pnm ((NM_LISTVIEW *) lParam)
			if (pnm->iSubItem==ls)
			{
				if (s[pnm->iSubItem]) s[pnm->iSubItem]=0;
				else s[pnm->iSubItem]=1;
			}
			else ls=pnm->iSubItem;
			ListView_SortItems(pnm->hdr.hwndFrom,WildCompareFunc,
				(LPARAM) MAKELONG(pnm->iSubItem,s[pnm->iSubItem]));
#undef pnm
			return 1; 
			case LVN_GETDISPINFO:
				LV_DISPINFO *pnmv;
				pnmv=(LV_DISPINFO *) lParam;
				if (pnmv->item.mask & LVIF_TEXT) 
				{
					WILDITEM *pitem = (WILDITEM *) (pnmv->item.lParam);
					lstrcpy(pnmv->item.pszText, 
					pitem->c[pnmv->item.iSubItem]);
				} 
			return 1; 
			case NM_DBLCLK:
				j=ListView_GetNextItem(m->hwndWV,-1,
					LVNI_ALL|LVNI_SELECTED);
				if (j!=-1)
				{
					it.mask = LVIF_PARAM; 
					it.iItem=j;
					it.iSubItem=0;
					ListView_GetItem(m->hwndWV,&it);
					WILDITEM *pitem=(WILDITEM *) it.lParam;

					if ((mdl->nfo->prot==1) && ((pitem->c[3][0]=='d') || (pitem->c[3][0]=='l')
						|| (pitem->c[0][0]=='.')))
					{
						if (pitem->c[0][0]=='.')
						{
							tmp=strrchr(bdl->cwd,'/');
							*tmp=0;
							tmp=strrchr(bdl->cwd,'/');
							if (tmp) *tmp=0;
							else strcpy(bdl->cwd,"/");
							if (strlen(bdl->cwd)==0) 
								strcpy(bdl->cwd,"/");
							if (bdl->cwd[strlen(bdl->cwd)-1]!='/')
								strcat(bdl->cwd,"/");
						}
						else 
						{
							if (pitem->c[3][0]=='l')
							{
								tmp=strstr(pitem->c[0],"->");
								if (tmp) strcpy(bdl->cwd,&tmp[3]);
							}
							else
							{
								strcat(bdl->cwd,pitem->c[0]);
								strcat(bdl->cwd,"/");
							}
						}
						SetDlgItemText(hdwnd,IDD_RDIR,bdl->cwd);
						PostMessage(Hserv,WM_G_BROWSE,(WPARAM)mdl,2);
						return 1;
					}
					else 
					{
						mode=0;
						if (SendMessage(m->hwndTB,TB_ISBUTTONCHECKED,
							(WPARAM) IDM_ASCII,0))
								mode=1;
						else 
							if (SendMessage(m->hwndTB,
								TB_ISBUTTONCHECKED,
								(WPARAM) IDM_BINARY,0))
								mode=2;
						GetDlgItemText(hdwnd,IDD_LDIR,str,1000);
						dln=new dlnfo(bdl->nfo->prot,bdl->nfo->host,
								bdl->nfo->port,bdl->nfo->user,
								bdl->nfo->pass,bdl->cwd,
								pitem->c[0],str,pitem->c[0]);
						bool uh=cfg.usehammer,ur=cfg.useretry;
						if (uh)
							if (cfg.hammerfallback) ur=true;
							else ur=false;
						SendURL(dln,cfg.defsplit,false,9,mode,
									cfg.resumeto,3,uh,ur);
						SetForegroundWindow(hdwnd);
					}
					return 1;
				}
			}
		if (((LPNMHDR) lParam)->hwndFrom==m->hwndLV2)
			switch (((LPNMHDR) lParam)->code)
			{
			case LVN_DELETEALLITEMS:
				j1=ListView_GetItemCount(m->hwndLV2)-1;
				for (j=j1;j>=0;j--)
				{
					ListView_DeleteItem(m->hwndLV2,j);
				}
				break;
			case LVN_DELETEITEM:
				NM_LISTVIEW *p;
		 		p = (NM_LISTVIEW FAR *) lParam;
				j1=ListView_GetItemCount(m->hwndLV2)-1;
				if (j1>p->iItem)
					for (j=p->iItem+1;j<=j1;j++)
					{
						STATUSITEM *pitem = (STATUSITEM *) GetLVlParam(m->hwndLV2,j);
						for (i=0;i<50;i++)
							if (((mainftp*)pitem->mdl->guiparam)->itempos[i].hwndU==m->hwndLV2)
								((mainftp*)pitem->mdl->guiparam)->itempos[i].pos--;
					}
				return 1;
			case LVN_GETDISPINFO:
				LV_DISPINFO *pnmv;
				pnmv=(LV_DISPINFO *) lParam;
				if (pnmv->item.mask & LVIF_TEXT) 
				{
					STATUSITEM *pitem = (STATUSITEM *) 
						(pnmv->item.lParam);
					if (!pnmv->item.iSubItem)
						pitem->c[0]=pitem->mdl->nfo->lfn;
					lstrcpy(pnmv->item.pszText, 
					pitem->c[pnmv->item.iSubItem]);
				} 
				return 1; 
			case NM_DBLCLK:
				j=ListView_GetNextItem(m->hwndLV2,-1,
					LVNI_ALL|LVNI_SELECTED);
				if (j!=-1)
				{
					STATUSITEM *pitem = (STATUSITEM *) GetLVlParam(m->hwndLV2,j);
					if (((mainftp*)pitem->mdl->guiparam)->blink)
					{
						SendMessage(((mainftp*)(pitem->mdl->guiparam))->hwild,WM_USER+1,0,WM_LBUTTONDBLCLK);
						return 1;
					}
					if (pitem->mdl->pause)
						PostMessage(Hserv,WM_G_START,(WPARAM)pitem->mdl,0);
					else 
					{
						ShowWindow(((mainftp*)(pitem->mdl->guiparam))->hwild,SW_HIDE);
						ShowWindow(((mainftp*)(pitem->mdl->guiparam))->hwild,SW_SHOWNORMAL);
					}
				}
				return 1;
			case -101:
				if (!ListView_GetSelectedCount(m->hwndLV2))
				{
					if (enablemenu)
					{
						enablemenu=false;
						for (j=0;j<enablecount;j++)
							EnableMenuItem(Hmenu,enableitem[j],MF_GRAYED);
					}
				}
				else 
					if (!enablemenu)
					{
						enablemenu=true;
						for (j=0;j<enablecount;j++)
							EnableMenuItem(Hmenu,enableitem[j],MF_ENABLED);
					}
				return 1;
			case LVN_KEYDOWN:
				LV_KEYDOWN *k;
				k= (LV_KEYDOWN FAR *) lParam;
				switch (k->wVKey)
				{
				case 65:

					return 1;
				}
			}
			return 0;
	case WM_COMMAND:
		if (HIWORD(wParam)==EN_CHANGE)
		{
			if (LOWORD(wParam)==IDD_HOST)
			{
				GetDlgItemText(hdwnd,IDD_HOST,str,1000);
				if (strlen(str)==1) 
					SetDlgItemInt(hdwnd,IDD_PORT,21,false);
				return 1;
			}
			
			if (LOWORD(wParam)==IDD_USER)
			{
				GetDlgItemText(hdwnd,IDD_USER,str,1000);
				GetDlgItemText(hdwnd,IDD_PASS,str2,1000);
				if (strlen(str))
					if (!strncmp(str,str2,strlen(str2)) || 
						!strcmp(str2,cfg.Email))
						SetDlgItemText(hdwnd,IDD_PASS,str);
				return 1;
			}
			return 0;
		}
		switch (LOWORD(wParam))
		{	
		case IDM_SELECTALL:
			for (j=0;j<ListView_GetItemCount(m->hwndWV);j++)
				ListView_SetItemState(m->hwndWV,j,
				LVIS_SELECTED,LVIS_SELECTED);
			return 1;
		case IDM_UNMARKALL:
			for (j=0;j<ListView_GetItemCount(m->hwndWV);j++)
				ListView_SetItemState(m->hwndWV,j,0, LVIS_SELECTED);
			return 1;
		case IDM_DOWNLOAD:
			j=ListView_GetNextItem(m->hwndWV,-1,
				LVNI_ALL|LVNI_SELECTED);
			mode=0;
			if (SendMessage(m->hwndTB,TB_ISBUTTONCHECKED,
				(WPARAM) IDM_ASCII,0))
				mode=1;
			else 
				if (SendMessage(m->hwndTB,TB_ISBUTTONCHECKED,
					(WPARAM) IDM_BINARY,0))
					mode=2;
			GetDlgItemText(hdwnd,IDD_LDIR,str,1000);
			while (j!=-1)
			{
				it.mask = LVIF_PARAM; 
				it.iItem=j;
				it.iSubItem=0;
				ListView_GetItem(m->hwndWV,&it);
				WILDITEM *pitem=(WILDITEM *) it.lParam;				
				if ((pitem->c[3][0]!='d') && (pitem->c[3][0]!='l'))
				{
					dln=new dlnfo(bdl->nfo->prot,bdl->nfo->host,
							bdl->nfo->port,bdl->nfo->user,
							bdl->nfo->pass,bdl->cwd,
							pitem->c[0],str,pitem->c[0]);
						bool uh=cfg.usehammer,ur=cfg.useretry;
						if (uh)
							if (cfg.hammerfallback) ur=true;
							else ur=false;
					SendURL(dln,cfg.defsplit,false,9,mode,
								cfg.resumeto,3,uh,ur);
				}
				j=ListView_GetNextItem(m->hwndWV,j,
					LVNI_ALL|LVNI_SELECTED);
			}
			return 1;
		case IDD_TASKSI:
			if (!ShowWindow(m->htask,SW_HIDE))
				ShowWindow(m->htask,SW_SHOW);
			return 1;

		case IDD_BROWSE:
			GetDlgItemText(hdwnd,IDD_LDIR,str,1000);
			BROWSEINFO bi;
			LPITEMIDLIST id;
			bi.hwndOwner=hdwnd;
			bi.pidlRoot=0;
			bi.pszDisplayName=str;
			bi.lpszTitle="Choose a directory";
			bi.ulFlags=BIF_RETURNONLYFSDIRS;
			bi.lpfn=0;
			if (id=SHBrowseForFolder(&bi))
			{
				SHGetPathFromIDList(id,str);
				strcat(str,"\\");
				SetDlgItemText(hdwnd,IDD_LDIR,str);
			}
			return 1;		
		
		case IDM_REFRESH:
			if (mdl->splitdl[0]->status<3)
			{
				MsgBox(hdwnd,"You must first login to the FTP.",
					0,MB_OK);
				return 1;
			}
			ShowWindow(GetDlgItem(m->hwild,IDD_TIMEOUT),SW_SHOW);
			PostMessage(Hserv,WM_G_BROWSE,(WPARAM)mdl,3);
			return 1;
		case IDM_ABORT:
			if (mdl->splitdl[0]->ctrlsock!=INVALID_SOCKET)
				mdl->splitdl[0]->TimedOut();
			return 1;
		case IDM_CONNECT:
			if (bdl->ctrlsock!=INVALID_SOCKET)
				SendMessage(hdwnd,WM_COMMAND,IDM_DISCONNECT,0);
			UpdateClient(hdwnd,mdl);
			GetDlgItemText(hdwnd,IDD_HOST,str,1000);
			if (!strlen(str)) return 1;
			ShowWindow(GetDlgItem(hdwnd,IDD_TIMEOUT),SW_SHOW);
			ShowWindow(GetDlgItem(hdwnd,IDD_PING),SW_SHOW);
			if (stricmp(str,mdl->nfo->host) || (lParam==999) || 
				!bdl->ctrladdr.sin_addr.s_addr)
			{
				bdl->nfo->host=ReDupString(bdl->nfo->host,str);
				mdl->nfo->host=ReDupString(mdl->nfo->host,str);
				sprintf(str,"Browsing %s%s",mdl->nfo->host
							,mdl->nfo->rdir);
				SetWindowText(hdwnd,str);
				RemoveWildLV(m->hwndLV2);
				//RemoveCache(m);
				j1=ListView_GetItemCount(hwndLV);
				for (j=0;j<j1;j++)
				{
					STATUSITEM *pitem = (STATUSITEM *) GetLVlParam(hwndLV,j);
					mb=pitem->mdl;
					if (!stricmp(mdl->nfo->host,mb->nfo->host)&&(mb->type!=2))
						AddItem2(m->hwndLV2,(mainftp*)mb->guiparam);
				}
				PostMessage(Hserv,WM_G_BROWSE,(WPARAM)mdl,2);
			}
			else
			{
				PostMessage(Hserv,WM_G_BROWSE,(WPARAM)mdl,2);
			}
			return 1;
		
		case IDM_DISCONNECT:
			SendMessage(m->hwndTB,TB_HIDEBUTTON,(WPARAM) IDD_TASKSI,
								(LPARAM) MAKELONG(true, 0));
			ShowWindow(GetDlgItem(hdwnd,IDD_TIMEOUT),SW_HIDE);
			ShowWindow(GetDlgItem(hdwnd,IDD_PING),SW_HIDE);
			wc(m->mftp,"Disconnected from server.",0);
			PostMessage(Hserv,WM_G_BROWSE,(WPARAM)mdl,0);
			return 1;

		case IDM_CUSTOM:
			DialogBoxParam(hinst,"CUSTOMDB",hdwnd,
				(DLGPROC) CustomFunc,(long) mdl);
			return 1;

		case IDM_CUSTOMDL:
			if (bdl->status<3)
			{
				MsgBox(hdwnd,"You must first login to the FTP.",
					0,MB_OK);
				return 1;
			}
			if (DialogBoxParam(hinst,"CUSTOMDB",hdwnd,
					(DLGPROC) CustomDL,(long) str))
			{
				mode=0;
				if (SendMessage(m->hwndTB,TB_ISBUTTONCHECKED,
											(WPARAM) IDM_ASCII,0))
					mode=1;
				else 
					if (SendMessage(m->hwndTB,TB_ISBUTTONCHECKED,
											(WPARAM) IDM_BINARY,0))
						mode=2;
				GetDlgItemText(hdwnd,IDD_LDIR,str2,1000);						
				dln=new dlnfo(bdl->nfo->prot,bdl->nfo->host,
						bdl->nfo->port,bdl->nfo->user,
						bdl->nfo->pass,bdl->cwd,
						str,str2,str);
				bool uh=cfg.usehammer,ur=cfg.useretry;
				if (uh)
					if (cfg.hammerfallback) ur=true;
					else ur=false;
				SendURL(dln,cfg.defsplit,false,9,mode,
							cfg.resumeto,3,uh,ur);
				SetForegroundWindow(hdwnd);
			}
			return 1;

		case IDM_ENTERURL:
			if (DialogBoxParam(hinst,"ENTERURL",hdwnd,
							(DLGPROC) EnterURLFunc,(long) m))
				UpdateClient(hdwnd,mdl);
			else
			{
				SetDlgItemText(hdwnd,IDD_HOST,bdl->nfo->host);
				SetDlgItemInt(hdwnd,IDD_PORT,bdl->nfo->port,false);
				SetDlgItemText(hdwnd,IDD_USER,bdl->nfo->user);
				SetDlgItemText(hdwnd,IDD_PASS,bdl->nfo->pass);
				SetDlgItemText(hdwnd,IDD_RDIR,bdl->nfo->rdir);
			}
			return 1;

		case IDOK:
			if (bdl->ctrlsock==INVALID_SOCKET)
				SendMessage(hdwnd,WM_COMMAND,IDM_CONNECT,0);
			else
			{
				GetDlgItemText(hdwnd,IDD_RDIR,str,1000);
				if (strlen(str))
					if (str[strlen(str)-1]!='/') strcat(str,"/");
				bdl->cwd=ReDupString(bdl->cwd,str);
				PostMessage(Hserv,WM_G_BROWSE,(WPARAM)mdl,2);
			}
			return 1;

		case IDCANCEL:
			//RemoveCache(m);
			RemoveDlg(hdwnd);
			PostMessage(Hserv,WM_G_BROWSE,(WPARAM)mdl,1);
			return 1;
		}
	}
	return 0;
}
*/

void UpdateClient(HWND hwnd,maindl *mdl)
{
	browsedl *bdl=(browsedl*)mdl->splitdl[0];
	char str[1000];
	GetDlgItemText(hwnd,IDD_RDIR,str,1000);
/*	if (bdl->btype==1)
	{
		if (strlen(str) && (str[strlen(str)-1]!='/')) strcat(str,"/");
		bdl->cwd=ReDupString(bdl->cwd,str);
		if (stricmp(bdl->mir->nfo->rdir,bdl->cwd))
			bdl->mir->nfo->rdir=ReDupString(bdl->mir->nfo->rdir,bdl->cwd);
	}
	else*/
	{
		if (!strlen(str))
		{
			bdl->mir->nfo->rdir=ReDupString(bdl->mir->nfo->rdir,"");
			bdl->mir->nfo->rfn=ReDupString(bdl->mir->nfo->rfn,"");
		}
		else
		{
			char *tmp;
			tmp=strrchr(str,'/');
			if (!tmp)
			{
				bdl->mir->nfo->rdir=ReDupString(bdl->mir->nfo->rdir,"");
				bdl->mir->nfo->rfn=ReDupString(bdl->mir->nfo->rfn,str);
			}
			else
			{
				bdl->mir->nfo->rdir=(char *)realloc(bdl->mir->nfo->rdir,tmp-str+3);
				strncpy(bdl->mir->nfo->rdir,str,tmp-str+1);
				bdl->mir->nfo->rdir[tmp-str+1]='\0';
				bdl->mir->nfo->rfn=ReDupString(bdl->mir->nfo->rfn,tmp+1);
			}
		}
		bdl->cwd=ReDupString(bdl->cwd,str);
	}
	GetDlgItemText(hwnd,IDD_USER,str,1000);
	if (stricmp(mdl->splitdl[0]->mir->nfo->user,str))
	{
		if (!strlen(str))
		{
			strcpy(str,"anonymous");
			SetDlgItemText(hwnd,IDD_USER,str);
			GetDlgItemText(hwnd,IDD_PASS,str,1000);
			if (!strlen(str) || !strcmp(str,"anonymous")) 
				SetDlgItemText(hwnd,IDD_PASS,cfg.Email);
		}
		bdl->mir->nfo->user=ReDupString(bdl->mir->nfo->user,str);
	}
	GetDlgItemText(hwnd,IDD_PASS,str,1000);
	if (stricmp(bdl->mir->nfo->pass,str))
	{
		if (!strlen(str))
		{
			strcpy(str,cfg.Email);
			SetDlgItemText(hwnd,IDD_PASS,str);
		}		
		bdl->mir->nfo->pass=ReDupString(bdl->mir->nfo->pass,str);
	}
	bdl->mir->nfo->port=GetDlgItemInt(hwnd,IDD_PORT,NULL,false);
}

void AddItem2(HWND hwndLV2, mainftp *m)
{
	int j,i;
	LVITEM it;
	it.mask = LVIF_TEXT | LVIF_PARAM | LVIF_IMAGE; 
	it.iItem=999;
	it.iSubItem=0;
	it.lParam=(LPARAM) m->item;
	it.pszText=LPSTR_TEXTCALLBACK;
	it.iImage= I_IMAGECALLBACK;
	j=ListView_InsertItem(hwndLV2,&it);
	for (i=0;i<50;i++)
		if (!m->itempos[i].hwndU)
		{
			m->itempos[i].hwndU=hwndLV2;
			m->itempos[i].pos=j;
			break;
		}
}

int CALLBACK WildCompareFunc(LPARAM lParam1,LPARAM lParam2,
								 LPARAM lParamSort)
{
	WILDITEM *pitem1 = (WILDITEM *) lParam1;
	WILDITEM *pitem2 = (WILDITEM *) lParam2;
	int i=0;
	_int16 col=LOWORD(lParamSort);
	_int16 s=HIWORD(lParamSort);
	if (!s) s=-1;
	if (!strcmp(pitem1->c[0],"..")) return -1;
	else if (!strcmp(pitem2->c[0],"..")) return 1;
	if (((*pitem1->c[3]=='d') || (*pitem1->c[3]=='l')) &&
		(*pitem2->c[3]!='d') && (*pitem2->c[3]!='l'))
		return -1;
	else
		if (((pitem2->c[3][0]=='d') || (pitem2->c[3][0]=='l')) &&
			(pitem1->c[3][0]!='d') && (pitem1->c[3][0]!='l'))
			return 1;

	if (col==2)
	{
		i=strncmp(&pitem1->c[2][6],&pitem2->c[2][6],2);
		if (i) return i*s;
		i=strncmp(&pitem1->c[2][3],&pitem2->c[2][3],2);
		if (i) return i*s;
		i=strncmp(&pitem1->c[2][0],&pitem2->c[2][0],2);
		if (i) return i*s;
		i=strncmp(&pitem1->c[2][9],&pitem2->c[2][9],5);
		if (i) return i*s;
		return lstrcmpi(pitem1->c[col],pitem2->c[col])*s;
	}
	if (col==1)
	{
		i=atoi(pitem1->c[1])-atoi(pitem2->c[1]);
		if (i) return i*s;
	}
	i=lstrcmpi(pitem1->c[col],pitem2->c[col])*s;
	return (i != 0) ? i:
        lstrcmpi(pitem1->c[0],pitem2->c[0])*s;
}

BOOL CALLBACK CustomFunc(HWND hdwnd, UINT message,
                         WPARAM wParam, LPARAM lParam)
{
	char str[1000];
	maindl *mdl=(maindl *) GetWindowLong(hdwnd,GWL_USERDATA);
	switch(message)
	{
	case WM_INITDIALOG:
		mdl=(maindl *)lParam;
		SetWindowLong(hdwnd,GWL_USERDATA,(LONG) mdl);
		return 1;
	case WM_ACTIVATE:
		if	(LOWORD(wParam) == WA_INACTIVE)
			hgdlg=NULL;
		else
			hgdlg=hdwnd;
		return 1;
	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case IDOK:
			GetDlgItemText(hdwnd,IDD_EDIT,str,990);
			if (!strlen(str)) EndDialog(hdwnd,0);
			strcat(str,"\r\n");
			//mdl->ErrMsg=ReDupString(mdl->ErrMsg,str);
			STELLDAEMON(BR_CUSTOM,mdl,str);
			EndDialog(hdwnd,1);
			return 1;
		case IDCANCEL:
			EndDialog(hdwnd,0);
			return 1;
		}
		return 0;
	}
	return 0;
}

BOOL CALLBACK EnterURLFunc(HWND hdwnd, UINT message,
                         WPARAM wParam, LPARAM lParam)
{
	static char user[1000],pass[1000],addr[1000],sdir[1000],
		sfn[1000],ldir[1000],lfn[1000],ports[10];
	static int prot,port;
	char str[1000];
	RECT r;
	mainftp *m=(mainftp *) GetWindowLong(hdwnd,GWL_USERDATA);
	switch(message)
	{
	case WM_INITDIALOG:
		m=(mainftp *)lParam;
		SetWindowLong(hdwnd,GWL_USERDATA,(LONG) m);
		GetDlgItemText(m->hwild,IDD_HOST,addr,1000);
		port=GetDlgItemInt(m->hwild,IDD_PORT,NULL,false);
		prot=m->mdl->mirrorhead->nfo->prot;
		GetDlgItemText(m->hwild,IDD_USER,user,1000);
		GetDlgItemText(m->hwild,IDD_PASS,pass,1000);
		GetDlgItemText(m->hwild,IDD_RDIR,sdir,1000);
		GetWindowRect(m->hwild,&r);
		SetWindowPos(hdwnd,HWND_TOP,(r.right-r.left)/2-150,r.top+250,0,0,SWP_NOSIZE);
		//SetForegroundWindow(GetDlgItem(hdwnd,IDD_EDIT));
		return 1;
	case WM_ACTIVATE:
		if	(LOWORD(wParam) == WA_INACTIVE)
			hgdlg=NULL;
		else
			hgdlg=hdwnd;
		return 1;
	case WM_COMMAND:
		if ((HIWORD(wParam)==EN_CHANGE) && (LOWORD(wParam)==IDD_EDIT))
		{
			char str2[1000];
			GetDlgItemText(hdwnd,IDD_EDIT,str,999);
			strcpy(str2,str);
			cs(str2);
			if (strcmp(str2,str))
			{
				strcpy(str,str2);
				SetDlgItemText(hdwnd,IDD_EDIT,str2);
				PostMessage(GetDlgItem(hdwnd,IDD_EDIT),
							EM_SETSEL,(WPARAM) (int) strlen(str2),
							(LPARAM) (int) strlen(str2));
			}
			dlnfo *dln=ConvertURL(str);
			prot=dln->prot;
			strcpy(addr,dln->host);
			port=dln->port;
			strcpy(user,dln->user);
			strcpy(pass,dln->pass);
			strcpy(sdir,dln->rdir);
			strcpy(sfn,dln->rfn);
			delete dln;
			if (strcmp(str2,str))
			{
				SetDlgItemText(hdwnd,IDD_URL,str2);
				PostMessage(GetDlgItem(hdwnd,IDD_URL),
					EM_SETSEL,(WPARAM) (int) strlen(str2)
					,(LPARAM) (int) strlen(str2));
			}
			SetDlgItemText(m->hwild,IDD_HOST,addr);
			SetDlgItemInt(m->hwild,IDD_PORT,port,false);
			SetDlgItemText(m->hwild,IDD_USER,user);
			SetDlgItemText(m->hwild,IDD_PASS,pass);
			sprintf(str,"%s%s",sdir,sfn);
			//if (strlen(str) && (str[strlen(str)-1]!='/'))
			//	strcat(str,"/");
			SetDlgItemText(m->hwild,IDD_RDIR,str);
			return 1;
		}
		switch (LOWORD(wParam))
		{
		case IDOK:
/*			if (prot==2)
				MsgBox(hdwnd,
					"This URL is using the HTTP protocl. You can't browse this URL.\nIf you wish to download a file using HTTP enter it in GetSmart main window.",
					addr,MB_OK);
			else*/
			m->mdl->mirrorhead->nfo->prot=prot;
			EndDialog(hdwnd,1);
			return 1;
		case IDCANCEL:
			EndDialog(hdwnd,0);
			return 1;
		}
		return 0;
	}
	return 0;
}

BOOL CALLBACK CustomDL(HWND hdwnd, UINT message,
                         WPARAM wParam, LPARAM lParam)
{
	char *str;
	switch(message)
	{
	case WM_INITDIALOG:
		SetWindowText(hdwnd,GetSTR2(129,"Enter a filename to download:"));
		dds2();
		SetWindowLong(hdwnd,GWL_USERDATA,(LONG) lParam);
		return 1;
	case WM_ACTIVATE:
		if	(LOWORD(wParam) == WA_INACTIVE)
			hgdlg=NULL;
		else
			hgdlg=hdwnd;
		return 1;
	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case IDOK:
			str=(char *) GetWindowLong(hdwnd,GWL_USERDATA);
			GetDlgItemText(hdwnd,IDD_EDIT,str,1000);
			if (!strlen(str)) EndDialog(hdwnd,0);
			EndDialog(hdwnd,1);
			return 1;
		case IDCANCEL:
			EndDialog(hdwnd,0);
			return 1;
		}
		return 0;
	}
	return 0;
}

BOOL CALLBACK DLorBRFunc(HWND hdwnd, UINT message,
							 WPARAM wParam, LPARAM lParam)
{
	switch(message)
	{
	case WM_INITDIALOG:
		SetWindowText(hdwnd,(char*) lParam);
		return 1;
	case WM_ACTIVATE:
		if	(LOWORD(wParam) == WA_INACTIVE)
			hgdlg=NULL;
		else
			hgdlg=hdwnd;
		return 1;
	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case IDD_DOWNLOAD:
			EndDialog(hdwnd,0);
			return 1;
		case IDD_BROWSE:
			EndDialog(hdwnd,1);
			return 1;
		}
		return 0;
	}
	return 0;
}
