
#include "GUI.h"
#include <shlobj.h>

#define IDH_CFGADVANCE 69
#define IDH_CFGAUTO 62
#define IDH_CFGBEPROXY 66
#define IDH_CFGDIR 64
#define IDH_CFGDUP 53
#define IDH_CFGHAM 67
#define IDH_CFGMIRROR 65
#define IDH_CFGPROXY 61
#define IDH_CFGVISUAL 68
#define IDH_CFGSKINS 87
#define IDH_CFGSERVER 86

BOOL CALLBACK InsPhoneFunc(HWND, UINT, WPARAM, LPARAM);
BOOL CALLBACK InsEXTFunc(HWND, UINT, WPARAM, LPARAM);
BOOL CALLBACK InsSiteFunc(HWND, UINT, WPARAM, LPARAM);
BOOL CALLBACK InsShortFunc(HWND, UINT, WPARAM, LPARAM);

int InitSmallSkin(Skinload &nfo);

BOOL CALLBACK AdvancedFunc(HWND hdwnd, UINT message,
                         WPARAM wParam, LPARAM lParam)
{
	unsigned int i;
	char str[1024];
	switch(message)
	{
	case WM_HELP:
		WinHelp(hdwnd, HelpFile, HELP_CONTEXT ,IDH_CFGADVANCE);
		return 1;
	case WM_INITDIALOG:
		if (cfg.keepsplit)
			SendDlgItemMessage(hdwnd,IDD_KEEPSPLIT,
				BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		SetDlgItemInt(hdwnd,IDD_MAXBUFFER,gcfg.maxbuffer,false);
/*		CreateUpDownControl(WS_CHILD|WS_BORDER|WS_VISIBLE|
			UDS_SETBUDDYINT|UDS_ALIGNRIGHT,
			10,10,50,50,hdwnd,IDD_SPIN4,hinst,
			GetDlgItem(hdwnd,IDD_FLUSH),30000,0,cfg.flushsize);*/
		if (changesplit) i=changesplit;
		else
		{
			i=cfg.maxsplit;
			changesplit=i;
		}
		CreateUpDownControl(WS_CHILD|WS_BORDER|WS_VISIBLE|
			UDS_SETBUDDYINT|UDS_ALIGNRIGHT,
			10,10,50,50,hdwnd,IDD_SPIN1,hinst,
			GetDlgItem(hdwnd,IDD_MAXSPLIT),TOPMAXSPLIT,2,i);
		CreateUpDownControl(WS_CHILD|WS_BORDER|WS_VISIBLE|
			UDS_SETBUDDYINT|UDS_ALIGNRIGHT,
			10,10,50,50,hdwnd,IDD_SPIN2,hinst,
			GetDlgItem(hdwnd,IDD_RESUMETO),3600,3,cfg.resumeto);
		CreateUpDownControl(WS_CHILD|WS_BORDER|WS_VISIBLE|
			UDS_SETBUDDYINT|UDS_ALIGNRIGHT,
			10,10,50,50,hdwnd,IDD_SPIN3,hinst,
			GetDlgItem(hdwnd,IDD_NORESUMETO),3600,3,cfg.noresumeto);
		if (cfg.checkint)
			SendDlgItemMessage(hdwnd,IDD_BIGINT,BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		if (cfg.checksmallint)
			SendDlgItemMessage(hdwnd,IDD_SMALLINT,BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		SetDlgItemInt(hdwnd,IDD_BIGCHECK,cfg.intsize,false);
		SetDlgItemInt(hdwnd,IDD_SMALLCHECK,cfg.intsmallsize,false);
		if (cfg.uuagent)
			SendDlgItemMessage(hdwnd,IDD_AGENT,BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		SetDlgItemText(hdwnd,IDD_AGENTS,cfg.uagent);
		if (cfg.referer)
			SendDlgItemMessage(hdwnd,IDD_REFERER,BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		return 1;
	case WM_ACTIVATE:
		if	(LOWORD(wParam) == WA_INACTIVE)
			hgdlg=NULL;
		else
			hgdlg=hdwnd;
		return 1;
	case WM_NOTIFY:
		switch (((NMHDR FAR *) lParam)->code)
		{
		case PSN_KILLACTIVE:
			i=GetDlgItemInt(hdwnd,IDD_MAXSPLIT,NULL,false);
			if ((i<2) || (i>TOPMAXSPLIT))
			{
				MsgBox(GetSTR2(130,"Invalid split number."),0,MB_OK);
				dds2();
				SetWindowLong(hdwnd,DWL_MSGRESULT,true);
			}
			else
				if (SendDlgItemMessage(hdwnd,IDD_SPIN4,UDM_GETPOS,0,0)>30000)
				{
					MsgBox("The flush buffer can't be bigger than 30,000 bytes.","Try again",MB_OK);
					SetWindowLong(hdwnd,DWL_MSGRESULT,true);
				}
				else
					if (i!=(unsigned)changesplit)
					{
						MsgBox(GetSTR2(131,"Only after you will restart GetSmart, \nthe change to the max split will take affect."),"Restart GetSmart",MB_OK);
						dds2();
					}
			return 1;
		case PSN_APPLY:
				if (SendDlgItemMessage(hdwnd,IDD_KEEPSPLIT,BM_GETCHECK,0,0)==BST_CHECKED)
					cfg.keepsplit=true;
				else cfg.keepsplit=false;
				gcfg.maxbuffer=GetDlgItemInt(hdwnd,IDD_MAXBUFFER,NULL,false);
				cfg.flushsize=SendDlgItemMessage(hdwnd,IDD_SPIN4,UDM_GETPOS,0,0);
				i=SendDlgItemMessage(hdwnd,IDD_SPIN1,UDM_GETPOS,0,0);
				if (i!=(unsigned)cfg.maxsplit) changesplit=i;
				cfg.resumeto=SendDlgItemMessage(hdwnd,IDD_SPIN2,UDM_GETPOS,0,0);
				cfg.noresumeto=SendDlgItemMessage(hdwnd,IDD_SPIN3,UDM_GETPOS,0,0);
				if (SendDlgItemMessage(hdwnd,IDD_BIGINT,BM_GETCHECK,0,0)==BST_CHECKED)
					cfg.checkint=true;
				else cfg.checkint=false;
				if (SendDlgItemMessage(hdwnd,IDD_SMALLINT,BM_GETCHECK,0,0)==BST_CHECKED)
					cfg.checksmallint=true;
				else cfg.checksmallint=false;
				cfg.intsize=GetDlgItemInt(hdwnd,IDD_BIGCHECK,NULL,false);
				cfg.intsmallsize=GetDlgItemInt(hdwnd,IDD_SMALLCHECK,NULL,false);
				if (SendDlgItemMessage(hdwnd,IDD_AGENT,BM_GETCHECK,0,0)==BST_CHECKED)
					cfg.uuagent=true;
				else cfg.uuagent=false;
				GetDlgItemText(hdwnd,IDD_AGENTS,str,1000);
				cfg.uagent=ReDupString(cfg.uagent,str);
				if (SendDlgItemMessage(hdwnd,IDD_REFERER,BM_GETCHECK,0,0)==BST_CHECKED)
					cfg.referer=true;
				else cfg.referer=false;
			return 1;
		}
	}
	return 0;
}

BOOL CALLBACK AutoFunc(HWND hdwnd, UINT message,
                         WPARAM wParam, LPARAM lParam)
{
	char str[1000];
	static char winstart[1024];
	LPITEMIDLIST sm;
	switch(message)
	{
    case WM_HELP:
		WinHelp(hdwnd, HelpFile, HELP_CONTEXT ,IDH_CFGAUTO);
		return 1;	
	case WM_INITDIALOG:
		CreateUpDownControl(WS_CHILD|WS_BORDER|WS_VISIBLE|
			UDS_SETBUDDYINT|UDS_ALIGNRIGHT,
			10,10,50,50,hdwnd,IDD_SPIN1,hinst,
			GetDlgItem(hdwnd,IDD_MAXACTIVE),100,1,cfg.maxactive);
/*		CreateUpDownControl(WS_CHILD|WS_BORDER|WS_VISIBLE|
			UDS_SETBUDDYINT|UDS_ALIGNRIGHT,
			10,10,50,50,hdwnd,IDD_SPIN1,hinst,
			GetDlgItem(hdwnd,IDD_DEFSPLIT),cfg.maxsplit,0,cfg.defsplit);*/
		CreateUpDownControl(WS_CHILD|WS_BORDER|WS_VISIBLE|
			UDS_SETBUDDYINT|UDS_ALIGNRIGHT,
			10,10,50,50,hdwnd,IDD_SPIN2,hinst,
			GetDlgItem(hdwnd,IDD_MAXSOCKS),1024,0,cfg.maxsocks);
		if (gcfg.catchcb) SendDlgItemMessage(hdwnd,IDD_CATCHCLIP,BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		if (gcfg.catchns) SendDlgItemMessage(hdwnd,IDD_CATCHNS,BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		if (cfg.startdl) SendDlgItemMessage(hdwnd,IDD_STARTDL,BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		if (cfg.startdef) SendDlgItemMessage(hdwnd,IDD_STARTDEF,BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		SetDlgItemText(hdwnd,IDD_CATCHEXT,cfg.catchext);
		SHGetSpecialFolderLocation(NULL,CSIDL_STARTUP,&sm);
		SHGetPathFromIDList(sm,str);
		sprintf(winstart,"%s\\GetSmart.lnk",str);
		if (!_access(winstart,0))
			SendDlgItemMessage(hdwnd,IDD_WINSTART,BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		return 1;
	case WM_ACTIVATE:
		if	(LOWORD(wParam) == WA_INACTIVE)
			hgdlg=NULL;
		else
			hgdlg=hdwnd;
		return 1;
	case WM_NOTIFY:
		switch (((NMHDR FAR *) lParam)->code)
		{
		case PSN_KILLACTIVE:
			int r1,r2;
			r1=GetDlgItemInt(hdwnd,IDD_MAXACTIVE,0,0);
			r2=GetDlgItemInt(hdwnd,IDD_DEFSPLIT,0,0);
			if (r1<1)
			{
				MsgBox(GetSTR2(132,"The number of simulataneous files\n to download, must be at least 1"),"Error",MB_OK);
				dds2();
				SetWindowLong(hdwnd,DWL_MSGRESULT,true);
			}
			else
				if (r2>cfg.maxsplit)
				{
					MsgBox("The default split parts can't be bigger than the max splits allowed.","Error",MB_OK);
					SetWindowLong(hdwnd,DWL_MSGRESULT,true);
				}
				else SetWindowLong(hdwnd,DWL_MSGRESULT,false);
			return 1;
		case PSN_APPLY:
			if (SendDlgItemMessage(hdwnd,IDD_CATCHCLIP,BM_GETCHECK,0,0)==BST_CHECKED)
			{
				gcfg.catchcb=true;
				CatchCB();
			}
			else 
			{
				gcfg.catchcb=false;
				CatchCB();
			}
			if (SendDlgItemMessage(hdwnd,IDD_CATCHNS,BM_GETCHECK,0,0)==BST_CHECKED)
			{
				if (!gcfg.catchns)
				{
					gcfg.catchns=true;
					//SendMessage(Hserv,WM_G_CATCHNS,0,0);
				}
			}
			else 
			{
				if (gcfg.catchns)
				{
					gcfg.catchns=false;
					//SendMessage(Hserv,WM_G_CATCHNS,0,0);
				}
			}
			if (SendDlgItemMessage(hdwnd,IDD_STARTDL,BM_GETCHECK,0,0)==BST_CHECKED)
				cfg.startdl=true;
			else cfg.startdl=false;
			if (SendDlgItemMessage(hdwnd,IDD_STARTDEF,BM_GETCHECK,0,0)==BST_CHECKED)
				cfg.startdef=true;
			else cfg.startdef=false;
			cfg.maxactive=SendDlgItemMessage(hdwnd,IDD_SPIN1,UDM_GETPOS,0,0);
			cfg.maxsocks=(unsigned short)SendDlgItemMessage(hdwnd,IDD_SPIN2,UDM_GETPOS,0,0);
			//cfg.defsplit=GetDlgItemInt(hdwnd,IDD_DEFSPLIT,0,0);
			GetDlgItemText(hdwnd,IDD_CATCHEXT,str,1000);
			if (str[strlen(str)-1]!=';') strcat(str,";");
			cfg.catchext=ReDupString(cfg.catchext,str);
			if (SendDlgItemMessage(hdwnd,IDD_WINSTART,BM_GETCHECK,0,0)==BST_CHECKED)
			{
				if (_access(winstart,0))
				{
					IShellLink* pShellLink; 
					HRESULT hres = CoCreateInstance(CLSID_ShellLink, 
											NULL, 
											CLSCTX_INPROC_SERVER, 
											IID_IShellLink, 
											(LPVOID*)&pShellLink); 
					if (SUCCEEDED(hres)) 
					{ 
						IPersistFile* pPersistFile;
						GetModuleFileName(NULL,str,1000);
						//sprintf(str,"%sGetSmart.exe",rundir);
						pShellLink->SetPath(str); 
						pShellLink->SetDescription(""); 
						hres = pShellLink->QueryInterface(IID_IPersistFile, 
												(LPVOID*)&pPersistFile); 
						if (SUCCEEDED(hres)) 
						{ 
							WCHAR wsz[MAX_PATH]; 
							pShellLink->SetArguments("t");
							MultiByteToWideChar(CP_ACP,0,winstart,-1,wsz,MAX_PATH);
							hres = pPersistFile->Save(wsz, TRUE);
							if(FAILED(hres))
								MessageBox(hdwnd,"Couldn't add GetSmart to StartUp.",0,MB_OK);
							pPersistFile->Release(); 
						}
						pShellLink->Release(); 
					}
				}
			}
			else
			{
				if (!_access(winstart,0))
				{
					DeleteFile(winstart);
					SHChangeNotify(SHCNE_DELETE,SHCNF_PATH,winstart,0);
				}
			}
			return 1;
		}
	}
	return 0;
}

BOOL CALLBACK DirsFunc(HWND hdwnd, UINT message,
                         WPARAM wParam, LPARAM lParam)
{
	char str[1024];
	extlist *el;
	LVITEM it;
	int j,i;

	switch(message)
	{
	case WM_HELP:
		WinHelp(hdwnd, HelpFile, HELP_CONTEXT ,IDH_CFGDIR);
		return 1;

	case WM_INITDIALOG:
		GetExtDir(str,"");
		SetDlgItemText(hdwnd,IDD_DEFDLDIR,str);
		SetDlgItemText(hdwnd,IDD_EMAIL,cfg.Email);
		SetDlgItemText(hdwnd,IDD_EMDIR,cfg.emdir);
		if (cfg.solveonfull) SendDlgItemMessage(hdwnd,IDD_SOLVEONFULL,
			BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		if (cfg.runexternal) SendDlgItemMessage(hdwnd,IDD_RUNEXTERNAL,
			BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		if (cfg.externalshow==SW_MINIMIZE) SendDlgItemMessage(hdwnd,
			IDD_MINIMIZE,BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		SetDlgItemText(hdwnd,IDD_FILE,cfg.externalfile);
		SetDlgItemText(hdwnd,IDD_PARAMETERS,cfg.externalparams);
		SetDlgItemText(hdwnd,IDD_TMP,cfg.tmpdir);
		if (cfg.istmpdir) SendDlgItemMessage(hdwnd,IDD_USETMP,
			BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		LV_COLUMN lvc;
		memset(&lvc,0,sizeof(lvc));
		lvc.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM;
		lvc.fmt = LVCFMT_LEFT;
		lvc.cx=60;
		lvc.iSubItem=0;
		char stmp[1024];
		strcpy(stmp,GetSTR2(133,"Extension"));
		lvc.pszText=stmp;
		ListView_InsertColumn(GetDlgItem(hdwnd,IDD_EXT),0,&lvc);
		lvc.cx=266;
		lvc.iSubItem=1;
		strcpy(stmp,GetSTR2(134,"Directory"));
		lvc.pszText=stmp;
		ListView_InsertColumn(GetDlgItem(hdwnd,IDD_EXT),1,&lvc);
		memset(&it,0,sizeof(it));
		it.mask = LVIF_TEXT;
		j=0;
		el=exthead->next;
		while (el!=NULL)
		{
			it.iItem=j;
			it.iSubItem=0;
			it.pszText=el->ext;
			it.cchTextMax=strlen(el->ext);
			ListView_InsertItem(GetDlgItem(hdwnd,IDD_EXT),&it);
			ListView_SetItemText(GetDlgItem(hdwnd,IDD_EXT),j,1,el->dir);
			j++;
			el=el->next;
		}
		dds2();
		return 1;
	case WM_ACTIVATE:
		if	(LOWORD(wParam) == WA_INACTIVE)
			hgdlg=NULL;
		else
			hgdlg=hdwnd;
		return 1;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDD_RMEXT:
			j=ListView_GetNextItem(GetDlgItem(hdwnd,IDD_EXT),-1,
							LVNI_ALL|LVNI_SELECTED);
			if (j<0) return true;
			el=exthead;
			for (i=0;i<=j;i++)
				if (el!=NULL) el=el->next;
			if (el==NULL) return true;
			delete el;
			ListView_DeleteAllItems(GetDlgItem(hdwnd,IDD_EXT));
			j=0;
			el=exthead->next;
			memset(&it,0,sizeof(it));
			it.mask = LVIF_TEXT;
			while (el!=NULL)
			{
				it.iItem=j;
				it.iSubItem=0;
				it.pszText=el->ext;
				it.cchTextMax=strlen(el->ext);
				ListView_InsertItem(GetDlgItem(hdwnd,IDD_EXT),&it);
				ListView_SetItemText(GetDlgItem(hdwnd,IDD_EXT),j,1,el->dir);
				j++;
				el=el->next;
			}
			return true;

		case IDD_ADDEXT:
			if (DialogBox(hlang,"INSEXT",hdwnd,(DLGPROC)InsEXTFunc))
			{
				j=0;
				el=exthead->next;
				while (el->next!=NULL)
				{
					j++;
					el=el->next;
				}
				memset(&it,0,sizeof(it));
				it.mask = LVIF_TEXT;
				it.iItem=j;
				it.iSubItem=0;
				it.pszText=el->ext;
				it.cchTextMax=strlen(el->ext);
				ListView_InsertItem(GetDlgItem(hdwnd,IDD_EXT),&it);
				ListView_SetItemText(GetDlgItem(hdwnd,IDD_EXT),j,1,el->dir);
			}
			return true;

		case IDD_BROWSEEXTERNAL:
			OPENFILENAME ofn;
			char dh[MAX_PATH];
			GetDlgItemText(hdwnd,IDD_FILE,str,1000);
			strcpy(dh,str);
			memset(&ofn,0,sizeof(ofn));
			ofn.lStructSize=sizeof(ofn);
			ofn.hwndOwner=hdwnd;
			ofn.hInstance=hinst;
			ofn.lpstrFile=dh;
			ofn.nMaxFile=MAX_PATH;
			ofn.lpstrInitialDir=str;
			ofn.Flags=OFN_PATHMUSTEXIST;
			ofn.lpstrDefExt=".exe";
			if (GetOpenFileName(&ofn))
				SetDlgItemText(hdwnd,IDD_FILE,ofn.lpstrFile);
			return 1;
		case IDD_BROWSEDLDIR:
			GetDlgItemText(hdwnd,IDD_DEFDLDIR,str,1000);
			BROWSEINFO bi;
			LPITEMIDLIST id;
			bi.hwndOwner=hdwnd;
			bi.pidlRoot=0;
			bi.pszDisplayName=str;
			char stmp[1024];
			strcpy(stmp,GetSTR2(127,"Choose a directory"));
			bi.lpszTitle=stmp;
			bi.ulFlags=BIF_RETURNONLYFSDIRS;
			bi.lpfn=0;
			if (id=SHBrowseForFolder(&bi))
			{
				SHGetPathFromIDList(id,str);
				SetDlgItemText(hdwnd,IDD_DEFDLDIR,str);
			}
			dds2();
			return 1;
		case IDD_BROWSEEMDIR:
			GetDlgItemText(hdwnd,IDD_EMDIR,str,1000);
			bi.hwndOwner=hdwnd;
			bi.pidlRoot=0;
			bi.pszDisplayName=str;
			strcpy(stmp,GetSTR2(127,"Choose a directory"));
			bi.lpszTitle=stmp;
			bi.ulFlags=BIF_RETURNONLYFSDIRS;
			bi.lpfn=0;
			if (id=SHBrowseForFolder(&bi))
			{
				SHGetPathFromIDList(id,str);
				SetDlgItemText(hdwnd,IDD_EMDIR,str);
			}
			dds2();
			return 1;
		}
		return 0;
	case WM_NOTIFY:
		switch (((NMHDR FAR *) lParam)->code)
		{
		case PSN_KILLACTIVE:
			GetDlgItemText(hdwnd,IDD_EMDIR,str,1000);
			if (strlen(str) && str[strlen(str)-1]!='\\')
				strcat(str,"\\");
			SetDlgItemText(hdwnd,IDD_EMDIR,str);
			GetDlgItemText(hdwnd,IDD_DEFDLDIR,str,1000);
			if (strlen(str) && str[strlen(str)-1]!='\\')
				strcat(str,"\\");
			SetDlgItemText(hdwnd,IDD_DEFDLDIR,str);
			if (!strlen(str))
			{
				MsgBox(GetSTR2(135,"You must enter a default download dir."),"Error",MB_OK);
				dds2();
				SetWindowLong(hdwnd,DWL_MSGRESULT,true);
				return 1;
			}
			GetDlgItemText(hdwnd,IDD_FILE,str,1000);
			if ((SendDlgItemMessage(hdwnd,IDD_RUNEXTERNAL,
				BM_GETCHECK,0,0)==BST_CHECKED) && !strlen(str))
			{
				MsgBox(GetSTR2(136,"You have chosen to use an external programm,\n but you have not set its location."),
					"Try again",MB_OK);
				dds2();
				SetWindowLong(hdwnd,DWL_MSGRESULT,true);
				return 1;
			}
			GetDlgItemText(hdwnd,IDD_EMAIL,str,1000);
			if (!strlen(str))
			{
				MsgBox(GetSTR2(137,"You must enter an Email."),"Error",MB_OK);
				dds2();
				SetWindowLong(hdwnd,DWL_MSGRESULT,true);
				return 1;
			}
			GetDlgItemText(hdwnd,IDD_EMDIR,str,1000);
			if ((SendDlgItemMessage(hdwnd,IDD_SOLVEONFULL,
				BM_GETCHECK,0,0)==BST_CHECKED) && !strlen(str))
			{
				MsgBox("You must enter a directory to use when download dir is full.",
					"Try again",MB_OK);
				SetWindowLong(hdwnd,DWL_MSGRESULT,true);
				return 1;
			}
			SetWindowLong(hdwnd,DWL_MSGRESULT,false);
			return 1;
		case PSN_APPLY:
			GetDlgItemText(hdwnd,IDD_DEFDLDIR,str,1000);
			if (str[strlen(str)-1]!='\\') strcat(str,"\\");
			exthead->dir=ReDupString(exthead->dir,str);
			GetDlgItemText(hdwnd,IDD_EMDIR,str,1000);
			if (strlen(str) && str[strlen(str)-1]!='\\')
				strcat(str,"\\");
			cfg.emdir=ReDupString(cfg.emdir,str);
			GetDlgItemText(hdwnd,IDD_EMAIL,str,1000);
			cfg.Email=ReDupString(cfg.Email,str);
			if (SendDlgItemMessage(hdwnd,IDD_SOLVEONFULL,
				BM_GETCHECK,0,0)==BST_CHECKED)
				cfg.solveonfull=true;
			else cfg.solveonfull=false;
			if (SendDlgItemMessage(hdwnd,IDD_USETMP,
				BM_GETCHECK,0,0)==BST_CHECKED)
				cfg.istmpdir=true;
			else cfg.istmpdir=false;
			if (SendDlgItemMessage(hdwnd,IDD_RUNEXTERNAL,
				BM_GETCHECK,0,0)==BST_CHECKED)
				cfg.runexternal=true;
			else cfg.runexternal=false;
			if (SendDlgItemMessage(hdwnd,IDD_MINIMIZE,
				BM_GETCHECK,0,0)==BST_CHECKED)
				cfg.externalshow=SW_MINIMIZE;
			else cfg.externalshow=SW_SHOW;
			GetDlgItemText(hdwnd,IDD_TMP,str,sizeof(str));
			if (str[strlen(str)-1]!='\\')
				strcat(str,"\\");
			cfg.tmpdir=ReDupString(cfg.tmpdir,str);
			GetDlgItemText(hdwnd,IDD_FILE,str,1024);
			cfg.externalfile=ReDupString(cfg.externalfile,str);
			GetDlgItemText(hdwnd,IDD_PARAMETERS,str,1024);
			cfg.externalparams=ReDupString(cfg.externalparams,str);
			ListView_DeleteAllItems(GetDlgItem(hdwnd,IDD_EXT));
			return 1;
		}
	}
	return 0;
}

BOOL CALLBACK DUPFunc(HWND hdwnd, UINT message,
                         WPARAM wParam, LPARAM lParam)
{
	char str[1000];
	static char ls[RAS_MaxEntryName + 1];
	switch(message)
	{
    case WM_HELP:
		WinHelp(hdwnd, HelpFile, HELP_CONTEXT ,IDH_CFGDUP);
		return 1;
	case WM_INITDIALOG:
		strcpy(ls,cfg.Dial.Entry);
		if (cfg.Dial.Use)
			SendDlgItemMessage(hdwnd,IDD_USE,BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		else
		{
			SendDlgItemMessage(hdwnd,IDD_DONTUSE,BM_SETCHECK,(WPARAM) BST_CHECKED,0);
			EnableWindow(GetDlgItem(hdwnd,IDD_ENTRY),false);
			EnableWindow(GetDlgItem(hdwnd,IDD_USER),false);
			EnableWindow(GetDlgItem(hdwnd,IDD_PASS),false);
			EnableWindow(GetDlgItem(hdwnd,IDD_PHONES),false);
			EnableWindow(GetDlgItem(hdwnd,IDD_ADD),false);
			EnableWindow(GetDlgItem(hdwnd,IDD_REMOVE),false);
			EnableWindow(GetDlgItem(hdwnd,IDD_TIMEOUT),false);
			EnableWindow(GetDlgItem(hdwnd,IDD_RETRY),false);
			EnableWindow(GetDlgItem(hdwnd,IDD_PAUSE),false);
			EnableWindow(GetDlgItem(hdwnd,IDD_LONGPAUSE),false);
			EnableWindow(GetDlgItem(hdwnd,IDD_LONGRETRY),false);
		}
		SetDlgItemText(hdwnd,IDD_USER,cfg.Dial.User);
		SetDlgItemText(hdwnd,IDD_PASS,cfg.Dial.Pass);
		RASENTRYNAME en[100];
		DWORD eni,sb;
		eni=0;
		sb=sizeof(en);
		eni=0;
		en[0].dwSize=sizeof(RASENTRYNAME);
		if (RasEnumEntriesx)
			RasEnumEntriesx(NULL,NULL,en,&sb,&eni);
		if (eni)
			for (sb=0;sb<eni;sb++)
				SendDlgItemMessage(hdwnd,IDD_ENTRY,CB_ADDSTRING,NULL,
								(LPARAM) (char*) en[sb].szEntryName);
		SendDlgItemMessage(hdwnd,IDD_ENTRY,CB_SELECTSTRING,(WPARAM) -1,
								(LPARAM) (char*) cfg.Dial.Entry);
		if (cfg.Dial.Subi!=-1)		
			for (sb=0;sb<=(DWORD) cfg.Dial.Subi;sb++)
				SendDlgItemMessage(hdwnd,IDD_PHONES,LB_ADDSTRING,NULL,
									(LPARAM) (char*) cfg.Dial.Phone[sb]);
		CreateUpDownControl(WS_CHILD|WS_BORDER|WS_VISIBLE|
			UDS_SETBUDDYINT|UDS_ALIGNRIGHT,
			10,10,50,50,hdwnd,IDD_SPIN5,hinst,
			GetDlgItem(hdwnd,IDD_TIMEOUT),10000,0,cfg.Dial.TO);
		CreateUpDownControl(WS_CHILD|WS_BORDER|WS_VISIBLE|
			UDS_SETBUDDYINT|UDS_ALIGNRIGHT,
			10,10,50,50,hdwnd,IDD_SPIN1,hinst,
			GetDlgItem(hdwnd,IDD_RETRY),10000,0,cfg.Dial.Busy);
		CreateUpDownControl(WS_CHILD|WS_BORDER|WS_VISIBLE|
			UDS_SETBUDDYINT|UDS_ALIGNRIGHT,
			10,10,50,50,hdwnd,IDD_SPIN2,hinst,
			GetDlgItem(hdwnd,IDD_PAUSE),10000,0,cfg.Dial.Pause);
		CreateUpDownControl(WS_CHILD|WS_BORDER|WS_VISIBLE|
			UDS_SETBUDDYINT|UDS_ALIGNRIGHT,
			10,10,50,50,hdwnd,IDD_SPIN3,hinst,
			GetDlgItem(hdwnd,IDD_LONGRETRY),10000,0,cfg.Dial.MaxLong);
		CreateUpDownControl(WS_CHILD|WS_BORDER|WS_VISIBLE|
			UDS_SETBUDDYINT|UDS_ALIGNRIGHT,
			10,10,50,50,hdwnd,IDD_SPIN4,hinst,
			GetDlgItem(hdwnd,IDD_LONGPAUSE),10000,0,cfg.Dial.LongPause);
		if (cfg.Dial.pulse)
			SendDlgItemMessage(hdwnd,IDD_PULSE,BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		return 1;
	case WM_ACTIVATE:
		if	(LOWORD(wParam) == WA_INACTIVE)
			hgdlg=NULL;
		else
			hgdlg=hdwnd;
		return 1;
	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case IDD_ADD:
			if (SendDlgItemMessage(hdwnd,IDD_PHONES,LB_GETCOUNT,0,0)>=15)
			{
				MsgBox(GetSTR2(138,"You can only enter up to 15 phone numbers."),0,MB_OK);
				dds2();
				return 1;
			}
			if (DialogBoxParam(hlang,"INSPHONEDB",hdwnd,
				(DLGPROC) InsPhoneFunc,(long) str))
				SendDlgItemMessage(hdwnd,IDD_PHONES,LB_ADDSTRING,
										NULL,(LPARAM) (char*) str);
			return 1;
		case IDD_REMOVE:
			int si[15];
			memset(si,0,sizeof(si));
			sb=SendDlgItemMessage(hdwnd,IDD_PHONES,LB_GETSELITEMS,
											15,(LPARAM) (LPINT) si);
			if (sb)
				for (eni=sb;eni>0;eni--)
					SendDlgItemMessage(hdwnd,IDD_PHONES,
							LB_DELETESTRING,(WPARAM) si[eni-1],0);
			return 1;
		}
		switch (HIWORD(wParam))
		{
		case CBN_SELCHANGE:
			sb=SendDlgItemMessage(hdwnd,IDD_ENTRY,CB_GETCURSEL,0,0);
			SendDlgItemMessage(hdwnd,IDD_ENTRY,CB_GETLBTEXT,sb,
								(LPARAM) (char*) str);
			if (strcmp(str,ls))
			{
				strcpy(ls,str);
				SendDlgItemMessage(hdwnd,IDD_PHONES,LB_RESETCONTENT,0,0);
				RASENTRY ep;
				ep.dwSize=sizeof(RASENTRY);
				sb=sizeof(RASENTRY);
				if (RasGetEntryPropertiesx)
				{
					if (ERROR_BUFFER_TOO_SMALL==
						RasGetEntryPropertiesx(NULL,str,&ep,
													&sb,NULL,NULL))
					{
						sb=0;
						RasGetEntryPropertiesx(NULL,str,NULL,
													&sb,NULL,NULL);
						if (sb)
						{
							LPRASENTRY ep2=(LPRASENTRY) malloc(sb+1);
							ep2->dwSize=sizeof(RASENTRY);
							sb++;
							RasGetEntryPropertiesx(NULL,str,ep2,
													&sb,NULL,NULL);
							SendDlgItemMessage(hdwnd,IDD_PHONES,
								LB_ADDSTRING,NULL,(LPARAM) (char*) ep2->szLocalPhoneNumber);
							free(ep2);
						}
					}
					else
						SendDlgItemMessage(hdwnd,IDD_PHONES,
							LB_ADDSTRING,NULL,(LPARAM) (char*) ep.
							szLocalPhoneNumber);
				}
				else
					if (RasGetEntryDialParamsx)
					{
						RASDIALPARAMS rdp;
						memset(&rdp,0,sizeof(RASDIALPARAMS));
						int pass;
						rdp.dwSize=sizeof(RASDIALPARAMS);
						strcpy(rdp.szEntryName,str);
						RasGetEntryDialParamsx(NULL,&rdp,&pass);
						strcpy(str,rdp.szPhoneNumber);
						if (!strlen(str))
						{
							strcpy(str,GetSTR2(139,"Default"));
							dds2();
						}
						SendDlgItemMessage(hdwnd,IDD_PHONES,
							LB_ADDSTRING,NULL,(LPARAM) (char*) str);
					}
			}
			return 1;
		case BN_CLICKED:
			if ((int) LOWORD(wParam)==IDD_USE)
			{
				EnableWindow(GetDlgItem(hdwnd,IDD_ENTRY),true);
				EnableWindow(GetDlgItem(hdwnd,IDD_USER),true);
				EnableWindow(GetDlgItem(hdwnd,IDD_PASS),true);
				EnableWindow(GetDlgItem(hdwnd,IDD_PHONES),true);
				EnableWindow(GetDlgItem(hdwnd,IDD_ADD),true);
				EnableWindow(GetDlgItem(hdwnd,IDD_REMOVE),true);
				EnableWindow(GetDlgItem(hdwnd,IDD_TIMEOUT),true);
				EnableWindow(GetDlgItem(hdwnd,IDD_RETRY),true);
				EnableWindow(GetDlgItem(hdwnd,IDD_PAUSE),true);
				EnableWindow(GetDlgItem(hdwnd,IDD_LONGPAUSE),true);
				EnableWindow(GetDlgItem(hdwnd,IDD_LONGRETRY),true);
				if (!hras)
				{
					LoadRas();
					if (!hras)
					{
						//MsgBox(0,"Use",0,MB_OK);
						SendDlgItemMessage(hdwnd,IDD_USE,BM_SETCHECK,
							(WPARAM) BST_UNCHECKED,0);
						SendDlgItemMessage(hdwnd,IDD_DONTUSE,
							BM_SETCHECK,(WPARAM) BST_CHECKED,0);
						return 1;
					}
					eni=0;
					sb=sizeof(en);
					eni=0;
					en[0].dwSize=sizeof(RASENTRYNAME);
					if (RasEnumEntriesx)
						RasEnumEntriesx(NULL,NULL,en,&sb,&eni);
					if (eni)
					for (sb=0;sb<eni;sb++)
						SendDlgItemMessage(hdwnd,IDD_ENTRY,
							CB_ADDSTRING,NULL,
							(LPARAM) (char*) en[sb].szEntryName);
				}
			}
			else
				if ((int) LOWORD(wParam)==IDD_DONTUSE)
				{
					EnableWindow(GetDlgItem(hdwnd,IDD_ENTRY),false);
					EnableWindow(GetDlgItem(hdwnd,IDD_USER),false);
					EnableWindow(GetDlgItem(hdwnd,IDD_PASS),false);
					EnableWindow(GetDlgItem(hdwnd,IDD_PHONES),false);
					EnableWindow(GetDlgItem(hdwnd,IDD_ADD),false);
					EnableWindow(GetDlgItem(hdwnd,IDD_REMOVE),false);
					EnableWindow(GetDlgItem(hdwnd,IDD_TIMEOUT),false);
					EnableWindow(GetDlgItem(hdwnd,IDD_RETRY),false);
					EnableWindow(GetDlgItem(hdwnd,IDD_PAUSE),false);
					EnableWindow(GetDlgItem(hdwnd,IDD_LONGPAUSE),false);
					EnableWindow(GetDlgItem(hdwnd,IDD_LONGRETRY),false);
				}
			return 1;
		}
		return 0;
	case WM_NOTIFY:
		switch (((NMHDR FAR *) lParam)->code)
		{
		case PSN_KILLACTIVE:
			if (SendDlgItemMessage(hdwnd,IDD_DONTUSE,BM_GETCHECK,
				0,0)==BST_CHECKED) return 1;
			GetDlgItemText(hdwnd,IDD_ENTRY,str,1000);
			if (!strlen(str))
			{
				MsgBox(
					GetSTR2(140,"You must specify a connection to use."),
					GetSTR2(141,"Change the connection value."),MB_OK);
				dds2();
				SetWindowLong(hdwnd,DWL_MSGRESULT,true);
				return 1;
			}
			if (!SendDlgItemMessage(hdwnd,IDD_PHONES,LB_GETCOUNT,0,0))
			{
				MsgBox(
					GetSTR2(142,"You must enter at least one phone number."),
					GetSTR2(143,"No phone numbers."),
					MB_OK);
				dds2();
				SetWindowLong(hdwnd,DWL_MSGRESULT,true);
				return 1;
			}
			sb=SendDlgItemMessage(hdwnd,IDD_SPIN5,UDM_GETPOS,0,0);
			if (sb>10000)
			{
				MsgBox(
				GetSTR2(144,"The maximum Timeout value is 10,000."),
				GetSTR2(145,"Invalid Timeout"),MB_OK);
				dds2();
				SetWindowLong(hdwnd,DWL_MSGRESULT,true);
				return 1;
			}
			sb=SendDlgItemMessage(hdwnd,IDD_SPIN1,UDM_GETPOS,0,0);
			if (sb>10000)
			{
				MsgBox(
				GetSTR2(145,"The maximum Retry value is 10,000."),
				"Invalid Retry.",MB_OK);
				dds2();
				SetWindowLong(hdwnd,DWL_MSGRESULT,true);
				return 1;
			}
			sb=SendDlgItemMessage(hdwnd,IDD_SPIN2,UDM_GETPOS,0,0);
			if (sb>10000)
			{
				MsgBox(
				GetSTR2(146,"The maximum Pause value is 10,000."),
				"Invalid Pause",MB_OK);
				dds2();
				SetWindowLong(hdwnd,DWL_MSGRESULT,true);
				return 1;
			}
			sb=SendDlgItemMessage(hdwnd,IDD_SPIN3,UDM_GETPOS,0,0);
			if (sb>10000)
			{
				MsgBox(
				GetSTR2(145,"The maximum Retry value is 10,000."),
				"Invalid Retry",MB_OK);
				dds2();
				SetWindowLong(hdwnd,DWL_MSGRESULT,true);
				return 1;
			}
			sb=SendDlgItemMessage(hdwnd,IDD_SPIN4,UDM_GETPOS,0,0);
			if (sb>10000)
			{
				MsgBox(
				GetSTR2(146,"The maximum Pause value is 10,000."),
				"Invalid Pause",MB_OK);
				dds2();
				SetWindowLong(hdwnd,DWL_MSGRESULT,true);
				return 1;
			}
			SetWindowLong(hdwnd,DWL_MSGRESULT,false);
			return 1;
		case PSN_APPLY:
			if (SendDlgItemMessage(hdwnd,IDD_USE,BM_GETCHECK,0,0)==BST_CHECKED)
				cfg.Dial.Use=true;
			else cfg.Dial.Use=false;
			GetDlgItemText(hdwnd,IDD_ENTRY,cfg.Dial.Entry,RAS_MaxEntryName);
			GetDlgItemText(hdwnd,IDD_USER,cfg.Dial.User,UNLEN);
			GetDlgItemText(hdwnd,IDD_PASS,cfg.Dial.Pass,PWLEN);
			eni=SendDlgItemMessage(hdwnd,IDD_PHONES,LB_GETCOUNT,0,0);
			for (sb=0;sb<eni;sb++)
				SendDlgItemMessage(hdwnd,IDD_PHONES,LB_GETTEXT,
					(WPARAM) sb, (LPARAM) (char*) cfg.Dial.Phone[sb]);
			cfg.Dial.Subi=eni-1;
			cfg.Dial.TO=SendDlgItemMessage(hdwnd,IDD_SPIN5,UDM_GETPOS,0,0);
			cfg.Dial.Busy=SendDlgItemMessage(hdwnd,IDD_SPIN1,UDM_GETPOS,0,0);
			cfg.Dial.Pause=SendDlgItemMessage(hdwnd,IDD_SPIN2,UDM_GETPOS,0,0);
			cfg.Dial.MaxLong=SendDlgItemMessage(hdwnd,IDD_SPIN3,UDM_GETPOS,0,0);
			cfg.Dial.LongPause=SendDlgItemMessage(hdwnd,IDD_SPIN4,UDM_GETPOS,0,0);
			if (SendDlgItemMessage(hdwnd,IDD_PULSE,BM_GETCHECK,0,0)==BST_CHECKED)
				cfg.Dial.pulse=true;
			else cfg.Dial.pulse=false;
			return 1;
		}
	}
	return 0;
}

BOOL CALLBACK FireFunc(HWND hdwnd, UINT message,
                         WPARAM wParam, LPARAM lParam)
{
	char str[1000];
	switch(message)
	{
    case WM_HELP:
		WinHelp(hdwnd, HelpFile, HELP_CONTEXT ,IDH_CFGPROXY);
		return 1;	
	case WM_INITDIALOG:
		SetDlgItemText(hdwnd,IDD_SOCKSUSER,cfg.Proxy.socksuser);
		SetDlgItemText(hdwnd,IDD_ADDR3,cfg.Proxy.sockshost);
		SetDlgItemInt(hdwnd,IDD_PORT3,cfg.Proxy.socksport,0);
		SetDlgItemText(hdwnd,IDD_ADDR2,cfg.Proxy.HHost);
		SetDlgItemInt(hdwnd,IDD_PORT2,cfg.Proxy.HTTPP,0);
		SetDlgItemText(hdwnd,IDD_ADDR1,cfg.Proxy.FHost);
		SetDlgItemInt(hdwnd,IDD_PORT1,cfg.Proxy.FTPP,0);
		if (cfg.Proxy.OnlyProxy)
			SendDlgItemMessage(hdwnd,IDD_ONLYPROXY,BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		if (cfg.Proxy.Passive)
			SendDlgItemMessage(hdwnd,IDD_PASV,BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		if (cfg.Proxy.nocache)
			SendDlgItemMessage(hdwnd,IDD_NOCACHE,BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		if (cfg.Proxy.UseHTTP)
			SendDlgItemMessage(hdwnd,IDD_USEHTTP,BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		if (cfg.Proxy.UseFTP)
			SendDlgItemMessage(hdwnd,IDD_USEFTP,BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		if (cfg.Proxy.socks)
			SendDlgItemMessage(hdwnd,IDD_USESOCKS,BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		if (cfg.Proxy.HTTP4FTP)
			SendDlgItemMessage(hdwnd,IDD_HTTP4FTP,BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		SetDlgItemText(hdwnd,IDD_HUSER,cfg.Proxy.huser);
		SetDlgItemText(hdwnd,IDD_HPASS,cfg.Proxy.hpass);
		return 1;
	case WM_ACTIVATE:
		if	(LOWORD(wParam) == WA_INACTIVE)
			hgdlg=NULL;
		else
			hgdlg=hdwnd;
		return 1;
	case WM_NOTIFY:
		switch (((NMHDR FAR *) lParam)->code)
		{
		case PSN_KILLACTIVE:
			if ((SendDlgItemMessage(hdwnd,IDD_USESOCKS,BM_GETCHECK,
				0,0)==BST_CHECKED) && (SendDlgItemMessage(hdwnd,IDD_PASV,BM_GETCHECK,
				0,0)!=BST_CHECKED))
			{
				MsgBox(
					GetSTR2(147,"For now GetSmart will support socks only with passive.\nYou will have to enable the passive mode."),
					"Temporary",MB_OK);
				dds2();
				SetWindowLong(hdwnd,DWL_MSGRESULT,true);
				return 1;
			}
			if ((SendDlgItemMessage(hdwnd,IDD_ONLYPROXY,BM_GETCHECK,
				0,0)==BST_CHECKED) && (SendDlgItemMessage(hdwnd,IDD_USEHTTP,BM_GETCHECK,
				0,0)!=BST_CHECKED)&& (SendDlgItemMessage(hdwnd,IDD_USEFTP,BM_GETCHECK,
				0,0)!=BST_CHECKED))
			{
				MsgBox(
					GetSTR2(344,"You have chosen to use proxy for your connection,\nbut you didn't enable any of the proxy.\nMark the Enable HTTP/FTP fields."),"",MB_OK);
				dds2();
				SetWindowLong(hdwnd,DWL_MSGRESULT,true);
				return 1;
			}
			return 1;
		case PSN_APPLY:
			cfg.Proxy.HTTPP=GetDlgItemInt(hdwnd,IDD_PORT2,0,0);
			GetDlgItemText(hdwnd,IDD_ADDR2,str,1000);
			cfg.Proxy.HHost=ReDupString(cfg.Proxy.HHost,str);
			cfg.Proxy.FTPP=GetDlgItemInt(hdwnd,IDD_PORT1,0,0);
			GetDlgItemText(hdwnd,IDD_ADDR1,str,1000);
			cfg.Proxy.FHost=ReDupString(cfg.Proxy.FHost,str);
			cfg.Proxy.socksport=GetDlgItemInt(hdwnd,IDD_PORT3,0,0);
			GetDlgItemText(hdwnd,IDD_ADDR3,str,1000);
			cfg.Proxy.sockshost=ReDupString(cfg.Proxy.sockshost,str);
			GetDlgItemText(hdwnd,IDD_SOCKSUSER,str,1000);
			cfg.Proxy.socksuser=ReDupString(cfg.Proxy.socksuser,str);
			GetDlgItemText(hdwnd,IDD_HUSER,cfg.Proxy.huser,sizeof(cfg.Proxy.huser));
			GetDlgItemText(hdwnd,IDD_HPASS,cfg.Proxy.hpass,sizeof(cfg.Proxy.hpass));
			if (SendDlgItemMessage(hdwnd,IDD_ONLYPROXY,BM_GETCHECK,0,0)==BST_CHECKED)
				cfg.Proxy.OnlyProxy=true;
			else cfg.Proxy.OnlyProxy=false;
			if (SendDlgItemMessage(hdwnd,IDD_NOCACHE,BM_GETCHECK,0,0)==BST_CHECKED)
				cfg.Proxy.nocache=true;
			else cfg.Proxy.nocache=false;
			if (SendDlgItemMessage(hdwnd,IDD_USEHTTP,BM_GETCHECK,0,0)==BST_CHECKED)
				cfg.Proxy.UseHTTP=true;
			else cfg.Proxy.UseHTTP=false;
			if (SendDlgItemMessage(hdwnd,IDD_USEFTP,BM_GETCHECK,0,0)==BST_CHECKED)
				cfg.Proxy.UseFTP=true;
			else cfg.Proxy.UseFTP=false;
			if (SendDlgItemMessage(hdwnd,IDD_USESOCKS,BM_GETCHECK,0,0)==BST_CHECKED)
				cfg.Proxy.socks=true;
			else cfg.Proxy.socks=false;
			if (SendDlgItemMessage(hdwnd,IDD_HTTP4FTP,BM_GETCHECK,0,0)==BST_CHECKED)
				cfg.Proxy.HTTP4FTP=true;
			else cfg.Proxy.HTTP4FTP=false;
			if (SendDlgItemMessage(hdwnd,IDD_PASV,BM_GETCHECK,0,0)==BST_CHECKED)
				cfg.Proxy.Passive=true;
			else cfg.Proxy.Passive=false;
			return 1;
		}
	}
	return 0;
}

BOOL CALLBACK HammerFunc(HWND hdwnd, UINT message,
                         WPARAM wParam, LPARAM lParam)
{
	switch(message)
	{
	case WM_HELP:
		WinHelp(hdwnd, HelpFile, HELP_CONTEXT ,IDH_CFGHAM);
		return 1;	
	case WM_INITDIALOG:
		if (cfg.usehammer)
			SendDlgItemMessage(hdwnd,IDD_USEHAMMER,
							BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		if (cfg.usemaxhammertime)
			SendDlgItemMessage(hdwnd,IDD_USEHAMMERTIME,
							BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		CreateUpDownControl(WS_CHILD|WS_BORDER|WS_VISIBLE|
			UDS_SETBUDDYINT|UDS_ALIGNRIGHT,
			10,10,50,50,hdwnd,IDD_SPIN1,hinst,
			GetDlgItem(hdwnd,IDD_HAMMERTIME),9999,5,cfg.maxhammertime);
		if (cfg.usemaxhammerretry)
			SendDlgItemMessage(hdwnd,IDD_USEHAMMERRETRY,
							BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		CreateUpDownControl(WS_CHILD|WS_BORDER|WS_VISIBLE|
			UDS_SETBUDDYINT|UDS_ALIGNRIGHT,
			10,10,50,50,hdwnd,IDD_SPIN2,hinst,
			GetDlgItem(hdwnd,IDD_HAMMERRETRY),9999,5,cfg.maxhammerretry);
		CreateUpDownControl(WS_CHILD|WS_BORDER|WS_VISIBLE|
			UDS_SETBUDDYINT|UDS_ALIGNRIGHT,
			10,10,50,50,hdwnd,IDD_SPIN3,hinst,
			GetDlgItem(hdwnd,IDD_HAMMERTASKS),MAXHAMMER,1,cfg.maxhammer);
		if (cfg.hammerfallback)
			SendDlgItemMessage(hdwnd,IDD_FALLBACK,
							BM_SETCHECK,(WPARAM) BST_CHECKED,0);		

		if (cfg.useretry)
			SendDlgItemMessage(hdwnd,IDD_USERETRY,
							BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		if (cfg.usemaxbusytime)
			SendDlgItemMessage(hdwnd,IDD_USEBUSYTIME,
							BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		CreateUpDownControl(WS_CHILD|WS_BORDER|WS_VISIBLE|
			UDS_SETBUDDYINT|UDS_ALIGNRIGHT,
			10,10,50,50,hdwnd,IDD_SPIN4,hinst,
			GetDlgItem(hdwnd,IDD_BUSYTIME),9999,5,cfg.maxbusytime);
		if (cfg.usemaxbusyretry)
			SendDlgItemMessage(hdwnd,IDD_USEBUSYRETRY,
							BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		CreateUpDownControl(WS_CHILD|WS_BORDER|WS_VISIBLE|
			UDS_SETBUDDYINT|UDS_ALIGNRIGHT,
			10,10,50,50,hdwnd,IDD_SPIN5,hinst,
			GetDlgItem(hdwnd,IDD_BUSYRETRY),9999,5,cfg.maxbusyretry);
		CreateUpDownControl(WS_CHILD|WS_BORDER|WS_VISIBLE|
			UDS_SETBUDDYINT|UDS_ALIGNRIGHT,
			10,10,50,50,hdwnd,IDD_SPIN6,hinst,
			GetDlgItem(hdwnd,IDD_DELAY),9999,0,cfg.nohammerbusydelay);
		return 1;
	case WM_ACTIVATE:
		if	(LOWORD(wParam) == WA_INACTIVE)
			hgdlg=NULL;
		else
			hgdlg=hdwnd;
		return 1;
	case WM_NOTIFY:
		switch (((NMHDR FAR *) lParam)->code)
		{
		case PSN_KILLACTIVE:
			if (SendDlgItemMessage(hdwnd,IDD_SPIN3,UDM_GETPOS,0,0)>MAXHAMMER)
			{
				MsgBox(GetSTR2(148,"The hammer tasks you have chosen, exceeds the maximum allowed."),
					"Try again",MB_OK);
				dds2();
				SetWindowLong(hdwnd,DWL_MSGRESULT,true);
			}
			else SetWindowLong(hdwnd,DWL_MSGRESULT,false);
			return 1;
		case PSN_APPLY:
			if (SendDlgItemMessage(hdwnd,IDD_USEHAMMER,BM_GETCHECK,0,0)==BST_CHECKED)
				cfg.usehammer=true;
			else cfg.usehammer=false;
			if (SendDlgItemMessage(hdwnd,IDD_USEHAMMERTIME,BM_GETCHECK,0,0)==BST_CHECKED)
				cfg.usemaxhammertime=true;
			else cfg.usemaxhammertime=false;
			cfg.maxhammertime=SendDlgItemMessage(hdwnd,IDD_SPIN1,UDM_GETPOS,0,0);
			if (SendDlgItemMessage(hdwnd,IDD_USEHAMMERRETRY,BM_GETCHECK,0,0)==BST_CHECKED)
				cfg.usemaxhammerretry=true;
			else cfg.usemaxhammerretry=false;
			cfg.maxhammerretry=SendDlgItemMessage(hdwnd,IDD_SPIN2,UDM_GETPOS,0,0);
			cfg.maxhammer=(unsigned short)SendDlgItemMessage(hdwnd,IDD_SPIN3,UDM_GETPOS,0,0);
			if (SendDlgItemMessage(hdwnd,IDD_FALLBACK,BM_GETCHECK,0,0)==BST_CHECKED)
				cfg.hammerfallback=true;
			else cfg.hammerfallback=false;

			if (SendDlgItemMessage(hdwnd,IDD_USERETRY,BM_GETCHECK,0,0)==BST_CHECKED)
				cfg.useretry=true;
			else cfg.useretry=false;
			if (SendDlgItemMessage(hdwnd,IDD_USEBUSYTIME,BM_GETCHECK,0,0)==BST_CHECKED)
				cfg.usemaxbusytime=true;
			else cfg.usemaxbusytime=false;
			cfg.maxbusytime=SendDlgItemMessage(hdwnd,IDD_SPIN4,UDM_GETPOS,0,0);
			if (SendDlgItemMessage(hdwnd,IDD_USEBUSYRETRY,BM_GETCHECK,0,0)==BST_CHECKED)
				cfg.usemaxbusyretry=true;
			else cfg.usemaxbusyretry=false;
			cfg.maxbusyretry=SendDlgItemMessage(hdwnd,IDD_SPIN5,UDM_GETPOS,0,0);
			cfg.nohammerbusydelay=SendDlgItemMessage(hdwnd,IDD_SPIN6,UDM_GETPOS,0,0);
			return 1;
		}
	}
	return 0;
}

BOOL CALLBACK VisualFunc(HWND hdwnd, UINT message,
                         WPARAM wParam, LPARAM lParam)
{
	char str[1024];
	switch(message)
	{
	case WM_HELP:
		WinHelp(hdwnd, HelpFile, HELP_CONTEXT ,IDH_CFGVISUAL);
		return 1;
	case WM_INITDIALOG:
		if (gcfg.finishmsgs) SendDlgItemMessage(hdwnd,IDD_FINISHMESSAGES,
			BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		if (gcfg.showdlwin) SendDlgItemMessage(hdwnd,IDD_SHOWDLWIN,
			BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		if (gcfg.showdltray) SendDlgItemMessage(hdwnd,IDD_SHOWDLTRAY,
			BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		if (gcfg.showdropbox) SendDlgItemMessage(hdwnd,IDD_SHOWDROPBOX,
			BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		if (cfg.lang) SendDlgItemMessage(hdwnd,IDD_LANG,
			BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		CreateUpDownControl(WS_CHILD|WS_BORDER|WS_VISIBLE|
			UDS_SETBUDDYINT|UDS_ALIGNRIGHT,
			10,10,50,50,hdwnd,IDD_SPIN1,hinst,
			GetDlgItem(hdwnd,IDD_LDL),50,1,gcfg.maxlastdl);
		sprintf(str,"%s%s",cfg.logdir,cfg.logfn);
		SetDlgItemText(hdwnd,IDD_LOGDIR,str);
		SetDlgItemText(hdwnd,IDD_LANGFN,cfg.langfn);
		if (cfg.multilog) SendDlgItemMessage(hdwnd,IDD_MULTILOG,
			BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		if (cfg.logwdl) SendDlgItemMessage(hdwnd,IDD_LOGWDL,
			BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		SetDlgItemText(hdwnd,IDD_NAME,cfg.name);
		return 1;
	case WM_ACTIVATE:
		if	(LOWORD(wParam) == WA_INACTIVE)
			hgdlg=NULL;
		else
			hgdlg=hdwnd;
		return 1;
	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case IDD_BROWSE:
			OPENFILENAME ofn;
			char dh[MAX_PATH];
			GetDlgItemText(hdwnd,IDD_LOGDIR,str,1000);
			strcpy(dh,str);
			memset(&ofn,0,sizeof(ofn));
			ofn.lStructSize=sizeof(ofn);
			ofn.hwndOwner=hdwnd;
			ofn.hInstance=hinst;
			ofn.lpstrFile=dh;
			ofn.nMaxFile=MAX_PATH;
			ofn.lpstrInitialDir=str;
			ofn.Flags=OFN_PATHMUSTEXIST;
			ofn.lpstrDefExt=".log";
			if (GetSaveFileName(&ofn))
				SetDlgItemText(hdwnd,IDD_LOGDIR,ofn.lpstrFile);
			return 1;
		case IDD_BROWSE2:
			GetDlgItemText(hdwnd,IDD_LANGFN,str,1000);
			strcpy(dh,str);
			memset(&ofn,0,sizeof(ofn));
			ofn.lStructSize=sizeof(ofn);
			ofn.hwndOwner=hdwnd;
			ofn.hInstance=hinst;
			ofn.lpstrFile=dh;
			ofn.nMaxFile=MAX_PATH;
			ofn.lpstrInitialDir=str;
			ofn.Flags=OFN_PATHMUSTEXIST;
			ofn.lpstrDefExt=".dll";
			if (GetOpenFileName(&ofn))
				SetDlgItemText(hdwnd,IDD_LANGFN,ofn.lpstrFile);
			return 1;
		}
		return 0;

	case WM_NOTIFY:
		switch (((NMHDR FAR *) lParam)->code)
		{
		case PSN_APPLY:
			if (SendDlgItemMessage(hdwnd,IDD_FINISHMESSAGES,BM_GETCHECK,0,0)==BST_CHECKED)
			{
				gcfg.finishmsgs=true;
				PostMessage(hwndgui,_SKN_BTSET,MAKELONG(5,0),1);
			}
			else 
			{
				gcfg.finishmsgs=false;
				PostMessage(hwndgui,_SKN_BTSET,MAKELONG(5,0),0);
			}
			if (SendDlgItemMessage(hdwnd,IDD_SHOWDLWIN,BM_GETCHECK,0,0)==BST_CHECKED)
				gcfg.showdlwin=true;
			else gcfg.showdlwin=false;
			if (SendDlgItemMessage(hdwnd,IDD_SHOWDLTRAY,BM_GETCHECK,0,0)==BST_CHECKED)
				gcfg.showdltray=true;
			else gcfg.showdltray=false;
			if (SendDlgItemMessage(hdwnd,IDD_SHOWDROPBOX,BM_GETCHECK,0,0)==BST_CHECKED)
				gcfg.showdropbox=true;
			else gcfg.showdropbox=false;
			Dropbox();
			gcfg.maxlastdl=(short)SendDlgItemMessage(hdwnd,IDD_SPIN1,UDM_GETPOS,0,0);
			char ldir[1024],lfn[1024],*tmp;
			GetDlgItemText(hdwnd,IDD_LOGDIR,ldir,1024);
			tmp = strrchr(ldir, '\\' );
			if (!tmp)
			{
				strcpy(lfn,ldir);
				memset(ldir,0,sizeof(ldir));
			}
			else
			{
				if (tmp) tmp++;
				if (tmp) 
				{
					strcpy(lfn,tmp);
					memset(tmp,0,strlen(lfn)+1);
				}
				else memset(lfn,0,1000);
			}
			cfg.logdir=ReDupString(cfg.logdir,ldir);
			cfg.logfn=ReDupString(cfg.logfn,lfn);
			if (SendDlgItemMessage(hdwnd,IDD_MULTILOG,BM_GETCHECK,0,0)==BST_CHECKED)
				cfg.multilog=true;
			else cfg.multilog=false;
			if (SendDlgItemMessage(hdwnd,IDD_LANG,BM_GETCHECK,0,0)==BST_CHECKED)
				cfg.lang=true;
			else cfg.lang=false;
			GetDlgItemText(hdwnd,IDD_LANGFN,str,1000);
			cfg.langfn=ReDupString(cfg.langfn,str);
			if (SendDlgItemMessage(hdwnd,IDD_LOGWDL,BM_GETCHECK,0,0)==BST_CHECKED)
				cfg.logwdl=true;
			else cfg.logwdl=false;
			GetDlgItemText(hdwnd,IDD_NAME,str,1000);
			cfg.name=ReDupString(cfg.name,str);
			return 1;
		}
	}
	return 0;
}

BOOL CALLBACK BeProxyFunc(HWND hdwnd, UINT message,
                         WPARAM wParam, LPARAM lParam)
{
	int j,i;
	sclist *sl;
	LVITEM it;
	switch(message)
	{
	case WM_HELP:
		WinHelp(hdwnd, HelpFile, HELP_CONTEXT ,IDH_CFGBEPROXY);
		return 1;	
	case WM_INITDIALOG:
		if (cfg.beproxy.use)
			SendDlgItemMessage(hdwnd,IDD_USE,
				BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		CreateUpDownControl(WS_CHILD|WS_BORDER|WS_VISIBLE|
			UDS_SETBUDDYINT|UDS_ALIGNRIGHT,
			10,10,50,50,hdwnd,IDD_SPIN4,hinst,
			GetDlgItem(hdwnd,IDD_IP4),255,0,HIBYTE(HIWORD(cfg.beproxy.ip)));
		CreateUpDownControl(WS_CHILD|WS_BORDER|WS_VISIBLE|
			UDS_SETBUDDYINT|UDS_ALIGNRIGHT,
			10,10,50,50,hdwnd,IDD_SPIN3,hinst,
			GetDlgItem(hdwnd,IDD_IP3),255,0,LOBYTE(HIWORD(cfg.beproxy.ip)));
		CreateUpDownControl(WS_CHILD|WS_BORDER|WS_VISIBLE|
			UDS_SETBUDDYINT|UDS_ALIGNRIGHT,
			10,10,50,50,hdwnd,IDD_SPIN2,hinst,
			GetDlgItem(hdwnd,IDD_IP2),255,0,HIBYTE(LOWORD(cfg.beproxy.ip)));
		CreateUpDownControl(WS_CHILD|WS_BORDER|WS_VISIBLE|
			UDS_SETBUDDYINT|UDS_ALIGNRIGHT,
			10,10,50,50,hdwnd,IDD_SPIN1,hinst,
			GetDlgItem(hdwnd,IDD_IP1),255,0,LOBYTE(LOWORD(cfg.beproxy.ip)));
		SetDlgItemInt(hdwnd,IDD_PORT,cfg.beproxy.port,false);
		CreateUpDownControl(WS_CHILD|WS_BORDER|WS_VISIBLE|
			UDS_SETBUDDYINT|UDS_ALIGNRIGHT,
			10,10,50,50,hdwnd,IDD_SPIN5,hinst,
			GetDlgItem(hdwnd,IDD_TIMEOUT),20000,0,cfg.beproxy.to);
		SetDlgItemInt(hdwnd,IDD_MINSIZE,cfg.beproxy.minsize,false);
		SetDlgItemInt(hdwnd,IDD_SPLITS,cfg.beproxy.dosplit,false);
		if (gcfg.proxy_showtray)
			SendDlgItemMessage(hdwnd,IDD_SHOWTRAY,
				BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		LV_COLUMN lvc;
		memset(&lvc,0,sizeof(lvc));
		lvc.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM;
		lvc.fmt = LVCFMT_LEFT;
		lvc.cx=60;
		lvc.iSubItem=0;
		lvc.pszText="Word";
		ListView_InsertColumn(GetDlgItem(hdwnd,IDD_SHORT),0,&lvc);
		lvc.cx=266;
		lvc.iSubItem=1;
		lvc.pszText="URL";
		ListView_InsertColumn(GetDlgItem(hdwnd,IDD_SHORT),1,&lvc);
		memset(&it,0,sizeof(it));
		it.mask = LVIF_TEXT;
		j=0;
		sl=schead;
		while (sl!=NULL)
		{
			it.iItem=j;
			it.iSubItem=0;
			it.pszText=sl->sc;
			it.cchTextMax=strlen(sl->sc);
			ListView_InsertItem(GetDlgItem(hdwnd,IDD_SHORT),&it);
			ListView_SetItemText(GetDlgItem(hdwnd,IDD_SHORT),j,1,sl->url);
			j++;
			sl=sl->next;
		}
		return 1;
	case WM_ACTIVATE:
		if	(LOWORD(wParam) == WA_INACTIVE)
			hgdlg=NULL;
		else
			hgdlg=hdwnd;
		return 1;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDD_RM:
			j=ListView_GetNextItem(GetDlgItem(hdwnd,IDD_SHORT),-1,
							LVNI_ALL|LVNI_SELECTED);
			if (j<0) return true;
			sl=schead;
			for (i=0;i<j;i++)
				if (sl!=NULL) sl=sl->next;
			if (sl==NULL) return true;
			delete sl;
			ListView_DeleteAllItems(GetDlgItem(hdwnd,IDD_SHORT));
			j=0;
			sl=schead;
			memset(&it,0,sizeof(it));
			it.mask = LVIF_TEXT;
			while (sl!=NULL)
			{
				it.iItem=j;
				it.iSubItem=0;
				it.pszText=sl->sc;
				it.cchTextMax=strlen(sl->sc);
				ListView_InsertItem(GetDlgItem(hdwnd,IDD_SHORT),&it);
				ListView_SetItemText(GetDlgItem(hdwnd,IDD_SHORT),j,1,sl->url);
				j++;
				sl=sl->next;
			}
			return true;

		case IDD_ADD:
			if (DialogBox(hlang,"INSSHORT",hdwnd,(DLGPROC)InsShortFunc))
			{
				j=0;
				sl=schead;
				while (sl->next!=NULL)
				{
					j++;
					sl=sl->next;
				}
				memset(&it,0,sizeof(it));
				it.mask = LVIF_TEXT;
				it.iItem=j;
				it.iSubItem=0;
				it.pszText=sl->sc;
				it.cchTextMax=strlen(sl->sc);
				ListView_InsertItem(GetDlgItem(hdwnd,IDD_SHORT),&it);
				ListView_SetItemText(GetDlgItem(hdwnd,IDD_SHORT),j,1,sl->url);
			}
			return true;
		}
		return true;

	case WM_NOTIFY:
		switch (((NMHDR FAR *) lParam)->code)
		{
		case PSN_KILLACTIVE:
			if (SendDlgItemMessage(hdwnd,IDD_USE,BM_GETCHECK,0,0)==BST_UNCHECKED)
				return 1;
			if ((SendDlgItemMessage(hdwnd,IDD_SPIN1,UDM_GETPOS,0,0)>255) ||
				(SendDlgItemMessage(hdwnd,IDD_SPIN2,UDM_GETPOS,0,0)>255) ||
				(SendDlgItemMessage(hdwnd,IDD_SPIN3,UDM_GETPOS,0,0)>255) ||
				(SendDlgItemMessage(hdwnd,IDD_SPIN4,UDM_GETPOS,0,0)>255))
			{
				MsgBox(GetSTR2(149,"This IP is invalid. A field can't be above 255."),
					"Try again",MB_OK);
				dds2();
				SetWindowLong(hdwnd,DWL_MSGRESULT,true);
				return 1;
			}
			if (GetDlgItemInt(hdwnd,IDD_PORT,NULL,false)>0xffff)
			{
				MsgBox(GetSTR2(150,"The port number is invalid."),
					"Try again",MB_OK);
				dds2();
				SetWindowLong(hdwnd,DWL_MSGRESULT,true);
				return 1;
			}
			if (GetDlgItemInt(hdwnd,IDD_SPLITS,NULL,false)>(unsigned)cfg.maxsplit)
			{
				MsgBox(GetSTR2(151,"The split number is invalid."),
					"Try again",MB_OK);
				dds2();
				SetWindowLong(hdwnd,DWL_MSGRESULT,true);
				return 1;
			}
			SetWindowLong(hdwnd,DWL_MSGRESULT,false);
			return 1;
		case PSN_APPLY:
			DWORD *ip;
			short port;
			BYTE d[4];
			bool use=false;
			d[0]=(BYTE)SendDlgItemMessage(hdwnd,IDD_SPIN1,UDM_GETPOS,0,0);
			d[1]=(BYTE)SendDlgItemMessage(hdwnd,IDD_SPIN2,UDM_GETPOS,0,0);
			d[2]=(BYTE)SendDlgItemMessage(hdwnd,IDD_SPIN3,UDM_GETPOS,0,0);
			d[3]=(BYTE)SendDlgItemMessage(hdwnd,IDD_SPIN4,UDM_GETPOS,0,0);
			ip=(DWORD *)d;
			port=(short)GetDlgItemInt(hdwnd,IDD_PORT,NULL,false);
			if (SendDlgItemMessage(hdwnd,IDD_USE,BM_GETCHECK,0,0)==BST_CHECKED)
				use=true;
			cfg.beproxy.to=(short)SendDlgItemMessage(hdwnd,IDD_SPIN5,UDM_GETPOS,0,0);
			cfg.beproxy.minsize=GetDlgItemInt(hdwnd,IDD_MINSIZE,NULL,false);
			cfg.beproxy.dosplit=GetDlgItemInt(hdwnd,IDD_SPLITS,NULL,false);
			if (SendDlgItemMessage(hdwnd,IDD_SHOWTRAY,BM_GETCHECK,0,0)==BST_CHECKED)
				gcfg.proxy_showtray=true;
			else gcfg.proxy_showtray=false;
			if (!use && cfg.beproxy.use)
			{
				cfg.beproxy.use=false;
				ShutProxy();
				cfg.beproxy.ip=*ip;
				cfg.beproxy.port=port;
				return 1;
			}
			if (!use && !cfg.beproxy.use)
			{
				cfg.beproxy.ip=*ip;
				cfg.beproxy.port=port;
				return 1;
			}
			if (use && !cfg.beproxy.use)
			{
				cfg.beproxy.use=true;
				cfg.beproxy.ip=*ip;
				cfg.beproxy.port=port;
				InitProxy();
			}
			if (use && cfg.beproxy.use && 
				((cfg.beproxy.ip!=*ip) || (cfg.beproxy.port!=port)))
			{
				ShutProxy();
				cfg.beproxy.ip=*ip;
				cfg.beproxy.port=port;
				InitProxy();
			}
			return 1;
		}
	}
	return 0;
}

BOOL CALLBACK MirrorFunc(HWND hdwnd, UINT message,
                         WPARAM wParam, LPARAM lParam)
{
	mirsite *mirs;
	LVITEM it;
	int j,i;
	switch(message)
	{
	case WM_HELP:
		WinHelp(hdwnd, HelpFile, HELP_CONTEXT ,IDH_CFGMIRROR);
		return 1;	
	case WM_INITDIALOG:
		if (cfg.mirr.autosearch) SendDlgItemMessage(hdwnd,IDD_AUTOSEARCH,
			BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		CreateUpDownControl(WS_CHILD|WS_BORDER|WS_VISIBLE|
			UDS_SETBUDDYINT|UDS_ALIGNRIGHT,
			10,10,50,50,hdwnd,IDD_SPIN1,hinst,
			GetDlgItem(hdwnd,IDD_MAXMIR),50,1,cfg.mirr.maxmirchecks);
		CreateUpDownControl(WS_CHILD|WS_BORDER|WS_VISIBLE|
			UDS_SETBUDDYINT|UDS_ALIGNRIGHT,
			10,10,50,50,hdwnd,IDD_SPIN2,hinst,
			GetDlgItem(hdwnd,IDD_MAXMIRGET),50,1,cfg.mirr.maxmirget);
		LV_COLUMN lvc;
		memset(&lvc,0,sizeof(lvc));
		lvc.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM;
		lvc.fmt = LVCFMT_LEFT;
		lvc.cx=286;
		lvc.iSubItem=0;
		lvc.pszText="Site";
		ListView_InsertColumn(GetDlgItem(hdwnd,IDD_SITES),0,&lvc);
		lvc.cx=40;
		lvc.iSubItem=1;
		lvc.pszText="Use";
		ListView_InsertColumn(GetDlgItem(hdwnd,IDD_SITES),1,&lvc);
		memset(&it,0,sizeof(it));
		it.mask = LVIF_TEXT;
		j=0;
		mirs=cfg.mirr.mirshead;
		while (mirs!=NULL)
		{
			it.iItem=j;
			it.iSubItem=0;
			it.pszText=mirs->url;
			it.cchTextMax=strlen(mirs->url);
			ListView_InsertItem(GetDlgItem(hdwnd,IDD_SITES),&it);
			ListView_SetItemText(GetDlgItem(hdwnd,IDD_SITES),j,1,mirs->use?GetSTR2(182,"Yes"):GetSTR2(183,"No"));
			j++;
			mirs=mirs->next;
		}
		return 1;
	case WM_ACTIVATE:
		if	(LOWORD(wParam) == WA_INACTIVE)
			hgdlg=NULL;
		else
			hgdlg=hdwnd;
		return 1;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDD_RMSITE:
			j=ListView_GetNextItem(GetDlgItem(hdwnd,IDD_SITES),-1,
							LVNI_ALL|LVNI_SELECTED);
			if (j<0) return true;
			mirs=cfg.mirr.mirshead;
			for (i=0;i<j;i++)
				if (mirs!=NULL) mirs=mirs->next;
			if (mirs==NULL) return true;
			delete mirs;
			ListView_DeleteAllItems(GetDlgItem(hdwnd,IDD_SITES));
			j=0;
			mirs=cfg.mirr.mirshead;
			memset(&it,0,sizeof(it));
			it.mask = LVIF_TEXT;
			while (mirs!=NULL)
			{
				it.iItem=j;
				it.iSubItem=0;
				it.pszText=mirs->url;
				it.cchTextMax=strlen(mirs->url);
				ListView_InsertItem(GetDlgItem(hdwnd,IDD_SITES),&it);
				ListView_SetItemText(GetDlgItem(hdwnd,IDD_SITES),j,1,mirs->use?GetSTR2(182,"Yes"):GetSTR2(183,"No"));
				j++;
				mirs=mirs->next;
			}
			return true;

		case IDD_ADDSITE:
			if (DialogBox(hlang,"INSSITE",hdwnd,(DLGPROC)InsSiteFunc))
			{
				j=0;
				mirs=cfg.mirr.mirshead;
				while (mirs->next!=NULL)
				{
					j++;
					mirs=mirs->next;
				}
				memset(&it,0,sizeof(it));
				it.mask = LVIF_TEXT;
				it.iItem=j;
				it.iSubItem=0;
				it.pszText=mirs->url;
				it.cchTextMax=strlen(mirs->url);
				ListView_InsertItem(GetDlgItem(hdwnd,IDD_SITES),&it);
				ListView_SetItemText(GetDlgItem(hdwnd,IDD_SITES),j,1,mirs->use?GetSTR2(182,"Yes"):GetSTR2(183,"No"));
			}
			return true;
		}
		return true;

	case WM_NOTIFY:
		switch (((NMHDR FAR *) lParam)->code)
		{
		case PSN_APPLY:
			if (SendDlgItemMessage(hdwnd,IDD_AUTOSEARCH,BM_GETCHECK,0,0)==BST_CHECKED)
				cfg.mirr.autosearch=true;
			else 
				cfg.mirr.autosearch=false;
			cfg.mirr.maxmirchecks=(short)SendDlgItemMessage(hdwnd,IDD_SPIN1,UDM_GETPOS,0,0);
			cfg.mirr.maxmirget=(short)SendDlgItemMessage(hdwnd,IDD_SPIN2,UDM_GETPOS,0,0);
			return 1;
		}
	}
	return 0;
}

BOOL CALLBACK ServerFunc(HWND hdwnd, UINT message,
                         WPARAM wParam, LPARAM lParam)
{
	switch(message)
	{
	case WM_HELP:
		WinHelp(hdwnd, HelpFile, HELP_CONTEXT ,IDH_CFGSERVER);
		return 1;	
	case WM_INITDIALOG:
		CreateUpDownControl(WS_CHILD|WS_BORDER|WS_VISIBLE|
			UDS_SETBUDDYINT|UDS_ALIGNRIGHT,
			10,10,50,50,hdwnd,IDD_SPIN1,hinst,
			GetDlgItem(hdwnd,IDD_MAXDL),1024,1,cfg.sdmaxdl);
		CreateUpDownControl(WS_CHILD|WS_BORDER|WS_VISIBLE|
			UDS_SETBUDDYINT|UDS_ALIGNRIGHT,
			10,10,50,50,hdwnd,IDD_SPIN2,hinst,
			GetDlgItem(hdwnd,IDD_MAXCON),1024,1,cfg.sdmaxcon);
		CreateUpDownControl(WS_CHILD|WS_BORDER|WS_VISIBLE|
			UDS_SETBUDDYINT|UDS_ALIGNRIGHT,
			10,10,50,50,hdwnd,IDD_SPIN3,hinst,
			GetDlgItem(hdwnd,IDD_MAXEACH),1024,1,cfg.sdmaxeach);
		return 1;
	case WM_ACTIVATE:
		if	(LOWORD(wParam) == WA_INACTIVE)
			hgdlg=NULL;
		else
			hgdlg=hdwnd;
		return 1;
	case WM_NOTIFY:
		switch (((NMHDR FAR *) lParam)->code)
		{
		case PSN_APPLY:
			cfg.sdmaxdl=(unsigned short)SendDlgItemMessage(hdwnd,IDD_SPIN1,UDM_GETPOS,0,0);
			cfg.sdmaxcon=(unsigned short)SendDlgItemMessage(hdwnd,IDD_SPIN2,UDM_GETPOS,0,0);
			cfg.sdmaxeach=(unsigned short)SendDlgItemMessage(hdwnd,IDD_SPIN3,UDM_GETPOS,0,0);
			return 1;
		}
	}
	return 0;
}

BOOL CALLBACK SkinFunc(HWND hdwnd, UINT message,
                         WPARAM wParam, LPARAM lParam)
{
	char str[1024];
	FILE *fp0;
	Skinload *n;
	static int alpha=gcfg.smallalpha;
	static bool trans=gcfg.smalltrans;
	switch(message)
	{
	case WM_HELP:
		WinHelp(hdwnd, HelpFile, HELP_CONTEXT ,IDH_CFGSKINS);
		return 1;	
	case WM_INITDIALOG:
		ShowWindow(GetDlgItem(hdwnd,IDD_SKINDIR),SW_HIDE);
		ShowWindow(GetDlgItem(hdwnd,IDD_BROWSEDIR),SW_HIDE);
		//SetDlgItemText(hdwnd,IDD_SKINDIR,gcfg.skindir);
		SetDlgItemText(hdwnd,IDD_SKINFILE,gcfg.exskinfn);
		if (gcfg.useexskin) SendDlgItemMessage(hdwnd,IDD_USEEXTERNAL,
			BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		else
			SendDlgItemMessage(hdwnd,IDD_USEDEFAULT,
				BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		PostMessage(hdwnd,WM_COMMAND,MAKELONG(IDD_SKINFILE,EN_CHANGE),0);
		if ((os.dwPlatformId==VER_PLATFORM_WIN32_NT) && (os.dwMajorVersion>=5))
		{
			ShowWindow(GetDlgItem(hdwnd,IDD_TRANS),SW_SHOW);
			ShowWindow(GetDlgItem(hdwnd,IDD_ALPHA),SW_SHOW);
			SendDlgItemMessage(hdwnd,IDD_ALPHA,TBM_SETRANGE,0,MAKELONG(0,255));
			SendDlgItemMessage(hdwnd,IDD_ALPHA,TBM_SETPOS,true,alpha);
			if (trans) SendDlgItemMessage(hdwnd,IDD_TRANS,
				BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		}
		return 1;
	case WM_HSCROLL:
		if ((HWND)lParam==GetDlgItem(hdwnd,IDD_ALPHA) && HIWORD(wParam))
		{
			alpha=HIWORD(wParam);
			if (trans && hwndprev)
			{
				MakeTransparent(hwndprev,0,alpha);
				SetForegroundWindow(hwndprev);
			}
		}
		return 1;
	case WM_ACTIVATE:
		if	(LOWORD(wParam) == WA_INACTIVE)
			hgdlg=NULL;
		else
			hgdlg=hdwnd;
		return 1;
	case WM_COMMAND:
		switch (HIWORD(wParam))
		{
		case BN_CLICKED:
			if ((int) LOWORD(wParam)==IDD_TRANS)
			{
				if (SendDlgItemMessage(hdwnd,IDD_TRANS,BM_GETCHECK,0,0)==BST_CHECKED)
				{
					trans=true;
					MakeTransparent(hwndprev,0,alpha);
				}
				else 
				{
					trans=false;
					MakeNotTransparent(hwndprev);
				}
			}
			break;

		case EN_CHANGE:
			if (LOWORD(wParam)==IDD_SKINFILE)
			{
				GetDlgItemText(hdwnd,IDD_SKINFILE,str,1000);
				if (strlen(str))
				{
					fp0=fopen(str,"rt");
					if (!fp0)
					{
						SetDlgItemText(hdwnd,IDD_NFONAME,GetSTR2(152,"Can't read skin file."));
						dds2();
						SetDlgItemText(hdwnd,IDD_NFOAUTHOR,"");
						SetDlgItemText(hdwnd,IDD_NFOVER,"");
						SetDlgItemText(hdwnd,IDD_NFOBPP,"");
						SetDlgItemText(hdwnd,IDD_NFODATE,"");
						SetDlgItemText(hdwnd,IDD_NFOCOMMENT,"");
						return 1;
					}
					fclose(fp0);
					n=new Skinload;
					n->numpr=1;
					n->numrg=4;
					n->numstbt=9;
					n->numtxt=25;
					n->numtr=1;
					n->type=0;
					n->basedir=_strdup(str);
					char *tc;
					if (tc=strrchr(n->basedir,'\\'))
						*(tc+1)='\0';
/*					n->rg=new RGloadSt[n->numrg];
					n->stbt=new STBTloadSt[n->numstbt];
					n->pr=new PRloadSt[n->numpr];
					n->tr=new TRloadSt[n->numtr];
					n->txt=new txtLD[n->numtxt];*/
					if (n->LoadFile(str)==-1)
					{
						SetDlgItemText(hdwnd,IDD_NFONAME,GetSTR2(153,"Can't initialize skin."));
						dds2();
						SetDlgItemText(hdwnd,IDD_NFOAUTHOR,"");
						SetDlgItemText(hdwnd,IDD_NFOVER,"");
						SetDlgItemText(hdwnd,IDD_NFOBPP,"");
						SetDlgItemText(hdwnd,IDD_NFODATE,"");
						SetDlgItemText(hdwnd,IDD_NFOCOMMENT,"");
						delete n;
						return 1;
					}
					if (n->name)
						SetDlgItemText(hdwnd,IDD_NFONAME,n->name);
					if (n->author)
						SetDlgItemText(hdwnd,IDD_NFOAUTHOR,n->author);
					if (n->ver)
						SetDlgItemText(hdwnd,IDD_NFOVER,n->ver);
					sprintf(str,GetSTR2(154,"Recommended for %ld bits per pixel resolutions."),n->bpp);
					dds2();
					SetDlgItemText(hdwnd,IDD_NFOBPP,str);
					if (n->date)
						SetDlgItemText(hdwnd,IDD_NFODATE,n->date);
					if (n->comment)
						SetDlgItemText(hdwnd,IDD_NFOCOMMENT,n->comment);
					delete n;
					return 1;
				}
				return 1;
			}
			break;
		}
		switch (LOWORD(wParam))
		{
		case IDD_BROWSEDIR:
			GetDlgItemText(hdwnd,IDD_SKINDIR,str,1000);
			BROWSEINFO bi;
			LPITEMIDLIST id;
			bi.hwndOwner=hdwnd;
			bi.pidlRoot=0;
			bi.pszDisplayName=str;
			char stmp[1024];
			strcpy(stmp,GetSTR2(127,"Choose a directory"));
			bi.lpszTitle=stmp;
			bi.ulFlags=BIF_RETURNONLYFSDIRS;
			bi.lpfn=0;
			if (id=SHBrowseForFolder(&bi))
			{
				SHGetPathFromIDList(id,str);
				SetDlgItemText(hdwnd,IDD_SKINDIR,str);
			}
			dds2();
			return 1;
		case IDD_BROWSESKIN:
			OPENFILENAME ofn;
			char dh[MAX_PATH];
			GetDlgItemText(hdwnd,IDD_SKINDIR,str,1000);
			//strcpy(dh,str);
			dh[0]='\0';
			memset(&ofn,0,sizeof(ofn));
			ofn.lStructSize=sizeof(ofn);
			ofn.hwndOwner=hdwnd;
			ofn.hInstance=hinst;
			ofn.lpstrFile=dh;
			ofn.nMaxFile=MAX_PATH;
			ofn.lpstrInitialDir=str;
			ofn.Flags=OFN_PATHMUSTEXIST;
			ofn.lpstrDefExt=".gsk";
			if (GetOpenFileName(&ofn))
				SetDlgItemText(hdwnd,IDD_SKINFILE,ofn.lpstrFile);
			return 1;
		case IDD_PREVIEW:
			if (hwndprev==NULL)
			{
				GetDlgItemText(hdwnd,IDD_SKINFILE,str,1000);
				if (strlen(str))
				{
					fp0=fopen(str,"rt");
					if (!fp0)
					{
						SetDlgItemText(hdwnd,IDD_NFONAME,GetSTR2(152,"Can't read skin file."));
						dds2();
						SetDlgItemText(hdwnd,IDD_NFOAUTHOR,"");
						SetDlgItemText(hdwnd,IDD_NFOVER,"");
						SetDlgItemText(hdwnd,IDD_NFOBPP,"");
						SetDlgItemText(hdwnd,IDD_NFODATE,"");
						SetDlgItemText(hdwnd,IDD_NFOCOMMENT,"");
						return 1;
					}
					fclose(fp0);
					n=new Skinload;
					n->numpr=1;
					n->numrg=4;
					n->numstbt=9;
					n->numtxt=25;
					n->numtr=1;
					n->type=0;
					n->basedir=_strdup(str);
					char *tc;
					if (tc=strrchr(n->basedir,'\\'))
						*(tc+1)='\0';
/*					n->rg=new RGloadSt[n->numrg];
					n->stbt=new STBTloadSt[n->numstbt];
					n->pr=new PRloadSt[n->numpr];
					n->tr=new TRloadSt[n->numtr];
					n->txt=new txtLD[n->numtxt];*/
					int ldflag;
					ldflag=n->LoadFile(str)==-1;
					n->tr[0].max=cfg.maxsplit;
					if ((ldflag==-1) || (prevskin.Init(*n,hlang)==-1))
					{
						SetDlgItemText(hdwnd,IDD_NFONAME,GetSTR2(153,"Can't initialize skin."));
						dds2();
						SetDlgItemText(hdwnd,IDD_NFOAUTHOR,"");
						SetDlgItemText(hdwnd,IDD_NFOVER,"");
						SetDlgItemText(hdwnd,IDD_NFOBPP,"");
						SetDlgItemText(hdwnd,IDD_NFODATE,"");
						SetDlgItemText(hdwnd,IDD_NFOCOMMENT,"");
						if (ldflag!=-1) prevskin.Kill();
						delete n;
						return 1;
					}
					delete n;
					
					CreateWindow("GSPrevWin",
						"",
						WS_POPUP|WS_SYSMENU|WS_MINIMIZEBOX,
						100,
						100,
						400,
						400,
						HWND_DESKTOP,
						NULL,
						hinst,
						(void *)&prevskinnfo);
					if (trans) MakeTransparent(hwndprev,false,alpha);
				}
			}
			else DestroyWindow(hwndprev);
			return 1;
		case IDD_VIEWDEF:
			if (hwndprev==NULL)
			{
				n=new Skinload;
				InitSmallSkin(*n);
				if (prevskin.Init(*n,hlang)==-1)
				{
						prevskin.Kill();
						delete n;
						return 1;
				}
				delete n;
					
				CreateWindow("GSPrevWin",
						"",
						WS_POPUP|WS_SYSMENU|WS_MINIMIZEBOX,
						100,
						100,
						400,
						400,
						HWND_DESKTOP,
						NULL,
						hinst,
						(void *)&prevskinnfo);
				if (trans) MakeTransparent(hwndprev,false,alpha);
			}
			else DestroyWindow(hwndprev);
			return 1;
		}
		return 0;
	case WM_NOTIFY:
		switch (((NMHDR FAR *) lParam)->code)
		{
		case PSN_APPLY:
			if (SendDlgItemMessage(hdwnd,IDD_USEDEFAULT,BM_GETCHECK,0,0)==BST_CHECKED)
				gcfg.useexskin=false;
			else 
				gcfg.useexskin=true;
			//GetDlgItemText(hdwnd,IDD_SKINDIR,str,1000);
			//if (strlen(str) && str[strlen(str)-1]!='\\')
				//strcat(str,"\\");
			//gcfg.skindir=ReDupString(gcfg.skindir,str);
			GetDlgItemText(hdwnd,IDD_SKINFILE,str,1000);
			gcfg.exskinfn=ReDupString(gcfg.exskinfn,str);
			gcfg.smalltrans=trans;
			gcfg.smallalpha=alpha;
		case PSN_RESET:
			if (hwndprev)
				DestroyWindow(hwndprev);
			return 1;

		}
	}
	return 0;
}

BOOL CALLBACK LVFunc(HWND hdwnd, UINT message,
                         WPARAM wParam, LPARAM lParam)
{
	char str[1024];
	static CHOOSECOLOR cc;
	static COLORREF cct[16];

	switch(message)
	{
    case WM_HELP:
		//WinHelp(hdwnd, HelpFile, HELP_CONTEXT ,IDH_CFGPROXY);
		return 1;	
	case WM_INITDIALOG:
		if (gcfg.lv.bkload)
			SendDlgItemMessage(hdwnd,IDD_BKLOAD,BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		else
			if (gcfg.lv.bkwallpaper)
				SendDlgItemMessage(hdwnd,IDD_BKWALLPAPER,BM_SETCHECK,(WPARAM) BST_CHECKED,0);
			else
				SendDlgItemMessage(hdwnd,IDD_BKCUSTOM,BM_SETCHECK,(WPARAM) BST_CHECKED,0);

		if (gcfg.lv.dynbk)
			SendDlgItemMessage(hdwnd,IDD_DYNBK,BM_SETCHECK,(WPARAM) BST_CHECKED,0);

		SetDlgItemText(hdwnd,IDD_BKFN,gcfg.lv.bkfn);

		memset(&cc,0,sizeof(cc));
		cc.lStructSize=sizeof(cc);
		cc.hwndOwner=hdwnd;
		cc.Flags=CC_ANYCOLOR|CC_FULLOPEN|CC_RGBINIT;
		memset(cct,0,sizeof(cct));
		cc.lpCustColors=cct;

		return 1;

	case WM_ACTIVATE:
		if	(LOWORD(wParam) == WA_INACTIVE)
			hgdlg=NULL;
		else
			hgdlg=hdwnd;
		return 1;

	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case IDD_BROWSEBK:
			OPENFILENAME ofn;
			char dh[MAX_PATH];
			GetDlgItemText(hdwnd,IDD_BKFN,str,1000);
			//strcpy(dh,str);
			dh[0]='\0';
			memset(&ofn,0,sizeof(ofn));
			ofn.lStructSize=sizeof(ofn);
			ofn.hwndOwner=hdwnd;
			ofn.hInstance=hinst;
			ofn.lpstrFile=dh;
			ofn.nMaxFile=MAX_PATH;
			ofn.lpstrInitialDir=str;
			ofn.Flags=OFN_PATHMUSTEXIST;
			ofn.lpstrDefExt=".bmp";
			if (GetOpenFileName(&ofn))
				SetDlgItemText(hdwnd,IDD_BKFN,ofn.lpstrFile);
			return 1;
		case IDD_BKCLR:
			cc.rgbResult=gcfg.lv.bkclr;
			if (ChooseColor(&cc))
				gcfg.lv.bkclr=cc.rgbResult;
			return 1;
		case IDD_TXTCLR:
			cc.rgbResult=gcfg.lv.txtclr;
			if (ChooseColor(&cc))
				gcfg.lv.txtclr=cc.rgbResult;
			return 1;
		case IDD_TXTCLR2:
			cc.rgbResult=gcfg.lv.txtclr2;
			if (ChooseColor(&cc))
				gcfg.lv.txtclr2=cc.rgbResult;
			return 1;
		case IDD_HDCLR:
			cc.rgbResult=gcfg.lv.hdclr;
			if (ChooseColor(&cc))
				gcfg.lv.hdclr=cc.rgbResult;
			return 1;
		case IDD_HDCLR2:
			cc.rgbResult=gcfg.lv.hdclr2;
			if (ChooseColor(&cc))
				gcfg.lv.hdclr2=cc.rgbResult;
			return 1;
		}
		return 1;

	case WM_NOTIFY:
		switch (((NMHDR FAR *) lParam)->code)
		{
		case PSN_APPLY:
			GetDlgItemText(hdwnd,IDD_BKFN,gcfg.lv.bkfn,sizeof(gcfg.lv.bkfn));
			if (SendDlgItemMessage(hdwnd,IDD_BKCUSTOM,BM_GETCHECK,0,0)==BST_CHECKED)
				gcfg.lv.bkcustom=true;
			else gcfg.lv.bkcustom=false;
			if (SendDlgItemMessage(hdwnd,IDD_BKWALLPAPER,BM_GETCHECK,0,0)==BST_CHECKED)
				gcfg.lv.bkwallpaper=true;
			else gcfg.lv.bkwallpaper=false;
			if (SendDlgItemMessage(hdwnd,IDD_BKLOAD,BM_GETCHECK,0,0)==BST_CHECKED)
				gcfg.lv.bkload=true;
			else gcfg.lv.bkload=false;
			if (SendDlgItemMessage(hdwnd,IDD_DYNBK,BM_GETCHECK,0,0)==BST_CHECKED)
				gcfg.lv.dynbk=true;
			else gcfg.lv.dynbk=false;
			return 1;
		}
	}
	return 0;
}

BOOL CALLBACK InsPhoneFunc(HWND hdwnd, UINT message,
						   WPARAM wParam, LPARAM lParam)
{
	static char *str;
	switch(message)
	{
	case WM_INITDIALOG:
		str=(char*) lParam;
		return 1;
	case WM_ACTIVATE:
		if	(LOWORD(wParam) == WA_INACTIVE)
			hgdlg=NULL;
		else
			hgdlg=hdwnd;
		return 1;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDCANCEL:
			EndDialog(hdwnd, 0);
			return 1;
		case IDOK:
			GetDlgItemText(hdwnd,IDD_EDIT,str,1000);
			EndDialog(hdwnd, 1);
			return 1;
		}
		return 0;
	}
	return 0;
}

BOOL CALLBACK InsEXTFunc(HWND hdwnd, UINT message,
						   WPARAM wParam, LPARAM lParam)
{
	char ext[1024],dir[1024];
	switch(message)
	{
	case WM_INITDIALOG:
		GetExtDir(dir,"");
		SetDlgItemText(hdwnd,IDD_DIR,dir);
		return true;
	case WM_ACTIVATE:
		if	(LOWORD(wParam) == WA_INACTIVE)
			hgdlg=NULL;
		else
			hgdlg=hdwnd;
		return 1;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDD_BROWSE:
			GetDlgItemText(hdwnd,IDD_DIR,dir,1024);
			BROWSEINFO bi;
			LPITEMIDLIST id;
			bi.hwndOwner=hdwnd;
			bi.pidlRoot=0;
			bi.pszDisplayName=dir;
			char stmp[1024];
			strcpy(stmp,GetSTR2(127,"Choose a directory"));
			bi.lpszTitle=stmp;
			bi.ulFlags=BIF_RETURNONLYFSDIRS;
			bi.lpfn=0;
			if (id=SHBrowseForFolder(&bi))
			{
				SHGetPathFromIDList(id,dir);
				strcat(dir,"\\");
				SetDlgItemText(hdwnd,IDD_DIR,dir);
			}
			dds2();
			return true;
		case IDCANCEL:
			EndDialog(hdwnd, 0);
			return 1;
		case IDOK:
			GetDlgItemText(hdwnd,IDD_EXT,ext,1024);
			GetDlgItemText(hdwnd,IDD_DIR,dir,1024);
			if (!strlen(ext) || !strlen(dir))
			{
				EndDialog(hdwnd, 0);
				return 1;
			}
			new extlist(ext,dir);
			EndDialog(hdwnd, 1);
			return 1;
		}
		return 0;
	}
	return 0;
}

BOOL CALLBACK InsShortFunc(HWND hdwnd, UINT message,
						   WPARAM wParam, LPARAM lParam)
{
	char sc[1024],url[1024];
	switch(message)
	{
	case WM_INITDIALOG:
		return true;
	case WM_ACTIVATE:
		if	(LOWORD(wParam) == WA_INACTIVE)
			hgdlg=NULL;
		else
			hgdlg=hdwnd;
		return 1;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDCANCEL:
			EndDialog(hdwnd, 0);
			return 1;
		case IDOK:
			GetDlgItemText(hdwnd,IDD_SC,sc,1024);
			GetDlgItemText(hdwnd,IDD_URL,url,1024);
			if (!strlen(sc) || !strlen(url))
			{
				EndDialog(hdwnd, 0);
				return 1;
			}
			new sclist(sc,url);
			EndDialog(hdwnd, 1);
			return 1;
		}
		return 0;
	}
	return 0;
}

BOOL CALLBACK InsSiteFunc(HWND hdwnd, UINT message,
						   WPARAM wParam, LPARAM lParam)
{
	char url[1024];
	switch(message)
	{
	case WM_INITDIALOG:
		return true;
	case WM_ACTIVATE:
		if	(LOWORD(wParam) == WA_INACTIVE)
			hgdlg=NULL;
		else
			hgdlg=hdwnd;
		return 1;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDCANCEL:
			EndDialog(hdwnd, 0);
			return 1;
		case IDOK:
			GetDlgItemText(hdwnd,IDD_URL,url,1024);
			if (!strlen(url))
			{
				EndDialog(hdwnd, 0);
				return 1;
			}
			new mirsite(url,true);
			EndDialog(hdwnd, 1);
			return 1;
		}
		return 0;
	}
	return 0;
}

bool Config()
{
	PROPSHEETPAGE psp[12];
	PROPSHEETHEADER psh;

	memset(psp,0,sizeof(psp));
	memset(&psh,0,sizeof(psh));

	psp[0].dwSize = sizeof(PROPSHEETPAGE);
	psp[0].dwFlags = 0;
	psp[0].hInstance = hlang;
	psp[0].pszTemplate = "CFGAUTO";
	psp[0].pfnDlgProc = (DLGPROC) AutoFunc;
	
	psp[1].dwSize = sizeof(PROPSHEETPAGE);
	psp[1].dwFlags = 0;
	psp[1].hInstance = hlang;
	psp[1].pszTemplate = "CFGDIRS";
	psp[1].pfnDlgProc = (DLGPROC) DirsFunc;
	
	psp[2].dwSize = sizeof(PROPSHEETPAGE);
	psp[2].dwFlags = 0;
	psp[2].hInstance = hlang;
	psp[2].pszTemplate = "CFGVISUAL";
	psp[2].pfnDlgProc = (DLGPROC) VisualFunc;

	psp[3].dwSize = sizeof(PROPSHEETPAGE);
	psp[3].dwFlags = 0;
	psp[3].hInstance = hlang;
	psp[3].pszTemplate = "CFGFIRE";
	psp[3].pfnDlgProc = (DLGPROC) FireFunc;

	psp[4].dwSize = sizeof(PROPSHEETPAGE);
	psp[4].dwFlags = 0;
	psp[4].hInstance = hlang;
	psp[4].pszTemplate = "CFGHAMMER";
	psp[4].pfnDlgProc = (DLGPROC) HammerFunc;

	psp[5].dwSize = sizeof(PROPSHEETPAGE);
	psp[5].dwFlags = 0;
	psp[5].hInstance = hlang;
	psp[5].pszTemplate = "CFGDUP";
	psp[5].pfnDlgProc = (DLGPROC) DUPFunc;

	psp[6].dwSize = sizeof(PROPSHEETPAGE);
	psp[6].dwFlags = 0;
	psp[6].hInstance = hlang;
	psp[6].pszTemplate = "CFGADVANCED";
	psp[6].pfnDlgProc = (DLGPROC) AdvancedFunc;

	psp[7].dwSize = sizeof(PROPSHEETPAGE);
	psp[7].dwFlags = 0;
	psp[7].hInstance = hlang;
	psp[7].pszTemplate = "CFGMIRROR";
	psp[7].pfnDlgProc = (DLGPROC) MirrorFunc;

	psp[8].dwSize = sizeof(PROPSHEETPAGE);
	psp[8].dwFlags = 0;
	psp[8].hInstance = hlang;
	psp[8].pszTemplate = "CFGBEPROXY";
	psp[8].pfnDlgProc = (DLGPROC) BeProxyFunc;

	psp[9].dwSize = sizeof(PROPSHEETPAGE);
	psp[9].dwFlags = 0;
	psp[9].hInstance = hlang;
	psp[9].pszTemplate = "CFGSKIN";
	psp[9].pfnDlgProc = (DLGPROC) SkinFunc;

	psp[10].dwSize = sizeof(PROPSHEETPAGE);
	psp[10].dwFlags = 0;
	psp[10].hInstance = hlang;
	psp[10].pszTemplate = "CFGSERVER";
	psp[10].pfnDlgProc = (DLGPROC) ServerFunc;

	psp[11].dwSize = sizeof(PROPSHEETPAGE);
	psp[11].dwFlags = 0;
	psp[11].hInstance = hlang;
	psp[11].pszTemplate = "CFGLV";
	psp[11].pfnDlgProc = (DLGPROC) LVFunc;

/*	psp[12].dwSize = sizeof(PROPSHEETPAGE);
	psp[12].dwFlags = PSP_USEREFPARENT;
	psp[12].hInstance = hlang;
	psp[12].pszTemplate = "CFGLV_LV";
	psp[12].pfnDlgProc = (DLGPROC) LV_LVFunc;*/

	psh.dwSize = sizeof(PROPSHEETHEADER);
	psh.dwFlags = PSH_PROPSHEETPAGE|PSH_NOAPPLYNOW;
	psh.hwndParent = hwndgui;
	psh.hInstance = hinst;
	//psh.pszIcon = MAKEINTRESOURCE(IDI_CELL_PROPERTIES);
	char stmp[1024];
	strcpy(stmp,GetSTR2(155,"Configuration"));
	psh.pszCaption = stmp;
	psh.nPages = sizeof(psp) / sizeof(PROPSHEETPAGE);
	//psh.nPages = 4;
    psh.nStartPage = 0;
	psh.ppsp = (LPCPROPSHEETPAGE) &psp;
	//psh.pfnCallback = NULL;
	PropertySheet(&psh);
	dds2();
	SaveConfig();
	SaveGUIConfig();
	return 1;
}
