
#include "GUI.h"

void mainftp::TaskWin()
{
	if (htask==NULL)
	{
		sktask.data=mdl;
		CreateWindowEx(cfg.r2l,"GSTaskWin",
					"",
					WS_OVERLAPPEDWINDOW,
					CW_USEDEFAULT,
					CW_USEDEFAULT,
					CW_USEDEFAULT,
					CW_USEDEFAULT,
					HWND_DESKTOP,
					NULL,
					hinst,
					(void *)&sktask);
	}
	else DestroyWindow(htask);
}

void smallftp::SmallWin()
{
	if (mdl->type==2)
	{
		m->BrowseWin();
		return;
	}
	if (hwnd==NULL)
	{
		sksmall.data=this;
		CreateWindow("GSSmallWin",
					"",
					WS_POPUP|WS_SYSMENU|WS_MINIMIZEBOX,
					100,
					100,
					400,
					400,
					HWND_DESKTOP,
					NULL,
					hinst,
					(void *)&sksmall);
	}
	else
	{
		ShowWindow(hwnd,SW_SHOW);
		ShowWindow(hwnd,SW_RESTORE);
		SetForegroundWindow(hwnd);
	}
}

void mainftp::BrowseWin()
{
	if (hwild==NULL)
	{
		mftp->sksmall.data=mdl;
		CreateWindowEx(cfg.r2l|WS_EX_CONTROLPARENT,"GSBrowseWin",
					"",
					WS_OVERLAPPEDWINDOW,
					100,
					100,
					700,
					500,
					HWND_DESKTOP,
					NULL,
					hinst,
					(void *)&mftp->sksmall);
	}
	else
	{
		ShowWindow(hwild,SW_SHOW);
		ShowWindow(hwild,SW_RESTORE);
		SetForegroundWindow(hwild);
	}
}

void smallftp::BufferWin()
{
	int j;
	if (hbuffer==NULL)
	{
		if (bdl==NULL)
			if (mdl->spliton)
			{
				int adv=-1,sp=0,i;
				for (i=0;i<=mdl->splitdex;i++)
					if (mdl->splitdl[i] && (mdl->splitdl[i]->status>adv))
					{
						adv=mdl->splitdl[i]->status;
						sp=i;
					}
				smallftp *f;
				f=(smallftp*)mdl->splitdl[sp]->guiparam;
				if (f->hbuffer==NULL)
					f->BufferWin();
				hbuffer=f->hbuffer;
				hwndBB=f->hwndBB;
				return;
			}
		skbuffer.data=this;
		hbuffer=CreateWindow("GSBufferWin",
					"",
					WS_OVERLAPPEDWINDOW,
					CW_USEDEFAULT,
					CW_USEDEFAULT,
					CW_USEDEFAULT,
					CW_USEDEFAULT,
					HWND_DESKTOP,
					NULL,
					hinst,
					(void *)&skbuffer);
		buffer *tmp,*tmp2=NULL;
		if (bdl==NULL)
			tmp=mdl->buffhead;
		else
			tmp=bdl->buffhead;
		j=-1;
		while (tmp)
		{
			j=SendMessage(hwndBB,LB_ADDSTRING,0,(LPARAM) tmp->txt);
			SendMessage(hwndBB, LB_SETITEMDATA, j,
					tmp->txt[strlen(tmp->txt)+1]);
			tmp2=tmp;
			tmp=tmp->next;
		}
		if (j!=-1)
			SendMessage(hwndBB,LB_SELECTSTRING,(WPARAM) 
						(j-1),(LPARAM) tmp2->txt);
	}
	else DestroyWindow(hbuffer);
}

void mainftp::MirrorWin()
{
	if (hmirror==NULL)
	{
		skmirror.data=this;
		CreateWindowEx(cfg.r2l,"GSMirrorWin",
					"",
					WS_OVERLAPPEDWINDOW,
					CW_USEDEFAULT,
					CW_USEDEFAULT,
					CW_USEDEFAULT,
					CW_USEDEFAULT,
					HWND_DESKTOP,
					NULL,
					hinst,
					(void *)&skmirror);
	}
	else DestroyWindow(hmirror);
}

void mainftp::UpdateTrack()
{
	if (!mdl->spliton) return;
	int j;
	j=ListView_GetNextItem(hwndLV,-1,LVNI_ALL|LVNI_SELECTED);
	if (j!=-1)
	{
		STATUSITEM *pitem = (STATUSITEM *) GetLVlParam(hwndLV,j);
		if (pitem->mdl==mdl)
			PostMessage(hwndgui,_SKN_TRJMP,MAKELONG(0,0),mdl->spliton);
	}
	if (htask!=NULL)
		PostMessage(htask,_SKN_TRJMP,MAKELONG(0,0),mdl->spliton);
	if (mftp->hwnd!=NULL)
		PostMessage(mftp->hwnd,_SKN_TRJMP,MAKELONG(0,0),mdl->spliton);
}

int mainftp::UpdateTray(unsigned long r,time_t tp)
{
	if (!gcfg.showdltray || (!mdl->spliton && !blink) ||
		(mdl->type==5) && !gcfg.proxy_showtray || (mdl->type==9) || (mdl->type==10))
	{
		if (ticon)
		{
			RemoveTray();
		}
		return 0;
	}
	HICON hIcon,hIcon3=NULL;
	unsigned long i,x,y;
	char str[1024];
	bool newtray=false;
	if (!ticon) newtray=true;
	if (!hmem)
	{
		HDC hdc=GetDC(hwndgui);
		hmem = CreateCompatibleDC(hdc);
		ReleaseDC(hwndgui,hdc);
	}

	if (!blink && !mdl->logged && (ticon!=1))
	{
		ticon=1;
		hIcon=LoadIcon(hlang,"LOGINICON");
		if (IconInfo.hbmColor)
		{
			SelectObject(hmem,prevbm);
			DeleteObject(IconInfo.hbmColor);
		}
		if (IconInfo.hbmMask) DeleteObject(IconInfo.hbmMask);
		GetIconInfo(hIcon,&IconInfo);
		DestroyIcon(hIcon);
		prevbm=SelectObject(hmem,IconInfo.hbmColor);
	}

	if (!blink && mdl->logged && (ticon!=2))
	{
		iconfill=0;
		ticon=2;
		hIcon=LoadIcon(hlang,"FILEICON");
		if (IconInfo.hbmColor)
		{
			SelectObject(hmem,prevbm);
			DeleteObject(IconInfo.hbmColor);
		}
		if (IconInfo.hbmMask) DeleteObject(IconInfo.hbmMask);
		GetIconInfo(hIcon,&IconInfo);
		DestroyIcon(hIcon);
		prevbm=SelectObject(hmem,IconInfo.hbmColor);
	}
	
	if (blink && (ticon!=3) && !mdl->done)
	{
		if (!IconInfo.hbmColor)
		{
			hIcon=LoadIcon(hlang,"LOGINICON");
			GetIconInfo(hIcon,&IconInfo);
			DestroyIcon(hIcon);
			prevbm=SelectObject(hmem,IconInfo.hbmColor);
		}
		ticon=3;
		for (y=29;y>10;y--)
			for (x=3+30-y;x<8+30-y;x++)
				SetPixel(hmem,x,y,RGB(255,0,0));
		for (y=29;y>10;y--)
			for (x=5+y-7;x>y-7;x--)
				SetPixel(hmem,x,y,RGB(255,0,0));
	}

	if (blink && mdl->done && (ticon!=4))
	{
		ticon=4;
		hIcon=LoadIcon(hlang,"FINISHICON");
				if (IconInfo.hbmColor)
		{
			SelectObject(hmem,prevbm);
			DeleteObject(IconInfo.hbmColor);
		}
		if (IconInfo.hbmMask) DeleteObject(IconInfo.hbmMask);
		GetIconInfo(hIcon,&IconInfo);
		DestroyIcon(hIcon);
		prevbm=SelectObject(hmem,IconInfo.hbmColor);
	}

	if (ticon==1 && !blink) 
	{
		if (mdl && (tp-mdl->timeout>1))
			for (y=7;y<14;y++)
				for (x=7;x<14;x++)
					SetPixel(hmem,x,y,RGB(255,0,0));
		else
			for (y=7;y<14;y++)
				for (x=7;x<14;x++)
					SetPixel(hmem,x,y,RGB(50,200,50));
		strcpy(str,mdl->mstxt);
	}
	
	if (ticon==2)
	{
		if (r && mdl->rsize)
		{
			sprintf(str,"%s  (%.1f%%) Est. %.2d:%.2d:%.2d",mdl->lfn,
				(int) (mdl->lbytes*1000.0/mdl->rsize)/10.0,
				r/3600,(r%3600)/60,((r%3600)%60));
		}
		else strcpy(str,mdl->mstxt);
		if (mdl->rsize>1)
			i=(unsigned long)(mdl->lbytes*654.0/mdl->rsize);
		else i=0;
		if (i>654) i=654;
		if (i<iconfill)
		{
			hIcon=LoadIcon(hlang,"FILEICON");
			if (IconInfo.hbmColor)
			{
				SelectObject(hmem,prevbm);
				DeleteObject(IconInfo.hbmColor);
			}
			if (IconInfo.hbmMask) DeleteObject(IconInfo.hbmMask);
			GetIconInfo(hIcon,&IconInfo);
			DestroyIcon(hIcon);
			prevbm=SelectObject(hmem,IconInfo.hbmColor);
		}
		iconfill=i;
		for (y=7;y<14;y++)
			for (x=7;x<14;x++)
				SetPixel(hmem,x,y,RGB(255,255,255));		
		for (y=30;y>30-i/22;y--)
			for (x=5;x<27;x++)
				SetPixel(hmem,x,y,RGB(0,0,255));
		for (x=5;x<5+i%22;x++)
			SetPixel(hmem,x,y,RGB(0,0,255));		
		if (!mdl->timeout || (tp-mdl->timeout>1))
			for (y=7;y<14;y++)
				for (x=7;x<14;x++)
					SetPixel(hmem,x,y,RGB(255,0,0));
		else
			for (y=7;y<14;y++)
				for (x=7;x<14;x++)
					SetPixel(hmem,x,y,RGB(50,200,50));
	}
	if (blink)
	{
		if (mdl->done)
			strcpy(str,GetSTR2(156,"Download was successful. Double click on the tray icon."));
		else
			strcpy(str,GetSTR2(157,"Error occured while trying to download. Double click the tray icon for more info."));
		dds2();
		if (bshow) bshow=false;
		else bshow=true;
		if (!bshow)
		{
			byte bx[16*16],bm[16][16];
			memset(bx,255,sizeof(bx));
			memset(bm,0,sizeof(bm));
			if (hIcon3) DestroyIcon(hIcon3);
			hIcon3 = CreateIcon(hinst,16,16,1,8,bx,&bm[0][0]);		
		}
		else
		{
			if (hIcon3) DestroyIcon(hIcon3);
			hIcon3=CreateIconIndirect(&IconInfo);
		}
	}
	else
	{
		if (hIcon3) DestroyIcon(hIcon3);
		hIcon3=CreateIconIndirect(&IconInfo);
	}
	NOTIFYICONDATA pnid;
	memset(&pnid,0,sizeof(pnid));
	pnid.cbSize=sizeof(NOTIFYICONDATA);
	pnid.hWnd=hwndgui;
	pnid.uID=(UINT)mdl;
	pnid.uFlags=NIF_ICON|NIF_MESSAGE|NIF_TIP;
	pnid.uCallbackMessage=TRAY_MSG;
	pnid.hIcon=hIcon3;
	if (strlen(str)>62) str[62]='\0';
	strcpy(pnid.szTip,str);
	if (newtray/* && !blink*/) Shell_NotifyIcon (NIM_ADD, &pnid ); 
	else Shell_NotifyIcon (NIM_MODIFY, &pnid );
/*	if (!lvimagepos)
	{
		for (i=1;i<=1024;i++)
			if (!lvimage[i]) break;
		if (i>1024) lvimagepos=0;
		else
		{
			lvimagepos=i;
			if (i>(unsigned)lvimagehigh)
					ImageList_AddIcon(hlvicons,hIcon3);
			else
				ImageList_ReplaceIcon(hlvicons,i,hIcon3);
			ImageList_GetImageInfo(hlvicons,i,&ImageInfo);
		}
	}
	else
		if (lvimagepos>0)
		{
//			char m[3072];
			//i=GetBitmapBits(IconInfo.hbmColor,3072,m);
			//i=SetBitmapBits(ImageInfo.hbmImage,3072,m);
			//ImageInfo.hbmImage=IconInfo.hbmColor;
			//GetBitmapBits(IconInfo.hbmMask,1024,m);
			//SetBitmapBits(ImageInfo.hbmMask,1024,m);
			//ImageInfo.hbmMask=IconInfo.hbmMask;
		}
//		if (lvimagepos>0) ImageList_ReplaceIcon(hlvicons,lvimagepos,
//												hIcon3);
/*	LV_ITEM it;
	memset(&it,0,sizeof(it));
	it.mask=LVIF_IMAGE;
	it.iImage= I_IMAGECALLBACK;
	it.iItem=item->pos;
	it.iSubItem=0;
	ListView_SetItem(hwndLV,&it);*/
	//SetClassLong(mftp->hwnd,GCL_HICON,(long) hIcon3);
	RECT rc;
	ListView_GetItemRect(hwndLV,item->pos,&rc,LVIR_BOUNDS);
	rc.right=20;
	InvalidateRect(hwndLV,&rc,false);

	DestroyIcon(hIcon3);
	return 1;
}

int mainftp::RemoveTray()
{
	NOTIFYICONDATA pnid;
	memset(&pnid,0,sizeof(pnid));
	ticon=0;
	iconfill=0;
	pnid.cbSize=sizeof(NOTIFYICONDATA);
	pnid.hWnd=hwndgui;
	pnid.uID=(UINT) mdl;
	pnid.uFlags=NIF_ICON|NIF_MESSAGE|NIF_TIP;
	pnid.uCallbackMessage=TRAY_MSG;
	Shell_NotifyIcon (NIM_DELETE, &pnid );
	if (IconInfo.hbmColor)
	{
		SelectObject(hmem,prevbm);
		DeleteObject(IconInfo.hbmColor);
	}
	if (IconInfo.hbmMask) DeleteObject(IconInfo.hbmMask);	
	if (hmem)
	{
		DeleteDC(hmem);
		hmem=NULL;
	}
	memset(&IconInfo,0,sizeof(ICONINFO));
	blink=false;
	return 1;
}

void mainftp::AddItem()
{
	next=NULL;
	if (donehead==NULL)
	{
		donehead=this;
		prev=NULL;
	}
	else
	{
		donelast->next=this;
		prev=donelast;
	}
	donelast=this;
}

void mainftp::RMItem()
{
	if (donehead==donelast)
	{
		donehead=NULL;
		donelast=NULL;
		next=NULL;
		prev=NULL;
		return;
	}
	if (this==donehead)
	{
		next->prev=NULL;
		donehead=next;
	}
	else
		if (next) next->prev=prev;
	
	if (this==donelast)
	{
		prev->next=NULL;
		donelast=prev;
	}
	else
		if (prev) prev->next=next;
	next=NULL;
	prev=NULL;
}

void mainftp::RMLV()
{
	int j;
	for (j=0;j<50;j++)
		if (itempos[j].hwndU)
		   ListView_DeleteItem(itempos[j].hwndU,itempos[j].pos);
	ListView_DeleteItem(hwndLV,item->pos);
	//SendMessage(hwndLV,LVM_DELETEITEM,(int) item->pos,0);
}

void mainftp::ShowMSG()
{
	char str[1024],lang[1024];
	int d;
	if (mdl->done)
	{
		sprintf(str,GetSTR2(5,"\"%s%s\" size:%d - Download complete"),
				mdl->ldir,mdl->lfn,mdl->rsize);
		strcat(str,"\n");
		d=mdl->begtime.DayDiff();
		if (d)
		{
			sprintf(lang,GetSTR2(6,"Started %d days ago."),d);
			strcat(str,lang);
			strcat(str,"\n");
		}
		if (mdl->rsize && mdl->totaltime)
		{
			char bak[1024];
			strcpy(bak,GetSTR2(7,"Average CPS %.2f kb/s."));
			sprintf(lang,bak,mdl->rsize/mdl->totaltime/1024.0);
			strcat(str,lang);
			strcat(str,"\n");
		}
		sprintf(lang,GetSTR2(8,"%d retries."),mdl->retries);
		strcat(str,lang);
		strcat(str,"\n");
		dds2();
		MsgBox(str,GetSTR2(158,"Download successful!"),
			MB_OK|MB_ICONINFORMATION|MB_SETFOREGROUND|MB_SYSTEMMODAL);
	}
	else
	{
		sprintf(str,GetSTR2(159,"Error downloading file.\n%s"),mdl->ErrMsg);
		dds2();
		MsgBox(str,mdl->lfn,
			MB_OK|MB_ICONEXCLAMATION|MB_SETFOREGROUND|MB_SYSTEMMODAL);
	}
}

void mainftp::ShowTTMSG()
{
	char str[1024],lang[1024];
	int d;
	if (mdl->done)
	{
		sprintf(str,GetSTR2(5,"\"%s%s\" size:%d - Download complete"),
				mdl->ldir,mdl->lfn,mdl->rsize);
		strcat(str,"\n");
		d=mdl->begtime.DayDiff();
		if (d)
		{
			sprintf(lang,GetSTR2(6,"Started %d days ago."),d);
			strcat(str,lang);
			strcat(str,"\n");
		}
		if (mdl->rsize && mdl->totaltime)
		{
			char bak[1024];
			strcpy(bak,GetSTR2(7,"Average CPS %.2f kb/s."));
			sprintf(lang,bak,mdl->rsize/mdl->totaltime/1024.0);
			strcat(str,lang);
			strcat(str,"\n");
		}
		sprintf(lang,GetSTR2(8,"%d retries."),mdl->retries);
		strcat(str,lang);
		strcat(str,"\n");
		dds2();
		SendMessage(ttip->hwnd,POPTIP_TXTUPDATE,(WPARAM)str,0);
	}
	else
	{
		sprintf(str,GetSTR2(159,"Error downloading %s\n%s"),mdl->lfn,mdl->ErrMsg);
		dds2();
		SendMessage(ttip->hwnd,POPTIP_TXTUPDATE,(WPARAM)str,0);
	}
}

void lastdl::AddItem()
{
	this->next=NULL;
	if (lastdlhead==NULL)
	{
		lastdlhead=this;
		this->prev=NULL;
	}
	else
	{
		lastdllast->next=this;
		this->prev=lastdllast;
	}
	lastdllast=this;
	HMENU h1,h2;
	h1=GetSubMenu(Hmenu,0);
	h2=GetSubMenu(h1,6);
	if (lastdlhead==this)
		DeleteMenu(h2,0,MF_BYPOSITION);
	unsigned short j=GetMenuItemCount(h2);
	if ((j>=gcfg.maxlastdl) && (lastdllast))
	{
		//lastdlhead->RMItem();
		delete lastdlhead;
		j--;
	}
	MENUITEMINFO mif;
	char str[1000];
	memset(&mif,0,sizeof(MENUITEMINFO));
	mif.cbSize=sizeof(MENUITEMINFO);
	mif.fMask=MIIM_TYPE | MIIM_ID;
	mif.fType=MFT_STRING;
	mif.fState=MFS_ENABLED;
	mif.wID=IDM_LASTDL+j;
	ConstURL(nfo,str);
	mif.dwTypeData=str;
	mif.cch=strlen(str);
	InsertMenuItem(h2,j,true,&mif);
	//DestroyMenu(h2);
	//DestroyMenu(h1);
	if (!LoadLDL) SaveLastDLs();
}

void lastdl::RMItem()
{
	if (lastdlhead==lastdllast)
	{
		lastdlhead=NULL;
		lastdllast=NULL;
		return;
	}
	if (this==lastdlhead)
	{
		this->next->prev=NULL;
		lastdlhead=this->next;
	}
	else
		if (this->next) this->next->prev=this->prev;
	
	if (this==lastdllast)
	{
		this->prev->next=NULL;
		lastdllast=this->prev;
	}
	else
		if (this->prev) this->prev->next=this->next;
	HMENU h1,h2;
	h1=GetSubMenu(Hmenu,0);
	h2=GetSubMenu(h1,6);
	DeleteMenu(h2,0,MF_BYPOSITION);
	int j,i;
	j=GetMenuItemCount(h2);
	MENUITEMINFO mif;
	memset(&mif,0,sizeof(MENUITEMINFO));
	mif.cbSize=sizeof(MENUITEMINFO);
	mif.fMask=MIIM_ID;
	for (i=0;i<j;i++)
	{
		mif.wID=IDM_LASTDL+i;
		SetMenuItemInfo(h2,i,true,&mif);
	}
	//DestroyMenu(h2);
	//DestroyMenu(h1);
	if (!LoadLDL) SaveLastDLs();
}
