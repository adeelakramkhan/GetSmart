
#include "GUI.h"

void CheckProt(HWND hdwnd,char *ports,int port)
{
	if ((atoi(ports)!=port) && (atoi(ports)==80))
	{
		SendDlgItemMessage(hdwnd,IDD_PROT1,BM_SETCHECK,
			(WPARAM) BST_UNCHECKED,0);
		SendDlgItemMessage(hdwnd,IDD_PROT2,BM_SETCHECK,
				(WPARAM) BST_CHECKED,0);
		SendDlgItemMessage(hdwnd,IDD_PROXY1,
				BM_SETCHECK,(WPARAM) BST_UNCHECKED,0);
		SendDlgItemMessage(hdwnd,IDD_PROXY2,
				BM_SETCHECK,(WPARAM) BST_UNCHECKED,0);
		SendDlgItemMessage(hdwnd,IDD_DIRECT,
					BM_SETCHECK,(WPARAM) BST_UNCHECKED,0);
		SendDlgItemMessage(hdwnd,IDD_SOCKS,
					BM_SETCHECK,(WPARAM) BST_UNCHECKED,0);
		if (cfg.Proxy.UseHTTP)
			SendDlgItemMessage(hdwnd,IDD_PROXY2,
				BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		else
			if (cfg.Proxy.socks)
				SendDlgItemMessage(hdwnd,IDD_SOCKS,
						BM_SETCHECK,(WPARAM) BST_CHECKED,0);
			else
				SendDlgItemMessage(hdwnd,IDD_DIRECT,
						BM_SETCHECK,(WPARAM) BST_CHECKED,0);
	}
	else
	if ((atoi(ports)!=port) && !stricmp(ports,"21"))
	{
		SendDlgItemMessage(hdwnd,IDD_PROT1,BM_SETCHECK,
							(WPARAM) BST_CHECKED,0);
		SendDlgItemMessage(hdwnd,IDD_PROT2,BM_SETCHECK,
							(WPARAM) BST_UNCHECKED,0);
		SendDlgItemMessage(hdwnd,IDD_PROXY1,
				BM_SETCHECK,(WPARAM) BST_UNCHECKED,0);		
		SendDlgItemMessage(hdwnd,IDD_PROXY2,
				BM_SETCHECK,(WPARAM) BST_UNCHECKED,0);
		SendDlgItemMessage(hdwnd,IDD_DIRECT,
					BM_SETCHECK,(WPARAM) BST_UNCHECKED,0);
		SendDlgItemMessage(hdwnd,IDD_SOCKS,
					BM_SETCHECK,(WPARAM) BST_UNCHECKED,0);
		if (cfg.Proxy.UseFTP)
			SendDlgItemMessage(hdwnd,IDD_PROXY1,
								BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		else
			if (cfg.Proxy.HTTP4FTP && cfg.Proxy.UseHTTP)
				SendDlgItemMessage(hdwnd,IDD_PROXY2,
								BM_SETCHECK,(WPARAM) BST_CHECKED,0);
			else
				if (cfg.Proxy.socks)
					SendDlgItemMessage(hdwnd,IDD_SOCKS,
							BM_SETCHECK,(WPARAM) BST_CHECKED,0);
				else
					SendDlgItemMessage(hdwnd,IDD_DIRECT,
							BM_SETCHECK,(WPARAM) BST_CHECKED,0);
	}
}

void UpdateURLBox(HWND hdwnd,lastdl* ldl)
{
	char str[1000];
		SendDlgItemMessage(hdwnd,IDD_PROT1,BM_SETCHECK,
			(WPARAM) BST_UNCHECKED,0);
		SendDlgItemMessage(hdwnd,IDD_PROT2,BM_SETCHECK,
				(WPARAM) BST_UNCHECKED,0);
		SendDlgItemMessage(hdwnd,IDD_PROXY1,
				BM_SETCHECK,(WPARAM) BST_UNCHECKED,0);
		SendDlgItemMessage(hdwnd,IDD_PROXY2,
				BM_SETCHECK,(WPARAM) BST_UNCHECKED,0);
		SendDlgItemMessage(hdwnd,IDD_DIRECT,
					BM_SETCHECK,(WPARAM) BST_UNCHECKED,0);
		SendDlgItemMessage(hdwnd,IDD_SOCKS,
					BM_SETCHECK,(WPARAM) BST_UNCHECKED,0);
		if (ldl->nfo->prot==1)
			SendDlgItemMessage(hdwnd,IDD_PROT1,
					BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		else
			SendDlgItemMessage(hdwnd,IDD_PROT2,
					BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		if (ldl->useproxy==1)
			SendDlgItemMessage(hdwnd,IDD_PROXY1,
					BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		else
			if (ldl->useproxy==2)
				SendDlgItemMessage(hdwnd,IDD_PROXY2,
					BM_SETCHECK,(WPARAM) BST_CHECKED,0);
			else
				if (ldl->useproxy==3)
					SendDlgItemMessage(hdwnd,IDD_SOCKS,
					BM_SETCHECK,(WPARAM) BST_CHECKED,0);
				else
					SendDlgItemMessage(hdwnd,IDD_DIRECT,
					BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		SendDlgItemMessage(hdwnd,IDD_PRIOR,CB_SETCURSEL,5-ldl->prior,0);
		if (ldl->type==2) SendDlgItemMessage(hdwnd,IDD_USECLIENT,
			BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		SetDlgItemText(hdwnd,IDD_HOST,ldl->nfo->host);
		SetDlgItemInt(hdwnd,IDD_PORT,ldl->nfo->port,0);
		sprintf(str,"%s%s",ldl->nfo->rdir,ldl->nfo->rfn);
		SetDlgItemText(hdwnd,IDD_DIR,str);
		SetDlgItemText(hdwnd,IDD_LOGIN,ldl->nfo->user);
		SetDlgItemText(hdwnd,IDD_PASS,ldl->nfo->pass);
		sprintf(str,"%s%s",ldl->ldir,ldl->lfn);
		SetDlgItemText(hdwnd,IDD_ELDIR,str);
		int i;
		if (ldl->uh && ldl->ur) i=0;
		else
			if (ldl->uh) i=1;
			else
				if (ldl->ur) i=2;
				else i=3;
		SendDlgItemMessage(hdwnd,IDD_ONBUSY,CB_SETCURSEL,i,0);
		SetDlgItemInt(hdwnd,IDD_TO,ldl->to,false);
}

BOOL CALLBACK URLFunc(HWND hdwnd, UINT message,
                         WPARAM wParam, LPARAM lParam)
{
	static char user[1000],pass[1000],addr[1000],sdir[1000],
		sfn[1000],ldir[1000],lfn[1000],ports[10];
	static int prot,port;
	static unsigned char prior=3;
	static time_t to=cfg.resumeto;
	char str[1000],*tmp;
	static bool ch,uh,ur,autodir;
	int i;
	dlnfo *dln;
	switch(message)
	{
    case WM_HELP:
		WinHelp(hdwnd, HelpFile, HELP_CONTEXT ,IDH_ENTERURL);
		return 1;
	case WM_INITDIALOG:
		prot=1;
		SendDlgItemMessage(hdwnd,IDD_PROT1,BM_SETCHECK,
			(WPARAM) BST_CHECKED,0);
		if (cfg.Proxy.UseFTP)
			SendDlgItemMessage(hdwnd,IDD_PROXY1,
								BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		else
			if (cfg.Proxy.HTTP4FTP && cfg.Proxy.UseHTTP)
				SendDlgItemMessage(hdwnd,IDD_PROXY2,
								BM_SETCHECK,(WPARAM) BST_CHECKED,0);
			else
				if (cfg.Proxy.socks)
					SendDlgItemMessage(hdwnd,IDD_SOCKS,
							BM_SETCHECK,(WPARAM) BST_CHECKED,0);
				else
					SendDlgItemMessage(hdwnd,IDD_DIRECT,
							BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		CreateUpDownControl(WS_CHILD|WS_BORDER|WS_VISIBLE|
			UDS_SETBUDDYINT|UDS_ALIGNRIGHT,
			10,10,50,50,hdwnd,IDD_SPIN1,hinst,
			GetDlgItem(hdwnd,IDD_SPLITI),cfg.maxsplit,2,cfg.defsplit);
		CreateUpDownControl(WS_CHILD|WS_BORDER|WS_VISIBLE|
			UDS_SETBUDDYINT|UDS_ALIGNRIGHT,
			10,10,50,50,hdwnd,IDD_SPIN2,hinst,
			GetDlgItem(hdwnd,IDD_TO),3000,2,cfg.resumeto);
		strcpy(str,GetSTR2(162,"5 - Highest"));
		SendDlgItemMessage(hdwnd,IDD_PRIOR,CB_ADDSTRING,0,(LPARAM)str);
		strcpy(str,GetSTR2(163,"4 - High"));
		SendDlgItemMessage(hdwnd,IDD_PRIOR,CB_ADDSTRING,0,(LPARAM)str);
		strcpy(str,GetSTR2(164,"3 - Normal"));
		SendDlgItemMessage(hdwnd,IDD_PRIOR,CB_ADDSTRING,0,(LPARAM)str);
		strcpy(str,GetSTR2(165,"2 - Low"));
		SendDlgItemMessage(hdwnd,IDD_PRIOR,CB_ADDSTRING,0,(LPARAM)str);
		strcpy(str,GetSTR2(166,"1 - Lowest"));
		SendDlgItemMessage(hdwnd,IDD_PRIOR,CB_ADDSTRING,0,(LPARAM)str);
		strcpy(str,GetSTR2(167,"0 - Don't download"));
		SendDlgItemMessage(hdwnd,IDD_PRIOR,CB_ADDSTRING,0,(LPARAM)str);
		SendDlgItemMessage(hdwnd,IDD_PRIOR,CB_SETCURSEL,2,0);
		strcpy(str,GetSTR2(168,"Use hammer with fallback"));
		SendDlgItemMessage(hdwnd,IDD_ONBUSY,CB_ADDSTRING,0,(LPARAM)str);
		strcpy(str,GetSTR2(169,"Use hammer only"));
		SendDlgItemMessage(hdwnd,IDD_ONBUSY,CB_ADDSTRING,0,(LPARAM)str);
		strcpy(str,GetSTR2(170,"Use normal retry"));
		SendDlgItemMessage(hdwnd,IDD_ONBUSY,CB_ADDSTRING,0,(LPARAM)str);
		strcpy(str,GetSTR2(171,"Don't retry on busy"));
		SendDlgItemMessage(hdwnd,IDD_ONBUSY,CB_ADDSTRING,0,(LPARAM)str);
		dds2();
		uh=cfg.usehammer;
		ur=cfg.useretry;
		if (uh)
			if (cfg.hammerfallback) ur=true;
			else ur=false;
		if (uh && ur) i=0;
		else
			if (uh) i=1;
			else
				if (ur) i=2;
				else i=3;
		SendDlgItemMessage(hdwnd,IDD_ONBUSY,CB_SETCURSEL,i,0);
		ch=false;
		strcpy(user,"anonymous");
		strcpy(pass,cfg.Email);
		GetExtDir(ldir,"");
		strcpy(lfn,"");
		strcpy(ports,"21");
		port=21;
		ch=true;
		SetDlgItemText(hdwnd,IDD_PORT,ports);
		ch=true;
		SetDlgItemText(hdwnd,IDD_LOGIN,user);
		ch=true;
		SetDlgItemText(hdwnd,IDD_PASS,pass);
		sprintf(str,"%s%s",ldir,lfn);
		SetDlgItemText(hdwnd,IDD_ELDIR,str);
		SetFocus(GetDlgItem(hdwnd,IDD_URL));
		autodir=true;
		if (lParam)
			UpdateURLBox(hdwnd,(lastdl*)lParam);
		return 1;
	case WM_ACTIVATE:
		if	(LOWORD(wParam) == WA_INACTIVE)
			hgdlg=NULL;
		else
			hgdlg=hdwnd;
		return 1;	
	case WM_COMMAND:
		if (HIWORD(wParam)==EN_CHANGE)
			if ((ch) || (LOWORD(wParam)==IDD_SPLIT)
				 || (LOWORD(wParam)==IDD_SPLITI))
			{
				ch=false;
				return 1;
			}
			else
			{
				if (LOWORD(wParam)==IDD_ELDIR)
				{
					autodir=false;
					GetDlgItemText(hdwnd,IDD_ELDIR,ldir,1000);
					tmp = strrchr(ldir, '\\' );
					if (!tmp)
					{
						strcpy(lfn,ldir);
						memset(ldir,0,sizeof(ldir));
					}
					else
					{
						if (tmp) tmp++;
						if (tmp) 
						{
							strcpy(lfn,tmp);
							memset(tmp,0,strlen(lfn)+1);
						}
						else memset(lfn,0,1000);
					}
				}
				else
				if (LOWORD(wParam)==IDD_URL)
				{
					char str2[1000];
					memset(str,0,sizeof(str));
					GetDlgItemText(hdwnd,IDD_URL,str,999);
					strcpy(str2,str);
					cs(str2);
					if (strcmp(str2,str))
					{
						strcpy(str,str2);
						SetDlgItemText(hdwnd,IDD_URL,str2);
						PostMessage(GetDlgItem(hdwnd,IDD_URL),
							EM_SETSEL,(WPARAM) (int) strlen(str2),
							(LPARAM) (int) strlen(str2));
					}
					dln=ConvertURL(str);
					sprintf(ports,"%ld",dln->port);
					CheckProt(hdwnd,ports,port);
					prot=dln->prot;
					strcpy(addr,dln->host);
					port=dln->port;
					strcpy(user,dln->user);
					strcpy(pass,dln->pass);
					strcpy(sdir,dln->rdir);
					strcpy(sfn,dln->rfn);
					delete dln;
					if (strcmp(str2,str))
					{
						ch=true;
						SetDlgItemText(hdwnd,IDD_URL,str2);
						PostMessage(GetDlgItem(hdwnd,IDD_URL),
							EM_SETSEL,(WPARAM) (int) strlen(str2)
							,(LPARAM) (int) strlen(str2));
					}
					sprintf(ports,"%ld",port);
					ch=true;
					SetDlgItemText(hdwnd,IDD_HOST,addr);
					ch=true;
					SetDlgItemText(hdwnd,IDD_PORT,ports);
					ch=true;
					SetDlgItemText(hdwnd,IDD_LOGIN,user);
					ch=true;
					SetDlgItemText(hdwnd,IDD_PASS,pass);
					if (strcmp(lfn,sfn))
					{
						strcpy(lfn,sfn);
						ch=true;
						if (autodir) GetExtDir(ldir,lfn);
						sprintf(str,"%s%s",ldir,lfn);
						SetDlgItemText(hdwnd,IDD_ELDIR,str);
					}
					ch=true;
					sprintf(str,"%s%s",sdir,sfn);
					SetDlgItemText(hdwnd,IDD_DIR,str);
				}
				else
				{
					GetDlgItemText(hdwnd,IDD_HOST,addr,1000);
					GetDlgItemText(hdwnd,IDD_PORT,ports,20);
					GetDlgItemText(hdwnd,IDD_LOGIN,str,1000);
					CheckProt(hdwnd,ports,port);
					if (stricmp(str,user))
					{
						if (!strcmp(user,pass) || !strcmp(pass,cfg.Email))
						{
							strcpy(pass,str);
							ch=true;
							SetDlgItemText(hdwnd,IDD_PASS,pass);
						}
						strcpy(user,str);
					}
					GetDlgItemText(hdwnd,IDD_PASS,pass,1000);
					GetDlgItemText(hdwnd,IDD_DIR,sdir,1000);
					port=atoi(ports);
					tmp = strrchr(sdir, '/' );
					if (tmp) tmp++;
					if (tmp) 
					{
						strcpy(sfn,tmp);
						memset(tmp,0,strlen(sfn)+1);
					}
					else memset(sfn,0,1000);
					strcpy(lfn,sfn);
					if (autodir) GetExtDir(ldir,lfn);
					sprintf(str,"%s%s",ldir,lfn);
					ch=true;
					SetDlgItemText(hdwnd,IDD_ELDIR,str);
					memset(str,0,sizeof(str));
					if (!strlen(addr)) return 1;
					if (strcmp(user,"anonymous") ||
						(strcmp(pass,cfg.Email)))
					{
						//if ((atoi(ports)==21) || (atoi(ports)==80))
						//	sprintf(str,"%s:%s@%s%s%s",user,pass,addr,
						//	sdir,sfn);
						//else
						if (SendDlgItemMessage(hdwnd,IDD_PROT1,
									BM_GETCHECK,0,0)==BST_CHECKED)
							sprintf(str,"ftp://%s:%s@%s:%s%s%s",user,pass,
												addr,ports,sdir,sfn);
						else
							sprintf(str,"http://%s:%s@%s:%s%s%s",user,pass,
												addr,ports,sdir,sfn);
					}
					else
						//if ((atoi(ports)==21) || (atoi(ports)==80))
						//	sprintf(str,"%s%s%s",addr,sdir,sfn);
						//else 
						if (SendDlgItemMessage(hdwnd,IDD_PROT1,
									BM_GETCHECK,0,0)==BST_CHECKED)
							sprintf(str,"ftp://%s:%s%s%s",addr,ports,sdir,sfn);
						else
							sprintf(str,"http://%s:%s%s%s",addr,ports,sdir,sfn);
					ch=true;
					dln=ConvertURL(str);
					prot=dln->prot;
					strcpy(addr,dln->host);
					port=dln->port;
					strcpy(user,dln->user);
					strcpy(pass,dln->pass);
					strcpy(sdir,dln->rdir);
					strcpy(sfn,dln->rfn);
					delete dln;
					SetDlgItemText(hdwnd,IDD_URL,str);
				}
				return 1;
			}

			switch(LOWORD(wParam))
			{
			case IDD_BROWSE:
				OPENFILENAME ofn;
				char dh[MAX_PATH], *tmp;
				sprintf(dh,"%s",sfn);
				memset(&ofn,0,sizeof(ofn));
				ofn.lStructSize=sizeof(ofn);
				ofn.hwndOwner=hdwnd;
				ofn.hInstance=hinst;
				ofn.lpstrFile=dh;
				ofn.nMaxFile=MAX_PATH;
				ofn.lpstrInitialDir=ldir;
				ofn.Flags=OFN_PATHMUSTEXIST;
				tmp=strchr(lfn,'.');
				if (tmp) tmp++;
				ofn.lpstrDefExt=tmp;
				if (GetSaveFileName(&ofn))
				{
					memset(ldir,0,sizeof(ldir));
			 		strncpy(ldir,ofn.lpstrFile,ofn.nFileOffset);
					strcpy(lfn,&ofn.lpstrFile[ofn.nFileOffset]);
					ch=true;
					SetDlgItemText(hdwnd,IDD_ELDIR,ofn.lpstrFile);
				}
				return 1;
				case IDCANCEL:
					EndDialog(hdwnd, 0);
				return 1;
				case IDOK:
					bool wc;
					wc=false;
					int proxy;
					proxy=0;
					memset(str,0,sizeof(str));
					if (SendDlgItemMessage(hdwnd,IDD_SPLIT,
						BM_GETCHECK,0,0)==BST_CHECKED)
						GetDlgItemText(hdwnd,IDD_SPLITI,str,1000);
					if (SendDlgItemMessage(hdwnd,IDD_PROXY1,
						BM_GETCHECK,0,0)==BST_CHECKED) proxy=1;
					if (SendDlgItemMessage(hdwnd,IDD_PROXY2,
						BM_GETCHECK,0,0)==BST_CHECKED) proxy=2;
					if (SendDlgItemMessage(hdwnd,IDD_SOCKS,
						BM_GETCHECK,0,0)==BST_CHECKED) proxy=3;
					if (SendDlgItemMessage(hdwnd,IDD_DIRECT,
						BM_GETCHECK,0,0)==BST_CHECKED) proxy=0;
					if (!strlen(lfn)) strcpy(lfn,sfn);
					if (SendDlgItemMessage(hdwnd,IDD_PROT1,
						BM_GETCHECK,0,0)==BST_CHECKED) prot=1;
					else prot=2;
					prior=5-(char)SendDlgItemMessage(hdwnd,IDD_PRIOR,CB_GETCURSEL,0,0);
					to=SendDlgItemMessage(hdwnd,IDD_SPIN2,UDM_GETPOS,0,0);
					if (SendDlgItemMessage(hdwnd,IDD_USECLIENT,
						BM_GETCHECK,0,0)==BST_CHECKED) wc=true;
					else wc=false;
					i=SendDlgItemMessage(hdwnd,IDD_ONBUSY,CB_GETCURSEL,0,0);
					dln=new dlnfo(prot,addr,port,user,pass,sdir,sfn);
					if (i==0)
					{
						uh=true;
						ur=true;
					}
					else
						if (i==1)
						{
							uh=true;
							ur=false;
						}
						else
							if (i==2)
							{
								uh=false;
								ur=true;
							}
							else
							{
								uh=false;
								ur=false;
							}
					if (SendURL(dln,ldir,lfn,atoi(str),wc,proxy,0,to,
						prior,uh,ur,cfg.checkint,cfg.checksmallint))
						EndDialog(hdwnd, 1);
				return 1;
			}
	  }
  
  return 0;
}

BOOL CALLBACK ExistSplitFunc(HWND hdwnd, UINT message,
							WPARAM wParam, LPARAM lParam)
{
	char str[1024],st0[1024];
	int j;
	lcl *lc=(lcl *) GetWindowLong(hdwnd,GWL_USERDATA);
	switch(message)
	{
	case WM_INITDIALOG:
		lc=(lcl *)lParam;
		sprintf(st0,"%s%s",lc->ldir,lc->lfn);
		SetWindowText(hdwnd,st0);
		SetWindowLong(hdwnd,GWL_USERDATA,(LONG) lc);
		return 1;
	case WM_ACTIVATE:
		if	(LOWORD(wParam) == WA_INACTIVE)
			hgdlg=NULL;
		else
			hgdlg=hdwnd;
		return 1;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDCANCEL:
			EndDialog(hdwnd, 0);
			return 1;
		case IDD_RESUMESPLIT:
			EndDialog(hdwnd, 1);
			return 1;
		case IDD_RESUME:
			WIN32_FIND_DATA ff;
			HANDLE hf;
			if (MsgBox(
				GetSTR2(172,"This will delete some of the parts\n that were \
already downloaded!"),lc->lfn,MB_OKCANCEL|MB_ICONEXCLAMATION)==IDOK)
			{
				dds2();
				for (j=0; j<cfg.maxsplit;j++)
				{
					sprintf(str,"%s%s (%ld)*",lc->ldir,lc->lfn,j);
					if ((hf=FindFirstFile(str,&ff))!=INVALID_HANDLE_VALUE)
					do
					{
						sprintf(str,"%s%s",lc->ldir,ff.cFileName);
						_unlink(str);
					} while (FindNextFile(hf,&ff));
				}
				EndDialog(hdwnd, 1);
			}
			return 1;
		case IDD_OVERWRITE:
			for (j=0; j<cfg.maxsplit;j++)
			{
				sprintf(str,"%s%s (%ld)*",lc->ldir,lc->lfn,j);
				if ((hf=FindFirstFile(str,&ff))!=INVALID_HANDLE_VALUE)
				do
				{
					sprintf(str,"%s%s",lc->ldir,ff.cFileName);
					_unlink(str);
				} while (FindNextFile(hf,&ff));
			}
			strcpy(str,lc->ldir);
			strcat(str,lc->lfn);
			if (strlen(cfg.stamp))
				strcat(str,cfg.stamp);
			_unlink(str);
			EndDialog(hdwnd, 1);
			return 1;
		case IDD_RENAME:
			if (MsgBox(GetSTR2(173,"Since this download used the split feature\nthis option will delete some of the parts\n that were already downloaded!"),lc->lfn,MB_OKCANCEL|MB_ICONEXCLAMATION)==IDOK)
			{
				dds2();
				for (j=0; j<cfg.maxsplit;j++)
				{
					sprintf(str,"%s%s (%ld)*",lc->ldir,lc->lfn,j);
					if ((hf=FindFirstFile(str,&ff))!=INVALID_HANDLE_VALUE)
					do
					{
						sprintf(str,"%s%s",lc->ldir,ff.cFileName);
						_unlink(str);
					} while (FindNextFile(hf,&ff));
				}
				strcpy(str,lc->ldir);
				strcat(str,lc->lfn);
				//DelFile(str);
				EndDialog(hdwnd, 1);
			}
			return 1;
		}
	}
	return 0;
}

BOOL CALLBACK ExistFunc(HWND hdwnd, UINT message,
							WPARAM wParam, LPARAM lParam)
{
	char str[1000],st0[1000];
	lcl *lc=(lcl *)GetWindowLong(hdwnd,GWL_USERDATA);
	switch(message)
	{
	case WM_INITDIALOG:
		lc=(lcl *)lParam;
		sprintf(st0,"%s%s",lc->ldir,lc->lfn);
		SetWindowText(hdwnd,st0);
		SetWindowLong(hdwnd,GWL_USERDATA,(LONG) lc);
		return 1;
	case WM_ACTIVATE:
		if	(LOWORD(wParam) == WA_INACTIVE)
			hgdlg=NULL;
		else
			hgdlg=hdwnd;
		return 1;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDCANCEL:
			EndDialog(hdwnd, 0);
			return 1;
		case IDD_RESUME:
			EndDialog(hdwnd, 1);
			return 1;
		case IDD_OVERWRITE:
			strcpy(str,lc->ldir);
			strcat(str,lc->lfn);
			_unlink(str);
			if (strlen(cfg.stamp))
				strcat(str,cfg.stamp);
			_unlink(str);
			EndDialog(hdwnd, 1);
			return 1;
		case IDD_RENAME:
			strcpy(str,lc->ldir);
			strcat(str,lc->lfn);
			//DelFile(str);
			EndDialog(hdwnd, 1);
			return 1;
		}
	}
	return 0;
}

BOOL CALLBACK PropFunc(HWND hdwnd, UINT message,
                         WPARAM wParam, LPARAM lParam)
{
	char str[1024],str1[1024],*tmp;
	int j,i;
	short t;
	bool uh,ur;
	maindl *mdl=(maindl *)GetWindowLong(hdwnd,GWL_USERDATA);
	PROPSHEETPAGE *psp;
	switch(message)
	{
	case WM_INITDIALOG:
		if (prop[8]) prop[7]=true;
		psp=(PROPSHEETPAGE *)lParam;
		mdl=(maindl *)psp->lParam;
		SetWindowLong(hdwnd,GWL_USERDATA,(LONG)mdl);
		if (mdl->splitdex || mdl->dosplit)
		{
			SendDlgItemMessage(hdwnd,IDD_SPLIT,
							BM_SETCHECK,(WPARAM) BST_CHECKED,0);			
			if (mdl->dosplit>mdl->splitdex+1) t=mdl->dosplit;
			else t=mdl->spliton;
			CreateUpDownControl(WS_CHILD|WS_BORDER|WS_VISIBLE|
				UDS_SETBUDDYINT|UDS_ALIGNRIGHT,
				10,10,50,50,hdwnd,IDD_SPIN1,hinst,
				GetDlgItem(hdwnd,IDD_SPLITI),cfg.maxsplit,2,t);
		}
		else
			CreateUpDownControl(WS_CHILD|WS_BORDER|WS_VISIBLE|
				UDS_SETBUDDYINT|UDS_ALIGNRIGHT,
				10,10,50,50,hdwnd,IDD_SPIN1,hinst,
				GetDlgItem(hdwnd,IDD_SPLITI),cfg.maxsplit,2,cfg.defsplit);
		CreateUpDownControl(WS_CHILD|WS_BORDER|WS_VISIBLE|
			UDS_SETBUDDYINT|UDS_ALIGNRIGHT,
			10,10,50,50,hdwnd,IDD_SPIN2,hinst,
			GetDlgItem(hdwnd,IDD_TO),3000,2,mdl->maxresumetimeout);
		if (mdl->type==2) SendDlgItemMessage(hdwnd,IDD_USECLIENT,
			BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		if (mdl->mirrorhead->nfo->prot==1) SendDlgItemMessage(hdwnd,IDD_PROT1,
				BM_SETCHECK,(WPARAM) BST_CHECKED,0);
			else
				if (mdl->mirrorhead->nfo->prot==2)
					SendDlgItemMessage(hdwnd,IDD_PROT2,BM_SETCHECK,
					(WPARAM) BST_CHECKED,0);
		if (mdl->useproxy==1)
			SendDlgItemMessage(hdwnd,IDD_PROXY1,
				BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		else
			if (mdl->useproxy==2)
				SendDlgItemMessage(hdwnd,IDD_PROXY2,
					BM_SETCHECK,(WPARAM) BST_CHECKED,0);
			else
				if (mdl->useproxy==3)
					SendDlgItemMessage(hdwnd,IDD_SOCKS,
						BM_SETCHECK,(WPARAM) BST_CHECKED,0);
				else
					SendDlgItemMessage(hdwnd,IDD_DIRECT,
						BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		SetDlgItemText(hdwnd,IDD_HOST,mdl->mirrorhead->nfo->host);
		SetDlgItemInt(hdwnd,IDD_PORT,mdl->mirrorhead->nfo->port,0);
		SetDlgItemText(hdwnd,IDD_DIR,mdl->mirrorhead->nfo->rdir);
		SetDlgItemText(hdwnd,IDD_FILE,mdl->mirrorhead->nfo->rfn);
		SetDlgItemText(hdwnd,IDD_LOGIN,mdl->mirrorhead->nfo->user);
		SetDlgItemText(hdwnd,IDD_PASS,mdl->mirrorhead->nfo->pass);
		sprintf(str,"%s%s",mdl->ldir,mdl->lfn);
		SetDlgItemText(hdwnd,IDD_ELDIR,str);
/*		if (prop[0]) 
		{
			EnableWindow(GetDlgItem(hdwnd,IDD_PROT1),false);
			EnableWindow(GetDlgItem(hdwnd,IDD_PROT2),false);
		}*/
		if (prop[1]) SendMessage(GetDlgItem(hdwnd,IDD_HOST),
			EM_SETREADONLY, (WPARAM) 1,0);
		if (prop[2]) SendMessage(GetDlgItem(hdwnd,IDD_PORT),
			EM_SETREADONLY, (WPARAM) 1,0);
		if (prop[3]) SendMessage(GetDlgItem(hdwnd,IDD_LOGIN),
			EM_SETREADONLY, (WPARAM) 1,0);
		if (prop[4]) SendMessage(GetDlgItem(hdwnd,IDD_PASS),
			EM_SETREADONLY, (WPARAM) 1,0);
		if (prop[5]) SendMessage(GetDlgItem(hdwnd,IDD_DIR),
			EM_SETREADONLY, (WPARAM) 1,0);
		if (prop[6]) SendMessage(GetDlgItem(hdwnd,IDD_FILE),
			EM_SETREADONLY, (WPARAM) 1,0);
		if (prop[8])
		{
			SendMessage(GetDlgItem(hdwnd,IDD_ELDIR),
							EM_SETREADONLY, (WPARAM) 1,0);
			ShowWindow(GetDlgItem(hdwnd,IDD_NOFN),SW_SHOW);
			ShowWindow(GetDlgItem(hdwnd,IDD_CSPLIT),SW_SHOW);
			ShowWindow(GetDlgItem(hdwnd,IDD_CPROT),SW_SHOW);
			ShowWindow(GetDlgItem(hdwnd,IDD_CCON),SW_SHOW);
			ShowWindow(GetDlgItem(hdwnd,IDD_CPRIOR),SW_SHOW);
			ShowWindow(GetDlgItem(hdwnd,IDD_CTO),SW_SHOW);
			ShowWindow(GetDlgItem(hdwnd,IDD_CONBUSY),SW_SHOW);
		}
		strcpy(str,GetSTR2(162,"5 - Highest"));
		SendDlgItemMessage(hdwnd,IDD_PRIOR,CB_ADDSTRING,0,(LPARAM)str);
		strcpy(str,GetSTR2(163,"4 - High"));
		SendDlgItemMessage(hdwnd,IDD_PRIOR,CB_ADDSTRING,0,(LPARAM)str);
		strcpy(str,GetSTR2(164,"3 - Normal"));
		SendDlgItemMessage(hdwnd,IDD_PRIOR,CB_ADDSTRING,0,(LPARAM)str);
		strcpy(str,GetSTR2(165,"2 - Low"));
		SendDlgItemMessage(hdwnd,IDD_PRIOR,CB_ADDSTRING,0,(LPARAM)str);
		strcpy(str,GetSTR2(166,"1 - Lowest"));
		SendDlgItemMessage(hdwnd,IDD_PRIOR,CB_ADDSTRING,0,(LPARAM)str);
		strcpy(str,GetSTR2(167,"0 - Don't download"));
		SendDlgItemMessage(hdwnd,IDD_PRIOR,CB_ADDSTRING,0,(LPARAM)str);
		SendDlgItemMessage(hdwnd,IDD_PRIOR,CB_SETCURSEL,5-mdl->prior,0);
		strcpy(str,GetSTR2(168,"Use hammer with fallback"));
		SendDlgItemMessage(hdwnd,IDD_ONBUSY,CB_ADDSTRING,0,(LPARAM)str);
		strcpy(str,GetSTR2(169,"Use hammer only"));
		SendDlgItemMessage(hdwnd,IDD_ONBUSY,CB_ADDSTRING,0,(LPARAM)str);
		strcpy(str,GetSTR2(170,"Use normal retry"));
		SendDlgItemMessage(hdwnd,IDD_ONBUSY,CB_ADDSTRING,0,(LPARAM)str);
		strcpy(str,GetSTR2(171,"Don't retry on busy"));
		SendDlgItemMessage(hdwnd,IDD_ONBUSY,CB_ADDSTRING,0,(LPARAM)str);
		dds2();
		uh=mdl->usehammer;
		ur=mdl->useretry;
		if (uh && ur) i=0;
		else
			if (uh) i=1;
			else
				if (ur) i=2;
				else i=3;
		SendDlgItemMessage(hdwnd,IDD_ONBUSY,CB_SETCURSEL,i,0);
		return 1;
	case WM_ACTIVATE:
		if	(LOWORD(wParam) == WA_INACTIVE)
			hgdlg=NULL;
		else
			hgdlg=hdwnd;
		return 1;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDD_BROWSE:
			if (!prop[8])
			{
				OPENFILENAME ofn;
				char dh[MAX_PATH], *tmp;
				sprintf(dh,"%s",mdl->mirrorhead->nfo->rfn);
				memset(&ofn,0,sizeof(ofn));
				ofn.lStructSize=sizeof(ofn);
				ofn.hwndOwner=hdwnd;
				ofn.hInstance=hinst;
				ofn.lpstrFile=dh;
				ofn.nMaxFile=MAX_PATH;
				ofn.lpstrInitialDir=mdl->ldir;
				ofn.Flags=OFN_PATHMUSTEXIST;
				tmp=strchr(mdl->lfn,'.');
				if (tmp) tmp++;
				ofn.lpstrDefExt=tmp;
				if (GetSaveFileName(&ofn))
					SetDlgItemText(hdwnd,IDD_ELDIR,ofn.lpstrFile);
			}
			else
			{
				strcpy(str,mdl->ldir);
				BROWSEINFO bi;
				LPITEMIDLIST id;
				bi.hwndOwner=hdwnd;
				bi.pidlRoot=0;
				bi.pszDisplayName=str;
				char stmp[1024];
				strcpy(stmp,GetSTR2(127,"Choose a directory"));
				bi.lpszTitle=stmp;
				bi.ulFlags=BIF_RETURNONLYFSDIRS;
				bi.lpfn=0;
				if (id=SHBrowseForFolder(&bi))
				{
					prop[7]=false;
					SHGetPathFromIDList(id,str);
					strcat(str,"\\");
					strcat(str,mdl->lfn);
					SetDlgItemText(hdwnd,IDD_ELDIR,str);
				}
				dds2();
			}
			return 1;
		}
		return 0;
	case WM_NOTIFY:
		switch (((NMHDR FAR *) lParam)->code)
		{
		case PSN_KILLACTIVE:
			GetDlgItemText(hdwnd,IDD_FILE,str,1000);
			GetDlgItemText(hdwnd,IDD_ELDIR,str1,1000);
			if (strlen(str)==0)
			{
				SetDlgItemText(hdwnd,IDD_FILE,"*.*");
			}
			GetDlgItemText(hdwnd,IDD_DIR,str,1000);
			if ((strlen(str)>0) && (str[strlen(str)-1]!='/'))
			{
				strcat(str,"/");
				SetDlgItemText(hdwnd,IDD_DIR,str);
			}
			t=(short)SendDlgItemMessage(hdwnd,IDD_SPIN1,UDM_GETPOS,0,0);
			if ((t>cfg.maxsplit) || (t<1))
			{
				MsgBox(GetSTR2(174,"The split number you have chosen is invalid."),0,MB_OK);
				dds2();
				SetWindowLong(hdwnd,DWL_MSGRESULT,true);
			}
			else SetWindowLong(hdwnd,DWL_MSGRESULT,false);
			return 1;
		case PSN_APPLY:
			j=ListView_GetNextItem(hwndLV,-1,LVNI_ALL|LVNI_SELECTED);
			while (j!=-1)
			{
				STATUSITEM *pitem = (STATUSITEM *) GetLVlParam(hwndLV,j);
				mdl=pitem->mdl;
/*				if (!prop[0])
					if (SendDlgItemMessage(hdwnd,IDD_PROT3,
								BM_GETCHECK,0,0)==BST_CHECKED) 
					{
						pitem->m->wildcards=true;
						pitem->m->prot=1;
					}
					else
						if (SendDlgItemMessage(hdwnd,IDD_PROT1,
							BM_GETCHECK,0,0)==BST_CHECKED)
							pitem->m->prot=1;
						else pitem->m->prot=2;*/
				if (!prop[1])
				{
					GetDlgItemText(hdwnd,IDD_HOST,str,sizeof(str));
					pitem->mdl->mirrorhead->nfo->host=ReDupString(pitem->mdl->mirrorhead->nfo->host,str);
				}
				if (!prop[2])
					pitem->mdl->mirrorhead->nfo->port=GetDlgItemInt(hdwnd,IDD_PORT,0,0);
				if (!prop[3])
				{
					GetDlgItemText(hdwnd,IDD_LOGIN,str,sizeof(str));
					pitem->mdl->mirrorhead->nfo->user=ReDupString(pitem->mdl->mirrorhead->nfo->user,str);
				}
				if (!prop[4])
				{
					GetDlgItemText(hdwnd,IDD_PASS,str,sizeof(str));
					pitem->mdl->mirrorhead->nfo->pass=ReDupString(pitem->mdl->mirrorhead->nfo->pass,str);
				}
				if (!prop[5])
				{
					GetDlgItemText(hdwnd,IDD_DIR,str,sizeof(str));				
					pitem->mdl->mirrorhead->nfo->rdir=ReDupString(pitem->mdl->mirrorhead->nfo->rdir,str);
				}
				if (!prop[6])
				{
					GetDlgItemText(hdwnd,IDD_FILE,str,sizeof(str));
					pitem->mdl->mirrorhead->nfo->rfn=ReDupString(pitem->mdl->mirrorhead->nfo->rfn,str);
				}
				GetDlgItemText(hdwnd,IDD_ELDIR,str,sizeof(str));
				tmp = strrchr(str, '\\' );
				if (!tmp)
				{
					if (!prop[8])
						pitem->mdl->lfn=ReDupString(pitem->mdl->lfn,str);
					if (!prop[7]) 
						pitem->mdl->ldir=ReDupString(pitem->mdl->ldir,"");
				}
				else
				{
					if (tmp) tmp++;
					if (tmp) 
					{
						if (!prop[8])
							pitem->mdl->lfn=ReDupString(pitem->mdl->lfn,tmp);
						memset(tmp,0,strlen(tmp)+1);
						if (!prop[7])
							pitem->mdl->ldir=ReDupString(pitem->mdl->ldir,str);
					}
					else 
						if (!prop[8])
							pitem->mdl->lfn=ReDupString(pitem->mdl->lfn,pitem->mdl->mirrorhead->nfo->rfn);
				}
				if (!prop[8])
				{
					UpdateList(pitem->mdl);
				}
				if ((SendDlgItemMessage(hdwnd,IDD_CSPLIT,BM_GETCHECK,0,0)==BST_CHECKED) || !prop[8])
					if (SendDlgItemMessage(hdwnd,IDD_SPLIT,BM_GETCHECK,0,0)==BST_CHECKED)
					{
						t=(short)SendDlgItemMessage(hdwnd,IDD_SPIN1,UDM_GETPOS,0,0);
						if (t<=mdl->splitdex+1) mdl->dosplit=t;
						else mdl->dosplit=t;
					}
				if ((SendDlgItemMessage(hdwnd,IDD_CPROT,BM_GETCHECK,0,0)==BST_CHECKED) || !prop[8])
					if (SendDlgItemMessage(hdwnd,IDD_PROT1,
						BM_GETCHECK,0,0)==BST_CHECKED)
						mdl->mirrorhead->nfo->prot=1;
					else mdl->mirrorhead->nfo->prot=2;
				if ((SendDlgItemMessage(hdwnd,IDD_CCON,BM_GETCHECK,0,0)==BST_CHECKED) || !prop[8])
					if (SendDlgItemMessage(hdwnd,IDD_PROXY1,
						BM_GETCHECK,0,0)==BST_CHECKED)
						mdl->useproxy=1;
					else
						if (SendDlgItemMessage(hdwnd,IDD_PROXY2,
							BM_GETCHECK,0,0)==BST_CHECKED)
							mdl->useproxy=2;
						else
							if (SendDlgItemMessage(hdwnd,IDD_SOCKS,
								BM_GETCHECK,0,0)==BST_CHECKED)
								mdl->useproxy=3;
							else mdl->useproxy=0;
				if ((SendDlgItemMessage(hdwnd,IDD_CPRIOR,BM_GETCHECK,0,0)==BST_CHECKED) || !prop[8])
					mdl->prior=5-(char)SendDlgItemMessage(hdwnd,
										IDD_PRIOR,CB_GETCURSEL,0,0);
				if ((SendDlgItemMessage(hdwnd,IDD_CTO,BM_GETCHECK,0,0)==BST_CHECKED) || !prop[8])
					mdl->maxresumetimeout=SendDlgItemMessage(hdwnd,IDD_SPIN2,UDM_GETPOS,0,0);
				if ((SendDlgItemMessage(hdwnd,IDD_CONBUSY,BM_GETCHECK,0,0)==BST_CHECKED) || !prop[8])
				{
					i=SendDlgItemMessage(hdwnd,IDD_ONBUSY,CB_GETCURSEL,0,0);
					if (i==0)
					{
						uh=true;
						ur=true;
					}
					else
						if (i==1)
						{
							uh=true;
							ur=false;
						}
						else
							if (i==2)
							{
								uh=false;
								ur=true;
							}
							else
							{
								uh=false;
								ur=false;
							}
					mdl->usehammer=uh;
					mdl->useretry=ur;
				}
				UpdateMDL(mdl);
				j=ListView_GetNextItem(hwndLV,j,
					LVNI_ALL|LVNI_SELECTED);
			}
			SaveURLs();
			return 1;
		}
	}
	return 0;
}

UINT APIENTRY OFNHookProc(HWND hdlg,UINT uiMsg,WPARAM wParam,
						  LPARAM lParam)
{
	switch(uiMsg)
	{
	case WM_INITDIALOG:
		RECT r1;
		GetClientRect(GetParent(hdlg),&r1);
		SetWindowPos(GetParent(hdlg),HWND_TOPMOST,
			GetSystemMetrics(SM_CXSCREEN)/2-r1.right/2,
			GetSystemMetrics(SM_CYSCREEN)/2-r1.bottom/2,
			0,0,SWP_NOSIZE|SWP_SHOWWINDOW);
		return 1;
	}
	return 0;
}

BOOL CALLBACK RemoveDBFunc(HWND hdwnd, UINT message,
							WPARAM wParam, LPARAM lParam)
{
	char str[1024];
	maindl *mdl=(maindl *)GetWindowLong(hdwnd,GWL_USERDATA);
	switch(message)
	{
	case WM_INITDIALOG:
		mdl=(maindl *)lParam;
		sprintf(str,"Remove %s",mdl->lfn);
		SetWindowText(hdwnd,str);
		SetWindowLong(hdwnd,GWL_USERDATA,(LONG) mdl);
		return 1;
	case WM_ACTIVATE:
		if	(LOWORD(wParam) == WA_INACTIVE)
			hgdlg=NULL;
		else
			hgdlg=hdwnd;
		return 1;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDCANCEL:
			EndDialog(hdwnd, 1);
			return 1;
		case IDD_DELFILE:
		case IDD_DELALL:
		case IDD_LEAVEFILE:
		case IDD_LEAVEALL:
			EndDialog(hdwnd, LOWORD(wParam));
			return 1;
		}
	}
	return 0;
}

BOOL CALLBACK AboutFunc(HWND hdwnd, UINT message,
                         WPARAM wParam, LPARAM lParam)
{
	long st;
	HDC hdc;
	static HFONT fnt;
	char str[1024];
	long link[5]={IDD_EMAIL7,IDD_EMAIL8,IDD_SITE1,IDD_SITE2,
					IDD_REGISTER};
	int i;
	switch(message)
	{
	case WM_INITDIALOG:
		for (i=0;i<5;i++)
		{
			st=GetWindowLong(GetDlgItem(hdwnd,link[i]),GWL_STYLE);
			SetWindowLong(GetDlgItem(hdwnd,link[i]),GWL_STYLE,st|SS_NOTIFY);
		}
		fnt=CreateFont(12,8,0,0,0,0,1,0,ANSI_CHARSET,
			OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,
			DEFAULT_QUALITY,DEFAULT_PITCH|FF_DONTCARE,
			"MS Sans Serif");	
		sprintf(str,"GNU-GPL version.");
		SetDlgItemText(hdwnd,IDD_REG,str);
		break;

	case WM_ACTIVATE:
		if	(LOWORD(wParam) == WA_INACTIVE)
			hgdlg=NULL;
		else
			hgdlg=hdwnd;
		return 1;

	case WM_CTLCOLORSTATIC:
		for (i=0;i<5;i++)
			if ((HWND)lParam==GetDlgItem(hdwnd,link[i]))
			{
				hdc=(HDC)wParam;
				SetTextColor(hdc,RGB(0,0,255));
				SetBkMode(hdc,TRANSPARENT);
				SelectObject(hdc,fnt);
				return (BOOL)(HBRUSH)GetStockObject(HOLLOW_BRUSH);
			}
		break;

	case WM_COMMAND:
		for (i=0;i<5;i++)
			if (LOWORD(wParam)==link[i])
			{
				char str[1024];
				GetDlgItemText(hdwnd,link[i],str,sizeof(str));
				ShellExecute(NULL,"open", str, NULL, NULL, SW_SHOWNORMAL);
				return 1;
			}
		switch(LOWORD(wParam))
		{
		case IDCANCEL:
			EndDialog(hdwnd, 0);
			return 1;
		case IDOK:
			EndDialog(hdwnd, 1);
			return 1;
		}
		return 0;
	}
	return 0;
}

BOOL CALLBACK AddMirFunc(HWND hdwnd, UINT message,
                         WPARAM wParam, LPARAM lParam)
{
	static char *url;
	switch(message)
	{
	case WM_INITDIALOG:
		SetWindowText(hdwnd,GetSTR2(176,"Enter the URL of the new mirror:"));
		dds2();
		url=(char*)lParam;
		return 1;
	case WM_ACTIVATE:
		if	(LOWORD(wParam) == WA_INACTIVE)
			hgdlg=NULL;
		else
			hgdlg=hdwnd;
		return 1;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDCANCEL:
			EndDialog(hdwnd, 0);
			return 1;
		case IDOK:
			GetDlgItemText(hdwnd,IDD_URL,url,1024);
			EndDialog(hdwnd, 1);
			return 1;
		}
		return 0;
	}
	return 0;
}

BOOL CALLBACK ServerCfgFunc(HWND hdwnd, UINT message,
                         WPARAM wParam, LPARAM lParam)
{
	char str[1024];
	server *ser;//=(server *)GetWindowLong(hdwnd,GWL_USERDATA);
	int j;
	SERVERITEM *pitem;
	switch(message)
	{
	case WM_INITDIALOG:
		j=ListView_GetNextItem(hwndSV,-1,LVNI_ALL|LVNI_SELECTED);
		pitem = (SERVERITEM *) GetLVlParam(hwndSV,j);
		ser=pitem->ser;			
		//ser=(server *)lParam;
		if (ListView_GetSelectedCount(hwndSV)>1)
		{
			sprintf(str,GetSTR2(177,"Server configuration"),ser->host);
			dds2();
			ShowWindow(GetDlgItem(hdwnd,IDD_MULTI),SW_SHOW);
		}
		else
		{
			sprintf(str,GetSTR2(178,"Configuration of %s"),ser->host);
			dds2();
		}
		SetWindowText(hdwnd,str);
		//SetWindowLong(hdwnd,GWL_USERDATA,(LONG) ser);
		CreateUpDownControl(WS_CHILD|WS_BORDER|WS_VISIBLE|
			UDS_SETBUDDYINT|UDS_ALIGNRIGHT,
			10,10,50,50,hdwnd,IDD_SPIN1,hinst,
			GetDlgItem(hdwnd,IDD_MAXDL),1024,1,ser->maxdl);
		CreateUpDownControl(WS_CHILD|WS_BORDER|WS_VISIBLE|
			UDS_SETBUDDYINT|UDS_ALIGNRIGHT,
			10,10,50,50,hdwnd,IDD_SPIN2,hinst,
			GetDlgItem(hdwnd,IDD_MAXCON),1024,1,ser->maxcon);
		CreateUpDownControl(WS_CHILD|WS_BORDER|WS_VISIBLE|
			UDS_SETBUDDYINT|UDS_ALIGNRIGHT,
			10,10,50,50,hdwnd,IDD_SPIN3,hinst,
			GetDlgItem(hdwnd,IDD_MAXEACH),1024,1,ser->maxeach);
		if (ser->only1ip)
			SendDlgItemMessage(hdwnd,IDD_ONLY1IP,
							BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		if (!ser->perm)
			SendDlgItemMessage(hdwnd,IDD_NOPERM,
					BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		return 1;
	case WM_ACTIVATE:
		if	(LOWORD(wParam) == WA_INACTIVE)
			hgdlg=NULL;
		else
			hgdlg=hdwnd;
		return 1;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDCANCEL:
			EndDialog(hdwnd, 0);
			return 1;
		case IDOK:
			j=ListView_GetNextItem(hwndSV,-1,LVNI_ALL|LVNI_SELECTED);
			while (j!=-1)
			{
				pitem = (SERVERITEM *) GetLVlParam(hwndSV,j);
				ser=pitem->ser;
				ser->maxdl=(unsigned short)SendDlgItemMessage(hdwnd,IDD_SPIN1,UDM_GETPOS,0,0);
				ser->maxcon=(unsigned short)SendDlgItemMessage(hdwnd,IDD_SPIN2,UDM_GETPOS,0,0);
				ser->maxeach=(unsigned short)SendDlgItemMessage(hdwnd,IDD_SPIN3,UDM_GETPOS,0,0);
				if (SendDlgItemMessage(hdwnd,IDD_ONLY1IP,BM_GETCHECK,0,0)==BST_CHECKED)
					ser->only1ip=true;
				else ser->only1ip=false;
				if (SendDlgItemMessage(hdwnd,IDD_NOPERM,BM_GETCHECK,0,0)==BST_CHECKED)
					ser->perm=false;
				else ser->perm=true;
				j=ListView_GetNextItem(hwndSV,j,LVNI_ALL|LVNI_SELECTED);
			}
			SaveConfig();
			EndDialog(hdwnd, 1);
			return 1;
		}
	}
	return 0;
}

BOOL CALLBACK SpeedLimitFunc(HWND hdwnd, UINT message,
                         WPARAM wParam, LPARAM lParam)
{
	switch(message)
	{
	case WM_INITDIALOG:
		if (lParam==NULL)
		{
			SetDlgItemInt(hdwnd,IDD_EDITSPEED,cfg.dlspeedlimit,false);
			SetDlgItemInt(hdwnd,IDD_EDITSPEED2,cfg.brspeedlimit,false);
			if (cfg.slonlyifdl)
				SendDlgItemMessage(hdwnd,IDD_ONLYIFDL,
								BM_SETCHECK,(WPARAM) BST_CHECKED,0);
			if (cfg.slonlyifbr)
				SendDlgItemMessage(hdwnd,IDD_ONLYIFBR,
								BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		}
		return 1;
	case WM_ACTIVATE:
		if	(LOWORD(wParam) == WA_INACTIVE)
			hgdlg=NULL;
		else
			hgdlg=hdwnd;
		return 1;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDCANCEL:
			EndDialog(hdwnd, -1);
			return 1;
		case IDOK:
			cfg.dlspeedlimit=GetDlgItemInt(hdwnd,IDD_EDITSPEED,NULL,false);
			cfg.brspeedlimit=GetDlgItemInt(hdwnd,IDD_EDITSPEED2,NULL,false);
			if (SendDlgItemMessage(hdwnd,IDD_ONLYIFDL,BM_GETCHECK,0,0)==BST_CHECKED)
				cfg.slonlyifdl=true;
			else cfg.slonlyifdl=false;
			if (SendDlgItemMessage(hdwnd,IDD_ONLYIFBR,BM_GETCHECK,0,0)==BST_CHECKED)
				cfg.slonlyifbr=true;
			else cfg.slonlyifbr=false;
			EndDialog(hdwnd, 1);
			return 1;
		}
		return 0;
	}
	return 0;
}

BOOL CALLBACK ExportFunc(HWND hdwnd, UINT message,
							WPARAM wParam, LPARAM lParam)
{
	char str[1024],str2[1024];
	static FILE *f=NULL;
	static bool all=false;
	static int j,count;
	maindl *mdl;
	mirrors *mir;
	switch(message)
	{
    case WM_HELP:
		WinHelp(hdwnd, HelpFile, HELP_CONTEXT ,IDH_EXPORT);
		return 1;
	case WM_INITDIALOG:
		if (ListView_GetNextItem(hwndLV,-1,LVNI_ALL|LVNI_SELECTED)==-1)
		{
			EnableWindow(GetDlgItem(hdwnd,IDD_SELECTITEMS),false);
			SendDlgItemMessage(hdwnd,IDD_ALLITEMS,
						BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		}
		else
			SendDlgItemMessage(hdwnd,IDD_SELECTITEMS,
						BM_SETCHECK,(WPARAM) BST_CHECKED,0);
		GetExtDir(str2,"");
		sprintf(str,"%sdownload.gsl",str2);
		SetDlgItemText(hdwnd,IDD_FILE,str);
		all=false;
		f=NULL;
		return 1;
	
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDD_BROWSE:
			OPENFILENAME ofn;
			char dh[MAX_PATH], *tmp;
			GetDlgItemText(hdwnd,IDD_FILE,str,1000);
			tmp=strrchr(str,'\\');
			if (tmp) tmp++;
			sprintf(dh,"%s",tmp);
			tmp[0]=0;
			memset(&ofn,0,sizeof(ofn));
			ofn.lStructSize=sizeof(ofn);
			ofn.hwndOwner=hdwnd;
			ofn.hInstance=hinst;
			ofn.lpstrFile=dh;
			ofn.nMaxFile=MAX_PATH;
			ofn.lpstrInitialDir=str;
			ofn.Flags=OFN_PATHMUSTEXIST;
			ofn.lpstrDefExt="gsl";
			if (GetSaveFileName(&ofn))
			{
				SetDlgItemText(hdwnd,IDD_FILE,ofn.lpstrFile);
			}
			return 1;
		case IDCANCEL:
			EndDialog(hdwnd, 0);
			return 1;
		case IDOK:
			GetDlgItemText(hdwnd,IDD_FILE,str,1000);
			if (SendDlgItemMessage(hdwnd,IDD_OVERWRITE,
						BM_GETCHECK,0,0)==BST_CHECKED)
				f=fopen(str,"w+t");
			else
				f=fopen(str,"a+t");
			if (!f)
			{
				MsgBox(
					GetSTR2(179,"Can't open file for writing, check your filename."),
					str,MB_OK);
				dds2();
				return 1;
			}
			if (SendDlgItemMessage(hdwnd,IDD_ALLITEMS,
						BM_GETCHECK,0,0)==BST_CHECKED)
				all=true;
			count=ListView_GetItemCount(hwndLV);
			if (all) j=0;
			else
				j=ListView_GetNextItem(hwndLV,-1,LVNI_ALL|LVNI_SELECTED);
			while (j>-1)
			{
				STATUSITEM *pitem = (STATUSITEM *) GetLVlParam(hwndLV,j);
				mdl=pitem->mdl;
				if (mdl->type!=1)
					goto wellonemore;
				ConstURL(mdl->mirrorhead->nfo,str2);
				sprintf(str,"URL: %s\n",str2);
				fwrite(str,1,strlen(str),f);
				sprintf(str,"File: %s%s\n",mdl->ldir,mdl->lfn);
				fwrite(str,1,strlen(str),f);
				mir=mdl->mirrorhead->next;
				while (mir)
				{
					ConstURL(mir->nfo,str2);
					sprintf(str,"Alt: %s\n",str2);
					fwrite(str,1,strlen(str),f);
					mir=mir->next;
				}
wellonemore:;
				if (all)
				{
					j++;
					if (j==count) j=-1;
				}
				else
					j=ListView_GetNextItem(hwndLV,j,LVNI_ALL|LVNI_SELECTED);
			}
			fclose(f);
			if (SendDlgItemMessage(hdwnd,IDD_REMOVE,
						BM_GETCHECK,0,0)==BST_CHECKED)
			{
				if (all) SendMessage(hwndgui,WM_COMMAND,IDM_SELECTALL,0);
				SendMessage(hwndgui,WM_COMMAND,IDM_REMOVE,0);
			}
			EndDialog(hdwnd, 1);
			return 1;
		}
	}
	return 0;
}

#define DTM_GETSYSTEMTIME 0x1001
#define DTM_SETSYSTEMTIME 0x1002
#define GDT_VALID 0

BOOL CALLBACK ScheduleFunc(HWND hdwnd, UINT message,
                         WPARAM wParam, LPARAM lParam)
{
	SYSTEMTIME st;
	switch(message)
	{
    case WM_HELP:
		WinHelp(hdwnd, HelpFile, HELP_CONTEXT ,IDH_SCHEDULE);
		return 1;
	case WM_INITDIALOG:
		GetLocalTime(&st);
		if (cfg.Schedule.EDL)
		{
			SendDlgItemMessage(hdwnd,IDD_EDL,BM_SETCHECK,
											(WPARAM) BST_CHECKED,0);
			st.wHour=cfg.Schedule.StartDL.tm_hour;
			st.wMinute=cfg.Schedule.StartDL.tm_min;
			st.wSecond=cfg.Schedule.StartDL.tm_sec;
			SendMessage(GetDlgItem(hdwnd,IDD_STARTDL), 
				DTM_SETSYSTEMTIME, GDT_VALID, (LPARAM)&st);
			if (cfg.Schedule.UseDLDate)
			{
				st.wYear=cfg.Schedule.DLDate.tm_year+1900;
				st.wMonth=cfg.Schedule.DLDate.tm_mon+1;
				st.wDay=cfg.Schedule.DLDate.tm_mday;
				SendMessage(GetDlgItem(hdwnd,IDD_DLDATE),
					DTM_SETSYSTEMTIME, GDT_VALID, (LPARAM)&st);
			}
		}
		if (cfg.Schedule.UseDLDate)
			SendDlgItemMessage(hdwnd,IDD_USEDLDATE,BM_SETCHECK,
											(WPARAM) BST_CHECKED,0);
		else
			SendDlgItemMessage(hdwnd,IDD_DLDOW,BM_SETCHECK,
											(WPARAM) BST_CHECKED,0);
		if (cfg.Schedule.DOW[0])
			SendDlgItemMessage(hdwnd,IDD_SUN,BM_SETCHECK,
											(WPARAM) BST_CHECKED,0);
		if (cfg.Schedule.DOW[1])
			SendDlgItemMessage(hdwnd,IDD_MON,BM_SETCHECK,
											(WPARAM) BST_CHECKED,0);
		if (cfg.Schedule.DOW[2])
			SendDlgItemMessage(hdwnd,IDD_TUE,BM_SETCHECK,
											(WPARAM) BST_CHECKED,0);
		if (cfg.Schedule.DOW[3])
			SendDlgItemMessage(hdwnd,IDD_WED,BM_SETCHECK,
											(WPARAM) BST_CHECKED,0);
		if (cfg.Schedule.DOW[4])
			SendDlgItemMessage(hdwnd,IDD_THU,BM_SETCHECK,
											(WPARAM) BST_CHECKED,0);
		if (cfg.Schedule.DOW[5])
			SendDlgItemMessage(hdwnd,IDD_FRI,BM_SETCHECK,
											(WPARAM) BST_CHECKED,0);
		if (cfg.Schedule.DOW[6])
			SendDlgItemMessage(hdwnd,IDD_SAT,BM_SETCHECK,
											(WPARAM) BST_CHECKED,0);
/*		if (cfg.Schedule.HangFinish)
			SendDlgItemMessage(hdwnd,IDD_HANGFINISH,BM_SETCHECK,
											(WPARAM) BST_CHECKED,0);
		if (cfg.Schedule.Redial)
			SendDlgItemMessage(hdwnd,IDD_REDIAL,BM_SETCHECK,
											(WPARAM) BST_CHECKED,0);*/
		if (cfg.Schedule.EHU)
		{
			SendDlgItemMessage(hdwnd,IDD_EHU,BM_SETCHECK,
											(WPARAM) BST_CHECKED,0);
			st.wHour=cfg.Schedule.StartHU.tm_hour;
			st.wMinute=cfg.Schedule.StartHU.tm_min;
			st.wSecond=cfg.Schedule.StartHU.tm_sec;
			SendMessage(GetDlgItem(hdwnd,IDD_STARTHU), 
				DTM_SETSYSTEMTIME, GDT_VALID, (LPARAM)&st);
			if (cfg.Schedule.UseHUDate)
			{
				st.wYear=cfg.Schedule.HUDate.tm_year+1900;
				st.wMonth=cfg.Schedule.HUDate.tm_mon+1;
				st.wDay=cfg.Schedule.HUDate.tm_mday;
				SendMessage(GetDlgItem(hdwnd,IDD_HUDATE),
					DTM_SETSYSTEMTIME, GDT_VALID, (LPARAM)&st);
			}
		}
		if (cfg.Schedule.UseHUDate)
			SendDlgItemMessage(hdwnd,IDD_USEHUDATE,BM_SETCHECK,
											(WPARAM) BST_CHECKED,0);
		else
			SendDlgItemMessage(hdwnd,IDD_HUDAILY,BM_SETCHECK,
											(WPARAM) BST_CHECKED,0);
		
		return 1;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDCANCEL:
			EndDialog(hdwnd, 0);
			return 1;
			break;
		case IDOK:
			if (SendDlgItemMessage(hdwnd,IDD_EDL,BM_GETCHECK,0,0)==BST_CHECKED)
			{
				cfg.Schedule.EDL=true;
				wait4sc=true;
			}
			else cfg.Schedule.EDL=false;
			SendMessage(GetDlgItem(hdwnd,IDD_STARTDL), 
				DTM_GETSYSTEMTIME, 0, (LPARAM)&st);
			cfg.Schedule.StartDL.tm_hour=st.wHour;
			cfg.Schedule.StartDL.tm_min=st.wMinute;
			cfg.Schedule.StartDL.tm_sec=st.wSecond;
			if (SendDlgItemMessage(hdwnd,IDD_USEDLDATE,BM_GETCHECK,0,0)==BST_CHECKED)
				cfg.Schedule.UseDLDate=true;
			else cfg.Schedule.UseDLDate=false;
			SendMessage(GetDlgItem(hdwnd,IDD_DLDATE),
				DTM_GETSYSTEMTIME, 0, (LPARAM)&st);
			cfg.Schedule.DLDate.tm_mday=st.wDay;
			cfg.Schedule.DLDate.tm_mon=st.wMonth-1;
			cfg.Schedule.DLDate.tm_year=st.wYear-1900;
			cfg.Schedule.DLDate.tm_wday=st.wDayOfWeek-1;
			if (SendDlgItemMessage(hdwnd,IDD_SUN,BM_GETCHECK,0,0)==BST_CHECKED)
				cfg.Schedule.DOW[0]=true;
			else cfg.Schedule.DOW[0]=false;
			if (SendDlgItemMessage(hdwnd,IDD_MON,BM_GETCHECK,0,0)==BST_CHECKED)
				cfg.Schedule.DOW[1]=true;
			else cfg.Schedule.DOW[1]=false;
			if (SendDlgItemMessage(hdwnd,IDD_TUE,BM_GETCHECK,0,0)==BST_CHECKED)
				cfg.Schedule.DOW[2]=true;
			else cfg.Schedule.DOW[2]=false;
			if (SendDlgItemMessage(hdwnd,IDD_WED,BM_GETCHECK,0,0)==BST_CHECKED)
				cfg.Schedule.DOW[3]=true;
			else cfg.Schedule.DOW[3]=false;
			if (SendDlgItemMessage(hdwnd,IDD_THU,BM_GETCHECK,0,0)==BST_CHECKED)
				cfg.Schedule.DOW[4]=true;
			else cfg.Schedule.DOW[4]=false;
			if (SendDlgItemMessage(hdwnd,IDD_FRI,BM_GETCHECK,0,0)==BST_CHECKED)
				cfg.Schedule.DOW[5]=true;
			else cfg.Schedule.DOW[5]=false;
			if (SendDlgItemMessage(hdwnd,IDD_SAT,BM_GETCHECK,0,0)==BST_CHECKED)
				cfg.Schedule.DOW[6]=true;
			else cfg.Schedule.DOW[6]=false;
/*			if (SendDlgItemMessage(hdwnd,IDD_HANGFINISH,BM_GETCHECK,0,0)==BST_CHECKED)
				cfg.Schedule.HangFinish=true;
			else cfg.Schedule.HangFinish=false;
			if (SendDlgItemMessage(hdwnd,IDD_REDIAL,BM_GETCHECK,0,0)==BST_CHECKED)
				cfg.Schedule.Redial=true;
			else cfg.Schedule.Redial=false;*/
			if (SendDlgItemMessage(hdwnd,IDD_EHU,BM_GETCHECK,0,0)==BST_CHECKED)
				cfg.Schedule.EHU=true;
			else cfg.Schedule.EHU=false;
			SendMessage(GetDlgItem(hdwnd,IDD_STARTHU),
				DTM_GETSYSTEMTIME, 0, (LPARAM)&st);
			cfg.Schedule.StartHU.tm_hour=st.wHour;
			cfg.Schedule.StartHU.tm_min=st.wMinute;
			cfg.Schedule.StartHU.tm_sec=st.wSecond;
			if (SendDlgItemMessage(hdwnd,IDD_USEHUDATE,BM_GETCHECK,0,0)==BST_CHECKED)
				cfg.Schedule.UseHUDate=true;
			else cfg.Schedule.UseHUDate=false;
			SendMessage(GetDlgItem(hdwnd,IDD_HUDATE),
				DTM_GETSYSTEMTIME, 0, (LPARAM)&st);
			cfg.Schedule.HUDate.tm_mday=st.wDay;
			cfg.Schedule.HUDate.tm_mon=st.wMonth-1;
			cfg.Schedule.HUDate.tm_year=st.wYear-1900;
			cfg.Schedule.HUDate.tm_wday=st.wDayOfWeek-1;
			SaveConfig();
			EndDialog(hdwnd, 1);
			return 1;
		}
		return 0;
	}
	return 0;
}

BOOL CALLBACK OfferGSUL(HWND hdwnd, UINT message,
                         WPARAM wParam, LPARAM lParam)
{
	char str[1024];
	switch(message)
	{
	case WM_INITDIALOG:
		if (lParam)
		{
			SetDlgItemText(hdwnd,IDD_IP,(char*)lParam);
			SetDlgItemText(hdwnd,IDD_NAME,(char*)lParam+strlen((char*)lParam)+1);
		}
		return 1;
	case WM_ACTIVATE:
		if	(LOWORD(wParam) == WA_INACTIVE)
			hgdlg=NULL;
		else
			hgdlg=hdwnd;
		return 1;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDD_BROWSE:
			OPENFILENAME ofn;
			char dh[MAX_PATH], *tmp;
			GetDlgItemText(hdwnd,IDD_FILE,str,1000);
			tmp=strrchr(str,'\\');
			if (tmp) tmp++;
			sprintf(dh,"%s",tmp);
			if (tmp) tmp[0]=0;
			else str[0]='\0';
			memset(&ofn,0,sizeof(ofn));
			ofn.lStructSize=sizeof(ofn);
			ofn.hwndOwner=hdwnd;
			ofn.hInstance=hinst;
			ofn.lpstrFile=dh;
			ofn.nMaxFile=MAX_PATH;
			ofn.lpstrInitialDir=str;
			ofn.Flags=OFN_PATHMUSTEXIST;
			//ofn.lpstrDefExt="";
			if (GetSaveFileName(&ofn))
			{
				SetDlgItemText(hdwnd,IDD_FILE,ofn.lpstrFile);
			}
			return 1;
		case IDD_FILE:
			if (HIWORD(wParam)==EN_CHANGE)
			{
				GetDlgItemText(hdwnd,IDD_FILE,str,1000);
				char *tmp,*tmp2;
				tmp=strrchr(str,'/');
				tmp2=strrchr(str,'\\');
				if (tmp2>tmp)
					tmp=tmp2;
				SetDlgItemText(hdwnd,IDD_REQ,(tmp? tmp+1:str));
				return 1;
			}
			return 0;

		case IDCANCEL:
			EndDialog(hdwnd, 0);
			return 1;
		case IDOK:
			DWORD *ip,i;
			BYTE d[4];
			memset(d,0,sizeof(d));
			GetDlgItemText(hdwnd,IDD_IP,str,1000);
			tmp=str;
			for (i=0;i<4;i++)
			{
				d[i]=atoi(tmp);
				tmp=strchr(tmp,'.');
				if (!tmp)
					break;
				tmp++;
			}
			bool use=false;
			ip=(DWORD *)d;
			char reqname[1024],dir[1024],fn[1024],name[1024];
			GetDlgItemText(hdwnd,IDD_REQ,reqname,1024);
			GetDlgItemText(hdwnd,IDD_FILE,str,1024);
			GetDlgItemText(hdwnd,IDD_NAME,name,1024);
			tmp=strrchr(str,'\\');
			if (tmp)
			{
				tmp++;
				strcpy(fn,tmp);
				*tmp='\0';
				strcpy(dir,str);
			}
			else
			{
				strcpy(fn,str);
				dir[0]='\0';
			}

			new gsdltable(*ip,0,reqname,dir,fn,name,true);
			EndDialog(hdwnd, 1);
			return 1;
		}
		return 0;
	}
	return 0;
}

