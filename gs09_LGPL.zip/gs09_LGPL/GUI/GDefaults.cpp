
int StatusCol[10]={150,65,30,45,75,40,35,30,50,250};
short StatusOrder[10]={0,1,2,3,4,5,6,7,8,9};
int TaskCol[9]={150,65,45,75,40,35,50,50,150};
int ServerCol[9]={150,65,45,75,40,35,50,50,150};
int MirrorCol[10]={150,65,30,45,75,40,35,30,50,250};
int WildCol[4]={250,65,100,50};

bool enablemenu=false;
long enableitem[8]={IDM_REMOVE,IDM_REMOVECLIP,IDM_COPYCLIP,
					IDM_DOWNLOAD,IDM_PAUSE,IDM_HIDE,
					IDM_PROPERTIES,IDM_MIRRORS},
					enablecount=8;

void InitComCtl(LPDWORD pdwMajor, LPDWORD pdwMinor);

extern char *sknormal;
extern char *skfast;

void InitGuiCfg()
{
	char str[_MAX_PATH];
	sprintf(str,"%sSkins\\",rundir);
	gcfg.skindir=DupString(str);
	if (_access(str,0))
			CreateDirectory(str,NULL);
	gcfg.exskinfn=DupString("");
	gcfg.useexskin=false;
	donehead=NULL;donelast=NULL;
	gcfg.showdltray=true;
	gcfg.showdlwin=true;
	gcfg.finishmsgs=true;
	gcfg.catchcb=true;
	gcfg.catchns=false;
	gcfg.proxy_showtray=false;
	lastdlhead=NULL;
	lastdllast=NULL;
	mainmirr=NULL;
	gcfg.maxlastdl=7;
	gcfg.maxbuffer=500;
	gcfg.smalltrans=false;
	gcfg.smallalpha=192;
	LoadLDL=false;
	ignoreclipboard=false;
	inclipchain=false;
	killgui=false;
	hwndNextViewer=NULL;
	hwndprev=NULL;
	hserver=NULL;
	hwndSV=NULL;
	hwnddropbox=NULL;
	ttip=NULL;
	gcfg.showdropbox=true;
	gcfg.dropposx=GetSystemMetrics(SM_CXSCREEN)/2;
	gcfg.dropposy=GetSystemMetrics(SM_CYSCREEN)/2;
	gcfg.showtt=true;
	gcfg.smalldrop=false;
	gcfg.lv.bkcustom=true;
	gcfg.lv.bkwallpaper=false;
	gcfg.lv.bkload=false;
	gcfg.lv.dynbk=false;
	gcfg.lv.bkclr=RGB(0,0,125);
	gcfg.lv.hdclr=RGB(55,255,55);
	gcfg.lv.hdclr2=RGB(255,55,55);
	gcfg.lv.txtclr=RGB(255,255,255);
	gcfg.lv.txtclr2=RGB(0,255,255);
	gcfg.lv.glassclr=RGB(127,127,255);
	gcfg.lv.bkfn[0]='\0';

	gfont=CreateFont(8,0,0,0,FW_BOLD,0,0,0,ANSI_CHARSET,
			OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,
			DEFAULT_QUALITY,DEFAULT_PITCH|FF_DONTCARE,
			"MS Sans Serif");
	hgdlg=NULL;
	memset(tipmsgs,0,sizeof(tipmsgs));
	sknormal=DupString(GetSTR2(160,"Normal"));
	skfast=DupString(GetSTR2(161,"Fast"));
	dds2();
	ctlminor=0;ctlmajor=0;
	InitComCtl(&ctlmajor,&ctlminor);
	memset(StatusExc,0,sizeof(StatusExc));
	StatusExc[2]=true;


}
