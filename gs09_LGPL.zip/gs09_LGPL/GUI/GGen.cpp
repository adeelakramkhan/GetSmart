
#include "GUI.h"

BOOL CALLBACK ExistSplitFunc(HWND,UINT,WPARAM,LPARAM);
BOOL CALLBACK ExistFunc(HWND,UINT,WPARAM,LPARAM);
UINT APIENTRY OFNHookProc(HWND,UINT,WPARAM,LPARAM);

bool SendURL(dlnfo *dln,char *ldir0,char *lfn0,int dosplit,bool wc,
			 int proxy,int mode,time_t to,unsigned char prior,
			 bool uh,bool ur,bool checkint,bool smallint)
{
	char lfn[_MAX_PATH],ldir[_MAX_PATH];
	char str[1024];
	if (!strlen(dln->rfn))
		dln->rfn=ReDupString(dln->rfn,"*.*");
	if (!lfn0 || !strlen(lfn0))
		strcpy(lfn,dln->rfn);
	else strcpy(lfn,lfn0);
	if (ldir0==NULL)
		GetExtDir(ldir,lfn);
	else strcpy(ldir,ldir0);
	if (strchr(dln->rfn,'*') || wc)
	{
		AddURL(dln,ldir,lfn,2,proxy,dosplit,to,prior,mode,uh,ur,
				checkint,smallint);
		return true;
	}
	maindl *dmdl;
	if (dmdl=CheckDup(dln))
	{
		sprintf(str,GetSTR2(94,"Detected a new mirror for %s"),dmdl->lfn);
		dds2();
		STELLGUI(SHOW_TIP,str,0);
		AddURL(dln,ldir,lfn,1,proxy,dosplit,to,prior,mode,uh,ur,
				checkint,smallint);
		return true;
	}
	sprintf(str,GetSTR2(95,"Detected file: %s"),dln->rfn);
	dds2();
	STELLGUI(SHOW_TIP,str,0);
	WIN32_FIND_DATA ff;
	char ffn[1024];
	if (cfg.istmpdir)
		strcpy(ffn,cfg.tmpdir);
	else strcpy(ffn,ldir);
	lcl lc(ffn,lfn);
	strcat(ffn,lfn);
	if (strlen(cfg.stamp))
		strcat(ffn,cfg.stamp);
	if (FindFirstFile(ffn,&ff)!=INVALID_HANDLE_VALUE)
	{
		strcpy(ffn,lc.ldir);
		strcat(ffn,lc.lfn);
		strcat(ffn," (1)*");
		if (FindFirstFile(ffn,&ff)!=INVALID_HANDLE_VALUE)
		{
			if (!DialogBoxParam(hlang,"EXISTSPLIT",hwndg,
					(DLGPROC) ExistSplitFunc, (long)&lc))
			{
				delete dln;
				return false;
			}
		}
		else
			if (!DialogBoxParam(hlang,"EXIST",hwndg,
					(DLGPROC) ExistFunc, (long)&lc))
			{
				delete dln;
				return false;
			}
	}
	else
		//if (cfg.istmpdir)
		{
			strcpy(ffn,ldir);
			strcat(ffn,lfn);
			if (FindFirstFile(ffn,&ff)!=INVALID_HANDLE_VALUE)
			{
				strcpy(lc.ldir,ldir);
				if (!DialogBoxParam(hlang,"EXIST",hwndg,
						(DLGPROC) ExistFunc, (long)&lc))
				{
					delete dln;
					return false;
				}
			}
		}
	AddURL(dln,ldir,lfn,1,proxy,dosplit,to,prior,mode,uh,ur,
			checkint,smallint);
	return true;
}

void CatchCB()
{
	if (!gcfg.catchcb)	
	{
		CheckMenuItem(Hmenu,IDM_CATCHCLIPBOARD,MF_UNCHECKED);
		if (inclipchain)
		{
			ChangeClipboardChain(hwndgui, hwndNextViewer);
			hwndNextViewer=NULL;
			inclipchain=false;
		}
	}
	else
	{
		CheckMenuItem(Hmenu,IDM_CATCHCLIPBOARD,MF_CHECKED);
		if (!inclipchain)
		{
			ignoreclipboard=true;
			hwndNextViewer=SetClipboardViewer(hwndgui);
			inclipchain=true;
		}
	}
}

void Dropbox()
{
	if (gcfg.showdropbox)
	{
		if (!hwnddropbox)
		{
			hwnddropbox=CreateWindow("GSDropbox",
			NULL,
			WS_POPUP | WS_VISIBLE,
			gcfg.dropposx,
			gcfg.dropposy,
			48,
			48,
			hwndg,
			NULL,
			hinst,
			NULL);
		}
	}
	else
		if (hwnddropbox)
		{
			DestroyWindow(hwnddropbox);
			hwnddropbox=NULL;
		}
}

void GotURL(char *url)
{
	cs(url);
	dlnfo *dln=ConvertURL(url);
	char lfn[1024],ldir[1024];
	maindl*dmdl=NULL;
	if (strchr(dln->rfn,'?') || cfg.startdef || (dmdl=CheckDup(dln)) || !strlen(dln->rfn))
	{
		char str[1024];
		if (dmdl!=NULL)
		{
			sprintf(str,GetSTR2(94,"Detected a new mirror for %s"),dmdl->lfn);
			dds2();
			STELLGUI(SHOW_TIP,str,0);
		}
		else
			if (cfg.startdef)
			{
				sprintf(str,GetSTR2(95,"Detected file: %s"),dln->rfn);
				dds2();
				STELLGUI(SHOW_TIP,str,0);
			}
		if (!strlen(dln->rfn))
			SendDefURL(dln,2);
		else SendDefURL(dln,1);
		return;
	}
	GetExtDir(ldir,dln->rfn);
	bool uh=cfg.usehammer,ur=cfg.useretry;
	if (uh)
		if (cfg.hammerfallback) ur=true;
		else ur=false;
	OPENFILENAME ofn;
	char dh[MAX_PATH], *tmp;
	sprintf(dh,"%s",dln->rfn);
	memset(&ofn,0,sizeof(ofn));
	ofn.lStructSize=sizeof(ofn);
	ofn.hwndOwner=HWND_DESKTOP;
	ofn.hInstance=hinst;
	ofn.lpstrFile=dh;
	ofn.nMaxFile=MAX_PATH;
	ofn.lpstrInitialDir=ldir;
	ofn.Flags=OFN_PATHMUSTEXIST|OFN_ENABLEHOOK|OFN_EXPLORER;
	ofn.lpfnHook=OFNHookProc;
	tmp=strchr(dln->rfn,'.');
	if (tmp) tmp++;
	ofn.lpstrDefExt=tmp;
	if (GetSaveFileName(&ofn))
	{
		char str[1024];
		memset(str,0,sizeof(str));
	 	strncpy(str,ofn.lpstrFile,ofn.nFileOffset);
		strcpy(ldir,str);
		strcpy(lfn,&ofn.lpstrFile[ofn.nFileOffset]);
		SendURL(dln,ldir,lfn,cfg.defsplit,false,9,0,cfg.resumeto,
			DEFPR,uh,ur,cfg.checkint,cfg.checksmallint);
	}
}


bool MakeTransparent(HWND hwnd,bool wstrans,int alpha)
{
	BOOL (STDAPICALLTYPE* SetLayeredWindowAttributesx)(
		HWND hwnd,
		COLORREF crKey,
		BYTE bAlpha,
		DWORD dwFlags)=NULL;

	HINSTANCE hin;
	hin=LoadLibrary("user32.dll");
	SetLayeredWindowAttributesx= (BOOL (STDAPICALLTYPE*)(HWND hwnd,
				COLORREF crKey,
				BYTE bAlpha,
				DWORD dwFlags))
				GetProcAddress(hin,"SetLayeredWindowAttributes");
	if (SetLayeredWindowAttributesx)
	{
		DWORD dwLong = GetWindowLong(hwnd, GWL_EXSTYLE);
		if (wstrans) dwLong|=WS_EX_TRANSPARENT;
		SetWindowLong(hwnd, GWL_EXSTYLE, dwLong | 0x00080000);//WS_EX_LAYERED
		SetLayeredWindowAttributesx(hwnd, RGB(0,0,0), alpha, 0x00000002);//LWA_ALPHA
	}
	FreeLibrary(hin);
	return (SetLayeredWindowAttributesx ?true:false);
}

bool MakeNotTransparent(HWND hwnd)
{
	DWORD dwLong = GetWindowLong(hwnd, GWL_EXSTYLE);
	//if (wstrans) dwLong|=WS_EX_TRANSPARENT;
	SetWindowLong(hwnd, GWL_EXSTYLE, dwLong & ~0x00080000 & ~WS_EX_TRANSPARENT);//WS_EX_LAYERED
	return true;
}
