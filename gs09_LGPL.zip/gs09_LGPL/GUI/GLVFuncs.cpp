
#include "GUI.h"
void AddItem2(HWND hwndLV2, mainftp *m);
LRESULT WINAPI NewLVProc(HWND, UINT, WPARAM, LPARAM);

BOOL WINAPI InitColumns(HWND hwndLV,char *h1,int *h2,int c,int who)
{
	struct htxts
	{ 
		char s[10][50];
	}*htxt;
	
	struct hls
	{
		int s[10];
	}*hl;
	htxt=(htxts*) h1;
	hl=(hls*)h2;

struct MLVCOLUMN
{
    UINT mask;
    int fmt;
    int cx;
    LPSTR pszText;
    int cchTextMax;
    int iSubItem;
    int iImage;
    int iOrder;
};
#define LVCF_ORDER              0x0020
	MLVCOLUMN lvc; 
    int iCol;
    lvc.mask = LVCF_FMT|LVCF_WIDTH|LVCF_TEXT|LVCF_SUBITEM|LVCF_ORDER;
    lvc.fmt = LVCFMT_LEFT;
		
    for (iCol = 0; iCol < c; iCol++) 
	{ 
		if (!who)
			lvc.iOrder=iCol;
		else
			if (who==1)
				lvc.iOrder=StatusOrder[iCol];
		lvc.cx = hl->s[iCol];
		lvc.iSubItem = iCol; 
		lvc.pszText =htxt->s[0,iCol];
		//if ((who==1) && (StatusExc[iCol]))
		//	lvc.iOrder = -1;
        if (ListView_InsertColumn(hwndLV, iCol, &lvc) == -1) 
            return FALSE;     
	}
	return TRUE; 
}


HWND DoCreateList(HWND hwndParent, char *h1,int *h2,int c,bool show,int who)
{
	HWND hwndLV;
	int r2l=0,ext=0;
	if (cfg.r2l)
		if ((os.dwPlatformId==VER_PLATFORM_WIN32_NT) && (os.dwMajorVersion>=5)
			|| (os.dwPlatformId==VER_PLATFORM_WIN32_WINDOWS) &&
			((os.dwMajorVersion!=4) || (os.dwMinorVersion)))
				r2l=0x0400000L|WS_EX_RTLREADING|WS_EX_LEFTSCROLLBAR;
	if ((ctlmajor>4) || (ctlmajor==4) && (ctlminor>=70))
	{
#define LVS_EX_HEADERDRAGDROP   0x00000010
#define LVS_EX_FULLROWSELECT    0x00000020
	ext=LVS_EX_FULLROWSELECT;//|LVS_EX_HEADERDRAGDROP;
	}
	if (show)
		hwndLV = CreateWindowEx(WS_EX_TOPMOST|r2l|ext,WC_LISTVIEW, "",
			WS_CHILD | WS_BORDER | LVS_REPORT | CCS_TOP | LVS_SHOWSELALWAYS,
			0, 0, 0, 0, hwndParent, NULL, hinst, NULL);
	else
		hwndLV = CreateWindowEx(WS_EX_DLGMODALFRAME | WS_EX_TOPMOST|r2l|ext,
		WC_LISTVIEW, "",WS_CHILD | WS_BORDER | LVS_REPORT | CCS_TOP | LVS_SHOWSELALWAYS,
			0, 0, 0, 0, hwndParent, NULL, hinst, NULL);
	if (hwndLV == NULL)
        return NULL;
	//SetProp(hwndLV, "OldProc",(HANDLE)GetWindowLong(hwndLV,GWL_WNDPROC));
	//SetWindowLong(hwndLV,GWL_WNDPROC,(DWORD)NewLVProc);
	InitColumns(hwndLV,h1,h2,c,who);
	if (show)
	{
		RECT rc;
		GetClientRect(hwndParent, &rc);
		SetWindowPos(hwndLV,0, rc.left, rc.top,
				rc.right , rc.bottom, SWP_SHOWWINDOW|SWP_NOZORDER);
	}
	return hwndLV;
}

void AddItem(HWND hwndLV2, maindl *mdl)
{
	char str[1000];
	int j;
	STATUSITEM *pitem=(STATUSITEM*)malloc(sizeof(STATUSITEM));
	pitem->mdl=mdl;
	pitem->c[0]=mdl->lfn;
	long c=0;
	if (mdl->rsize)
	{
		sprintf(str,"%.1dk",mdl->rsize/1024);
		pitem->c[1]=DupString(str);
/*		if (mdl->splitdex)
		{
			for (j=0;j<=mdl->splitdex;j++)
				if (!mdl->spdone[j]) c+=mdl->localbytes[j];
		}
		else c=mdl->localbytes[0];
		c+=mdl->locallost;*/
		c=mdl->lbytes;
		sprintf(str,"%.1f%%",(int) (c*1000.0/mdl->rsize) /10.0);
		pitem->c[2]=DupString(str);
		if (mdl->resume) strcpy(str,GetSTR2(182,"Yes"));
		else strcpy(str,GetSTR2(183,"No"));
		pitem->c[5]=DupString(str);
	}
	else
	{
		pitem->c[1]=DupString("???");
		pitem->c[2]=DupString("0%");
		pitem->c[5]=DupString("???");
	}
	pitem->c[3]=DupString("0 kb/s");
	pitem->c[4]=DupString("???");
	pitem->c[6]=DupString("0 s");
	sprintf(str,"%ld",mdl->prior);
	pitem->c[7]=DupString(str);
	sprintf(str,"%s%s",mdl->mirrorhead->nfo->host,mdl->mirrorhead->nfo->rdir);
	pitem->c[8]=DupString(str);
	pitem->c[9]=DupString(GetSTR2(65,"Paused."));
	dds2();
	((mainftp*)(mdl->guiparam))->item=pitem;

	LVITEM it;
	memset(&it,0,sizeof(it));
	it.mask = LVIF_TEXT | LVIF_PARAM | LVIF_IMAGE; 
	pitem->pos=ListView_GetItemCount(hwndLV2);
	it.iItem=pitem->pos;
	it.iSubItem=0;
	it.lParam=(LPARAM) pitem;
	it.iImage= I_IMAGECALLBACK;
	it.pszText=LPSTR_TEXTCALLBACK;
	j=ListView_InsertItem(hwndLV2,&it);

	for (j=0;j<10;j++)
		pitem->cb[j]=DupString(pitem->c[j]);

	for (j=0;j<ListView_GetItemCount(hwndLV);j++)
	{
		STATUSITEM *pitem = (STATUSITEM *) GetLVlParam(hwndLV,j);
		if (pitem->mdl->spliton && (pitem->mdl->type==2) && 
			!strcmp(pitem->mdl->mirrorhead->nfo->host,
			mdl->mirrorhead->nfo->host))
			AddItem2(((mainftp*)pitem->mdl->guiparam)->hwndLV2,
						(mainftp*)mdl->guiparam);
	}
}

void UpdateMainSmall(smallftp *f,int r,time_t ct)
{
#define mdl f->mdl
	char str[1024];
	int i;
	time_t tp=ct-mdl->starttime;
	if ((f->m->mftp->hwnd!=NULL) && !f->m->mftp->opentrack && mdl->resume)
	{
		f->m->mftp->opentrack=true;
		PostMessage(f->m->mftp->hwnd,_SKN_BTSET,MAKELONG(6,1),1);
		PostMessage(f->m->mftp->hwnd,_SKN_RGN,MAKELONG(3,1),
					MAKELONG(_S_RGIN|_S_RGOUT,0));
	}
	if (!mdl->starttime)
		tp=0;
	if (mdl->rsize)
	{
		sprintf(f->txt[0],"%.1f%% %s (%s)",
				(int) (mdl->lbytes*1000.0/mdl->rsize) /10.0,
				mdl->lfn,mdl->ldir);
		sprintf(f->txt[2],"%.1fk/%.1fk",mdl->lbytes/1024.0,
				mdl->rsize/1024.0);
		PostMessage(f->hwnd,_SKN_PRTOT,MAKELONG(0,0),mdl->rsize);
		PostMessage(f->hwnd,_SKN_PRCUR,MAKELONG(0,0),mdl->lbytes);
	}
	else
	{
		sprintf(f->txt[0],"%.1fkb %s (%s)",
				mdl->lbytes/1024.0,mdl->lfn,mdl->ldir);
		sprintf(f->txt[2],"%.1fk/???",mdl->lbytes/1024.0);
	}
	SetWindowText(f->hwnd,f->txt[0]);
	sprintf(str,"%s %s",mdl->mirrorhead->nfo->host,mdl->mirrorhead->nfo->rdir);
	strncpy(f->txt[1],str,79);
	f->txt[1][79]=0;
	sprintf(f->txt[3],"%.2d:%.2d:%.2d",tp/3600,(tp%3600)/60,
										((tp%3600)%60));
	if (r)
		sprintf(f->txt[5],"%.2d:%.2d:%.2d",r/3600,(r%3600)/60,
											((r%3600)%60));
	else strcpy(f->txt[5],"??:??:??");
	if (tp)
		sprintf(f->txt[4],"%.2f kb/s",mdl->sbytes/1024.0/tp);
	else strcpy(f->txt[4],"0.00 kb/s");
	sprintf(f->txt[6],"%.2f kb/s",mdl->cps/1024.0);
	sprintf(f->txt[7],"%ld",mdl->spliton);
	sprintf(f->txt[9],"%ld",ct-mdl->timeout);
	sprintf(f->txt[11],"%ld ms",mdl->pingtime);
	if (mdl->done && !mdl->spliton)
	{
		PostMessage(f->hwnd,_SKN_BTSET,MAKELONG(3,0),2);
		sprintf(f->txt[8],GetSTR2(180,"Done"));
		dds2();
	}
	else
		if (mdl->spliton)
		{
			PostMessage(f->hwnd,_SKN_BTSET,MAKELONG(3,0),0);
			sprintf(f->txt[8],GetSTR2(181,"Pause"));
			dds2();
		}
		else
		{
			PostMessage(f->hwnd,_SKN_BTSET,MAKELONG(3,0),1);
			sprintf(f->txt[8],GetSTR2(109,"Resume"));
			dds2();
		}
	for(i=0;i<smallskin.numtxt;i++)
		if (smallskin.txt[i].def<21)
			PostMessage(f->hwnd,_SKN_TXTUP,MAKELONG(i,0),0);

/*		PostMessage(f->hwnd,_SKN_TXT,MAKELONG(1,0),(LPARAM)f->txt[1]);
	PostMessage(f->hwnd,_SKN_TXT,MAKELONG(2,0),(LPARAM)f->txt[2]);
	PostMessage(f->hwnd,_SKN_TXT,MAKELONG(3,0),(LPARAM)f->txt[3]);
	PostMessage(f->hwnd,_SKN_TXT,MAKELONG(4,0),(LPARAM)f->txt[4]);
	PostMessage(f->hwnd,_SKN_TXT,MAKELONG(5,0),(LPARAM)f->txt[5]);
	PostMessage(f->hwnd,_SKN_TXT,MAKELONG(6,0),(LPARAM)f->txt[6]);
	PostMessage(f->hwnd,_SKN_TXT,MAKELONG(7,0),(LPARAM)mdl->mstxt);
	PostMessage(f->hwnd,_SKN_TXT,MAKELONG(8,0),(LPARAM)f->txt[7]);
	PostMessage(f->hwnd,_SKN_TXT,MAKELONG(9,0),(LPARAM)f->txt[8]);
	PostMessage(f->hwnd,_SKN_TXT,MAKELONG(10,0),(LPARAM)f->txt[9]);
	PostMessage(f->hwnd,_SKN_TXT,MAKELONG(11,0),(LPARAM)f->txt[10]);*/

#undef mdl
}

void UpdateMDL(maindl *mdl)
{
	char str[1000];
	time_t tp,ct;
	time(&tp);
	ct=tp;
	int r=0;
	if (mdl->starttime) tp-=mdl->starttime;
	else tp=0;
	//if (tp==0) tp=1;
	if (tp && (mdl->sbytes/tp) && (mdl->rsize))
		r=(mdl->rsize-mdl->lbytes)/(mdl->sbytes/tp);
	else r=0;
	if (!mdl->starttime) r=0;
	mainftp *m=(mainftp*) mdl->guiparam;
	STATUSITEM *pitem= (STATUSITEM *) m->item;
	m->UpdateTray(r,ct);
	if (mdl->rsize)
	{
/*		double qq=(int) (localbytes0*1000.0/size0) /10.0;
		if (qq>110)
		{
			sprintf(str,"%sdebug.log",rundir);
			FILE*logf=fopen(str,"a+t");
			if (logf)
			{
				SYSTEMTIME st;
				GetSystemTime(&st);
				sprintf(str,"%d/%d/%d - %d:%d\n",st.wDay,st.wMonth,st.wYear,st.wHour,st.wMinute);
				fwrite(str,1,strlen(str),logf);
				sprintf(str,"size: %d\n",size0);
				fwrite(str,1,strlen(str),logf);
				sprintf(str,"locallost: %d\n",mdl->locallost);
				fwrite(str,1,strlen(str),logf);
				for (j=0;j<=mdl->splitdex;j++)
					if (!mdl->spdone[j])
					{
						sprintf(str,"split %d: %d\n",j,mdl->localbytes[j]);
						fwrite(str,1,strlen(str),logf);
					}
				HANDLE hh;
				WIN32_FIND_DATA ff;
				sprintf(str,"%s%s*",mdl->nfo->ldir,mdl->nfo->lfn);
				if ( (hh=FindFirstFile(str,&ff))!=INVALID_HANDLE_VALUE)
				do
				{
					FILE *fs;
					unsigned long size;
					fs=fopen(ff.cFileName,"rb");
					if (fs)
					{
						size=_filelength(_fileno(fs));
						fclose(fs);
					}
					else size=0;
					sprintf(str,"%s %d\n",ff.cFileName,size);
					fwrite(str,1,strlen(str),logf);
				} while (FindNextFile(hh,&ff));
				fclose(logf);
			}
			SendMessage(hwndg,WM_G_MAINSTOP,(WPARAM)mdl,0);
		}
*/
		sprintf(str,"%.1f kb",mdl->rsize/1024.0);
		if (strcmp(pitem->c[1],str))
			pitem->c[1]=ReDupString(pitem->c[1],str);
		sprintf(str,"%.1f%%",(int) (mdl->lbytes*1000.0/mdl->rsize) /10.0);
		if (strcmp(pitem->c[2],str))
			pitem->c[2]=ReDupString(pitem->c[2],str);
	}
	else
	{
		sprintf(str,"%.1f kb",mdl->lbytes/1024.0);
		if (strcmp(pitem->c[2],str))
			pitem->c[2]=ReDupString(pitem->c[2],str);
	}
	if (mdl->info)
	{
		if (mdl->resume)
			strcpy(str,GetSTR2(182,"Yes"));
		else strcpy(str,GetSTR2(183,"No"));
		dds2();
		if (strcmp(pitem->c[5],str))
			pitem->c[5]=ReDupString(pitem->c[5],str);
	}
	if (r)
	{
		sprintf(str,"%.2d:%.2d:%.2d",r/3600,(r%3600)/60,((r%3600)%60));
		if (strcmp(pitem->c[4],str))
			pitem->c[4]=ReDupString(pitem->c[4],str);
	}
	sprintf(str,"%.1f kb/s",mdl->cps/1024.0);
	if (strcmp(pitem->c[3],str))
		pitem->c[3]=ReDupString(pitem->c[3],str);
	if (!mdl->spliton)
		strcpy(str,"0 s");
	else sprintf(str,"%d s",ct-mdl->timeout);
	if (strcmp(pitem->c[6],str))
		pitem->c[6]=ReDupString(pitem->c[6],str);
	sprintf(str,"%d",mdl->prior);
	if (strcmp(pitem->c[7],str))
		pitem->c[7]=ReDupString(pitem->c[7],str);
	sprintf(str,"%s%s",mdl->mirrorhead->nfo->host,mdl->mirrorhead->nfo->rdir);
	if (strcmp(pitem->c[8],str))
		pitem->c[8]=ReDupString(pitem->c[8],str);
	if (strcmp(pitem->c[9],mdl->mstxt))
		pitem->c[9]=ReDupString(pitem->c[9],mdl->mstxt);

	UpdateList(pitem->mdl);

	if (m->mftp && m->mftp->hwnd)
		UpdateMainSmall(m->mftp,r,ct);

	if (m->htask && !mdl->done)
	{
		for (r=0;r<=mdl->splitdex;r++)
			if (!mdl->spdone[r])
				UpdateTask(mdl,r,-1);
		if (mdl->busydl)
			for (r=0;r<=mdl->hamdex;r++)
					UpdateTask(mdl,-1,r);
	}
}

void UpdateList(maindl *mdl)
{
	mainftp *m=(mainftp*) mdl->guiparam;
	if (m==NULL) return;
	int j;
	STATUSITEM *pitem= (STATUSITEM *)m->item;
	for (j=0;j<50;j++)
		if (m->itempos[j].hwndU)
			ListView_RedrawItems(m->itempos[j].hwndU,m->itempos[j].pos,m->itempos[j].pos);
/*
			for (i=0;i<10;i++)
				if (strcmp(pitem->c[i],pitem->cb[i]))
					ListView_SetItemText(m->itempos[j].hwndU,
							m->itempos[j].pos,i,LPSTR_TEXTCALLBACK);*/
/*	for (i=0;i<10;i++)
		if (strcmp(pitem->c[i],pitem->cb[i]))
		{
			ListView_SetItemText(hwndLV,pitem->pos,i,LPSTR_TEXTCALLBACK);
			pitem->cb[i]=ReDupString(pitem->cb[i],pitem->c[i]);
		}*/
	ListView_RedrawItems(hwndLV,pitem->pos,pitem->pos);
	//ImageList_ReplaceIcon(hlvicons,0,
	//					((mainftp*)(mdl->guiparam))->hIcon3);
/*	LV_ITEM it;
	memset(&it,0,sizeof(it));
	it.mask=LVIF_IMAGE;
	it.iImage=I_IMAGECALLBACK;
	it.iItem=pitem->pos;
	it.iSubItem=0;
	ListView_SetItem(hwndLV,&it);*/
}

void CreateTask(maindl* mdl,int sp,int hm)
{
	char str[1000];
	int j,pl,pos,i;
	if (sp!=-1) 
		i=sp;
	else 
		i=mdl->busydl->splitdex;
	LVITEM it;
	memset(&it,0,sizeof(it));
	it.mask = LVIF_TEXT | LVIF_PARAM;// | LVIF_IMAGE; 
	mainftp *m=(mainftp*) mdl->guiparam;
	if (sp!=-1)
	{
		pl=sp;
		if (m->tlastsp && m->tlasthm)
		{
			for (j=TOPMAXSPLIT;j<TOPMAXSPLIT+MAXHAMMER;j++)
				if (m->titem[j]) m->titem[j]->pos++;
		}
		m->tlastsp++;
		pos=m->tlastsp;
	}
	else
	{
		pl=TOPMAXSPLIT+hm;
		if (m->tlasthm)
		{
			m->tlasthm++;
			pos=m->tlasthm+m->tlastsp+2;
		}
		else
		{
			m->tlasthm++;
			pos=m->tlasthm+m->tlastsp+2;
			it.iItem=TOPMAXSPLIT+MAXHAMMER;
			it.iSubItem=0;
			strcpy(str,"");
			it.pszText=str;
			it.cchTextMax=strlen(str);
			ListView_InsertItem(m->hwndTV,&it);
			strcpy(str,GetSTR2(184,"Hammer tasks:"));
			dds2();
			it.pszText=str;
			it.cchTextMax=strlen(str);
			ListView_InsertItem(m->hwndTV,&it);
		}
	}
	STATUSITEM *pitem=(STATUSITEM*)malloc(sizeof(STATUSITEM));
	pitem->mdl=mdl;
	pitem->pos=pos;
	m->titem[pl]=pitem;
	it.iItem=pos;
	it.iSubItem=0;
	it.lParam=(LPARAM) pitem;
	it.iImage= I_IMAGECALLBACK;
	it.pszText=LPSTR_TEXTCALLBACK;
	j=ListView_InsertItem(m->hwndTV,&it);
	for (j=0;j<10;j++)
	{
		pitem->c[j]=DupString("");
		pitem->cb[j]=DupString(pitem->c[j]);
	}
}

void RemoveTask(maindl* mdl,int sp,int hm)
{
	int j,pl,pos;
	LVITEM it;
	memset(&it,0,sizeof(it));
	it.mask = LVIF_TEXT | LVIF_PARAM;// | LVIF_IMAGE; 
	mainftp *m=(mainftp*) mdl->guiparam;
	if (sp!=-1) pl=sp;
	else pl=TOPMAXSPLIT+hm;
	STATUSITEM *pitem=(STATUSITEM*)m->titem[pl];
	if (!pitem) return;
	if (sp!=-1)
	{
		if (m->tlasthm || (m->tlastsp!=pitem->pos))
		{
			for (j=0;j<TOPMAXSPLIT+MAXHAMMER;j++)
				if (m->titem[j] && (m->titem[j]->pos>pitem->pos))
					m->titem[j]->pos--;
		}
		m->tlastsp--;
	}
	else
	{
		if ((m->tlasthm+m->tlastsp+2)!=pitem->pos)
		{
			for (j=TOPMAXSPLIT;j<TOPMAXSPLIT+MAXHAMMER;j++)
				if (m->titem[j] && (m->titem[j]->pos>pitem->pos))
					m->titem[j]->pos--;
			m->tlasthm--;
		}
		else
		{
			m->tlasthm--;
			if (!m->tlasthm)
			{
				pos=m->tlastsp+1;
				ListView_DeleteItem(m->hwndTV,pos);
				ListView_DeleteItem(m->hwndTV,pos);
				pitem->pos-=2;
			}
		}
	}
	ListView_DeleteItem(m->hwndTV,pitem->pos);
	m->titem[pl]=NULL;
	for (j=0;j<10;j++)
	{
		if (pitem->c[j]!=NULL) free(pitem->c[j]);
		if (pitem->cb[j]!=NULL) free(pitem->cb[j]);
	}
	free(pitem);
}

void UpdateTask(maindl *mdl, int sp, int hm)
{
	char str[1000];
	int j,pl;
    basicdl *bdl;
	mainftp *m=(mainftp*) mdl->guiparam;
	if (sp!=-1) pl=sp;
	else pl=TOPMAXSPLIT+hm;
	if (!m->titem[pl])
		CreateTask(mdl,sp,hm);
	STATUSITEM *pitem=(STATUSITEM*)m->titem[pl];
	if (sp!=-1) 
	{
		bdl=mdl->splitdl[sp];
		j=sp;
	}
	else 
	{
		bdl=mdl->hamdl[hm];
		j=mdl->busydl->splitdex;
	}
	if ((sp!=-1) && mdl->sps[sp])
		sprintf(str,"%s (%ld) %ld-%ld",mdl->lfn,j,mdl->sps[sp],
										mdl->spe[sp]);
	else
		if (hm!=-1)
			sprintf(str,"%s (%ld)",mdl->lfn,j);
		else
			strcpy(str,mdl->lfn);
	if (strcmp(pitem->c[0],str))
		pitem->c[0]=ReDupString(pitem->c[0],str);
	if (sp!=-1)
	{
		if (mdl->rsize)
		{
			sprintf(str,"%.1f kb",(mdl->spe[sp]-mdl->sps[sp])/1024.0);
			if (strcmp(pitem->c[2],str))
				pitem->c[2]=ReDupString(pitem->c[2],str);
		}
		time_t tp,ts=0;
		int r;
		time(&tp);
		if (bdl!=NULL) ts=tp-bdl->starttime;
		if (mdl->spe[j]-mdl->sps[j])
		{
			sprintf(str,"%.1f%%",(int) (mdl->localbytes[sp]*1000.0/(mdl->spe[sp]-mdl->sps[sp])) /10.0);
			if (strcmp(pitem->c[3],str))
				pitem->c[3]=ReDupString(pitem->c[3],str);
			if (bdl!=NULL)
			{
				if (ts && (mdl->sessionbytes[sp]/ts))
					r=(mdl->spe[j]-mdl->sps[j]-mdl->localbytes[j])/(mdl->sessionbytes[j]/ts);
				else r=0;
				if (!bdl->starttime) r=0;
				if (r)
				{
					sprintf(str,"%.2d:%.2d:%.2d",r/3600,(r%3600)/60,((r%3600)%60));
					if (strcmp(pitem->c[5],str))
					pitem->c[5]=ReDupString(pitem->c[5],str);				pitem->c[4]=ReDupString(pitem->c[4],str);
				}
			}
		}
		else
		{
			if (sp!=-1)
			{
				sprintf(str,"%.1f kb",mdl->localbytes[sp]/1024.0);
				if (strcmp(pitem->c[3],str))
					pitem->c[3]=ReDupString(pitem->c[3],str);
			}
		}
		if (bdl!=NULL)
		{
			if (strcmp(pitem->c[1],bdl->mir->nfo->host))
				pitem->c[1]=ReDupString(pitem->c[1],bdl->mir->nfo->host);
			sprintf(str,"%.1f kb/s",bdl->cps/1024.0);
			if (strcmp(pitem->c[4],str))
				pitem->c[4]=ReDupString(pitem->c[4],str);

			sprintf(str,"%d s",tp-bdl->timeout);
			if (strcmp(pitem->c[6],str))
				pitem->c[6]=ReDupString(pitem->c[6],str);
		}
	}
	if (mdl->bstxt[pl])
		if (strcmp(pitem->c[7],mdl->bstxt[pl]))
			pitem->c[7]=ReDupString(pitem->c[7],mdl->bstxt[pl]);
/*	for (j=0;j<8;j++)
		if (strcmp(pitem->c[j],pitem->cb[j]))
		{
			ListView_SetItemText(m->hwndTV,pitem->pos,j,LPSTR_TEXTCALLBACK);
			pitem->cb[j]=ReDupString(pitem->cb[j],pitem->c[j]);
		}*/
	ListView_RedrawItems(m->hwndTV,pitem->pos,pitem->pos);
}

LPARAM GetLVlParam(HWND hwnd,int j)
{
	LVITEM it;
	it.mask = LVIF_PARAM;
	it.iItem=j;
	it.iSubItem=0;
	ListView_GetItem(hwnd,&it);
	return it.lParam;
}

int GetFtp(maindl *mdl,int j,int &s,int &h,bool &ex)
{
	mainftp *m=(mainftp*)mdl->guiparam;
	ex=true;
	s=-1;h=-1;
	if (!j || (j==m->tlastsp+1) || (j==m->tlastsp+2) || 
		(j>m->tlastsp+m->tlasthm+3))
		return 0;
	if (j<m->tlastsp+2)
	{
		for (s=0;s<TOPMAXSPLIT;s++)
			if (m->titem[s] && (m->titem[s]->pos==j)) break;
		if (s==TOPMAXSPLIT) return 0;
		if (!mdl->splitdl[s]) ex=false;
		return 1;
	}
	else
	{
		for (h=TOPMAXSPLIT;h<TOPMAXSPLIT+MAXHAMMER;h++)
			if (m->titem[h] && (m->titem[h]->pos==j)) break;
		if (h==TOPMAXSPLIT+MAXHAMMER) return 0;
		h-=TOPMAXSPLIT;
		if (!mdl->hamdl[h]) ex=false;
		return 1;
	}
	return 1;
}

int CALLBACK StatusCmpFunc(LPARAM lParam1,LPARAM lParam2,
								 LPARAM lParamSort)
{
	STATUSITEM *pitem1 = (STATUSITEM *) lParam1;
	STATUSITEM *pitem2 = (STATUSITEM *) lParam2;
	int i=0;
	_int16 col=LOWORD(lParamSort);
	_int16 s=HIWORD(lParamSort);
	if (!s) s=-1;
	if (col==1)
	{
		i=atoi(pitem1->c[1])-atoi(pitem2->c[1]);
		if (i) return i*s;
		if ((pitem1->c[1][0]=='?') && (pitem2->c[1][0]!='?'))
			return s*-1;
		if ((pitem2->c[1][0]=='?') && (pitem1->c[1][0]!='?'))
			return s;
	}
	if ((col==2) || (col==3) || (col==6) || (col==7))
	{
		i=atoi(pitem1->c[col])-atoi(pitem2->c[col]);
		if (i) return i*s;
	}

	if (col==4)
	{
		if ((pitem1->c[col][0]=='?') && (pitem2->c[col][0]!='?'))
			return s*-1;
		if ((pitem2->c[col][0]=='?') && (pitem1->c[col][0]!='?'))
			return s;
		if ((strlen(pitem1->c[col])>=8)&&(strlen(pitem2->c[col])>=8))
		{
			i=atoi(pitem1->c[col])-atoi(pitem2->c[col]);
			if (i) return i*s;
			i=atoi(&pitem1->c[col][3])-atoi(&pitem2->c[col][3]);
			if (i) return i*s;
			i=atoi(&pitem1->c[col][6])-atoi(&pitem2->c[col][6]);
			if (i) return i*s;
			col=0;
		}
	}
			
	if (col==5)
	{
		if ((pitem1->c[col][0]=='?') && (pitem2->c[col][0]!='?'))
			return s*-1;
		if ((pitem2->c[col][0]=='?') && (pitem1->c[col][0]!='?'))
			return s;
		i=pitem2->mdl->resume-pitem1->mdl->resume;
		if (i) return i*s;
		col=0;
	}

	if (col==9)
	{
		int s1=0,s2=0;
		for (i=0;i<=pitem1->mdl->splitdex;i++)
			if (pitem1->mdl->splitdl[i] && 
				(pitem1->mdl->splitdl[i]->status>s1))
				s1=pitem1->mdl->splitdl[i]->status;
		for (i=0;i<=pitem2->mdl->splitdex;i++)
			if (pitem2->mdl->splitdl[i] && 
				(pitem2->mdl->splitdl[i]->status>s2))
				s2=pitem2->mdl->splitdl[i]->status;
		i=s2-s1;
		if (i) return i*s;
		col=0;
	}

	i=lstrcmpi(pitem1->c[col],pitem2->c[col])*s;
	return (i != 0) ? i:
        lstrcmpi(pitem1->c[0],pitem2->c[0])*s;
}

void AddSerItem(server *ser)
{
	char str[1000];
	int j;
	SERVERITEM *pitem=(SERVERITEM*)malloc(sizeof(SERVERITEM));
	pitem->ser=ser;
	pitem->c[0]=ser->host;
	pitem->c[1]=DupString(itoa(ser->dls,str,10));
	pitem->c[2]=DupString(itoa(ser->actdl,str,10));
	pitem->c[3]=DupString(itoa(ser->actcon,str,10));
	pitem->c[4]=DupString(itoa(ser->logged,str,10));
	pitem->c[5]=DupString(itoa(ser->maxdl,str,10));
	pitem->c[6]=DupString(itoa(ser->maxcon,str,10));
	pitem->c[7]=DupString(GetSTR2(183,"No"));
	dds2();
	ser->guiparam=pitem;
	LVITEM it;
	memset(&it,0,sizeof(it));
	it.mask = LVIF_TEXT | LVIF_PARAM | LVIF_IMAGE; 
	pitem->pos=ListView_GetItemCount(hwndSV);
	it.iItem=pitem->pos;
	it.iSubItem=0;
	it.lParam=(LPARAM) pitem;
	it.iImage= 0;
	it.pszText=LPSTR_TEXTCALLBACK;
	j=ListView_InsertItem(hwndSV,&it);

	for (j=0;j<=7;j++)
		pitem->cb[j]=DupString(pitem->c[j]);
}

void UpdateSerList(server *ser)
{
	char str[1024];
//	int j;
	SERVERITEM *pitem= (SERVERITEM *)ser->guiparam;
	if (strcmp(pitem->c[1],itoa(ser->dls,str,10)))
		pitem->c[1]=ReDupString(pitem->c[1],itoa(ser->dls,str,10));
	if (strcmp(pitem->c[2],itoa(ser->actdl,str,10)))
		pitem->c[2]=ReDupString(pitem->c[2],itoa(ser->actdl,str,10));
	if (strcmp(pitem->c[3],itoa(ser->actcon,str,10)))
		pitem->c[3]=ReDupString(pitem->c[3],itoa(ser->actcon,str,10));
	if (strcmp(pitem->c[4],itoa(ser->logged,str,10)))
		pitem->c[4]=ReDupString(pitem->c[4],itoa(ser->logged,str,10));
	if (strcmp(pitem->c[5],itoa(ser->maxdl,str,10)))
		pitem->c[5]=ReDupString(pitem->c[5],itoa(ser->maxdl,str,10));
	if (strcmp(pitem->c[6],itoa(ser->maxcon,str,10)))
		pitem->c[6]=ReDupString(pitem->c[6],itoa(ser->maxcon,str,10));
	if (ser->only1ip) strcpy(str,GetSTR2(182,"Yes"));
	else strcpy(str,GetSTR2(183,"No"));
	dds2();
	if (strcmp(pitem->c[7],str))
		pitem->c[7]=ReDupString(pitem->c[7],str);
/*	for (j=0;j<8;j++)
		if (strcmp(pitem->c[j],pitem->cb[j]))
		{
			ListView_SetItemText(hwndSV,pitem->pos,j,LPSTR_TEXTCALLBACK);
			pitem->cb[j]=ReDupString(pitem->cb[j],pitem->c[j]);
		}*/
	ListView_RedrawItems(hwndSV,pitem->pos,pitem->pos);
}

void AddMirrorItem(mirrors *mir)
{
	char str[1024];
	int j;
	MIRRORITEM *pitem=(MIRRORITEM*)malloc(sizeof(MIRRORITEM));
	pitem->mir=mir;
	pitem->c[0]=mir->nfo->host;
	if (mir->nfo->prot==1)
		strcpy(str,"FTP");
	else strcpy(str,"HTTP");
	pitem->c[1]=DupString(str);
	pitem->c[2]=DupString("???");
	pitem->c[3]=DupString("???");
	pitem->c[4]=DupString("???");
	pitem->c[5]=DupString("???");
	pitem->c[6]=DupString("???");
	pitem->c[7]=DupString("0");
	pitem->c[8]=DupString("???");
	pitem->c[9]=DupString(GetSTR2(79,"Not verified yet"));
	dds2();
	mir->guiparam=pitem;
	LVITEM it;
	memset(&it,0,sizeof(it));
	it.mask = LVIF_TEXT | LVIF_PARAM | LVIF_IMAGE; 
	pitem->pos=ListView_GetItemCount(((mainftp*)mir->mdl->guiparam)->hwndMV);
	it.iItem=pitem->pos;
	it.iSubItem=0;
	it.lParam=(LPARAM) pitem;
	it.iImage= 0;
	it.pszText=LPSTR_TEXTCALLBACK;
	j=ListView_InsertItem(((mainftp*)mir->mdl->guiparam)->hwndMV,&it);
	for (j=0;j<=9;j++)
		pitem->cb[j]=DupString(pitem->c[j]);
}

void UpdateMirrorList(mirrors *mir)
{
	char str[1024];
//	int j;
	MIRRORITEM *pitem= (MIRRORITEM *)mir->guiparam;
	if (mir->nfo->prot==1)
		strcpy(str,"FTP");
	else strcpy(str,"HTTP");
	if (strcmp(pitem->c[1],str))
		pitem->c[1]=ReDupString(pitem->c[1],str);
	sprintf(str,"%.1f kb",mir->rsize/1024.0);
	if (mir->mdl->rsize && mir->rsize)
	{
		 if (mir->mdl->rsize==mir->rsize)
			 strcat(str,GetSTR2(185," MATCH"));
		 else strcat(str,GetSTR2(186," MISMATCH"));
		 dds2();
	}
	if (strcmp(pitem->c[2],str))
		pitem->c[2]=ReDupString(pitem->c[2],str);
	if (mir->resume)
		strcpy(str,GetSTR2(182,"Yes"));
	else strcpy(str,GetSTR2(183,"No"));
	dds2();
	if (strcmp(pitem->c[3],str))
		pitem->c[3]=ReDupString(pitem->c[3],str);
	sprintf(str,"%ld sec",mir->time2dl);
	if (strcmp(pitem->c[4],str))
		pitem->c[4]=ReDupString(pitem->c[4],str);
	sprintf(str,"%ld ms",mir->ping);
	if (strcmp(pitem->c[5],str))
		pitem->c[5]=ReDupString(pitem->c[5],str);
	sprintf(str,"%ld%%",mir->pinglost);
	if (strcmp(pitem->c[6],str))
		pitem->c[6]=ReDupString(pitem->c[6],str);
	if (strcmp(pitem->c[7],itoa(mir->used,str,10)))
		pitem->c[7]=ReDupString(pitem->c[7],itoa(mir->used,str,10));
	if (mir->only1ip)
		strcpy(str,GetSTR2(182,"Yes"));
	else strcpy(str,GetSTR2(183,"No"));
	dds2();
	if (strcmp(pitem->c[8],str))
		pitem->c[8]=ReDupString(pitem->c[8],str);
	if (strcmp(pitem->c[9],mir->status))
		pitem->c[9]=ReDupString(pitem->c[9],mir->status);
	PostMessage(((mainftp*)mir->mdl->guiparam)->hmirror,
		_SKN_TXTUP,MAKELONG(0,0),0);
/*	for (j=0;j<10;j++)
		if (strcmp(pitem->c[j],pitem->cb[j]))
		{
			ListView_SetItemText(((mainftp*)mir->mdl->guiparam)->hwndMV,
				pitem->pos,j,LPSTR_TEXTCALLBACK);
			pitem->cb[j]=ReDupString(pitem->cb[j],pitem->c[j]);
		}*/
	ListView_RedrawItems(((mainftp*)mir->mdl->guiparam)->hwndMV,pitem->pos,pitem->pos);
}
