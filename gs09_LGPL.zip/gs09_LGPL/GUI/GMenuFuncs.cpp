
#include "GUI.h"

BOOL CALLBACK RemoveDBFunc(HWND, UINT, WPARAM, LPARAM);
BOOL CALLBACK PropFunc(HWND, UINT, WPARAM, LPARAM);

void DoRemove(bool clip)
{
	int	r=0,ln=0,j;
	char str[1024],*p;
	HGLOBAL hgout=NULL;
	mainftp *m;
	if (clip)
	{
		j=ListView_GetNextItem(hwndLV,-1,LVNI_ALL|LVNI_SELECTED);
		while (j!=-1)
		{
			STATUSITEM *pitem = (STATUSITEM *) GetLVlParam(hwndLV,j);
			m=(mainftp*)pitem->mdl->guiparam;
			ConstURL(m->mdl->mirrorhead->nfo,str);
			ln=ln+strlen(str)+2;
			j=ListView_GetNextItem(hwndLV,j,LVNI_ALL|LVNI_SELECTED);
		}
		hgout=GlobalAlloc(GHND|GMEM_DDESHARE,(DWORD) ln);
		if (OpenClipboard(hwndgui)) EmptyClipboard();
		p=(char *)GlobalLock(hgout);
	}
	j=ListView_GetNextItem(hwndLV,-1,LVNI_ALL|LVNI_SELECTED);
	while (j!=-1)
	{
		STATUSITEM *pitem = (STATUSITEM *) GetLVlParam(hwndLV,j);
		m=(mainftp*)pitem->mdl->guiparam;
		if ((!m->mdl->spliton) || (MsgBox(
    		 GetSTR2(187,"Download is in progress.\nDo you wish to stop it?"),
					m->mdl->lfn, MB_ICONQUESTION|MB_YESNO)==IDYES))
		{
			dds2();
			if (m->mdl->lbytes && (r!=IDD_DELALL) && 
						(r!=IDD_LEAVEALL))
			r=DialogBoxParam(hlang,"REMOVEDB",hwndgui,
						(DLGPROC) RemoveDBFunc, (long) m->mdl);
			if (r==1) return;
			if (clip && p)
			{
				ConstURL(m->mdl->mirrorhead->nfo,str);
				strncpy(p,str,strlen(str));
				p=p+strlen(str);
			}
			switch (r)
			{
			case IDD_DELFILE:
			case IDD_DELALL:
				TELLDAEMON(RM_MDL,m->mdl,1);
				break;
			default:
				TELLDAEMON(RM_MDL,m->mdl,0);
			}
		}
		j=ListView_GetNextItem(hwndLV,j,LVNI_ALL|LVNI_SELECTED);
	}
	if (clip) 
	{
		if (p)
		{
			*p=0;
			if (gcfg.catchcb) ignoreclipboard=true;
			SetClipboardData(CF_TEXT,hgout);
		}
		CloseClipboard();
		GlobalFree(hgout);
	}
}

void DoCopyclip()
{
	int ln=0,j;
	j=ListView_GetNextItem(hwndLV,-1,LVNI_ALL|LVNI_SELECTED);
	maindl *mdl;
	HGLOBAL hgout;
	char str[1024],*p;
	while (j!=-1)
	{
		STATUSITEM *pitem = (STATUSITEM *) GetLVlParam(hwndLV,j);
		mdl=pitem->mdl;
		ConstURL(mdl->mirrorhead->nfo,str);
		ln=ln+strlen(str)+2;
		j=ListView_GetNextItem(hwndLV,j,LVNI_ALL|LVNI_SELECTED);
	}
	hgout=GlobalAlloc(GHND|GMEM_DDESHARE,(DWORD) ln);
	if (OpenClipboard(hwndgui)) EmptyClipboard();
	p=(char *)GlobalLock(hgout);
	if (p)
	{
		j=ListView_GetNextItem(hwndLV,-1,LVNI_ALL|LVNI_SELECTED);
		while (j!=-1)
		{
			STATUSITEM *pitem = (STATUSITEM *) GetLVlParam(hwndLV,j);
			mdl=pitem->mdl;
			ConstURL(mdl->mirrorhead->nfo,str);
			strncpy(p,str,strlen(str));
			p=p+strlen(str);
			j=ListView_GetNextItem(hwndLV,j,LVNI_ALL|LVNI_SELECTED);
		}
		*p=0;
	}
	if (gcfg.catchcb) ignoreclipboard=true;
	SetClipboardData(CF_TEXT,hgout);
	CloseClipboard();
	GlobalFree(hgout);
}

void DoProperties()
{
	maindl *mdl,*fmdl;
	int j;
	memset(prop,false,sizeof(prop));
	j=ListView_GetNextItem(hwndLV,-1,LVNI_ALL|LVNI_SELECTED);
	if (j!=-1)
	{
		STATUSITEM *pitem = (STATUSITEM *) GetLVlParam(hwndLV,j);
		fmdl=pitem->mdl;
	}
	else return;
	j=ListView_GetNextItem(hwndLV,j,LVNI_ALL|LVNI_SELECTED);
	while (j!=-1)
	{
		STATUSITEM *pitem = (STATUSITEM *) GetLVlParam(hwndLV,j);
		mdl=pitem->mdl;
		if (fmdl->mirrorhead->nfo->prot!=mdl->mirrorhead->nfo->prot) prop[0]=true;
		if (strcmp(fmdl->mirrorhead->nfo->host,mdl->mirrorhead->nfo->host)) prop[1]=true;
		if (fmdl->mirrorhead->nfo->port!=mdl->mirrorhead->nfo->port) prop[2]=true;
		if (strcmp(fmdl->mirrorhead->nfo->user,mdl->mirrorhead->nfo->user)) prop[3]=true;
		if (strcmp(fmdl->mirrorhead->nfo->pass,mdl->mirrorhead->nfo->pass)) prop[4]=true;
		if (strcmp(fmdl->mirrorhead->nfo->rdir,mdl->mirrorhead->nfo->rdir)) prop[5]=true;
		if (strcmp(fmdl->mirrorhead->nfo->rfn,mdl->mirrorhead->nfo->rfn)) prop[6]=true;
		if (strcmp(fmdl->ldir,mdl->ldir)) prop[7]=true;
		if (strcmp(fmdl->lfn,mdl->lfn)) prop[8]=true;
		j=ListView_GetNextItem(hwndLV,j,LVNI_ALL|LVNI_SELECTED);
	}
	PROPSHEETPAGE psp;
	PROPSHEETHEADER psh;
	psp.dwSize = sizeof(PROPSHEETPAGE)+10;
	psp.dwFlags = 0;
	psp.hInstance = hlang;
	psp.pszTemplate = "PROPERTIES";
	psp.pfnDlgProc = (DLGPROC) PropFunc;
	psp.lParam=(LPARAM) fmdl;
	psh.dwSize = sizeof(PROPSHEETHEADER);
	psh.dwFlags = PSH_PROPSHEETPAGE|PSH_NOAPPLYNOW;
	psh.hwndParent = hwndgui;
	psh.hInstance = hinst;
	if (prop[6])
		psh.pszCaption = (char*) GetSTR2(189,"Properties for selected files");
	else psh.pszCaption = (char*) fmdl->lfn;
	dds2();
	psh.nPages = 1;
	psh.nStartPage = 0;
	psh.ppsp = (LPCPROPSHEETPAGE) &psp;
	PropertySheet(&psh);
	dds2();
}

void Import()
{
	FILE *f;
	char str[1024],dldir[_MAX_PATH];
	f=NULL;
	maindl *mdl=NULL;
	OPENFILENAME ofn;
	char dh[MAX_PATH], *tmp;
	strcpy(dh,"download.gsl");
	memset(&ofn,0,sizeof(ofn));
	ofn.lStructSize=sizeof(ofn);
	ofn.hwndOwner=hwndgui;
	ofn.hInstance=hinst;
	ofn.lpstrFile=dh;
	ofn.nMaxFile=MAX_PATH;
	GetExtDir(dldir,"");
	ofn.lpstrInitialDir=dldir;
	ofn.Flags=OFN_PATHMUSTEXIST;
	ofn.lpstrDefExt="gsl";
	if (GetOpenFileName(&ofn))
	{
		f=fopen(ofn.lpstrFile,"rt");
		if (!f)
		{
			MsgBox(GetSTR2(190,"Can't open file. It probably doesn't exist."),
				ofn.lpstrFile,MB_OK);
			dds2();
			return;
		}
		mdl=NULL;
		while (fgets(str,1000,f))
		{
			if (strlen(str)) str[strlen(str)-1]=0;
			if (!strnicmp(str,"URL: ",5))
			{
				dlnfo *dln=ConvertURL(&str[5]);
				mdl=CheckDup(dln);
				if (mdl)
					AddMirror(mdl,dln);
				else
				{
					char ldir[1024];
					GetExtDir(ldir,dln->rfn);
					mdl=new maindl(dln,ldir,dln->rfn,1);
					//mdl->AddSer();
					mdl->CheckExist();
					//SendMessage(Hgui,WM_D_MAIN,(WPARAM) mdl,0);
					mdl->maxresumetimeout=cfg.resumeto;
					mdl->useproxy=GetProxy(dln->prot,1);
					mdl->dosplit=cfg.defsplit;
					mdl->ftpmode=0;
					mdl->prior=3;
					bool uh=cfg.usehammer,ur=cfg.useretry;
					if (uh)
						if (cfg.hammerfallback) ur=true;
						else ur=false;
					mdl->usehammer=uh;
					mdl->useretry=ur;
					mdl->usemaxbusytime=cfg.usemaxbusytime;
					mdl->usemaxbusyretry=cfg.usemaxbusyretry;
					mdl->usemaxhammertime=cfg.usemaxhammertime;
					mdl->usemaxhammerretry=cfg.usemaxhammerretry;
				}
			}
			if (!strnicmp(str,"File: ",6))
			{
				if (str[strlen(str)-1]==10) str[strlen(str)-1]='\0';
				tmp = strrchr(str, '\\' );
				if (!tmp)
				{
					if (mdl!=NULL)
					{
						mdl->lfn=ReDupString(mdl->lfn,&str[6]);
						mdl->ldir=ReDupString(mdl->ldir,"");
					}
				}
				else
				{
					if (tmp) tmp++;
					if (tmp) 
					{
						if (mdl!=NULL)
						{
							mdl->lfn=ReDupString(mdl->lfn,tmp);
							memset(tmp,0,strlen(mdl->lfn)+1);
							mdl->ldir=ReDupString(mdl->ldir,&str[6]);
						}
					}
				}
			}
			if (!strnicmp(str,"Alt: ",5))
			{
				dlnfo *dln=ConvertURL(&str[5]);
				if (mdl!=NULL)
					AddMirror(mdl,dln);
				delete dln;
			}
		}
		fclose(f);
	}
	SaveURLs();
}

void BrowseURL()
{
	int j;
	j=ListView_GetNextItem(hwndLV,-1,LVNI_ALL|LVNI_SELECTED);
	maindl *mdl;
	dlnfo *dln;
	while (j!=-1)
	{
		STATUSITEM *pitem = (STATUSITEM *) GetLVlParam(hwndLV,j);
		mdl=pitem->mdl;
		dln=new dlnfo(mdl->mirrorhead->nfo);
		dln->rfn=ReDupString(dln->rfn,"*.*");
		AddURL(dln,0,0,2,mdl->useproxy,0,mdl->maxresumetimeout,DEFPR,0,
			mdl->usehammer,mdl->useretry,mdl->checkint,mdl->smallint);
		j=ListView_GetNextItem(hwndLV,j,LVNI_ALL|LVNI_SELECTED);
	}
}

void ShowSmall(bool show)
{
	int i,j;
	j=ListView_GetItemCount(hwndLV);
	maindl *mdl;
	for (i=0;i<j;i++)
	{
		STATUSITEM *pitem = (STATUSITEM *) GetLVlParam(hwndLV,i);
		mdl=pitem->mdl;
		if (show && mdl->spliton)
			((mainftp*)mdl->guiparam)->mftp->SmallWin();
		else
			if (!show&&(((mainftp*)mdl->guiparam)->mftp->hwnd!=NULL))
				DestroyWindow(((mainftp*)mdl->guiparam)->mftp->hwnd);
	}
}

void ShowErr()
{
	int j;
	char str[1000];
	maindl *mdl;
	j=ListView_GetNextItem(hwndLV,-1,LVNI_ALL|LVNI_SELECTED);
	if (j!=-1)
	{
		STATUSITEM *pitem = (STATUSITEM *) GetLVlParam(hwndLV,j);
		mdl=pitem->mdl;
		if (strlen(mdl->ErrMsg))
		{
			sprintf(str,"%s\n%s",pitem->c[9],mdl->ErrMsg);
			MsgBox(str,mdl->lfn,
					MB_OK|MB_ICONEXCLAMATION|MB_SETFOREGROUND|MB_SYSTEMMODAL);
		}
		else
		{
			MsgBox(GetSTR2(191,"No error message available.")
				,mdl->lfn,MB_OK|MB_ICONEXCLAMATION|MB_SETFOREGROUND|MB_SYSTEMMODAL);
			dds2();
		}
	}
}
