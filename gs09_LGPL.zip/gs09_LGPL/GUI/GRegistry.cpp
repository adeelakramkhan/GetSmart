
#include "GUI.h"

int LoadGUIConfig()
{
	HKEY hkey=HKEY_CURRENT_USER;
	char subkey[]="Software\\GetSmart\\Config\\GSgui";
	DWORD result,r;
	r=RegCreateKeyEx(hkey,subkey,0, 0,REG_OPTION_NON_VOLATILE,
		KEY_ALL_ACCESS,NULL,&cfgkey,&result);
	if (r!=ERROR_SUCCESS)
	{
		MsgBox(GetSTR2(96,"Error reading configuration!"),0,MB_OK);
		dds2();
		return 0;
	}
	regkey=cfgkey;
	GetReg("FinishMessages",&gcfg.finishmsgs,sizeof(gcfg.finishmsgs));
	GetReg("ShowDLWin",&gcfg.showdlwin,sizeof(gcfg.showdlwin));
	GetReg("ShowDLTray",&gcfg.showdltray,sizeof(gcfg.showdltray));
	GetReg("StatusCol",&StatusCol,sizeof(StatusCol));
	GetReg("StatusRect",&StatusRect,sizeof(RECT));
	GetReg("ServerCol",&ServerCol,sizeof(ServerCol));
	GetReg("ServerRect",&ServerRect,sizeof(ServerRect));
	GetReg("MirrorCol",&MirrorCol,sizeof(MirrorCol));
	GetReg("MirrorRect",&MirrorRect,sizeof(MirrorRect));
	GetReg("TaskCol",&TaskCol,sizeof(TaskCol));
	GetReg("TaskRect",&TaskRect,sizeof(TaskRect));
	GetReg("WildCol",&WildCol,sizeof(WildCol));
	GetReg("BufferRect",&BufferRect,sizeof(BufferRect));
	GetReg("BrowseRect",&BrowseRect,sizeof(BrowseRect));
	GetReg("CatchClipboard",&gcfg.catchcb,sizeof(gcfg.catchcb));
	GetReg("ProxyShowTray",&gcfg.proxy_showtray,sizeof(gcfg.proxy_showtray));
	GetReg("CatchNS",&gcfg.catchns,sizeof(gcfg.catchns));
	GetReg("ShowDropbox",&gcfg.showdropbox,sizeof(gcfg.showdropbox));
	GetReg("DropBoxX",&gcfg.dropposx,sizeof(gcfg.dropposx));
	GetReg("DropBoxY",&gcfg.dropposy,sizeof(gcfg.dropposy));
	GetReg("ShowTT",&gcfg.showtt,sizeof(gcfg.showtt));
	GetReg("SmallDropbox",&gcfg.smalldrop,sizeof(gcfg.smalldrop));
	GetReg("TipMsgs",&tipmsgs,sizeof(tipmsgs));
	gcfg.skindir=GetReg("SkinDir",gcfg.skindir,0);
	GetReg("UseExternalSkin",&gcfg.useexskin,sizeof(gcfg.useexskin));
	gcfg.exskinfn=GetReg("SkinFileName",gcfg.exskinfn,0);
	GetReg("MaxBuffer",&gcfg.maxbuffer,sizeof(gcfg.maxbuffer));
	GetReg("MaxLastDL",&gcfg.maxlastdl,sizeof(gcfg.maxlastdl));
	GetReg("SmallTransparent",&gcfg.smalltrans,sizeof(gcfg.smalltrans));
	GetReg("SmallAlpha",&gcfg.smallalpha,sizeof(gcfg.smallalpha));
	GetReg("ListView",&gcfg.lv,sizeof(gcfg.lv));
	RegCloseKey(cfgkey);
	return 1;
}

int SaveGUIConfig()
{
#ifdef gsdbg
	return 0;
#endif
	HKEY hkey=HKEY_CURRENT_USER;
	char subkey[]="Software\\GetSmart\\Config\\GSgui";
	DWORD result,r;
	r=RegCreateKeyEx(hkey,subkey,0, 0,REG_OPTION_NON_VOLATILE,
		KEY_ALL_ACCESS,NULL,&cfgkey,&result);
	if (r!=ERROR_SUCCESS)
	{
		MsgBox(GetSTR2(97,"Error saving configuration!"),0,MB_OK);
		dds2();
		return 0;
	}	
	regkey=cfgkey;
	SetReg("FinishMessages",&gcfg.finishmsgs,sizeof(gcfg.finishmsgs));
	SetReg("ShowDLWin",&gcfg.showdlwin,sizeof(gcfg.showdlwin));
	SetReg("ShowDLTray",&gcfg.showdltray,sizeof(gcfg.showdltray));
	SetReg("StatusCol",&StatusCol,sizeof(StatusCol));
	SetReg("StatusRect",&StatusRect,sizeof(RECT));
	SetReg("ServerCol",&ServerCol,sizeof(ServerCol));
	SetReg("ServerRect",&ServerRect,sizeof(ServerRect));
	SetReg("MirrorCol",&MirrorCol,sizeof(MirrorCol));
	SetReg("MirrorRect",&MirrorRect,sizeof(MirrorRect));
	SetReg("TaskCol",&TaskCol,sizeof(TaskCol));
	SetReg("TaskRect",&TaskRect,sizeof(TaskRect));
	SetReg("WildCol",&WildCol,sizeof(WildCol));
	SetReg("BufferRect",&BufferRect,sizeof(BufferRect));
	SetReg("BrowseRect",&BrowseRect,sizeof(BrowseRect));
	SetReg("CatchClipboard",&gcfg.catchcb,sizeof(gcfg.catchcb));
	SetReg("ProxyShowTray",&gcfg.proxy_showtray,sizeof(gcfg.proxy_showtray));
	SetReg("CatchNS",&gcfg.catchns,sizeof(gcfg.catchns));
	SetReg("ShowDropbox",&gcfg.showdropbox,sizeof(gcfg.showdropbox));
	SetReg("DropBoxX",&gcfg.dropposx,sizeof(gcfg.dropposx));
	SetReg("DropBoxY",&gcfg.dropposy,sizeof(gcfg.dropposy));
	SetReg("ShowTT",&gcfg.showtt,sizeof(gcfg.showtt));
	SetReg("SmallDropbox",&gcfg.smalldrop,sizeof(gcfg.smalldrop));
	SetReg("TipMsgs",&tipmsgs,sizeof(tipmsgs));
	SetReg("SkinDir",gcfg.skindir);
	SetReg("UseExternalSkin",&gcfg.useexskin,sizeof(gcfg.useexskin));
	SetReg("SkinFileName",gcfg.exskinfn);
	SetReg("MaxBuffer",&gcfg.maxbuffer,sizeof(gcfg.maxbuffer));
	SetReg("MaxLastDL",&gcfg.maxlastdl,sizeof(gcfg.maxlastdl));
	SetReg("SmallTransparent",&gcfg.smalltrans,sizeof(gcfg.smalltrans));
	SetReg("SmallAlpha",&gcfg.smallalpha,sizeof(gcfg.smallalpha));
	SetReg("ListView",&gcfg.lv,sizeof(gcfg.lv));
	RegCloseKey(cfgkey);
	return 1;
}

int LoadLastDLs()
{
	char user[1024],pass[1024],addr[1024],sdir[1024],
		sfn[1024],ldir[1024],lfn[1024];
	int j;
	unsigned short prot,type=0;
	unsigned short port;
	LoadLDL=true;
	HKEY hkey=HKEY_CURRENT_USER,urlkey;
	char subkey[]="Software\\GetSmart\\Config\\GSgui",szurl[70];
	j=0;
	sprintf(szurl,"%s\\LastDL%ld",subkey,j);		
	while (RegOpenKeyEx(hkey,szurl,0,KEY_ALL_ACCESS,&urlkey)==ERROR_SUCCESS)
	{
		regkey=urlkey;
		GetReg("Protocol",&prot,sizeof(prot));
		GetReg("Host",addr);
		GetReg("Port",&port,sizeof(port));
		GetReg("UserName",user);
		GetReg("Password",pass);
		GetReg("RDirectory",sdir);
		GetReg("RFileName",sfn);
		GetReg("LocalDLDir",ldir);
		GetReg("LocalFileName",lfn);
		GetReg("DownloadType",&type,sizeof(type));
		dlnfo *nfo=new dlnfo(prot,addr,port, user,pass,sdir,sfn);
		short useproxy=GetProxy(nfo->prot,type);
		short prior=3,mode=0;
		time_t to=cfg.resumeto;
		bool ur=cfg.useretry,uh=cfg.usehammer;
		GetReg("UseProxy",&useproxy,sizeof(useproxy));
		GetReg("Priority",&prior,sizeof(prior));
		GetReg("TimeOut",&to,sizeof(to));
		GetReg("FTPMode",&mode,sizeof(mode));
		GetReg("UseHammer",&uh,sizeof(uh));
		GetReg("UseRetry",&ur,sizeof(ur));
		new lastdl(nfo,ldir,lfn,type,useproxy,to,prior,mode,uh,ur);
		RegCloseKey(urlkey);
		j++;
		sprintf(szurl,"%s\\LastDL%ld",subkey,j);		
	}
	LoadLDL=false;
	return 1;
}

int SaveLastDLs()
{
#ifdef gsdbg
	return 0;
#endif
	int j,r;
	HKEY hkey=HKEY_CURRENT_USER,urlkey;
	char subkey[]="Software\\GetSmart\\Config\\GSgui",szurl[70];
	lastdl *ldl=lastdlhead;
	j=0;
	while (ldl)
	{
		sprintf(szurl,"%s\\LastDL%ld",subkey,j);
		r=RegCreateKeyEx(hkey,szurl,0, 0,REG_OPTION_NON_VOLATILE,
			KEY_ALL_ACCESS,NULL,&urlkey,0);
		if (r==ERROR_SUCCESS)
		{
			regkey=urlkey;
			SetReg("Protocol",&ldl->nfo->prot,sizeof(ldl->nfo->prot));
			SetReg("Host",ldl->nfo->host);
			SetReg("Port",&ldl->nfo->port,sizeof(ldl->nfo->port));
			SetReg("UserName",ldl->nfo->user);
			SetReg("Password",ldl->nfo->pass);
			SetReg("RDirectory",ldl->nfo->rdir);
			SetReg("RFileName",ldl->nfo->rfn);
			SetReg("LocalDLDir",ldl->ldir);
			SetReg("LocalFileName",ldl->lfn);
			SetReg("FTPMode",&ldl->mode,sizeof(ldl->mode));
			SetReg("UseHammer",&ldl->uh,sizeof(ldl->uh));
			SetReg("UseRetry",&ldl->ur,sizeof(ldl->ur));
			SetReg("Proxy",&ldl->useproxy,sizeof(ldl->useproxy));
			SetReg("Priority",&ldl->prior,sizeof(ldl->prior));
			SetReg("TimeOut",&ldl->to,sizeof(ldl->to));
			SetReg("DownloadType",&ldl->type,sizeof(ldl->type));
			RegCloseKey(urlkey);
		}
		ldl=ldl->next;
		j++;
	}
	sprintf(szurl,"%s\\LastDL%ld",subkey,j);
	while (RegOpenKeyEx(hkey,szurl,0,KEY_ALL_ACCESS,&urlkey)==ERROR_SUCCESS)
	{
		RegCloseKey(urlkey);
		RegDeleteKey(hkey,szurl);
		j++;
		sprintf(szurl,"%s\\LastDL%ld",subkey,j);		
	}
	return 1;
}

