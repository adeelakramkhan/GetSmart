
#define _this_is_gui_
//#define WINVER 0x0500
#include "GUI.h"
#include "GDefaults.cpp"
#include "Drgdrpt.h"

char *sknormal;
char *skfast;
bool doexit=false;

int InitSmallSkin(Skinload &nfo);
void ShutDown();
void GetMainLVIcon(HICON &hIcon3,STATUSITEM *pitem,int&ic);

void ProxyOn();
void ProxyOff();

mylv lv,slv;

BOOL CALLBACK AddGSTable(HWND hdwnd, UINT message,
                         WPARAM wParam, LPARAM lParam);
BOOL CALLBACK DLGS(HWND hdwnd, UINT message,
                         WPARAM wParam, LPARAM lParam);

LRESULT CALLBACK GuiFunc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK TasksFunc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK BufferFunc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK SmallFunc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK PrevFunc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK ServerFunc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK MirrorFunc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK BrowseFunc(HWND, UINT, WPARAM, LPARAM);
LRESULT WINAPI NewLVProc(HWND, UINT, WPARAM, LPARAM);
BOOL CALLBACK AboutFunc(HWND, UINT, WPARAM, LPARAM);
BOOL CALLBACK ServerCfgFunc(HWND, UINT, WPARAM, LPARAM);
BOOL CALLBACK AddMirFunc(HWND, UINT, WPARAM, LPARAM);
BOOL CALLBACK SpeedLimitFunc(HWND, UINT, WPARAM, LPARAM);
BOOL CALLBACK ExportFunc(HWND, UINT, WPARAM, LPARAM);
BOOL CALLBACK ScheduleFunc(HWND, UINT, WPARAM, LPARAM);
BOOL CALLBACK OfferGSUL(HWND, UINT, WPARAM, LPARAM);
int CALLBACK StatusCmpFunc(LPARAM, LPARAM, LPARAM);
BOOL WINAPI ShortcutMenu(HWND hwnd, int x, int y);
BOOL WINAPI ShortcutMenu2(HWND hwnd, int x, int y,HWND hwndLV);
VOID APIENTRY DisplayGeneralMenu(HWND hwnd, POINT pt);
VOID APIENTRY DisplayItemMenu(HWND hwnd, POINT pt);
VOID APIENTRY DisplayItemMenu2(HWND hwnd, POINT pt);
VOID APIENTRY DisplayShowModeMenu(HWND hwnd,POINT pt);
VOID APIENTRY DisplayItemTrayMenu(HWND hwnd,POINT pt);
VOID APIENTRY DisplayStatusTrayMenu(HWND hwnd,POINT pt);
int CALLBACK WildCompareFunc(LPARAM lParam1,LPARAM lParam2,
								 LPARAM lParamSort);
void DoRemove(bool clip);
void DoCopyclip();
void DoProperties();
void BrowseURL();
void Import();
void ShowErr();
void ShowSmall(bool show);
int GetFtp(maindl *mdl,int j,int &s,int &h,bool &ex);
void GuiManagerFunc();
VOID CreateMainMenu();
VOID CreateBrowseMenu();

//#include <crtdbg.h>
HMENU hmmfile,hmmedit,hmmaction,hmmadvanced,hmmhelp,hmmrecent;
HMENU hbmconnection,hbmdownloads,hbmsession;

WNDCLASSEX wcx[9];

DWORD WINAPI InitGUI(DWORD d)
{
	MSG msg;
	HACCEL hAccel;
	RECT dr;

	Hserv=(HWND) d;
	HelpFile=(char*) malloc(strlen(rundir)+15);
	sprintf(HelpFile,"%sGetSmart.hlp",rundir);

	InitGuiCfg();
  
    memset(wcx,0,sizeof(wcx));

	wcx[0].cbSize = sizeof(WNDCLASSEX);
    wcx[0].style = CS_BYTEALIGNCLIENT|CS_BYTEALIGNWINDOW;
    wcx[0].lpfnWndProc = GuiFunc;
    wcx[0].cbClsExtra = 0;
    wcx[0].cbWndExtra = 0;
    wcx[0].hInstance = hinst;
    wcx[0].hIcon = LoadIcon(hlang, "AAAA");
    wcx[0].hCursor = LoadCursor(NULL, IDC_ARROW);
    wcx[0].hbrBackground = NULL;
    wcx[0].lpszMenuName =  NULL;
    wcx[0].lpszClassName = "GSGUI";
    wcx[0].hIconSm = NULL;
	if (!RegisterClassEx(&wcx[0])) return 0;

	wcx[1].cbSize = sizeof(WNDCLASSEX);
    wcx[1].style = CS_BYTEALIGNCLIENT|CS_BYTEALIGNWINDOW;
    wcx[1].lpfnWndProc = TasksFunc;
    wcx[1].cbClsExtra = 0;
    wcx[1].cbWndExtra = 0;
    wcx[1].hInstance = hinst;
    wcx[1].hIcon = LoadIcon(hlang, "AAAA");
    wcx[1].hCursor = LoadCursor(NULL, IDC_ARROW);
    wcx[1].hbrBackground = NULL;
    wcx[1].lpszMenuName =  NULL;//"TASKSMENU";
    wcx[1].lpszClassName = "GSTaskWin";
    wcx[1].hIconSm = NULL;
	if (!RegisterClassEx(&wcx[1])) return 0;

	wcx[2].cbSize = sizeof(WNDCLASSEX);
    wcx[2].style = CS_BYTEALIGNCLIENT|CS_BYTEALIGNWINDOW;
    wcx[2].lpfnWndProc = SmallFunc;
    wcx[2].cbClsExtra = 0;
    wcx[2].cbWndExtra = 0;
    wcx[2].hInstance = hinst;
    wcx[2].hIcon = LoadIcon(hlang, "AAAA");
    wcx[2].hCursor = LoadCursor(NULL, IDC_ARROW);
    wcx[2].hbrBackground = NULL;
    wcx[2].lpszMenuName =  NULL;
    wcx[2].lpszClassName = "GSSmallWin";
    wcx[2].hIconSm = NULL;
	if (!RegisterClassEx(&wcx[2])) return 0;

	wcx[3].cbSize = sizeof(WNDCLASSEX);
    wcx[3].style = CS_BYTEALIGNCLIENT|CS_BYTEALIGNWINDOW;
    wcx[3].lpfnWndProc = BufferFunc;
    wcx[3].cbClsExtra = 0;
    wcx[3].cbWndExtra = 0;
    wcx[3].hInstance = hinst;
    wcx[3].hIcon = LoadIcon(hlang, "AAAA");
    wcx[3].hCursor = LoadCursor(NULL, IDC_ARROW);
    wcx[3].hbrBackground = NULL;//(HBRUSH)GetStockObject(BLACK_BRUSH);
    wcx[3].lpszMenuName =  NULL;
    wcx[3].lpszClassName = "GSBufferWin";
    wcx[3].hIconSm = NULL;
	if (!RegisterClassEx(&wcx[3])) return 0;

	wcx[4].cbSize = sizeof(WNDCLASSEX);
    wcx[4].style = CS_BYTEALIGNCLIENT|CS_BYTEALIGNWINDOW;
    wcx[4].lpfnWndProc = PrevFunc;
    wcx[4].cbClsExtra = 0;
    wcx[4].cbWndExtra = 0;
    wcx[4].hInstance = hinst;
    wcx[4].hIcon = LoadIcon(hlang, "AAAA");
    wcx[4].hCursor = LoadCursor(NULL, IDC_ARROW);
    wcx[4].hbrBackground = NULL;
    wcx[4].lpszMenuName =  NULL;
    wcx[4].lpszClassName = "GSPrevWin";
    wcx[4].hIconSm = NULL;
	if (!RegisterClassEx(&wcx[4])) return 0;

	wcx[5].cbSize = sizeof(WNDCLASSEX);
    wcx[5].style = CS_BYTEALIGNCLIENT|CS_BYTEALIGNWINDOW;
    wcx[5].lpfnWndProc = ServerFunc;
    wcx[5].cbClsExtra = 0;
    wcx[5].cbWndExtra = 0;
    wcx[5].hInstance = hinst;
    wcx[5].hIcon = LoadIcon(hlang, "AAAA");
    wcx[5].hCursor = LoadCursor(NULL, IDC_ARROW);
    wcx[5].hbrBackground = NULL;
    wcx[5].lpszMenuName =  NULL;
    wcx[5].lpszClassName = "GSServerWin";
    wcx[5].hIconSm = NULL;
	if (!RegisterClassEx(&wcx[5])) return 0;

	wcx[6].cbSize = sizeof(WNDCLASSEX);
    wcx[6].style = CS_BYTEALIGNCLIENT|CS_BYTEALIGNWINDOW;
    wcx[6].lpfnWndProc = MirrorFunc;
    wcx[6].cbClsExtra = 0;
    wcx[6].cbWndExtra = 0;
    wcx[6].hInstance = hinst;
    wcx[6].hIcon = LoadIcon(hlang, "AAAA");
    wcx[6].hCursor = LoadCursor(NULL, IDC_ARROW);
    wcx[6].hbrBackground = NULL;
    wcx[6].lpszMenuName =  NULL;
    wcx[6].lpszClassName = "GSMirrorWin";
    wcx[6].hIconSm = NULL;
	if (!RegisterClassEx(&wcx[6])) return 0;

	wcx[7].cbSize = sizeof(WNDCLASSEX);
    wcx[7].style = CS_BYTEALIGNCLIENT|CS_BYTEALIGNWINDOW;
    wcx[7].lpfnWndProc = DropboxFunc;
    wcx[7].cbClsExtra = 0;
    wcx[7].cbWndExtra = 0;
    wcx[7].hInstance = hinst;
    wcx[7].hIcon = NULL;
    wcx[7].hCursor = LoadCursor(NULL, IDC_ARROW);
    wcx[7].hbrBackground = NULL;
    wcx[7].lpszMenuName =  NULL;
    wcx[7].lpszClassName = "GSDropbox";
    wcx[7].hIconSm = NULL;
	if (!RegisterClassEx(&wcx[7])) return 0;

	wcx[8].cbSize = sizeof(WNDCLASSEX);
    wcx[8].style = CS_BYTEALIGNCLIENT|CS_BYTEALIGNWINDOW;
    wcx[8].lpfnWndProc = BrowseFunc;
    wcx[8].cbClsExtra = 0;
    wcx[8].cbWndExtra = 0;
    wcx[8].hInstance = hinst;
    wcx[8].hIcon = LoadIcon(hlang, "AAAA");
    wcx[8].hCursor = LoadCursor(NULL, IDC_ARROW);
    wcx[8].hbrBackground = NULL;//(HBRUSH)GetStockObject(BLACK_BRUSH);
    wcx[8].lpszMenuName =  NULL;
    wcx[8].lpszClassName = "GSBrowseWin";
    wcx[8].hIconSm = NULL;
	if (!RegisterClassEx(&wcx[8])) return 0;

	LoadGUIConfig();

	if (!StatusRect.top && !StatusRect.left && !StatusRect.right &&
		!StatusRect.bottom)
	{
		dr.top=CW_USEDEFAULT;
		dr.left=CW_USEDEFAULT;
		dr.right=CW_USEDEFAULT;
		dr.bottom=CW_USEDEFAULT;
	}
	else 
	{
		dr=StatusRect;
		dr.right=StatusRect.right-StatusRect.left;
		dr.bottom=StatusRect.bottom-StatusRect.top;
	}

	InitSkins();

	CreateWindowEx(0,"GSGUI",
			"GetSmart",
			WS_OVERLAPPEDWINDOW,
			dr.left,
			dr.top,
			dr.right,
			dr.bottom,
			HWND_DESKTOP,
			NULL,
			hinst,
			(void*)&mainskinnfo);
	LoadLastDLs();

	if (!starttray)
	{
		ShowWindow(hwndgui,swstart);
		SetForegroundWindow(hwndgui);
	}
	
	hAccel=LoadAccelerators(hlang,"MYMENU");
	SetTimer(hwndgui,1,1000,NULL);

	UpdateWindow(hwndgui);

	while(GetMessage(&msg, NULL, 0, 0))
	{
		if (hgdlg)
			if (IsDialogMessage(hgdlg,&msg))
				continue;
		if (!TranslateAccelerator(hwndgui,hAccel,&msg))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}
	UnregisterClass("GSGUI",hinst);
	DeleteObject(wcx[0].hbrBackground);
	lv.kill();
	if (doexit) PostMessage(Hserv,WM_G_DESTROY,0,0);
	return msg.wParam;
}

LRESULT CALLBACK GuiFunc(HWND hwnd, UINT message,
                            WPARAM wParam, LPARAM lParam)
{
#define pm ((mainftp*)pitem->mdl->guiparam)
	char htxt[10][50],str[1024];
	static char LClip[500];
	static char sksplits[10];
	static int sortd[10]={1,0,0,0,0,0,0,1,1},lsortd=-1;
	static bool dbgreg=0;
	static mainftp *TrayM=NULL;
	maindl *mdl;
	basicdl *bdl;
	mainftp *m;
	smallftp *f;
	int j,i;
	STATUSITEM *pitem;
	LV_DISPINFO *pnmv;
	NOTIFYICONDATA pnid;
    //LPDRAWITEMSTRUCT lpdis;

	if (message>WM_USER+3000)
	{
		switch (message-WM_USER-3000)
		{
		case MDL_ADD:
			mdl=(maindl*)wParam;
			if ((mdl->type==4) || (mdl->type==6))
				break;
			m=new mainftp;
			m->mdl=mdl;
			mdl->guiparam=m;
			m->mftp=new smallftp;
			m->mftp->m=m;
			m->mftp->mftp=m->mftp;
			m->mftp->mdl=mdl;
			AddItem(hwndLV,mdl);
			break;
		case MDL_START:
			mdl=(maindl*)wParam;
			m=(mainftp*)mdl->guiparam;
			if (!m) break;
			if (m->blink)
			{
				m->RMItem();
				m->blink=false;
			}
			if (gcfg.showdlwin && (mdl->type!=5) && (mdl->type!=9) && (mdl->type!=10) || (mdl->type==2))
				if (m->mftp->hwnd==NULL) m->mftp->SmallWin();
			ListView_RedrawItems(hwndLV,m->item->pos,m->item->pos);
			for (j=0;j<50;j++)
				if (m->itempos[j].hwndU)
					ListView_RedrawItems(m->itempos[j].hwndU,
							m->itempos[j].pos,m->itempos[j].pos);
			break;
		case MDL_STOP:
			mdl=(maindl*)wParam;
			m=(mainftp*)mdl->guiparam;
			if (!m) break;
			if (gcfg.finishmsgs && (mdl->type==1))
				if (mdl->done || mdl->error.en)
					if (gcfg.showdltray)
					{
						m->blink=true;
						m->AddItem();
					}
			if (mdl->type==2) break;
			UpdateMDL(mdl);
			ListView_RedrawItems(hwndLV,m->item->pos,m->item->pos);
			for (j=0;j<50;j++)
				if (m->itempos[j].hwndU)
					ListView_RedrawItems(m->itempos[j].hwndU,
							m->itempos[j].pos,m->itempos[j].pos);
			if (m->htask!=NULL)
				DestroyWindow(m->htask);
			if (m->mftp->hbuffer!=NULL)
				DestroyWindow(m->mftp->hbuffer);
			if (m->mftp->kill)
			{
				m->mftp->kill=false;
				if (m->mftp->hwnd!=NULL)
					DestroyWindow(m->mftp->hwnd);
			}
			if (mdl->type==1)
			{
				if (gcfg.finishmsgs)
					if (mdl->done || mdl->error.en)
						if (!gcfg.showdltray)
							if (mdl->done || (m->mftp->hwnd==NULL))
								m->ShowMSG();
				if ((mdl->done || mdl->error.en) && hwnddropbox && 
					gcfg.showtt && ttip)
					m->ShowTTMSG();
			}
			//if (!mdl->done) TELLDAEMON(START_MDL,mdl,0);
			break;
		case MDL_RM:
			mdl=(maindl*)wParam;
			m=(mainftp*)mdl->guiparam;
			if (!m)
			{
				delete mdl;
				break;
			}
			UpdateMDL(mdl);
			ListView_RedrawItems(hwndLV,m->item->pos,m->item->pos);
			if (mdl->done && (mdl->type==1))
			{
				dlnfo *dln=new dlnfo (mdl->mirrorhead->nfo);
				lastdl *ldl=lastdlhead;
				while (ldl)
				{
					if (!stricmp(ldl->nfo->rfn,dln->rfn))
						break;
					ldl=ldl->next;
				}
				if (ldl==NULL)
					new lastdl(dln,mdl->ldir,mdl->lfn,mdl->type,
					mdl->useproxy,mdl->maxresumetimeout,mdl->prior,
					mdl->ftpmode,mdl->usehammer,mdl->useretry);
				else
					delete dln;
			}
			//bool dbgdone;
			//dbgdone=false;
			if (!m->blink || !mdl->done)
			{
				m->RMLV();
				//if (mdl->done) dbgdone=true;
				delete mdl;
			}
/*			if (!dbgdone)
			{
				AddURL(new dlnfo(1,"127.0.0.1",21,"anonymous","qwerty@host.com","/pub/","icq99a.exe"),
			   "d:\\",0,1,9,6,20,3,0,true,true,false,false);
			//	AddURL(new dlnfo(1,"ftp.infomall.co.il",21,"anonymous","qwerty@host.com","/","globes32.exe"),
			  // "d:\\",0,1,9,6,20,3,0,true,true,false,false);
				break;
			}
//			fclose(gfp);
			
			char *db,*sb;
			int r;
			db=(char*)malloc(100000);
			sb=(char*)malloc(100000);
			FILE *s,*d;
			s=fopen("d:\\tmp\\icq99a.exe","rb");
			d=fopen("d:\\icq99a.exe","rb");
			if (d)
			do
			{
				r=fread(sb,1,100000,s);
				if (!r) break;
				fread(db,1,r,d);
				if (memcmp(sb,db,r))
				{
					int dg;
					//MsgBox("ERROR - NOT compare",0,MB_OK);
					dg=2;
				}
			}while (r);
			fclose(s);
			if (d) fclose(d);
			free(db);
			free(sb);
			_unlink("d:\\icq99a.exe");
			gfp=fopen("d:\\tmp\\icq99a.exe","rb");
			//_unlink("d:\\gs\\gs08a\\debug\\GetSmart.log");
		AddURL(new dlnfo(1,"127.0.0.1",21,"anonymous","qwerty@host.com","/pub/","icq99a.exe"),
			   "d:\\",0,1,9,6,20,3,0,true,true,false,false);*/
			break;
		case BDL_START:
			bdl=(basicdl*)wParam;
			if (!bdl) break; // check that
			m=(mainftp*)bdl->mdl->guiparam;
			if (!m) break;
			f=new smallftp;
			f->m=m;
			f->mftp=m->mftp;
			f->mdl=bdl->mdl;
			f->bdl=bdl;
			bdl->guiparam=f;
			if ((bdl->type==2) && (!bdl->splitdex))
				f->hwndBB=m->mftp->hwndBB;
			if (bdl->type!=2) m->UpdateTrack();
			ListView_RedrawItems(hwndLV,m->item->pos,m->item->pos);
			if ((bdl->mdl->spliton==1) && (m->mftp->hbuffer!=NULL))
			{
				m->mftp->BufferWin();
				m->mftp->BufferWin();
			}
			break;
		case BDL_STOP:
			bdl=(basicdl*)wParam;
			m=(mainftp*) bdl->mdl->guiparam;
			if (!m)
			{
				delete bdl;
				break;
			}
			if (m->htask)
				RemoveTask(bdl->mdl,bdl->splitdex,bdl->hamdex);
			if (bdl->type!=2)
				m->UpdateTrack();
			f=(smallftp*)bdl->guiparam;
			if (f)
			{
				if ((bdl->type==2) && (!bdl->splitdex))
					f->hwndBB=NULL;				
				delete f;
			}
			delete bdl;
			break;
		case BUFF_ADD:
			bdl=(basicdl*)wParam;
			if (!bdl->guiparam) break;
			f=(smallftp *)bdl->guiparam;
			if (f->hwndBB!=NULL)
			{
				j=SendMessage(f->hwndBB,LB_ADDSTRING,0,
								(LPARAM)bdl->bufflast->txt);
				SendMessage(f->hwndBB, LB_SETITEMDATA, j,
					bdl->bufflast->txt[strlen(bdl->bufflast->txt)+1]);
				i=j;
				if ((unsigned)j>gcfg.maxbuffer)
				{
					if (f->autoscroll)
						SendMessage(f->hwndBB,LB_DELETESTRING,0,0);
					else
					{
						SendMessage(f->hwndBB,WM_SETREDRAW,0,0);
						j=SendMessage(f->hwndBB,LB_GETTOPINDEX,0,0);
						SendMessage(f->hwndBB,LB_DELETESTRING,0,0);
						if (j)
							SendMessage(f->hwndBB,LB_SETTOPINDEX,j-1,0);
						SendMessage(f->hwndBB,WM_SETREDRAW,1,0);
					}
				}
				if (f->autoscroll)
					SendMessage(f->hwndBB,LB_SELECTSTRING,(WPARAM)
						(i-2),(LPARAM) bdl->bufflast->txt);
			}
			break;
		case BUFF_RM:
			bdl=(basicdl*)wParam;
			if (!bdl->guiparam) break;
			f=(smallftp *)bdl->guiparam;
			if (f->hwndBB!=NULL)
				SendMessage(f->hwndBB,LB_DELETESTRING,0,0);
			break;
		case GOT_URL:
			GotURL((char *)wParam);
			free((char*)wParam);
			break;
		case GOT_IP:
			DialogBoxParam(hinst,"GSULOFFER",hwnd,(DLGPROC)OfferGSUL,wParam);
			free((char*)wParam);
			break;
		case UPDATE_MDL:
			mdl=(maindl*)wParam;
			m=(mainftp*)mdl->guiparam;
			if (!m) break;
			UpdateMDL(mdl);
			ListView_RedrawItems(hwndLV,m->item->pos,m->item->pos);
			for (j=0;j<50;j++)
				if (m->itempos[j].hwndU)
					ListView_RedrawItems(m->itempos[j].hwndU,
							m->itempos[j].pos,m->itempos[j].pos);
			if (cfg.robot)
				PostMessage(hwndgui,_SKN_BTSET,MAKELONG(3,0),1);
			else PostMessage(hwndgui,_SKN_BTSET,MAKELONG(3,0),0);
			break;
		case UPDATE_BAR:
			if (cfg.disconnect)
				PostMessage(hwnd,_SKN_BTSET,MAKELONG(9,0),1);
			else PostMessage(hwnd,_SKN_BTSET,MAKELONG(9,0),0);
			break;
		case SERVER_RM:
			server *ser;
			ser=(server *)wParam;
			if (hserver!=NULL)
				ListView_DeleteItem(hwndSV,
							((SERVERITEM*)ser->guiparam)->pos);
			delete ser;
			break;

		case MIRROR_RM:
			mirrors *mir;
			mir=(mirrors *)wParam;
			m=(mainftp*)mir->mdl->guiparam;
			if (m && (m->hmirror!=NULL))
				ListView_DeleteItem(m->hwndMV,
							((MIRRORITEM*)mir->guiparam)->pos);
			delete mir;
			break;

		case SHOW_TIP:
			if (hwnddropbox && gcfg.showtt && ttip)
				SendMessage(ttip->hwnd,POPTIP_TXTUPDATE,wParam,0);
			break;

// oyd11, 14 Nov 1999:
		case MK_NEW_BOX:
			static MyDropBox *mosheBox1;
			mosheBox1=new MosheBox;
			mosheBox1->init();
			break;
			

		case GBR_CLEAN:
			mdl=(maindl*)wParam;
			m=(mainftp*)mdl->guiparam;
			switch (mdl->type)
			{
			case 2:
				ListView_DeleteAllItems(m->hwndWV);
/*				if ((((browsedl*)mdl->splitdl[0])->btype==1) && (strlen(mdl->splitdl[0]->cwd)>1))
				{
					LV_ITEM it;
					it.mask = LVIF_TEXT | LVIF_PARAM | LVIF_IMAGE;
					it.iItem=0;
					it.iSubItem=0;
					WILDITEM *pitem = (WILDITEM *) malloc(sizeof(WILDITEM));
					pitem->c[0]=DupString("..");
					pitem->c[1]=DupString(" ");
					pitem->c[2]=DupString(" ");
					pitem->c[3]=DupString(" ");
					it.lParam=(LPARAM) pitem;
					it.pszText=LPSTR_TEXTCALLBACK;
					it.iImage=0;
					j=ListView_InsertItem(m->hwndWV,&it);
				}*/
				break;
			}
			break;

		case GBR_START:
			mdl=(maindl*)wParam;
			m=(mainftp*)mdl->guiparam;
			switch (mdl->type)
			{
			case 2:
				ShowWindow(GetDlgItem(m->mftp->hwnd,IDD_TIMEOUT),SW_HIDE);
				sprintf(str,"%s%s",mdl->mirrorhead->nfo->host,
						mdl->splitdl[0]->cwd);
				SetWindowText(m->mftp->hwnd,str);
				break;
			}
			break;

		case GBR_END:
			mdl=(maindl*)wParam;
			m=(mainftp*)mdl->guiparam;
			switch (mdl->type)
			{
			case 2:
				ShowWindow(GetDlgItem(m->mftp->hwnd,IDD_TIMEOUT),SW_SHOW);
				ListView_SortItems(m->hwndWV,
					WildCompareFunc,(LPARAM) MAKELONG(0,1));
				TELLGUI(GBR_UPDATE,mdl,0);
				break;
			}
			break;

		case GBR_ADDITEM:
			mdl=(maindl*)wParam;
			m=(mainftp*)mdl->guiparam;
			switch (mdl->type)
			{
			case 2:
				LV_ITEM it;
				clientlist *cl;
				cl=(clientlist*)lParam;
				WILDITEM *pitem2 = (WILDITEM *) malloc(sizeof(WILDITEM));
				pitem2->c[0]=DupString(cl->fn);
				sprintf(str,"%.1dk",cl->size/1024);
				pitem2->c[1]=DupString(str);
				pitem2->c[2]=DupString(cl->date);
				pitem2->c[3]=DupString(cl->attr);
				it.mask = LVIF_TEXT | LVIF_PARAM | LVIF_IMAGE; 
				it.iItem=ListView_GetItemCount(m->hwndWV);
				it.iSubItem=0;
				it.lParam=(LPARAM) pitem2;
				it.pszText=LPSTR_TEXTCALLBACK;
				if (cl->attr[0]=='d') it.iImage=0;
				else 
					if (cl->attr[0]=='l') it.iImage=1;
					else it.iImage=2;
				j=ListView_InsertItem(m->hwndWV,&it);
				break;
			}
			break;

		case GBR_UPDATE:
			mdl=(maindl*)wParam;
			m=(mainftp*)mdl->guiparam;
			switch (mdl->type)
			{
			case 2:
				SetDlgItemText(m->hwild,IDD_RDIR,((browsedl*)mdl->splitdl[0])->cwd);
				if (SendDlgItemMessage(m->hwild,IDD_RDIR,
					CB_FINDSTRINGEXACT,(WPARAM) -1,
					(LPARAM) ((browsedl*)mdl->splitdl[0])->cwd)==CB_ERR)
					SendDlgItemMessage(m->hwild,IDD_RDIR,CB_ADDSTRING,0, 
							(LPARAM) ((browsedl*)mdl->splitdl[0])->cwd);
				break;
			}
			break;

		case TASK_CRASH:
			pnid.cbSize=sizeof(NOTIFYICONDATA);
			pnid.hWnd=hwnd;
			pnid.uID=-2;
			pnid.uFlags=NIF_ICON|NIF_MESSAGE|NIF_TIP;
			pnid.uCallbackMessage=WM_USER+1;
			pnid.hIcon=LoadIcon(hlang,"AAAA");
			
			strcpy(pnid.szTip,"GetSmart - The Smartest Download Manager");
			Shell_NotifyIcon (NIM_ADD, &pnid);
			i=ListView_GetItemCount(hwndLV);
			for (j=0;j<i;j++)
			{
				STATUSITEM *pitem = (STATUSITEM *) GetLVlParam(hwndLV,j);
				if (pm)
					pm->ticon=0;
			}
			break;

		default:
			goto out;
		}
		return 0;
	}
out:
	if (lv.LVFunc(hwnd,message,wParam,lParam))
		return 0;
	LRESULT ret=mainskin.fn(hwnd,message,wParam,lParam);
	switch(message)
	{
	case WM_D_DESTROY:
		DestroyWindow(hwnd);
		break;
	case WM_ACTIVATE:
		if (IsWindow(hwndLV)) SetFocus(hwndLV);
		break;
	case WM_CREATE:
		OleInitialize(NULL);
		hwndgui=hwnd;
		CreateMainMenu();
		CreateBrowseMenu();
		SetMenu(hwnd,Hmenu);
		strcpy(htxt[0],GetSTR2(102,"File Name"));
		strcpy(htxt[1],GetSTR2(103,"Size"));
		strcpy(htxt[2],GetSTR2(106,"Progress"));
		strcpy(htxt[3],GetSTR2(107,"Current speed"));
		strcpy(htxt[4],GetSTR2(108,"Est. Time Left"));
		strcpy(htxt[5],GetSTR2(109,"Resume"));
		strcpy(htxt[6],GetSTR2(110,"Timeout"));
		strcpy(htxt[7],GetSTR2(111,"Priority"));
		strcpy(htxt[8],GetSTR2(112,"URL"));
		strcpy(htxt[9],GetSTR2(113,"Status"));
		dds2();
		lv.pos.top=40;
		lv.pos.bottom=-40;
		lv.usewall=gcfg.lv.bkwallpaper;
		lv.loadbkbmp=gcfg.lv.bkload;
		strcpy(lv.bkfn,gcfg.lv.bkfn);
		lv.dynbg=gcfg.lv.dynbk;
		lv.bkclr=gcfg.lv.bkclr;
		lv.fgclr=gcfg.lv.txtclr;
		lv.fgclr2=gcfg.lv.txtclr2;
		lv.hdclr=gcfg.lv.hdclr;
		lv.hdclr2=gcfg.lv.hdclr2;
		lv.glassclr=gcfg.lv.glassclr;

		lv.Init(hwnd,&htxt[0][0],&StatusCol[0],10);
		hwndLV=lv.hwndLV;
		//hwndLV=DoCreateList(hwnd,&htxt[0][0],&StatusCol[0],10,true,1);

		HICON hiconItem;
		hlvicons = ImageList_Create(GetSystemMetrics(SM_CXSMICON),
			GetSystemMetrics(SM_CYSMICON),ILC_COLOR8|ILC_MASK,7,1);
		hiconItem = LoadIcon(hlang, "MAIN1ICON");
		ImageList_AddIcon(hlvicons, hiconItem);
		DeleteObject(hiconItem);
		hiconItem = LoadIcon(hlang, "MAIN2ICON");
		ImageList_AddIcon(hlvicons, hiconItem);
		DeleteObject(hiconItem);
		hiconItem = LoadIcon(hlang, "MAIN3ICON");
		ImageList_AddIcon(hlvicons, hiconItem);
		DeleteObject(hiconItem);
		hiconItem = LoadIcon(hlang, "MAIN4ICON");
		ImageList_AddIcon(hlvicons, hiconItem);
		DeleteObject(hiconItem);
		hiconItem = LoadIcon(hlang, "ROBOTICON");
		ImageList_AddIcon(hlvicons, hiconItem);
		DeleteObject(hiconItem);
		hiconItem = LoadIcon(hlang, "SUCCESSICON");
		ImageList_AddIcon(hlvicons, hiconItem);
		DeleteObject(hiconItem);
		hiconItem = LoadIcon(hlang, "ERRORICON");
		ImageList_AddIcon(hlvicons, hiconItem);
		DeleteObject(hiconItem);
		hiconItem = LoadIcon(hlang, "AAAA");
		ImageList_AddIcon(hlvicons, hiconItem);
		DeleteObject(hiconItem);
		ListView_SetImageList(hwndLV, hlvicons, LVSIL_SMALL);
		//Hmenu=GetMenu(hwnd);
		if (cfg.robot)
			PostMessage(hwnd,_SKN_BTSET,MAKELONG(3,0),1);
			else CheckMenuItem(Hmenu,IDM_AUTODL,MF_UNCHECKED);
		if (!cfg.disconnect)
			CheckMenuItem(Hmenu,IDM_DISCONNECT,MF_UNCHECKED);
		else PostMessage(hwnd,_SKN_BTSET,MAKELONG(9,0),1);
		if (gcfg.finishmsgs)
			PostMessage(hwnd,_SKN_BTSET,MAKELONG(5,0),1);
		if (cfg.usegsul)
			PostMessage(hwnd,_SKN_BTSET,MAKELONG(13,0),1);
		if (gcfg.catchcb) CatchCB();
		else CheckMenuItem(Hmenu,IDM_CATCHCLIPBOARD,MF_UNCHECKED);
		if (gcfg.showdropbox) Dropbox();
		SendMessage(hwnd,WM_COMMAND,WM_SIZE,0);
		
		// tell daemon we're alive
		SendMessage(Hserv,WM_G_HWND,(WPARAM)hwnd,0);

		PostMessage(hwnd,_SKN_TXT,MAKELONG(0,0),(LPARAM)sknormal);
		PostMessage(hwnd,_SKN_TXT,MAKELONG(1,0),(LPARAM)skfast);
		strcpy(sksplits,"1");
		PostMessage(hwnd,_SKN_TXT,MAKELONG(2,0),(LPARAM)sksplits);
		memset(&pnid,0,sizeof(NOTIFYICONDATA));
		pnid.cbSize=sizeof(NOTIFYICONDATA);
		pnid.hWnd=hwnd;
		pnid.uID=-2;
		pnid.uFlags=NIF_ICON|NIF_MESSAGE|NIF_TIP;
		pnid.uCallbackMessage=WM_USER+1;
		pnid.hIcon=LoadIcon(hlang,"AAAA");
		strcpy(pnid.szTip,"GetSmart - The Smartest Download Manager");
		Shell_NotifyIcon (NIM_ADD, &pnid );
		if (!tipmsgs[0] && hwnddropbox && gcfg.showtt && ttip)
		{
			tipmsgs[0]=true;
			SendMessage(ttip->hwnd,POPTIP_TXTUPDATE,(WPARAM)GetSTR2(194,"Hello! I'm your little \"thingy\"\nMove with your mouse and touch me to see what am I"),MAKELONG(500,7000));
			dds2();
			SaveGUIConfig();
		}
		break;

/*	case WM_PAINT:
	static BOOL (STDAPICALLTYPE* UpdateLayeredWindowx)(
	  HWND hwnd,              // handle to the layered window
	  HDC hdcDst,             // handle to the screen device context
	  POINT *pptDst,          // specifies the new screen position
	  SIZE *psize,            // specifies the new size of the layered window
	  HDC hdcSrc,             // handle to the surface device context
	  POINT *pptSrc,          // specifies the layer position
	  COLORREF crKey,         // specifies the color key
	  BLENDFUNCTION *pblend,  // pointer to the blend function
	  DWORD dwFlags           // flags
	);
	if (!UpdateLayeredWindowx)
	{
		HINSTANCE hin;
		hin=LoadLibrary("user32.dll");
		UpdateLayeredWindowx= (BOOL (STDAPICALLTYPE*)(	  HWND hwnd,              // handle to the layered window
	  HDC hdcDst,             // handle to the screen device context
	  POINT *pptDst,          // specifies the new screen position
	  SIZE *psize,            // specifies the new size of the layered window
	  HDC hdcSrc,             // handle to the surface device context
	  POINT *pptSrc,          // specifies the layer position
	  COLORREF crKey,         // specifies the color key
	  BLENDFUNCTION *pblend,  // pointer to the blend function
	  DWORD dwFlags           // flags
	))		GetProcAddress(hin,"UpdateLayeredWindow");
		POINT pt1,pt2;
		SIZE sz;
		sz.cx=100;
		sz.cy=100;
		pt1.x=0;
		pt1.y=0;
		pt2.x=0;
		pt2.y=0;
		BLENDFUNCTION bf;
		bf.BlendOp=AC_SRC_OVER;
		bf.BlendFlags=0;
		bf.SourceConstantAlpha=190;
		bf.AlphaFormat=0x01;//AC_SRC_ALPHA
		UpdateLayeredWindowx(hwnd,NULL,0,0(HDC)wParam,&pt2,0,&bf,0x00000002);//ULW_ALPHA
		//FreeLibrary(hin);
	}
	break;*/

	case WM_SIZE:
		if (wParam==SIZE_MINIMIZED) break;
		RECT rc;
        GetClientRect(hwndgui, &rc);
		//SetWindowPos(hwndLV,0,rc.left,rc.top+40,rc.right,rc.bottom-40,SWP_SHOWWINDOW|SWP_NOZORDER);
 		break;

	case WM_MOVE:
		RECT re;
		GetClientRect(hwnd,&re);
		if (!re.bottom && !re.right) break;
		GetWindowRect(hwnd,&StatusRect);
		break;
 
    case WM_HELP:
		if (((LPHELPINFO) lParam)->iContextType==HELPINFO_MENUITEM)
		{
			for (j=0;j<4;j++)
				if (GetSubMenu(Hmenu,j)==((LPHELPINFO) lParam)->hItemHandle)
				{
					WinHelp(hwnd,HelpFile,HELP_CONTEXT , j+10);
					break;
				}
			break;
		}
		PostMessage(hwnd,WM_COMMAND,IDM_HELP,0);
		break;

	case WM_RBUTTONUP:
		if (HIWORD(lParam)<40)
				if (mainskinnfo.bover!=-1)
					WinHelp(hwnd, HelpFile, 
							HELP_CONTEXTPOPUP,40+mainskinnfo.bover);
		break;
	case WM_CONTEXTMENU:
		if (!ShortcutMenu(hwnd, LOWORD(lParam), HIWORD(lParam))) 
			return DefWindowProc(hwnd, message, wParam, lParam);
		break;
	case WM_USER+1:
		if (lParam==WM_RBUTTONDOWN)
		{ 
			POINT pt;
			GetCursorPos(&pt);
			//ShowWindow(hwnd,SW_HIDE);
			//BringWindowToTop(HWND_DESKTOP);
			//SetForegroundWindow(HWND_DESKTOP);
			//SetWindowPos(hwnd,0,0,0,0,0,SWP_NOACTIVATE|SWP_NOMOVE|SWP_NOSIZE);
			DisplayStatusTrayMenu(hwnd,pt);
			break;
		}
		if (lParam==WM_LBUTTONDBLCLK)
		{
			ShowWindow(hwnd,SW_SHOW);
			ShowWindow(hwnd,SW_RESTORE);
			SetForegroundWindow(hwnd);
		}
		break;
	case TRAY_MSG:
		mdl=(maindl*)wParam;
		m=(mainftp *)mdl->guiparam;
		if (lParam==WM_RBUTTONDOWN)
		{ 
			POINT pt;
			GetCursorPos(&pt);
			//BringWindowToTop(hwndg);
			//SetForegroundWindow(hwndg);
			TrayM=m;
			DisplayItemTrayMenu(hwnd,pt);
			break;
		}
		if (lParam==WM_LBUTTONDBLCLK)
		{
			if (m->blink)
			{
				m->RMItem();
				m->RemoveTray();
				m->blink=false;
				if (!m->skipmsg)
					m->ShowMSG();
				else m->skipmsg=false;
				if (mdl->done)
				{
					m->RMLV();
					delete mdl;
				}
				else
					if (m->mftp->hwnd!=NULL)
						DestroyWindow(m->mftp->hwnd);
			}
			else m->mftp->SmallWin();
		}
		break;

	case WM_NOTIFY:
		if (((LPNMHDR) lParam)->code==-307)
		{
			for (j=0;j<10;j++)
				StatusCol[j]=ListView_GetColumnWidth(hwndLV,j);
			break;
		}
		if (((LPNMHDR) lParam)->code==TTN_NEEDTEXT)
		{
			LPTOOLTIPTEXT lpttt;
			lpttt = (LPTOOLTIPTEXT) lParam;
			lpttt->hinst = hinst;
			int idButton = lpttt->hdr.idFrom;
			switch (idButton)
			{
				case 0:
					strcpy(str,GetSTR2(195,"Start downloading"));
					lpttt->lpszText = str;
					break;
				case 1:
					strcpy(str,GetSTR2(196,"Pause selected download"));
					lpttt->lpszText = str;
					break;
				case 2:
					strcpy(str,GetSTR2(197,"Pause all downloads"));
					lpttt->lpszText = str;
					break;
				case 3:
					strcpy(str,GetSTR2(198,"Enable/Disable Smart Pilot"));
					lpttt->lpszText = str;
					break;
				case 4:
					strcpy(str,GetSTR2(199,"Show download window / tray icon"));
					lpttt->lpszText = str;
					break;
				case 5:
					strcpy(str,GetSTR2(200,"Show pop up message when a download is finished"));
					lpttt->lpszText = str;
					break;
				case 6:
					strcpy(str,GetSTR2(201,"Show/Hide Server manager"));
					lpttt->lpszText = str;
					break;
				case 7:
					strcpy(str,GetSTR2(202,"Change speed limit"));
					lpttt->lpszText = str;
					break;
				case 8:
					strcpy(str,GetSTR2(203,"Open the browser"));
					lpttt->lpszText = str;
					break;
				case 9:
					strcpy(str,GetSTR2(204,"Hangup when done"));
					lpttt->lpszText = str;
					break;
				case 10:
					strcpy(str,GetSTR2(205,"Shutdown computer when done"));
					lpttt->lpszText = str;
					break;
				case 11:
					strcpy(str,GetSTR2(206,"Redial if disconnected"));
					lpttt->lpszText = str;
					break;
				case 12:
					strcpy(str,GetSTR2(207,"Schedule Downloads / Hangups"));
					lpttt->lpszText = str;
				case 13:
					strcpy(str,GetSTR2(346,"Allow send/retrieval of files"));
					lpttt->lpszText = str;
					break;
			}
			dds2();
			break;
		}

		if (((LPNMHDR) lParam)->hwndFrom==hwndLV)
			switch (((LPNMHDR) lParam)->code)
			{
			case LVN_DELETEALLITEMS:
				i=ListView_GetItemCount(hwndLV);
				for (j=i-1;j>=0;j--)
					ListView_DeleteItem(hwndLV,j);
				break;
			case LVN_DELETEITEM:
				NM_LISTVIEW *p;
		 		p = (NM_LISTVIEW FAR *) lParam;
				pitem = (STATUSITEM *) p->lParam;
				m=(mainftp*)pitem->mdl->guiparam;
				mdl=pitem->mdl->next;
				delete m;
				for (j=1;j<10;j++)
					free(pitem->c[j]);
				for (j=0;j<10;j++)
					free(pitem->cb[j]);
				j=pitem->pos;
				i=ListView_GetItemCount(hwndLV);
				free(pitem);
				int j2;
				for (j2=j+1;j2<i;j2++)
				{
					pitem=(STATUSITEM *) GetLVlParam(hwndLV,j2);
					if (pitem->mdl->guiparam)
						((mainftp*)pitem->mdl->guiparam)->item->pos--;
				}
				break;
			case LVN_COLUMNCLICK:
#define pnm ((NM_LISTVIEW *) lParam)
				if (pnm->iSubItem==lsortd)
				{
					if (sortd[pnm->iSubItem]) sortd[pnm->iSubItem]=0;
					else sortd[pnm->iSubItem]=1;
				}
				else lsortd=pnm->iSubItem;
				ListView_SortItems(pnm->hdr.hwndFrom,StatusCmpFunc,
					(LPARAM) MAKELONG(pnm->iSubItem,sortd[pnm->iSubItem]));
				for (j=0;j<ListView_GetItemCount(hwndLV);j++)
				{
					STATUSITEM *pitem = (STATUSITEM *) GetLVlParam(hwndLV,j);
					pitem->pos=j;
				}
				break;
#undef pnm
			case LVN_GETDISPINFO:
				pnmv=(LV_DISPINFO *) lParam;
/*				if (pnmv->item.mask & LVIF_TEXT) 
				{
					STATUSITEM *pitem = (STATUSITEM *)(pnmv->item.lParam);
					if (!pnmv->item.iSubItem) pitem->c[0]=pitem->mdl->lfn;
					if ((strlen(pitem->c[pnmv->item.iSubItem])+1)>(unsigned)pnmv->item.cchTextMax)
					{
						strncpy(pnmv->item.pszText,pitem->c[pnmv->item.iSubItem],
								pnmv->item.cchTextMax-1);
						pnmv->item.pszText[pnmv->item.cchTextMax-1]='\0';
					}
					else
						lstrcpy(pnmv->item.pszText,pitem->c[pnmv->item.iSubItem]);
				}*/
				if (pnmv->item.mask & LVIF_IMAGE)
				{
					STATUSITEM *pitem = (STATUSITEM *)(pnmv->item.lParam);
					if (pitem->mdl->spliton)
					{
//						ImageList_ReplaceIcon(hlvicons,0,
//							((mainftp*)(pitem->mdl->guiparam))->hIcon3);
						//pnmv->item.iImage=((mainftp*)(pitem->mdl->guiparam))->lvimagepos;
						switch (pitem->mdl->type)
						{
						case 2:
							pnmv->item.iImage=2;
							break;
						case 5:
							pnmv->item.iImage=3;
							break;
						case 9:
						case 10:
							pnmv->item.iImage=7;
							break;
						default:
							pnmv->item.iImage=1;
							if (pm->mftp->hwnd!=NULL)
								PostMessage(pm->mftp->hwnd,_SKN_BTSET,MAKELONG(7,0),0);
						}
					}
					else
						if (pitem->mdl->done)
						{
							pnmv->item.iImage=5;
							if (pm->mftp->hwnd!=NULL)
								PostMessage(pm->mftp->hwnd,_SKN_BTSET,MAKELONG(7,0),2);
						}
						else
							if (pitem->mdl->error.en && pitem->mdl->wait)
							{
								pnmv->item.iImage=6;
								if (pm->mftp->hwnd!=NULL)
									PostMessage(pm->mftp->hwnd,_SKN_BTSET,MAKELONG(7,0),3);
							}
							else
								if (pitem->mdl->wait)
									pnmv->item.iImage=4;
								else
								{
									pnmv->item.iImage=0;
									if (pm->mftp->hwnd!=NULL)
										PostMessage(pm->mftp->hwnd,_SKN_BTSET,MAKELONG(7,0),1);
								}
				}
				break; 
			case NM_DBLCLK:
				PostMessage(hwnd,WM_COMMAND,IDM_DOWNLOAD,0);
				break;
			case LVN_ITEMCHANGED:
				if (!ListView_GetSelectedCount(hwndLV))
				{
					if (enablemenu)
					{
						enablemenu=false;
						for (j=0;j<enablecount;j++)
							EnableMenuItem(Hmenu,enableitem[j],MF_GRAYED);
					}
				}
				else 
				{
					if (!enablemenu)
					{
						enablemenu=true;
						for (j=0;j<enablecount;j++)
							EnableMenuItem(Hmenu,enableitem[j],MF_ENABLED);
					}
					j=ListView_GetNextItem(hwndLV,-1,
										LVNI_ALL|LVNI_SELECTED);
					if (j!=-1)
					{
						STATUSITEM *pitem = (STATUSITEM *) GetLVlParam(hwndLV,j);
						if (pitem->mdl->spliton)
							PostMessage(hwnd,_SKN_TRJMP,MAKELONG(0,0),
												pitem->mdl->spliton);
					}
				}
				break;
			case LVN_KEYDOWN:
				LV_KEYDOWN *k;
				k= (LV_KEYDOWN FAR *) lParam;
				switch (k->wVKey)
				{
				case 65:
					//ProxyOff();
	//DialogBox(hinst,"GSULTABLE",hwnd,(DLGPROC)AddGSTable);

/*	new gsdltable(cfg.beproxy.ip,0,"test","e:\\","myprg.zip");
	AddURL(new dlnfo(2,"127.0.0.1",GSULPORT,"anonymous",
		cfg.Email,"","test"),"c:\\",
		"test.zip",7,9,0,cfg.resumeto,DEFPR,0,false,false,0,0);*/

					break;
					if (dbgreg)
						((basicdl*)NULL)->CalcCps(777);
/*
struct MLVCOLUMN
{
    UINT mask;
    int fmt;
    int cx;
    LPSTR pszText;
    int cchTextMax;
    int iSubItem;
    int iImage;
    int iOrder;
};

	MLVCOLUMN lvc; 
    int iCol;
#define LVCF_ORDER              0x0020
    lvc.mask = LVCF_ORDER ;
    lvc.fmt = LVCFMT_LEFT;
		
		lvc.iOrder=9;
		//lvc.cx = hl->s[iCol];
		//lvc.iSubItem = iCol; 
		//lvc.pszText =htxt->s[0,iCol];
        ListView_SetColumn(hwndLV, 0, &lvc);
*/	
					//SendMessage(ttip->hwnd,POPTIP_TXTUPDATE,(WPARAM)"This is a test",0);
					//((mainftp*)lastitem->guiparam)->BrowseWin();
					//ShutDown();
					//HWND tst;
					//tst=(HWND) 0xEE4;
					//SetWindowPos(tst,HWND_NOTOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE);
					//cfg.checkonadd=true;
					//long l;
					//l=GetWindowLong(tst,GWL_STYLE);
					//l&=!WS_VISIBLE;
					//SetWindowLong(tst,GWL_STYLE,l);
					//ShowWindow(tst,SW_HIDE);
					break;
				case 66:
					//DialogBox(hinst,"GSDL",hwnd,(DLGPROC)DLGS);
					break;
				case 81:
					break;
				case 73:
					break;
				}
				break;
			}
		break;

	case WM_USER+10:
		STATUSITEM *pitem;
		int dx;
		pitem= (STATUSITEM *) ((DRAWITEMSTRUCT *)wParam)->itemData;
		if (lParam==0)
		{
			int ic;
			HICON hIcon3=NULL;
			GetMainLVIcon(hIcon3,pitem,ic);
			if (hIcon3)
			{
				DrawIconEx(lv.tmpdc,0,0,hIcon3,15,15,0,0,DI_NORMAL);
				DeleteObject(hIcon3);
			}
			else ImageList_Draw(lv.il,ic,lv.tmpdc,0,0,ILD_TRANSPARENT);
			dx=20;
		}
		else dx=2;
		lv.PutTXT(dx,pitem->c[lv.colorder[lParam]]);
		break;

	case WM_USER+11:
		if (((signed)wParam)==lsortd)
		{
			if (sortd[wParam]) sortd[wParam]=0;
			else sortd[wParam]=1;
		}
		else lsortd=wParam;
		ListView_SortItems(hwndLV,StatusCmpFunc,
			(LPARAM) MAKELONG(wParam,sortd[wParam]));
		for (j=0;j<ListView_GetItemCount(hwndLV);j++)
		{
			STATUSITEM *pitem = (STATUSITEM *) GetLVlParam(hwndLV,j);
			pitem->pos=j;
		}
		break;

	case WM_CLOSE:
		ShowWindow(hwnd,SW_HIDE);
		break;
	case WM_CHANGECBCHAIN:
		if ((HWND) wParam == hwndNextViewer)
			hwndNextViewer = (HWND) lParam;
        else
			if (hwndNextViewer != NULL)
				SendMessage(hwndNextViewer, message, wParam, lParam);
        break;
	case WM_DRAWCLIPBOARD:
		if (ignoreclipboard)
			ignoreclipboard=false;
		else
			if (IsClipboardFormatAvailable(CF_TEXT))
				if (OpenClipboard(NULL))
				{
					char *p,*t,*t2,*tmp;
					HGLOBAL hgin=GetClipboardData(CF_TEXT);
					p=(char *)GlobalLock(hgin);
					t=p;
					unsigned int j=0;
					if ((p!=NULL) && 
						(!strlen(LClip) || strcmp(p,LClip) || ((int) wParam==999)))
					{
						if (strlen(p)<491)
							strcpy(LClip,p);
						else strncpy(LClip,p,490);
						while (1==1)
						{
							if (cfg.usegsul && !strnicmp(p,"ICQ #",5))
							{
								tmp=strstr(p,"Current/Last IP : ");
								if (tmp)
								{
									tmp+=18;
									t=strchr(tmp,'\r');
									if (t)
									{
										char ip[1024],name[1024];
										strncpy(ip,tmp,t-tmp);
										ip[t-tmp]='\0';
										tmp=strstr(p,"Nickname        : ");
										if (tmp)
										{
											tmp+=18;
											t=strchr(tmp,'\r');
											if (t)
											{
												strncpy(name,tmp,t-tmp);
												name[t-tmp]='\0';
											}
										}
										if (!stricmp(name,"Not Entered"))
										{
											tmp=strstr(p,"First Name      : ");
											if (tmp)
											{
												tmp+=18;
												t=strchr(tmp,'\r');
												if (t)
												{
													strncpy(name,tmp,t-tmp);
													name[t-tmp]='\0';
												}
											}
										}
										if (!stricmp(name,"Not Entered"))
											strcpy(name,"Unknown");
										t2=(char*)malloc(strlen(ip)+strlen(name)+5);
										strcpy(t2,ip);
										strcpy(t2+strlen(t2)+1,name);
										TELLGUI(GOT_IP,t2,0);
									}
								}
								break;
							}
						//
							while ((j<strlen(p)) && (*t!=0) && (*t!=10))
							{
								t++;
								j++;
							}
							if (j>1024) j=1024;
							memcpy(str,p,j);
							t2=str+j-1;
							while ((*t2==10) || (*t2==13))
								t2--;
							*(++t2)=0;
							if (strnicmp(str,"HTTP://",7) && 
								strnicmp(str,"FTP://",6)) break;
							if ((int)wParam==999)
							{
								tmp=DupString(str);
								TELLGUI(GOT_URL,tmp,0);
							}
							else
								if (DLURL(str))
								{
									tmp=DupString(str);
									TELLGUI(GOT_URL,tmp,0);
								}
							if (!*t || (j==strlen(p))) break;
							j=0;
							t++;
							p=t;
						}
					}
					GlobalUnlock(hgin);
					CloseClipboard();
					SaveURLs();
				}
		if (hwndNextViewer && ((int)wParam!=999)) 
			SendMessage(hwndNextViewer, message, wParam, lParam); 
		break;
	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case IDM_GETURLCLIP:
			SendMessage(hwnd,WM_DRAWCLIPBOARD,(WPARAM) 999,0);
			break;
		case IDM_DOWNLOAD:
			j=ListView_GetNextItem(hwndLV,-1,LVNI_ALL|LVNI_SELECTED);
			while (j!=-1)
			{
				STATUSITEM *pitem = (STATUSITEM *) GetLVlParam(hwndLV,j);
				if (!pitem->mdl->spliton)
				{
					if (pm->blink)
					{
						PostMessage(hwnd,TRAY_MSG,(WPARAM)pitem->mdl,(LPARAM) WM_LBUTTONDBLCLK);
						break;
					}
					else
					{
						TELLDAEMON(START_MDL,pitem->mdl,0);
						UpdateMDL(pitem->mdl);
					}
				}
				else 
				{
					pm->mftp->SmallWin();
				}
				j=ListView_GetNextItem(hwndLV,j,LVNI_ALL|LVNI_SELECTED);
			}
			break;
		case IDM_STOP:
			j=ListView_GetNextItem(hwndLV,-1,LVNI_ALL|LVNI_SELECTED);
			while (j!=-1)
			{
				STATUSITEM *pitem = (STATUSITEM *) GetLVlParam(hwndLV,j);
				if (pitem->mdl->spliton)
				{
					pm->mftp->kill=true;
				}
				else
					if (pm->mftp->hwnd!=NULL)
						DestroyWindow(pm->mftp->hwnd);
				TELLDAEMON(STOP_MDL,pitem->mdl,0);
				j=ListView_GetNextItem(hwndLV,j,LVNI_ALL|LVNI_SELECTED);
			}
			break;
		case IDM_STOPALL:
			for (j=0;j<ListView_GetItemCount(hwndLV);j++)
			{
				STATUSITEM *pitem = (STATUSITEM *) GetLVlParam(hwndLV,j);
				if (pm->mftp->hwnd!=NULL)
					if (pitem->mdl->spliton)
						pm->mftp->kill=true;
					else DestroyWindow(pm->mftp->hwnd);
			}
			TELLDAEMON(STOP_ALL,0,0);
			break;
		case IDM_SHOWTASKS:
			j=ListView_GetNextItem(hwndLV,-1,LVNI_ALL|LVNI_SELECTED);
			while (j!=-1)
			{
				STATUSITEM *pitem = (STATUSITEM *) GetLVlParam(hwndLV,j);
				pm->TaskWin();
				j=ListView_GetNextItem(hwndLV,j,LVNI_ALL|LVNI_SELECTED);
			}
			break;
		case IDM_MIRRORS:
			j=ListView_GetNextItem(hwndLV,-1,LVNI_ALL|LVNI_SELECTED);
			while (j!=-1)
			{
				STATUSITEM *pitem = (STATUSITEM *) GetLVlParam(hwndLV,j);
				pm->MirrorWin();
				j=ListView_GetNextItem(hwndLV,j,LVNI_ALL|LVNI_SELECTED);
			}
			break;
		case IDM_CONSOLE:
			j=ListView_GetNextItem(hwndLV,-1,LVNI_ALL|LVNI_SELECTED);
			while (j!=-1)
			{
				STATUSITEM *pitem = (STATUSITEM *) GetLVlParam(hwndLV,j);
				pm->mftp->BufferWin();
				j=ListView_GetNextItem(hwndLV,j,LVNI_ALL|LVNI_SELECTED);
			}
			break;
		case IDM_ABOUT:
			DialogBox(hinst,"ABOUT",hwnd,(DLGPROC)AboutFunc);
			break;
		case IDM_EXPORT:
			if (ListView_GetItemCount(hwndLV))
				DialogBox(hlang,"EXPORT",hwndgui,(DLGPROC) ExportFunc);
			break;
		case IDM_IMPORT:
			Import();
			break;
		case IDM_DIAL:
			TELLDAEMON(DIAL,0,0);
			break;
		case IDM_HIDEALL:
			ShowSmall(false);
			break;
		case IDM_SHOWALL:
			ShowSmall(true);
			break;
		case IDM_SHOWSTATUS:
			ShowWindow(hwnd,SW_SHOW);
			ShowWindow(hwnd,SW_RESTORE);
			SetForegroundWindow(hwnd);
			break;
		case IDM_SHOWERROR:
			ShowErr();
			break;
		case IDM_DLSHOW:
		case IDM_DLHIDE:
			if (TrayM==NULL) break;
			if (TrayM->blink)
			{
				TrayM->RMItem();
				TrayM->RemoveTray();
				TrayM->blink=false;
				if (!TrayM->skipmsg)
					TrayM->ShowMSG();
				else TrayM->skipmsg=false;
				if (TrayM->mdl->done)
				{
					TrayM->RMLV();
					delete TrayM->mdl;
				}
				else
					if (TrayM->mftp->hwnd!=NULL)
						DestroyWindow(TrayM->mftp->hwnd);
			}
			else
				if (LOWORD(wParam)==IDM_DLSHOW)
					TrayM->mftp->SmallWin();
				else DestroyWindow(TrayM->mftp->hwnd);
			break;

		case IDM_DLSTOP:
			if (TrayM==NULL) break;
			if (TrayM->mdl->spliton)
			{
				TrayM->mftp->kill=true;
			}
			else
				if (TrayM->mftp->hwnd!=NULL)
					DestroyWindow(TrayM->mftp->hwnd);
			TELLDAEMON(STOP_MDL,TrayM->mdl,0);
			break;

		case IDM_DLMIRRORS:
			if (TrayM!=NULL)
				TrayM->MirrorWin();
			break;
		case IDM_DLPROPERTIES:
			if (TrayM==NULL) break;
			j=ListView_GetNextItem(hwndLV,-1,LVNI_ALL|LVNI_SELECTED);
			while (j!=-1)
			{
				//STATUSITEM *pitem = (STATUSITEM *) GetLVlParam(hwndLV,j);
				ListView_SetItemState(hwndLV,j,0,LVIS_SELECTED);
				j=ListView_GetNextItem(hwndLV,j,
					LVNI_ALL|LVNI_SELECTED);
			}
			ListView_SetItemState(hwndLV,TrayM->item->pos,
								LVIS_SELECTED,LVIS_SELECTED);
			DoProperties();
			break;
		case IDM_BROWSEFTP:
			BrowseURL();
			break;
		case IDM_DLTASKMAN:
			if (TrayM!=NULL)
				TrayM->TaskWin();
			break;
		case IDM_DLCONSOLE:
			if (TrayM!=NULL)
				TrayM->mftp->BufferWin();
			break;
		case IDM_DLCHANGESHAPE:
			if ((TrayM==NULL) || (TrayM->mftp->hwnd==NULL)) break;
			PostMessage(TrayM->mftp->hwnd,_SKN_BTSET,MAKELONG(6,1),1);
			PostMessage(TrayM->mftp->hwnd,_SKN_RGN,MAKELONG(3,4),
						MAKELONG(_S_RGIN|_S_RGOUT,0));
			break;
//		case IDM_DLCHANGELIMIT:
//			break;
		case IDM_HELP:
			WinHelp(hwnd,HelpFile,HELP_FINDER,0);
			break;
		case IDM_CONFIG:
			Config();
			break;
		case IDM_AUTODL:
			if (cfg.robot)
			{
				PostMessage(hwnd,_SKN_BTSET,MAKELONG(3,0),0);
				TELLDAEMON(ROBOT_ST,0,0);
				CheckMenuItem(Hmenu,IDM_AUTODL,MF_UNCHECKED);
			}
			else
			{
				PostMessage(hwnd,_SKN_BTSET,MAKELONG(3,0),1);
				CheckMenuItem(Hmenu,IDM_AUTODL,MF_CHECKED);
/*				j=ListView_GetNextItem(hwndLV,-1,LVNI_ALL|LVNI_SELECTED);
				if (j!=-1)
				{
					while (j!=-1)
					{
						STATUSITEM *pitem = (STATUSITEM *) GetLVlParam(hwndLV,j);
						TELLDAEMON(ROBOT_ST,pitem->mdl,2);
						j=ListView_GetNextItem(hwndLV,j,
							LVNI_ALL|LVNI_SELECTED);
					}			
					TELLDAEMON(ROBOT_ST,0,3);
				}
				else*/
				TELLDAEMON(ROBOT_ST,0,1);
			}
			break;
		case IDM_DISCONNECT:
			if (!cfg.disconnect)
			{
				PostMessage(hwnd,_SKN_BTSET,MAKELONG(9,0),1);
				CheckMenuItem(Hmenu,IDM_DISCONNECT,MF_CHECKED);
				cfg.disconnect=true;
			}
			else
			{
				PostMessage(hwnd,_SKN_BTSET,MAKELONG(9,0),0);
				CheckMenuItem(Hmenu,IDM_DISCONNECT,MF_UNCHECKED);
				cfg.disconnect=false;
			}
			break;
		case IDM_SHOWDLWIN:
			if (gcfg.showdlwin)
			{
				gcfg.showdlwin=false;
				CheckMenuItem(Hmenu,IDM_SHOWDLWIN,MF_UNCHECKED);
				SendMessage(hwnd,WM_COMMAND,IDM_HIDEALL,0);
			}
			else
			{
				gcfg.showdlwin=true;
				CheckMenuItem(Hmenu,IDM_SHOWDLWIN,MF_CHECKED);
				SendMessage(hwnd,WM_COMMAND,IDM_SHOWALL,0);
			}
			break;
		case IDM_SHOWDLTRAY:
			if (gcfg.showdltray)
			{
				gcfg.showdltray=false;
				CheckMenuItem(Hmenu,IDM_SHOWDLTRAY,MF_UNCHECKED);
			}
			else
			{
				gcfg.showdltray=true;
				CheckMenuItem(Hmenu,IDM_SHOWDLTRAY,MF_CHECKED);
			}
			break;
		case IDM_CATCHCLIPBOARD:
			if (gcfg.catchcb)
			{
				gcfg.catchcb=false;
				CatchCB();
			}
			else
			{
				gcfg.catchcb=true;
				CatchCB();
			}
			break;
		case IDM_SPEEDLIMIT:
			DialogBoxParam(hlang,"SPEEDLIMIT",hwnd,
				(DLGPROC)SpeedLimitFunc,NULL);
			break;
		case IDM_SCHEDULE:
			if (!datepick)
				MsgBox(GetSTR(278,"Your COMCTL32.DLL file is old.\nYou must \
download a newer version in order to use the scheduler.\nThis file \
is available at www.microsoft.com"),"Incompatible COMCTL32.DLL",MB_OK);
			else
				DialogBox(hlang,"SCHEDULEDB",hwnd,
					(DLGPROC) ScheduleFunc);
			break;
		case IDM_OFFERFILE:
			DialogBox(hinst,"GSULOFFER",hwnd,(DLGPROC)OfferGSUL);
			break;
		case IDM_FTPCLIENT:
			dlnfo *dln;
			dln=new dlnfo(1,"",21,"anonymous",cfg.Email,"","*.*");
			AddURL(dln,0,0,2,9,0,cfg.resumeto,DEFPR,0,cfg.usehammer,
				cfg.useretry,cfg.checkint,cfg.checksmallint);
			break;
		case IDM_SHOWSER:
			if (hserver==NULL)
			{
				CreateWindowEx(cfg.r2l,"GSServerWin",
					"",
					WS_OVERLAPPEDWINDOW,
					CW_USEDEFAULT,
					CW_USEDEFAULT,
					CW_USEDEFAULT,
					CW_USEDEFAULT,
					HWND_DESKTOP,
					NULL,
					hinst,
					(void *)&serverskinnfo);
				PostMessage(hwnd,_SKN_BTSET,MAKELONG(6,0),1);
			}
			else
			{
				DestroyWindow(hserver);
				PostMessage(hwnd,_SKN_BTSET,MAKELONG(6,0),0);
			}
			break;

		case IDM_URL:
			DialogBoxParam(hlang,"PROPERTIES1",hwndgui,
				(DLGPROC)URLFunc,NULL);
			break;
		case IDM_PROPERTIES:
			DoProperties();
			break;
		case IDM_REMOVECLIP:
			DoRemove(true);
			break;
		case IDM_REMOVE:
			DoRemove(false);
			break;
		case IDM_COPYCLIP:
			DoCopyclip();
			break;
		case IDM_SELECTALL:
			i=ListView_GetItemCount(hwndLV);
			for (j=0;j<=i;j++)
				ListView_SetItemState(hwndLV,j,
				LVIS_SELECTED,LVIS_SELECTED);
			break;
		case IDM_SELECTACTIVE:
			j=ListView_GetNextItem(hwndLV,-1,LVNI_ALL|LVNI_SELECTED);
			while (j!=-1)
			{
				STATUSITEM *pitem = (STATUSITEM *) GetLVlParam(hwndLV,j);
				if (!pitem->mdl->spliton) 
					ListView_SetItemState(hwndLV,j,0,LVIS_SELECTED);
				j=ListView_GetNextItem(hwndLV,j,
					LVNI_ALL|LVNI_SELECTED);
			}			
			i=ListView_GetItemCount(hwndLV);
			for (j=0;j<i;j++)
			{
				STATUSITEM *pitem = (STATUSITEM *) GetLVlParam(hwndLV,j);
				if (pitem->mdl->spliton) 
					ListView_SetItemState(hwndLV,j,
					LVIS_SELECTED,LVIS_SELECTED);
			}
			UpdateWindow(hwndLV);
			break;
		case IDM_SHOWMODE:
			POINT pt;
			GetCursorPos(&pt);
			DisplayShowModeMenu(hwnd,pt);
			break;
		case IDM_FINISHMESSAGES:
			if (gcfg.finishmsgs)
			{
				gcfg.finishmsgs=false;
				PostMessage(hwnd,_SKN_BTSET,MAKELONG(5,0),0);
			}
			else
			{
				gcfg.finishmsgs=true;
				PostMessage(hwnd,_SKN_BTSET,MAKELONG(5,0),1);
			}
			break;
		case IDM_UNINSTALL:
			PostMessage(hwndg,WM_USER+1031,1,0);
			break;
		case IDM_CHECK4UPDATE:
			upddlchk::Chk4Upd();
			break;
		case IDM_EXIT:
			killgui=true;
			doexit=true;
			//DestroyWindow(hwnd);
			//PostMessage(Hserv,WM_G_DESTROY,0,0);
			SendMessage(Hserv,WM_G_DESTROY,0,0);
			break;
		case IDM_SHUTGUI:
			killgui=true;
			SendMessage(Hserv,WM_G_DESTROYGUI,0,0);
			break;

		default:
			if ((LOWORD(wParam)>=IDM_LASTDL) && (LOWORD(wParam)<IDM_LASTDL+100))
			{
				j=0;
				lastdl *ldl=lastdlhead;
				while (ldl)
				{
					if (j>=LOWORD(wParam)-IDM_LASTDL)
						break;
					j++;
					ldl=ldl->next;
				}
				if (ldl)
					DialogBoxParam(hlang,"PROPERTIES1",hwnd,
							(DLGPROC)URLFunc,(LPARAM) ldl);
				break;
			}
		}
	case WM_TIMER:
		if (!killgui)
			GuiManagerFunc();
		break;
	case WM_DESTROY: 
		//delete (mainftp*)listhead->guiparam;
		SaveGUIConfig();
		KillTimer(hwnd,1);
		ListView_DeleteAllItems(hwndLV);
		hlvicons=ListView_SetImageList(hwndLV, NULL, LVSIL_SMALL);
		DestroyWindow(hwndLV);
		i=ImageList_RemoveAll(hlvicons);
		i=ImageList_Destroy(hlvicons);
		
		LoadLDL=true;
		while (lastdllast!=NULL)
			delete lastdllast;
		memset(&pnid,0,sizeof(NOTIFYICONDATA));
		pnid.cbSize=sizeof(NOTIFYICONDATA);
		pnid.hWnd=hwnd;
		pnid.uID=-2;
		pnid.uFlags=NIF_ICON|NIF_MESSAGE|NIF_TIP;
		pnid.uCallbackMessage=WM_USER+1;
		pnid.hIcon=LoadIcon(hlang,"AAAA");
		strcpy(pnid.szTip,"GetSmart - The Smartest Download Manager");
		Shell_NotifyIcon (NIM_DELETE, &pnid );
		if (hserver!=NULL)
			DestroyWindow(hserver);
		if (gcfg.catchcb)
		{
			gcfg.catchcb=false;
			CatchCB();
		}
		if (gcfg.showdropbox)
		{
			gcfg.showdropbox=false;
			Dropbox();
		}
		OleUninitialize();
		UnregisterClass("GSBufferWin",hinst);
		UnregisterClass("GSTaskWin",hinst);
		UnregisterClass("GSSmallWin",hinst);
		UnregisterClass("GSPrevWin",hinst);
		UnregisterClass("GSServerWin",hinst);
		UnregisterClass("GSMirrorWin",hinst);
		UnregisterClass("GSDropbox",hinst);
		UnregisterClass("GSBrowseWin",hinst);

		SetMenu(hwnd,NULL);

		DestroyMenu(hmmfile);
		DestroyMenu(hmmedit);
		DestroyMenu(hmmaction);
		DestroyMenu(hmmadvanced);
		DestroyMenu(hmmhelp);
		DestroyMenu(hmmrecent);
		DestroyMenu(Hmenu);

		DestroyMenu(hbmconnection);
		DestroyMenu(hbmdownloads);
		DestroyMenu(hbmsession);
		DestroyMenu(Hmenu2);

		for (j=1;j<9;j++)
			DeleteObject(wcx[j].hbrBackground);
		DestroyMenu(Hmenu);
		DeleteObject(gfont);
		free(HelpFile);
		free(sknormal);
		free(skfast);
		mainskin.Kill();
		taskskin.Kill();
		smallskin.Kill();
		bufferskin.Kill();
		serverskin.Kill();
		mirrorskin.Kill();
		browseskin.Kill();
		if (datepick) FreeLibrary(hctl);
		free(gcfg.exskinfn);
		free(gcfg.skindir);
		PostQuitMessage(0);
		break;

	case SKN_BTUP:
        switch (LOWORD(wParam)){
        case 0:
			PostMessage(hwnd,WM_COMMAND,IDM_DOWNLOAD,0);
			break;
        case 1:
			PostMessage(hwnd,WM_COMMAND,IDM_STOP,0);
			break;
        case 2:
			PostMessage(hwnd,WM_COMMAND,IDM_STOPALL,0);
			break;
		case 3:
			PostMessage(hwnd,WM_COMMAND,IDM_AUTODL,0);
			break;
		case 4:
			PostMessage(hwnd,WM_COMMAND,IDM_SHOWMODE,0);
			break;
		case 5:
			PostMessage(hwnd,WM_COMMAND,IDM_FINISHMESSAGES,0);
			break;
		case 6:
			PostMessage(hwnd,WM_COMMAND,IDM_SHOWSER,0);
			break;
		case 7:
			PostMessage(hwnd,WM_COMMAND,IDM_SPEEDLIMIT,0);
			break;
		case 8:
			PostMessage(hwnd,WM_COMMAND,IDM_FTPCLIENT,0);
			break;
		case 9:
			PostMessage(hwnd,WM_COMMAND,IDM_DISCONNECT,0);
			break;
		case 10:
			if (!cfg.shutdown)
			{
				PostMessage(hwnd,_SKN_BTSET,MAKELONG(10,0),1);
				cfg.shutdown=true;
			}
			else
			{
				PostMessage(hwnd,_SKN_BTSET,MAKELONG(10,0),0);
				cfg.shutdown=false;
			}
			break;
		case 11:
			if (!cfg.Dial.reconnect)
			{
				PostMessage(hwnd,_SKN_BTSET,MAKELONG(11,0),1);
				cfg.Dial.reconnect=true;
			}
			else
			{
				PostMessage(hwnd,_SKN_BTSET,MAKELONG(11,0),0);
				cfg.Dial.reconnect=false;
			}
			break;
		case 12:
			PostMessage(hwnd,WM_COMMAND,IDM_SCHEDULE,0);
			break;
		case 13:
			if (!cfg.usegsul)
			{
				PostMessage(hwnd,_SKN_BTSET,MAKELONG(13,0),1);
				InitGSUL();
				cfg.usegsul=true;
			}
			else
			{
				PostMessage(hwnd,_SKN_BTSET,MAKELONG(13,0),0);
				ShutGSUL();
				cfg.usegsul=false;
			}
			break;
		}
        break;
		
	case SKN_TRLV:
		j=ListView_GetNextItem(hwndLV,-1,LVNI_ALL|LVNI_SELECTED);
		if (j==-1)
		{
			MsgBox(GetSTR2(208,"You must mark a download before changing the split"),
						"Nothing to do.",MB_OK);
			dds2();
			break;
		}
		while (j!=-1)
		{
			STATUSITEM *pitem = (STATUSITEM *) GetLVlParam(hwndLV,j);
			m=(mainftp*)pitem->mdl->guiparam;
			if (lParam!=pitem->mdl->spliton)
			{
				time(&m->tracktime);
				m->trackpos=lParam;
			}
			else m->tracktime=0;
			j=ListView_GetNextItem(hwndLV,j,LVNI_ALL|LVNI_SELECTED);
		}
        break;
	case SKN_TRUP:
		sprintf(sksplits,"%ld",lParam);
		PostMessage(hwnd,_SKN_TXT,MAKELONG(2,0),(LPARAM)sksplits);
		break;
	default:
		if (ret==-1)
			return DefWindowProc(hwnd, message, wParam, lParam);
	}
	return 0;
#undef pm
}

void GuiManagerFunc()
{
	maindl *mdl;
	mainftp *tmp;
	char str[1024];
#define m ((mainftp*)mdl->guiparam)
	time_t tm;
	time(&tm);
	int i;
	for (i=0;i<=lastmact;i++)
	{
		mdl=actmdls[i].mdl;
		if (mdl && mdl->guiparam)
		{
			UpdateMDL(mdl);
			if (mdl->done) break;
			if (m->tracktime && (tm-m->tracktime>2))
			{
				TELLDAEMON(CHANGE_SPLIT,mdl,m->trackpos);
				m->tracktime=0;
			}
/*			if (tm-mdl->starttime==10)
				TELLDAEMON(STOP_BDL,mdl,MAKELONG(3,-1));
			if (tm-mdl->starttime==13)
				TELLDAEMON(STOP_BDL,mdl,MAKELONG(5,-1));
			if (tm-mdl->starttime==18)
			{
				m->trackpos=100;
				m->tracktime=tm;
			}
			if ((tm-mdl->starttime>20) && !((tm-mdl->starttime)%15))
			{
				srand( (unsigned)time( NULL ) );
				m->tracktime=tm;
				m->trackpos=rand()%100;
			}
			if ((tm-mdl->starttime>20) && !((tm-mdl->starttime)%35))
			{
				srand( (unsigned)time( NULL ) );
				if (rand()%2)
					PostMessage(Hserv,STOP_MDL+WM_USER+3000,(WPARAM)mdl,0);
				else
				{
					m->skipmsg=true;
					TELLDAEMON(RM_MDL,mdl,0);
				}
			}*/
		}
	}
#undef m
	if (gcfg.finishmsgs)
	{
		tmp=donehead;
		while (tmp!=NULL)
		{
			tmp->UpdateTray(0,0);
			tmp=tmp->next;
		}
	}
	tmp=mainmirr;
	while (tmp)
	{
		mirrors *mir=tmp->mdl->mirrorhead;
		while (mir)
		{
			if (!mir->guiparam)
				AddMirrorItem(mir);
			UpdateMirrorList(mir);
			mir=mir->next;
		}
		tmp=tmp->mirnext;
	}
	if ((hserver!=NULL) && (serhead!=NULL))
	{
		server *ser=serhead;
		while (ser)
		{
			if (ser->guiparam==NULL)
				AddSerItem(ser);
			UpdateSerList(ser);
			ser=ser->next;
		}
	}
	if (lastact==-1) SetWindowText(hwndgui,*gstitle);
	else
	{
		if (activedl && activebr)
			sprintf(str,"%.2f kb/s  DL:%.2f kb/s  Proxy:%.2f kb/s",
				globalcps/1024.0,gdlcps/1024.0,gbrcps/1024.0);
		else sprintf(str,"%.2f kb/s",globalcps/1024.0);
		SetWindowText(hwndgui,str);
	}
}

LRESULT CALLBACK SmallFunc(HWND hwnd, UINT message,
                            WPARAM wParam, LPARAM lParam)
{
	//char str[1024];
	//int j;
	static char sktxt[10][80];//,tmp[1024];
	strcpy(sktxt[0],GetSTR2(209,"Tasks"));
	strcpy(sktxt[1],GetSTR2(110,"Timeout"));
	strcpy(sktxt[2],GetSTR2(210,"Splits"));
	strcpy(sktxt[3],"URL:");
	strcpy(sktxt[4],GetSTR2(211,"Elapsed:"));
	strcpy(sktxt[5],GetSTR2(212,"Est:"));
	strcpy(sktxt[6],GetSTR2(213,"Cur:"));
	strcpy(sktxt[7],GetSTR2(214,"Hide"));
	strcpy(sktxt[8],GetSTR2(215,"Ping"));
	strcpy(sktxt[9],GetSTR2(216,"Mirrors"));
	dds2();
/*	sprintf(tmp,"SmallFunc call, message:%ld\n",message);
	fwrite(tmp,1,strlen(tmp),gfp);*/
	smallftp *f=NULL;
	SkinWinNfo *sksmall=(SkinWinNfo*)GetWindowLong(hwnd,GWL_USERDATA);
	if (sksmall)
		f=(smallftp*)sksmall->data;
	//mainftp *m;
	//if (mdl) m=(mainftp*)(mdl->guiparam);
	LRESULT ret=smallskin.fn(hwnd,message,wParam,lParam);
	switch(message)
	{
    case WM_HELP:
		WinHelp(hwnd, HelpFile, HELP_CONTEXT ,IDH_DLWINDOW);
		break;
	case WM_CREATE:
/*		strcpy(tmp,"In create...\n");
		fwrite(tmp,1,strlen(tmp),gfp);*/
		sksmall=(SkinWinNfo*)(((LPCREATESTRUCT) lParam)->lpCreateParams); 
		f=(smallftp*)sksmall->data;
		f->hwnd=hwnd;
		if (f->mdl->spliton)
		{
			PostMessage(hwnd,_SKN_TRJMP,MAKELONG(0,0),f->mdl->spliton);
			sprintf(f->txt[10],"%ld",f->mdl->spliton);
		}
		else strcpy(f->txt[10],"1");

		int i;
		for (i=0;i<smallskin.numtxt;i++)
			if (smallskin.txt[i].def<12)
			{	
				if(smallskin.txt[i].def==10)
					f->trtxti=i;
				PostMessage(hwnd,_SKN_TXT,MAKELONG(i,0),(LPARAM)f->txt[smallskin.txt[i].def]);
			}
			else
			{
				switch(smallskin.txt[i].def)
				{
				case 20:
					if (f->bdl==NULL)
						PostMessage(hwnd,_SKN_TXT,MAKELONG(i,0),(LPARAM)f->mdl->mstxt);
					else PostMessage(hwnd,_SKN_TXT,MAKELONG(i,0),(LPARAM)f->mdl->bstxt[f->bdl->txtpos]);
					break;
				case 21:
				case 22:
				case 23:
				case 24:
				case 25:
				case 26:
				case 27:
				case 28:
				case 29:
				case 30:
					PostMessage(hwnd,_SKN_TXT,MAKELONG(i,0),
										(LPARAM)sktxt[smallskin.txt[i].def-21]);
					break;
				case 40:
					PostMessage(hwnd,_SKN_TXT,MAKELONG(i,0),
										(LPARAM)sknormal);
					break;
				case 41:
					PostMessage(hwnd,_SKN_TXT,MAKELONG(i,0),
										(LPARAM)skfast);
					break;
				}
			}
		PostMessage(hwnd,_SKN_PRTOT,MAKELONG(0,0),1);
		PostMessage(hwnd,_SKN_PRCUR,MAKELONG(0,0),0);
		if (f->mdl->spliton)
			PostMessage(hwnd,_SKN_BTSET,MAKELONG(7,0),0);
		else
			if (f->mdl->done)
				PostMessage(hwnd,_SKN_BTSET,MAKELONG(7,0),2);
			else
				if (f->mdl->error.en)
					PostMessage(hwnd,_SKN_BTSET,MAKELONG(7,0),3);
				else
					PostMessage(hwnd,_SKN_BTSET,MAKELONG(7,0),1);
		//int ret2;
		//ret2=AnimateWindow(hwnd,1000,AW_BLEND);
		if (gcfg.smalltrans)
			MakeTransparent(hwnd,false,gcfg.smallalpha);
		ShowWindow(hwnd,SW_SHOW);
		break;
	case WM_MOVE:
		RECT re;
		GetWindowRect(hwnd,&re);
		if (gcfg.showtt && ttip && !tipmsgs[2] && !gcfg.useexskin)
		{
			POINT pt;
			GetCursorPos(&pt);
			if (pt.y-re.top<20)
			{
				tipmsgs[2]=true;
				SendMessage(ttip->hwnd,POPTIP_TXTUPDATE,
					(WPARAM)GetSTR2(217,"You don't have to use the title bar to move the window!\n\
You can move it from anywhere, \njust click somewhere in the window and move it."),0);
				dds2();
				SaveGUIConfig();
			}
		}
		//if (!re.bottom && !re.right) break;
		break;
	case WM_NOTIFY:
		if (((LPNMHDR) lParam)->code==TTN_NEEDTEXT)
		{
			LPTOOLTIPTEXT lpttt;
			lpttt = (LPTOOLTIPTEXT) lParam;
			lpttt->hinst = hinst;
			int idButton = lpttt->hdr.idFrom;
			switch (idButton)
			{
				char str[1024];
			case 0:
				strcpy(str,GetSTR2(218,"Stop download and close window"));
				lpttt->lpszText=str;
				break;
			case 1:
				strcpy(str,GetSTR2(219,"Minimize window"));
				lpttt->lpszText=str;
				break;
			case 2:
				strcpy(str,GetSTR2(220,"Show/Hide Task manager"));
				lpttt->lpszText=str;
				break;
			case 3:
				strcpy(str,GetSTR2(221,"Pause/Resume a download"));
				lpttt->lpszText=str;
				break;
			case 4:
				strcpy(str,GetSTR2(222,"Show/Hide console window"));
				lpttt->lpszText=str;
				break;
			case 5:
				strcpy(str,GetSTR2(223,"Hide this window - the download will continue"));
				lpttt->lpszText=str;
				break;
			case 6:
				strcpy(str,GetSTR2(224,"Show/Hide Split track bar"));
				lpttt->lpszText=str;
				break;
			case 8:
				strcpy(str,GetSTR2(225,"Show/Hide Mirrors manager"));
				lpttt->lpszText=str;
				break;
/*			case 7:
			    lpttt->lpszText = "Split track bar";
				break;
			case 10:
			    lpttt->lpszText = "Set speed limit";
				break;*/
			}
			dds2();
		}
		break;
	case WM_CLOSE:
		DestroyWindow(hwnd);
		//SaveGUIConfig();
		break;
	case WM_DESTROY:
		SaveGUIConfig();
		f->hwnd=NULL;
		if (f==f->m->mftp)
			f->opentrack=false;
		break;
	case SKN_BTUP:
        switch (LOWORD(wParam)){
        case 0:
			if (f->bdl==NULL)
			{
				if (f->mdl->spliton)
				{
					f->kill=true;
					TELLDAEMON(STOP_MDL,f->mdl,0);
				}
				else
					if (f->m->blink)
					{
						f->m->skipmsg=true;
						PostMessage(hwndgui,TRAY_MSG,(WPARAM)f->mdl,(LPARAM) WM_LBUTTONDBLCLK);
					}
					else
						DestroyWindow(hwnd);
			}
			else
				TELLDAEMON(STOP_BDL,f->bdl,MAKELONG(f->bdl->splitdex,f->bdl->hamdex));
			break;
        case 1:
			ShowWindow(hwnd,SW_MINIMIZE);
			break;
        case 2:
			f->m->TaskWin();
			break;
		case 3:
			if (f->bdl!=NULL)
				TELLDAEMON(STOP_BDL,f->bdl,MAKELONG(f->bdl->splitdex,f->bdl->hamdex));
			else
				if (f->mdl->spliton)
					TELLDAEMON(STOP_MDL,f->mdl,0);
				else
					if (f->mdl->done)
					{
						f->m->skipmsg=true;
						SendMessage(hwndgui,TRAY_MSG,(WPARAM)f->mdl,(LPARAM) WM_LBUTTONDBLCLK);
					}
					else
					{
						f->mdl->wait=true;
						TELLDAEMON(START_MDL,f->mdl,0);
					}
			break;
		case 4:
			//if ((f->bdl==NULL) && (f->m->mftp->hbuffer!=NULL))
			//	f->killbuffer=true;
			f->BufferWin();
			break;
		case 5:
			DestroyWindow(hwnd);
			break;
		case 6:
			if (/*f->mdl->resume && */(f->bdl==NULL))
			{
				PostMessage(hwnd,_SKN_BTSET,MAKELONG(6,1),1);
				PostMessage(hwnd,_SKN_RGN,MAKELONG(3,4),
							MAKELONG(_S_RGIN|_S_RGOUT,0));
			}
			break;
		case 8:
			f->m->MirrorWin();
			break;
		}
        break;
	case SKN_TRLV:
		time(&f->m->tracktime);
		f->m->trackpos=lParam;
        break;
	case SKN_TRUP:
		if (f->trtxti==-1) break;
		sprintf(f->txt[10],"%ld",lParam);
		PostMessage(hwnd,_SKN_TXTUP,MAKELONG(f->trtxti,0),0);
        break;
    default:
        if (ret==-1)
			return DefWindowProc(hwnd, message, wParam, lParam);
	}
	return ret;
}

LRESULT CALLBACK TasksFunc(HWND hwnd, UINT message,
                            WPARAM wParam, LPARAM lParam)
{
	char htxt[9][50],str[1024];
	static char sksplits[10];
//	LV_DISPINFO *pnmv;
	int j,r,s,h;
	maindl *mdl=NULL;
	bool ex;
	SkinWinNfo *sktask=(SkinWinNfo*)GetWindowLong(hwnd,GWL_USERDATA);
	if (sktask)
		mdl=(maindl*)sktask->data;
	mainftp *m;
	if (mdl)
	{
		m=(mainftp*)(mdl->guiparam);
		if (m->tlv.LVFunc(hwnd,message,wParam,lParam))
			return 0;
	}
	LRESULT ret=taskskin.fn(hwnd,message,wParam,lParam);
	switch(message)
	{
	case WM_ACTIVATE:
		if (IsWindow(m->hwndTV))
			SetFocus(m->hwndTV);
		if	(LOWORD(wParam) == WA_INACTIVE)
			hgdlg=NULL;
		else
			hgdlg=hwnd;
		break;
    case WM_HELP:
		WinHelp(hwnd, HelpFile, HELP_CONTEXT ,IDH_TASKMANAGER);
		break;
	case WM_CREATE:
		sktask=(SkinWinNfo*)(((LPCREATESTRUCT) lParam)->lpCreateParams); 
		mdl=(maindl*)sktask->data;
		m=(mainftp*)(mdl->guiparam);
		m->htask=hwnd;
		if (TaskRect.top || TaskRect.left || TaskRect.right ||
													TaskRect.bottom)
			MoveWindow(hwnd,TaskRect.left,TaskRect.top,
				TaskRect.right-TaskRect.left,
				TaskRect.bottom-TaskRect.top,true);
		sprintf(str,GetSTR2(226,"Tasks for %s"),mdl->lfn);
		SetWindowText(hwnd,str);
		strcpy(htxt[0],GetSTR2(102,"File Name"));
		strcpy(htxt[1],GetSTR2(227,"Host"));
		strcpy(htxt[2],GetSTR2(103,"Size"));
		strcpy(htxt[3],GetSTR2(106,"Progress"));
		strcpy(htxt[4],GetSTR2(107,"Current Speed"));
		strcpy(htxt[5],GetSTR2(108,"Est. Time Left"));
		strcpy(htxt[6],GetSTR2(110,"Timeout"));
		strcpy(htxt[7],GetSTR2(113,"Status"));
		dds2();
		m->tlv.pos.top=40;
		m->tlv.pos.bottom=-40;
		m->tlv.Init(hwnd,&htxt[0][0],&TaskCol[0],8);
		m->hwndTV=m->tlv.hwndLV;
		ListView_SetImageList(m->hwndTV, hlvicons, LVSIL_SMALL);
		//m->hwndTV=DoCreateList(hwnd,&htxt[0][0],&TaskCol[0],8,true,0);
		LVITEM it;
		memset(&it,0,sizeof(it));
		it.mask = LVIF_TEXT | LVIF_PARAM;// | LVIF_IMAGE; 
		it.iItem=0;
		it.iSubItem=0;
		strcpy(str,GetSTR2(228,"Split Tasks:"));
		dds2();
		it.pszText=str;
		it.cchTextMax=strlen(str);
		ListView_InsertItem(m->hwndTV,&it);
		strcpy(str,"");
		for (j=1;j<8;j++)
		{
			it.iSubItem=j;
			ListView_InsertItem(m->hwndTV,&it);
		}
		if (mdl->spliton)
			PostMessage(hwnd,_SKN_TRJMP,MAKELONG(0,0),mdl->spliton);
		if (!mdl->done)
		{
			int r;
			for (r=0;r<=mdl->splitdex;r++)
				if (!mdl->spdone[r])
					UpdateTask(mdl,r,-1);
			if (mdl->busydl!=NULL)
				for (r=0;r<=mdl->hamdex;r++)
					UpdateTask(mdl,-1,r);
		}
		PostMessage(hwnd,_SKN_TXT,MAKELONG(0,0),(LPARAM)sknormal);
		PostMessage(hwnd,_SKN_TXT,MAKELONG(1,0),(LPARAM)skfast);
		strcpy(sksplits,"1");
		PostMessage(hwnd,_SKN_TXT,MAKELONG(2,0),(LPARAM)sksplits);
		ShowWindow(hwnd,SW_SHOW);
		break;
	case WM_SIZE:
		if (wParam==SIZE_MINIMIZED) break;
		RECT rc;
        GetClientRect(hwnd, &rc);
/*        SetWindowPos(m->hwndTV, HWND_TOP, rc.left, rc.top+40, 
				rc.right , rc.bottom-40, SWP_SHOWWINDOW);  */
		GetWindowRect(hwnd,&TaskRect);
		SendMessage(hwnd,_SKN_RESIZE,0,0);
		break;
	case WM_MOVE:
		RECT re;
		GetClientRect(hwnd,&re);
		if (!re.bottom && !re.right) break;
		GetWindowRect(hwnd,&TaskRect);
		break;
	case WM_CONTEXTMENU: 
		if (!ShortcutMenu2(hwnd, LOWORD(lParam), HIWORD(lParam),m->hwndTV)) 
			return DefWindowProc(hwnd, message, wParam, lParam);
		break;
	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case IDCANCEL:
			ShowWindow(hwnd,SW_HIDE);
			break;
/*		case IDM_HIDE:
			j=ListView_GetNextItem(g->hwndTV,-1,LVNI_ALL|LVNI_SELECTED);
			while (j!=-1)
			{
				ret=GetFtp(m,j,s,h,ex);
				if (ret && ex)
					if (s>-1) ShowWindow(((smallftp*)(m->splitdl[s]->guiparam))->hwnd,SW_HIDE);
					else ShowWindow(((smallftp*)(m->hamdl[h]->guiparam))->hwnd,SW_HIDE);
				j=ListView_GetNextItem(g->hwndTV,j,
					LVNI_ALL|LVNI_SELECTED);
			}
			break;
		
		case IDM_SHOW:
			j=ListView_GetNextItem(g->hwndTV,-1,LVNI_ALL|LVNI_SELECTED);
			while (j!=-1)
			{
				ret=GetFtp(m,j,s,h,ex);
				if (ret && ex)
					if (s>-1) 
					{
						ShowWindow(((smallftp*)(m->splitdl[s]->guiparam))->hwnd,SW_HIDE);
						ShowWindow(((smallftp*)(m->splitdl[s]->guiparam))->hwnd,SW_SHOW);
					}
					else 
					{
						ShowWindow(((smallftp*)(m->hamdl[h]->guiparam))->hwnd,SW_HIDE);
						ShowWindow(((smallftp*)(m->hamdl[h]->guiparam))->hwnd,SW_SHOW);
					}
				j=ListView_GetNextItem(g->hwndTV,j,
					LVNI_ALL|LVNI_SELECTED);
			}
			break;*/
		
		case IDM_STOP:
			j=ListView_GetNextItem(m->hwndTV,-1,
				LVNI_ALL|LVNI_SELECTED);
			while (j!=-1)
			{
				r=GetFtp(mdl,j,s,h,ex);
				if (r && ex)
					TELLDAEMON(STOP_BDL,mdl,MAKELONG(s,h));
				if (!mdl->spliton) break;
				j=ListView_GetNextItem(m->hwndTV,j,
					LVNI_ALL|LVNI_SELECTED);
			}
			break;

		case IDM_DOWNLOAD:
			j=ListView_GetNextItem(m->hwndTV,-1,
				LVNI_ALL|LVNI_SELECTED);
			while (j!=-1)
			{
				r=GetFtp(mdl,j,s,h,ex);
				if (r && ex)
				{
					// show win
				}
				else
					if (r)
						TELLDAEMON(START_BDL,mdl,MAKELONG(s,h));
				j=ListView_GetNextItem(m->hwndTV,j,
					LVNI_ALL|LVNI_SELECTED);
			}
			break;
		case IDM_CONSOLE:
			j=ListView_GetNextItem(m->hwndTV,-1,
				LVNI_ALL|LVNI_SELECTED);
			while (j!=-1)
			{
				r=GetFtp(mdl,j,s,h,ex);
				if (ex)
				{
					basicdl *bdl;
					if (s>-1) bdl=mdl->splitdl[s];
					else bdl=mdl->splitdl[h];
					((smallftp*)bdl->guiparam)->BufferWin();
				}
				j=ListView_GetNextItem(m->hwndTV,j,
					LVNI_ALL|LVNI_SELECTED);
			}
			break;
		}
		break;
	case WM_CLOSE:
		DestroyWindow(hwnd);
		SaveGUIConfig();
		break;
	case WM_NOTIFY:
		if (((LPNMHDR) lParam)->code==-307)
		{
			for (j=0;j<8;j++)
				TaskCol[j]=ListView_GetColumnWidth(m->hwndTV,j);
			//SaveGUIConfig();
			break;
		}
		if (((LPNMHDR) lParam)->hwndFrom==m->hwndTV)
			switch (((LPNMHDR) lParam)->code)
			{
			case NM_DBLCLK:
				SendMessage(hwnd,WM_COMMAND,IDM_DOWNLOAD,0);
				break;
/*			case LVN_GETDISPINFO:
				pnmv=(LV_DISPINFO *) lParam;
				if (pnmv->item.mask & LVIF_TEXT) 
				{
					if (!pnmv->item.iItem || (pnmv->item.iItem==m->tlastsp+1)
						|| (pnmv->item.iItem==m->tlastsp+2))
						break;
					STATUSITEM *pitem = (STATUSITEM *)(pnmv->item.lParam);
					lstrcpy(pnmv->item.pszText,pitem->c[pnmv->item.iSubItem]);
				}*/
			}

		if (((LPNMHDR) lParam)->code==TTN_NEEDTEXT)
		{
			LPTOOLTIPTEXT lpttt;
			lpttt = (LPTOOLTIPTEXT) lParam;
			lpttt->hinst = hinst;
			int idButton = lpttt->hdr.idFrom;
			switch (idButton)
			{
				case 0:
					strcpy(str,GetSTR2(229,"Start selected tasks"));
					lpttt->lpszText = str;
					break;
				case 1:
					strcpy(str,GetSTR2(230,"Pause selected tasks"));
					lpttt->lpszText = str;
					break;
				case 2:
					strcpy(str,GetSTR2(231,"Stop download"));
				    lpttt->lpszText = str;
					break;
			}
			dds2();
		}
		break;

	case WM_USER+10:
		STATUSITEM *pitem;
		//int dx;
		pitem= (STATUSITEM *) ((DRAWITEMSTRUCT *)wParam)->itemData;
		if (!pitem)
		{
			if (!lParam)
			{
				ListView_GetItemText(m->hwndTV,((DRAWITEMSTRUCT *)wParam)->itemID,0,str,1000);
				m->tlv.PutTXT(2,str);
			}
			break;
		}
/*		if (lParam==0)
		{
			int ic;
			HICON hIcon3=NULL;
			GetMainLVIcon(hIcon3,pitem,ic);
			if (hIcon3)
			{
				DrawIconEx(lv.tmpdc,0,0,hIcon3,15,15,0,0,DI_NORMAL);
				DeleteObject(hIcon3);
			}
			else ImageList_Draw(lv.il,ic,lv.tmpdc,0,0,ILD_TRANSPARENT);
			dx=20;
		}
		else dx=2;*/
		m->tlv.PutTXT(2,pitem->c[m->tlv.colorder[lParam]]);
		break;

/*	case WM_USER+11:
		if (((signed)wParam)==lsortd)
		{
			if (sortd[wParam]) sortd[wParam]=0;
			else sortd[wParam]=1;
		}
		else lsortd=wParam;
		ListView_SortItems(hwndLV,StatusCmpFunc,
			(LPARAM) MAKELONG(wParam,sortd[wParam]));
		for (j=0;j<ListView_GetItemCount(hwndLV);j++)
		{
			STATUSITEM *pitem = (STATUSITEM *) GetLVlParam(hwndLV,j);
			pitem->pos=j;
		}
		break;*/

	case WM_DESTROY:
		SaveGUIConfig();
		for (j=0;j<MAXHAMMER;j++)
			if (m->titem[j+TOPMAXSPLIT]!=NULL)
				RemoveTask(mdl,-1,j);
		for (j=0;j<cfg.maxsplit;j++)
			if (m->titem[j]!=NULL)
				RemoveTask(mdl,j,-1);
		ListView_SetImageList(m->hwndTV, 0, LVSIL_SMALL);
		DestroyWindow(m->hwndTV);
		m->htask=NULL;
		m->tlv.kill();
		break;
	case SKN_BTUP:
        switch (LOWORD(wParam)){
        case 0:
			PostMessage(hwnd,WM_COMMAND,IDM_DOWNLOAD,0);
			break;
        case 1:
			PostMessage(hwnd,WM_COMMAND,IDM_STOP,0);
			break;
        case 2:
			TELLDAEMON(STOP_MDL,mdl,0);
			break;
		}
        break;
	case SKN_TRLV:
		time(&m->tracktime);
		m->trackpos=lParam;
        break;
	case SKN_TRUP:
		sprintf(sksplits,"%ld",lParam);
		PostMessage(hwnd,_SKN_TXT,MAKELONG(2,0),(LPARAM)sksplits);
		break;
    default:
        if (ret==-1)
			return DefWindowProc(hwnd, message, wParam, lParam);
	}
	return 0;
}

BOOL WINAPI ShortcutMenu(HWND hwnd, int x, int y) 
{ 
	RECT rc;
	POINT pt = { x, y };
	if (ListView_GetNextItem(hwndLV,-1,LVNI_ALL|LVNI_SELECTED)>-1)
	{
		DisplayItemMenu(hwnd, pt);
		return TRUE;
	}
	GetClientRect(hwnd, &rc);  
	ScreenToClient(hwnd, &pt);  
	if (PtInRect(&rc, pt))
	{
		ClientToScreen(hwnd, &pt);
		DisplayGeneralMenu(hwnd, pt);
		return TRUE;
	}
    return FALSE;
}

VOID APIENTRY DisplayStatusTrayMenu(HWND hwnd,POINT pt)
{
	HMENU hmenu,hmenuTrackPopup;

	int r2l=0;
	if (cfg.r2l)
		r2l=MFT_RIGHTJUSTIFY|MFT_RIGHTORDER;

	hmenu=CreateMenu();
	hmenuTrackPopup=CreateMenu();

	MENUITEMINFO mi;
	memset(&mi,0,sizeof(MENUITEMINFO));
	mi.cbSize=sizeof(MENUITEMINFO);
	mi.fMask=MIIM_SUBMENU|MIIM_TYPE;
	mi.fType=r2l|MFT_STRING;
	mi.hSubMenu=hmenuTrackPopup;
	InsertMenuItem(hmenu,0,true,&mi);

	memset(&mi,0,sizeof(MENUITEMINFO));
	mi.cbSize=sizeof(MENUITEMINFO);
	mi.fMask=MIIM_TYPE|MIIM_DATA|MIIM_ID;
	mi.fType=r2l|MFT_STRING;
	mi.wID=IDM_SHOWSTATUS;
	mi.dwTypeData=GetSTR(328,"Show status window");
	InsertMenuItem(hmenuTrackPopup,0,true,&mi);

	mi.wID=IDM_URL;
	mi.dwTypeData=GetSTR(285,"&Enter URL                       Ctrl+E");
	InsertMenuItem(hmenuTrackPopup,1,true,&mi);

	mi.wID=IDM_HIDEALL;
	mi.dwTypeData=GetSTR(305,"Hide all");
	InsertMenuItem(hmenuTrackPopup,2,true,&mi);

	mi.wID=IDM_STOPALL;
	mi.dwTypeData=GetSTR(304,"Pa&use all                              Ctrl+U");
	InsertMenuItem(hmenuTrackPopup,3,true,&mi);

	mi.fType=r2l|MFT_SEPARATOR;
	InsertMenuItem(hmenuTrackPopup,4,true,&mi);

	mi.fType=r2l|MFT_STRING;
	mi.wID=IDM_DIAL;
	mi.dwTypeData=GetSTR(306,"Dia&l to the InterNet              Ctrl+L");
	InsertMenuItem(hmenuTrackPopup,5,true,&mi);

	mi.fType=r2l|MFT_SEPARATOR;
	InsertMenuItem(hmenuTrackPopup,6,true,&mi);

	mi.fType=r2l|MFT_STRING;
	mi.wID=IDM_EXIT;
	mi.dwTypeData=GetSTR(290,"&Shut down GetSmart        Ctrl+X");
	InsertMenuItem(hmenuTrackPopup,7,true,&mi);

	mi.wID=IDM_SHUTGUI;
	mi.dwTypeData=GetSTR(291,"Shut down GUI only         Ctrl+G");
	InsertMenuItem(hmenuTrackPopup,8,true,&mi);

	TrackPopupMenuEx(hmenuTrackPopup ,TPM_LEFTALIGN|TPM_LEFTBUTTON, 
		pt.x, pt.y,hwnd,NULL);
	DestroyMenu(hmenuTrackPopup);
	DestroyMenu(hmenu);
}

VOID APIENTRY DisplayItemTrayMenu(HWND hwnd,POINT pt)
{ 
	HMENU hmenu,hmenuTrackPopup;
	int r2l=0;
	if (cfg.r2l)
		r2l=MFT_RIGHTJUSTIFY|MFT_RIGHTORDER;

	hmenu=CreateMenu();
	hmenuTrackPopup=CreateMenu();

	MENUITEMINFO mi;
	memset(&mi,0,sizeof(MENUITEMINFO));
	mi.cbSize=sizeof(MENUITEMINFO);
	mi.fMask=MIIM_SUBMENU|MIIM_TYPE;
	mi.fType=r2l|MFT_STRING;
	mi.hSubMenu=hmenuTrackPopup;
	InsertMenuItem(hmenu,0,true,&mi);

	memset(&mi,0,sizeof(MENUITEMINFO));
	mi.cbSize=sizeof(MENUITEMINFO);
	mi.fMask=MIIM_TYPE|MIIM_DATA|MIIM_ID;
	mi.fType=r2l|MFT_STRING;
	mi.wID=IDM_DLSHOW;
	mi.dwTypeData=GetSTR(324,"Show");
	InsertMenuItem(hmenuTrackPopup,0,true,&mi);

	mi.wID=IDM_DLSTOP;
	mi.dwTypeData=GetSTR(299,"&Pause             Ctrl+P");
	InsertMenuItem(hmenuTrackPopup,1,true,&mi);

	mi.wID=IDM_DLHIDE;
	mi.dwTypeData=GetSTR(300,"&Hide               Ctrl+H");
	InsertMenuItem(hmenuTrackPopup,2,true,&mi);

	mi.wID=IDM_DLMIRRORS;
	mi.dwTypeData=GetSTR(301,"&Mirrors           Ctrl+M");
	InsertMenuItem(hmenuTrackPopup,3,true,&mi);

	mi.fType=r2l|MFT_SEPARATOR;
	InsertMenuItem(hmenuTrackPopup,4,true,&mi);

	mi.fType=r2l|MFT_STRING;
	mi.wID=IDM_DLPROPERTIES;
	mi.dwTypeData=GetSTR(302,"P&roperties      Alt+ENTER");
	InsertMenuItem(hmenuTrackPopup,5,true,&mi);

	mi.fType=r2l|MFT_SEPARATOR;
	InsertMenuItem(hmenuTrackPopup,6,true,&mi);

	mi.fType=r2l|MFT_STRING;
	mi.wID=IDM_DLCONSOLE;
	mi.dwTypeData=GetSTR(222,"Show/Hide console window");
	InsertMenuItem(hmenuTrackPopup,7,true,&mi);

	mi.wID=IDM_DLTASKMAN;
	mi.dwTypeData=GetSTR(220,"Show/Hide Task manager");
	InsertMenuItem(hmenuTrackPopup,8,true,&mi);

	mi.wID=IDM_DLCHANGESHAPE;
	mi.dwTypeData=GetSTR(325,"Hide/Show &Split track");
	InsertMenuItem(hmenuTrackPopup,9,true,&mi);

	TrackPopupMenu(hmenuTrackPopup,TPM_LEFTALIGN | TPM_LEFTBUTTON, 
		pt.x, pt.y, 0, hwnd, NULL);
	DestroyMenu(hmenuTrackPopup);
	DestroyMenu(hmenu);
}

VOID APIENTRY DisplayGeneralMenu(HWND hwnd, POINT pt)
{ 
	HMENU hmenu,hmenuTrackPopup;
	int r2l=0;
	if (cfg.r2l)
		r2l=MFT_RIGHTJUSTIFY|MFT_RIGHTORDER;

	hmenu=CreateMenu();
	hmenuTrackPopup=CreateMenu();

	MENUITEMINFO mi;
	memset(&mi,0,sizeof(MENUITEMINFO));
	mi.cbSize=sizeof(MENUITEMINFO);
	mi.fMask=MIIM_SUBMENU|MIIM_TYPE;
	mi.fType=r2l|MFT_STRING;
	mi.hSubMenu=hmenuTrackPopup;
	InsertMenuItem(hmenu,0,true,&mi);

	mi.fMask=MIIM_DATA|MIIM_ID|MIIM_TYPE;
	mi.hSubMenu=NULL;
	mi.wID=IDM_SELECTALL;
	mi.dwTypeData=GetSTR(295,"Select &All                             Ctrl+A");
	InsertMenuItem(hmenuTrackPopup,0,true,&mi);

	mi.wID=IDM_SELECTACTIVE;
	mi.dwTypeData=GetSTR(296,"Select acti&ve                        Ctrl+V");
	InsertMenuItem(hmenuTrackPopup,1,true,&mi);
	
	mi.fType=r2l|MFT_SEPARATOR;
	InsertMenuItem(hmenuTrackPopup,2,true,&mi);

	mi.fType=r2l|MFT_STRING;
	mi.wID=IDM_STOPALL;
	mi.dwTypeData=GetSTR(304,"Pa&use all                              Ctrl+U");
	InsertMenuItem(hmenuTrackPopup,3,true,&mi);

	mi.fType=r2l|MFT_SEPARATOR;
	InsertMenuItem(hmenuTrackPopup,4,true,&mi);

	mi.fType=r2l|MFT_STRING;
	mi.wID=IDM_CONFIG;
	mi.dwTypeData=GetSTR(297,"&Configuration                        Ctrl+C");
	InsertMenuItem(hmenuTrackPopup,5,true,&mi);

	TrackPopupMenu(hmenuTrackPopup,TPM_LEFTALIGN | TPM_LEFTBUTTON, 
		pt.x, pt.y, 0, hwnd, NULL);
	DestroyMenu(hmenuTrackPopup);
	DestroyMenu(hmenu);
}

VOID APIENTRY DisplayItemMenu(HWND hwnd, POINT pt)
{ 
	HMENU hmenu,hmenuTrackPopup;

	int r2l=0;
	if (cfg.r2l)
		r2l=MFT_RIGHTJUSTIFY|MFT_RIGHTORDER;

	hmenu=CreateMenu();
	hmenuTrackPopup=CreateMenu();

	MENUITEMINFO mi;
	memset(&mi,0,sizeof(MENUITEMINFO));
	mi.cbSize=sizeof(MENUITEMINFO);
	mi.fMask=MIIM_SUBMENU|MIIM_TYPE;
	mi.fType=r2l|MFT_STRING;
	mi.hSubMenu=hmenuTrackPopup;
	InsertMenuItem(hmenu,0,true,&mi);

	memset(&mi,0,sizeof(MENUITEMINFO));
	mi.cbSize=sizeof(MENUITEMINFO);
	mi.fMask=MIIM_TYPE|MIIM_DATA|MIIM_ID;
	mi.fType=r2l|MFT_STRING;
	mi.wID=IDM_DOWNLOAD;
	mi.dwTypeData=GetSTR(298,"&Download");
	InsertMenuItem(hmenuTrackPopup,0,true,&mi);

	mi.wID=IDM_STOP;
	mi.dwTypeData=GetSTR(299,"&Pause             Ctrl+P");
	InsertMenuItem(hmenuTrackPopup,1,true,&mi);

	mi.wID=IDM_HIDE;
	mi.dwTypeData=GetSTR(300,"&Hide               Ctrl+H");
	InsertMenuItem(hmenuTrackPopup,2,true,&mi);

	mi.wID=IDM_REMOVE;
	mi.dwTypeData=GetSTR(292,"&Remove entry                       DEL");
	InsertMenuItem(hmenuTrackPopup,3,true,&mi);

	mi.fType=r2l|MFT_SEPARATOR;
	InsertMenuItem(hmenuTrackPopup,4,true,&mi);

	mi.fType=r2l|MFT_STRING;
	mi.wID=IDM_CONSOLE;
	mi.dwTypeData=GetSTR(222,"Show/Hide console window");
	InsertMenuItem(hmenuTrackPopup,5,true,&mi);

	mi.wID=IDM_SHOWTASKS;
	mi.dwTypeData=GetSTR(220,"Show/Hide Task manager");
	InsertMenuItem(hmenuTrackPopup,6,true,&mi);

	mi.wID=IDM_MIRRORS;
	mi.dwTypeData=GetSTR(301,"&Mirrors           Ctrl+M");
	InsertMenuItem(hmenuTrackPopup,7,true,&mi);

	mi.fType=r2l|MFT_SEPARATOR;
	InsertMenuItem(hmenuTrackPopup,8,true,&mi);

	mi.fType=r2l|MFT_STRING;
	mi.wID=IDM_PROPERTIES;
	mi.dwTypeData=GetSTR(302,"P&roperties      Alt+ENTER");
	InsertMenuItem(hmenuTrackPopup,9,true,&mi);

	mi.wID=IDM_SHOWERROR;
	mi.dwTypeData=GetSTR(323,"Show &Error message");
	InsertMenuItem(hmenuTrackPopup,10,true,&mi);

	TrackPopupMenu(hmenuTrackPopup,TPM_LEFTALIGN | TPM_LEFTBUTTON, 
		pt.x, pt.y, 0, hwnd, NULL);
	DestroyMenu(hmenuTrackPopup);
	DestroyMenu(hmenu);
}

VOID APIENTRY DisplayShowModeMenu(HWND hwnd,POINT pt)
{ 
	HMENU hmenu,hmenuTrackPopup;

	int r2l=0;
	if (cfg.r2l)
		r2l=MFT_RIGHTJUSTIFY|MFT_RIGHTORDER;

	hmenu=CreateMenu();
	hmenuTrackPopup=CreateMenu();

	MENUITEMINFO mi;
	memset(&mi,0,sizeof(MENUITEMINFO));
	mi.cbSize=sizeof(MENUITEMINFO);
	mi.fMask=MIIM_SUBMENU|MIIM_TYPE;
	mi.fType=r2l|MFT_STRING;
	mi.hSubMenu=hmenuTrackPopup;
	InsertMenuItem(hmenu,0,true,&mi);

	mi.fMask=MIIM_DATA|MIIM_ID|MIIM_TYPE|MIIM_STATE;
	mi.hSubMenu=NULL;
	mi.fState=MFS_CHECKED;
	mi.wID=IDM_SHOWDLWIN;
	mi.dwTypeData=GetSTR(326,"Show small download window");
	InsertMenuItem(hmenuTrackPopup,0,true,&mi);

	mi.wID=IDM_SHOWDLTRAY;
	mi.dwTypeData=GetSTR(327,"Show download tray icon");
	InsertMenuItem(hmenuTrackPopup,1,true,&mi);

	if (!gcfg.showdlwin) CheckMenuItem(hmenu,IDM_SHOWDLWIN,MF_UNCHECKED);
	if (!gcfg.showdltray) CheckMenuItem(hmenu,IDM_SHOWDLTRAY,MF_UNCHECKED);

	TrackPopupMenu(hmenuTrackPopup,TPM_LEFTALIGN | TPM_LEFTBUTTON,
										pt.x, pt.y, 0, hwnd, NULL);
	DestroyMenu(hmenuTrackPopup);
	DestroyMenu(hmenu);
}

BOOL WINAPI ShortcutMenu2(HWND hwnd, int x, int y,HWND hwndLV) 
{ 
//	RECT rc;
	POINT pt = { x, y };
	if (ListView_GetNextItem(hwndLV,-1,LVNI_ALL|LVNI_SELECTED)>-1)
	{
		DisplayItemMenu2(hwnd, pt);
		return TRUE;
	}
/*	GetClientRect(hwnd, &rc);  
	ScreenToClient(hwnd, &pt);  
	if (PtInRect(&rc, pt))
	{
		ClientToScreen(hwnd, &pt);
		DisplayGeneralMenu(hwnd, pt);
		return TRUE;
	}*/
    return FALSE;
 } 

/*VOID APIENTRY DisplayGeneralMenu(HWND hwnd, POINT pt)
{ 
	HMENU hmenu,hmenuTrackPopup;
	if ((hmenu = LoadMenu(hinst, "GENERALMENU")) == NULL)
		return;  
	hmenuTrackPopup = GetSubMenu(hmenu, 0);
	TrackPopupMenu(hmenuTrackPopup,TPM_LEFTALIGN | TPM_LEFTBUTTON, 
		pt.x, pt.y, 0, hwnd, NULL);
	DestroyMenu(hmenuTrackPopup);
	DestroyMenu(hmenu);
}*/

VOID APIENTRY DisplayItemMenu2(HWND hwnd, POINT pt)
{ 
	HMENU hmenu,hmenuTrackPopup;

	int r2l=0;
	if (cfg.r2l)
		r2l=MFT_RIGHTJUSTIFY|MFT_RIGHTORDER;

	hmenu=CreateMenu();
	hmenuTrackPopup=CreateMenu();

	MENUITEMINFO mi;
	memset(&mi,0,sizeof(MENUITEMINFO));
	mi.cbSize=sizeof(MENUITEMINFO);
	mi.fMask=MIIM_SUBMENU|MIIM_TYPE;
	mi.fType=r2l|MFT_STRING;
	mi.hSubMenu=hmenuTrackPopup;
	InsertMenuItem(hmenu,0,true,&mi);

	memset(&mi,0,sizeof(MENUITEMINFO));
	mi.cbSize=sizeof(MENUITEMINFO);
	mi.fMask=MIIM_TYPE|MIIM_DATA|MIIM_ID;
	mi.fType=r2l|MFT_STRING;
	mi.wID=IDM_DOWNLOAD;
	mi.dwTypeData=GetSTR(329,"&Start task");
	InsertMenuItem(hmenuTrackPopup,0,true,&mi);

	mi.wID=IDM_STOP;
	mi.dwTypeData=GetSTR(299,"&Pause             Ctrl+P");
	InsertMenuItem(hmenuTrackPopup,1,true,&mi);

	mi.fType=r2l|MFT_SEPARATOR;
	InsertMenuItem(hmenuTrackPopup,2,true,&mi);

	mi.fType=r2l|MFT_STRING;
	mi.wID=IDM_CONSOLE;
	mi.dwTypeData=GetSTR(222,"Show/Hide console window");
	InsertMenuItem(hmenuTrackPopup,3,true,&mi);

	mi.fType=r2l|MFT_SEPARATOR;
	InsertMenuItem(hmenuTrackPopup,4,true,&mi);


	TrackPopupMenu(hmenuTrackPopup,TPM_LEFTALIGN | TPM_LEFTBUTTON, 
		pt.x, pt.y, 0, hwnd, NULL);
	DestroyMenu(hmenuTrackPopup);
	DestroyMenu(hmenu);
}

LRESULT WINAPI NewListProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	WNDPROC OldProc;
	
	OldProc = (WNDPROC)GetProp( hWnd, "OldProc");


	//if ((msg==WM_HSCROLL) || (msg==WM_VSCROLL))
	//	SendMessage(GetParent(hWnd),msg,wParam,lParam);
//	if (msg==LB_DELETESTRING)
//		SendMessage(hWnd,WM_SETREDRAW,0,0);
		
	/*	if (( msg == WM_CREATE) || ( msg == WM_SIZE))
	{
		HDC hdc=GetDC(hWnd);
		HBRUSH hb;
		RECT re;
		hb=CreateSolidBrush(RGB(0,0,0));
		GetClientRect(hWnd,&re);
		FillRect(hdc, &re, hb);
		DeleteObject(hb);
		ReleaseDC(hWnd,hdc);
	}*/

	if( msg == WM_DESTROY )
	{
		SetWindowLong( hWnd, GWL_WNDPROC, (DWORD)OldProc);
		RemoveProp( hWnd, "OldProc");
	}
	
	
	if( msg == WM_ERASEBKGND )                  //  Background needs erased
	{
		HBRUSH hBrush;
		RECT Rect, itemRect;
		int iCount;
		iCount = SendMessage( hWnd, LB_GETCOUNT, 0, 0);
		SendMessage( hWnd, LB_GETITEMRECT, iCount - 1,(LPARAM)&itemRect);
		GetClientRect( hWnd, &Rect);
		if( itemRect.bottom > Rect.bottom )//  If more than can display
			return 1;
		hBrush = CreateSolidBrush(0);
		Rect.top = itemRect.bottom;
		FillRect( (HDC)wParam, &Rect, hBrush );
		DeleteObject( hBrush );
		return 1;
	}
	return( CallWindowProc( (int (__stdcall*)(void))OldProc, hWnd, msg, wParam, lParam));
}

LRESULT CALLBACK BufferFunc(HWND hwnd, UINT message,
                         WPARAM wParam, LPARAM lParam)
{
	char str[1024];
	char c;
    int y;
	smallftp *f;
    LPMEASUREITEMSTRUCT lpmis;
    LPDRAWITEMSTRUCT lpdis;
	TEXTMETRIC tm;
	static COLORREF clr[5]={RGB(0,0,255), RGB(0,255,0), RGB(60,200,60),
		RGB(255,0,0), RGB(255,255,255) };
	SkinWinNfo *skbuffer=(SkinWinNfo*)GetWindowLong(hwnd,GWL_USERDATA);
	if (skbuffer)
		f=(smallftp *)skbuffer->data;
	LRESULT ret=bufferskin.fn(hwnd,message,wParam,lParam);
	switch(message)
	{
	case WM_CREATE:
		skbuffer=(SkinWinNfo*)(((LPCREATESTRUCT) lParam)->lpCreateParams); 
		f=(smallftp *)skbuffer->data;
		f->hwndBB = CreateWindowEx(0,
		"LISTBOX", "",WS_CHILD |WS_VSCROLL|LBS_HASSTRINGS|LBS_NOSEL|LBS_OWNERDRAWFIXED|LBS_NOINTEGRALHEIGHT,
			0, 0, 0, 0, hwnd, NULL, hinst, NULL);
		SetProp( f->hwndBB, "OldProc", (HANDLE)GetWindowLong( f->hwndBB, GWL_WNDPROC));
		SetWindowLong( f->hwndBB, GWL_WNDPROC, (DWORD)NewListProc);
		if ((f->bdl==NULL) || (!f->mdl->spe[f->bdl->splitdex]))
			sprintf(str,"Console of %s",f->mdl->lfn);
		else
			sprintf(str,"Console of %s (%d) %d-%d",f->mdl->lfn,
					f->bdl->splitdex,f->mdl->sps[f->bdl->splitdex],
					f->mdl->spe[f->bdl->splitdex]);
		SetWindowText(hwnd,str);
		if (BufferRect.top || BufferRect.left || BufferRect.right ||
													BufferRect.bottom)
			MoveWindow(hwnd,BufferRect.left,BufferRect.top,
				BufferRect.right-BufferRect.left,
				BufferRect.bottom-BufferRect.top,true);
		if (f->autoscroll)
				PostMessage(hwnd,_SKN_BTSET,MAKELONG(0,0),1);
		SendMessage(hwnd,WM_SIZE,0,0);
		ShowWindow(hwnd,SW_SHOW);
		break;
	case WM_ACTIVATE:
		if	(LOWORD(wParam) == WA_INACTIVE)
			hgdlg=NULL;
		else
			hgdlg=hwnd;
		break;
	case WM_SIZE:
		if (wParam==SIZE_MINIMIZED) break;
		RECT rc;
        GetClientRect(hwnd, &rc);
        SetWindowPos(f->hwndBB, HWND_TOP, rc.left, rc.top+40,
				rc.right , rc.bottom-40, SWP_SHOWWINDOW);  
		GetWindowRect(hwnd,&BufferRect);
		SendMessage(hwnd,_SKN_RESIZE,0,0);
		//if (wParam) PostMessage(hwnd,WM_SIZE,0,0);
		break;
	case WM_MOVE:
		RECT re;
		GetClientRect(hwnd,&re);
		if (!re.bottom && !re.right) break;
		GetWindowRect(hwnd,&BufferRect);
		break;
	case WM_ERASEBKGND:
		return DefWindowProc(hwnd, message, wParam, lParam);

	case WM_NOTIFY:
		if (((LPNMHDR) lParam)->code==TTN_NEEDTEXT)
		{
			LPTOOLTIPTEXT lpttt;
			lpttt = (LPTOOLTIPTEXT) lParam;
			lpttt->hinst = hinst;
			int idButton = lpttt->hdr.idFrom;
			switch (idButton)
			{
			case 0:
				strcpy(str,GetSTR2(232,"Enable / Disable autoscroll"));
				lpttt->lpszText = str;
				break;
			}
			dds2();
		}
		break;

/*	case WM_CTLCOLORLISTBOX:
		HBRUSH hb;
		hb=CreateSolidBrush(RGB(0,0,0));
		GetClientRect((HWND)lParam,&re);
		FillRect( (HDC)wParam, &re, hb);
		DeleteObject(hb);
		break;*/

	case WM_MEASUREITEM: 
		lpmis = (LPMEASUREITEMSTRUCT) lParam;
		//GetTextMetrics(lpmis->hDC, &tm);
		//lpmis->itemHeight = tm.tmHeight;
		break;

	case WM_DRAWITEM: 
		lpdis = (LPDRAWITEMSTRUCT) lParam; 
		if (lpdis->itemID == -1)
			break;
		switch (lpdis->itemAction)
		{
		case ODA_SELECT: 
		case ODA_DRAWENTIRE: 
			SendMessage(lpdis->hwndItem,
						LB_GETTEXT, lpdis->itemID, (LPARAM) str);
			GetTextMetrics(lpdis->hDC, &tm);
			y = (lpdis->rcItem.bottom + lpdis->rcItem.top - 
				tm.tmHeight) / 2;
			//c=txt[strlen(txt)+1];
			c=(char)SendMessage(lpdis->hwndItem,LB_GETITEMDATA,
					lpdis->itemID, (LPARAM) 0);
			if (c>4) c=4;
			SendMessage(lpdis->hwndItem, LB_GETITEMRECT, 
				lpdis->itemID, (LPARAM)&re);
			HBRUSH hb;
			hb = CreateSolidBrush(0);
			FillRect(lpdis->hDC, &re, hb);            //  Paint item background area
			DeleteObject(hb);

			SetTextColor(lpdis->hDC,clr[c]);
			SetBkMode(lpdis->hDC,TRANSPARENT);
			TextOut(lpdis->hDC,
						0,
						y,
						str,
						strlen(str));
			break;
		case ODA_FOCUS: 
                     /* 
                     * Do not process focus changes. The focus caret 
                     * (outline rectangle) indicates the selection. 
                     * The Which one? (IDOK) button indicates the final 
                     * selection. 
                     */ 
                     break; 
		}
		break;
	case WM_DESTROY:
		SaveGUIConfig();
		SendMessage(f->hwndBB,LB_RESETCONTENT,0,0);
		DestroyWindow(f->hwndBB);
		if ((f->m->mftp!=f) && (f->m->mftp->hbuffer==f->hbuffer))
		{
			f->m->mftp->hbuffer=NULL;
			if (f->mdl->spliton && !f->m->mftp->killbuffer)
			{
				f->m->mftp->BufferWin();
				f->m->mftp->killbuffer=true;
			}
		}
		f->hbuffer=NULL;
		break;
/*	case WM_HSCROLL:
	case WM_VSCROLL:
		if (!f->autoscroll)
		{
			//GetClientRect(f->hwndBB,&re);
			SendMessage(f->hwndBB,WM_SETREDRAW,1,0);
			//InvalidateRect(f->hwndBB,&re,false);
			f->autoscroll=true;
			SendMessage(f->hwndBB,message,wParam,lParam);
			f->autoscroll=false;
			SendMessage(f->hwndBB,WM_SETREDRAW,0,0);
		}
		break;*/
	case SKN_BTUP:
        switch (LOWORD(wParam))
		{
        case 0:
			if (f->autoscroll)
			{
				f->autoscroll=false;
				PostMessage(hwnd,_SKN_BTSET,MAKELONG(0,0),0);
				//SendMessage(f->hwndBB,WM_SETREDRAW,0,0);
			}
			else
			{
				f->autoscroll=true;
				PostMessage(hwnd,_SKN_BTSET,MAKELONG(0,0),1);
				//SendMessage(f->hwndBB,WM_SETREDRAW,1,0);
			}
		}
		break;
	default:
		if (ret==-1)
			return DefWindowProc(hwnd, message, wParam, lParam);
	}
	return 0;
}

struct prevstat
{
	char *lfn, *ldir, *host, *rdir;
	time_t starttime;
	bool opentrack,done;
	HWND hwnd;
	unsigned long rsize,lbytes,sbytes,cps,spliton;

	prevstat(HWND hwnd0,char *host0,char *rdir0,char *ldir0,
				char *lfn0,unsigned long rsize0)
	{
		time(&starttime);
		hwnd=hwnd0;
		host=DupString(host0);
		rdir=DupString(rdir0);
		ldir=DupString(ldir0);
		lfn=DupString(lfn0);
		rsize=rsize0;
		opentrack=false;
		lbytes=0;
		sbytes=0;
		spliton=1;
		cps=0;
		done=false;
	}
	~prevstat()
	{
		free(host);
		free(rdir);
		free(ldir);
		free(lfn);
	}
};

void UpdatePrevSmall(char txt[11][80],prevstat *ps)
{
	char str[1024];
	int i;
	time_t tp,ct;
	time(&ct);
	tp=ct-ps->starttime;
	if (ps->spliton)
	{
		time_t t;
		time(&t);
		srand( (unsigned)t);
		for (i=0;(unsigned)i<ps->spliton;i++)
		{
			ps->lbytes+=3000+rand()%1000;
			ps->sbytes+=3000+rand()%1000;
		}
		if (ps->lbytes>=ps->rsize)
		{
			ps->lbytes=ps->rsize;
			ps->done=true;
			ps->spliton=0;
		}
	}
	if (!ps->opentrack)
	{
		ps->opentrack=true;
		PostMessage(ps->hwnd,_SKN_BTSET,MAKELONG(6,1),1);
		PostMessage(ps->hwnd,_SKN_RGN,MAKELONG(3,1),
					MAKELONG(_S_RGIN|_S_RGOUT,0));
	}
	if (ps->rsize)
	{
		sprintf(txt[0],"Preview - %.1f%% %s (%s)",
				(int) (ps->lbytes*1000.0/ps->rsize) /10.0,
				ps->lfn,ps->ldir);
		sprintf(txt[2],"%.1fk/%.1fk",ps->lbytes/1024.0,
				ps->rsize/1024.0);
		PostMessage(ps->hwnd,_SKN_PRTOT,MAKELONG(0,0),ps->rsize);
		PostMessage(ps->hwnd,_SKN_PRCUR,MAKELONG(0,0),ps->lbytes);
	}
	else
	{
		sprintf(txt[0],"Preview - %.1fkb %s (%s)",
				ps->lbytes/1024.0,ps->lfn,ps->ldir);
		sprintf(txt[2],"%.1fk/???",ps->lbytes/1024.0);
	}
	SetWindowText(ps->hwnd,txt[0]);
	sprintf(str,"%s %s",ps->host,ps->rdir);
	strncpy(txt[1],str,79);
	txt[1][79]=0;
	sprintf(txt[3],"%.2d:%.2d:%.2d",tp/3600,(tp%3600)/60,
										((tp%3600)%60));
	int r;
	if (tp && (ps->sbytes/tp) && (ps->rsize))
		r=(ps->rsize-ps->lbytes)/(ps->sbytes/tp);
	else r=0;
	if (r)
		sprintf(txt[5],"%.2d:%.2d:%.2d",r/3600,(r%3600)/60,
											((r%3600)%60));
	else strcpy(txt[5],"??:??:??");
	if (tp)
		sprintf(txt[4],"%.2f kb/s",ps->sbytes/1024.0/tp);
	else strcpy(txt[4],"0.00 kb/s");
	sprintf(txt[6],"%.2f kb/s",ps->cps/1024.0);
	sprintf(txt[7],"%ld",ps->spliton);
	sprintf(txt[9],"%ld",0);
	if (ps->done)
	{
		PostMessage(ps->hwnd,_SKN_BTSET,MAKELONG(3,0),2);
		sprintf(txt[8],GetSTR2(180,"Done"));
		dds2();
	}
	else
		if (ps->spliton)
		{
			PostMessage(ps->hwnd,_SKN_BTSET,MAKELONG(3,0),0);
			sprintf(txt[8],GetSTR2(181,"Pause"));
			dds2();
		}
		else
		{
			PostMessage(ps->hwnd,_SKN_BTSET,MAKELONG(3,0),1);
			sprintf(txt[8],GetSTR2(109,"Resume"));
			dds2();
		}
	for(i=0;i<prevskin.numtxt;i++)
		if (prevskin.txt[i].def<21)
			PostMessage(ps->hwnd,_SKN_TXTUP,MAKELONG(i,0),0);
}

LRESULT CALLBACK PrevFunc(HWND hwnd, UINT message,
                            WPARAM wParam, LPARAM lParam)
{
	//int j;
	static char sktxt[10][80];
	static short trtxti=-1;
	static prevstat *ps;

	strcpy(sktxt[0],GetSTR2(209,"Tasks"));
	strcpy(sktxt[1],GetSTR2(110,"Timeout"));
	strcpy(sktxt[2],GetSTR2(210,"Splits"));
	strcpy(sktxt[3],"URL:");
	strcpy(sktxt[4],GetSTR2(211,"Elapsed:"));
	strcpy(sktxt[5],GetSTR2(212,"Est:"));
	strcpy(sktxt[6],GetSTR2(213,"Cur:"));
	strcpy(sktxt[7],GetSTR2(214,"Hide"));
	strcpy(sktxt[8],GetSTR2(215,"Ping"));
	strcpy(sktxt[9],GetSTR2(216,"Mirrors"));
	static char txt[11][80],stxt[80];
	strncpy(stxt,GetSTR2(28,"Downloading file."),80);
	dds2();

	SkinWinNfo *skprev=(SkinWinNfo*)GetWindowLong(hwnd,GWL_USERDATA);

	LRESULT ret=prevskin.fn(hwnd,message,wParam,lParam);
	switch(message)
	{
    case WM_HELP:
//		WinHelp(hwnd, HelpFile, HELP_CONTEXT ,IDH_TASKMANAGER);
		break;
	case WM_CREATE:
		skprev=(SkinWinNfo*)(((LPCREATESTRUCT) lParam)->lpCreateParams); 
		hwndprev=hwnd;
		strcpy(txt[10],"1");
		int i;
		for (i=0;i<prevskin.numtxt;i++)
			if (prevskin.txt[i].def<11)
			{
				if(prevskin.txt[i].def==10)
					trtxti=i;
				PostMessage(hwnd,_SKN_TXT,MAKELONG(i,0),(LPARAM)txt[prevskin.txt[i].def]);
			}
			else
			{
				switch(prevskin.txt[i].def)
				{
				case 20:
					PostMessage(hwnd,_SKN_TXT,MAKELONG(i,0),(LPARAM)stxt);
					break;
				case 21:
				case 22:
				case 23:
				case 24:
				case 25:
				case 26:
				case 27:
				case 28:
				case 29:
				case 30:
					PostMessage(hwnd,_SKN_TXT,MAKELONG(i,0),
										(LPARAM)sktxt[prevskin.txt[i].def-21]);
					break;
				case 40:
					PostMessage(hwnd,_SKN_TXT,MAKELONG(i,0),
										(LPARAM)sknormal);
					break;
				case 41:
					PostMessage(hwnd,_SKN_TXT,MAKELONG(i,0),
										(LPARAM)skfast);
					break;
				}
			}
		PostMessage(hwnd,_SKN_PRTOT,MAKELONG(0,0),1);
		PostMessage(hwnd,_SKN_PRCUR,MAKELONG(0,0),0);
		ShowWindow(hwnd,SW_SHOW);
		i=ListView_GetItemCount(hwndLV);
		if (!i)
		{
			char str[1024];
			GetExtDir(str,".exe");
			ps=new prevstat(hwnd,"getsmart.hypermart.net","/",str,
				"GSFull.exe",500000);
		}
		else
		{
			time_t t;
			time(&t);
			srand( (unsigned)t );
			STATUSITEM *pitem = (STATUSITEM *) GetLVlParam(hwndLV,rand()%i);
			unsigned long rs=pitem->mdl->rsize;
			if (!rs)
				rs=500000+rand()%500000;
			ps=new prevstat(hwnd,pitem->mdl->mirrorhead->nfo->host,pitem->mdl->mirrorhead->nfo->rdir,
							pitem->mdl->ldir,pitem->mdl->lfn,rs);
		}
		PostMessage(hwnd,_SKN_BTSET,MAKELONG(7,0),0);
		SetTimer(hwnd,1,1000,0);
		break;
	case WM_MOVE:
//		RECT re;
//		GetClientRect(hwnd,&re);
//		if (!re.bottom && !re.right) break;
		break;
	case WM_TIMER:
		if (ps->spliton)
			UpdatePrevSmall(txt,ps);
		if (ps->spliton)
			PostMessage(hwnd,_SKN_BTSET,MAKELONG(7,0),0);
		else
			if (ps->done)
				PostMessage(hwnd,_SKN_BTSET,MAKELONG(7,0),2);
			else
				PostMessage(hwnd,_SKN_BTSET,MAKELONG(7,0),1);
		break;
	case WM_NOTIFY:
		if (((LPNMHDR) lParam)->code==TTN_NEEDTEXT)
		{
			LPTOOLTIPTEXT lpttt;
			lpttt = (LPTOOLTIPTEXT) lParam;
			lpttt->hinst = hinst;
			int idButton = lpttt->hdr.idFrom;
			switch (idButton)
			{
				char str[1024];
			case 0:
				strcpy(str,GetSTR2(218,"Stop download and close window"));
				lpttt->lpszText=str;
				break;
			case 1:
				strcpy(str,GetSTR2(219,"Minimize window"));
				lpttt->lpszText=str;
				break;
			case 2:
				strcpy(str,GetSTR2(220,"Show/Hide Task manager"));
				lpttt->lpszText=str;
				break;
			case 3:
				strcpy(str,GetSTR2(221,"Pause/Resume a download"));
				lpttt->lpszText=str;
				break;
			case 4:
				strcpy(str,GetSTR2(222,"Show/Hide console window"));
				lpttt->lpszText=str;
				break;
			case 5:
				strcpy(str,GetSTR2(223,"Hide this window - the download will continue"));
				lpttt->lpszText=str;
				break;
			case 6:
				strcpy(str,GetSTR2(224,"Show/Hide Split track bar"));
				lpttt->lpszText=str;
				break;
			case 8:
				strcpy(str,GetSTR2(225,"Show/Hide Mirrors manager"));
				lpttt->lpszText=str;
				break;
/*			case 7:
			    lpttt->lpszText = "Split track bar";
				break;
			case 10:
			    lpttt->lpszText = "Set speed limit";
				break;*/
			}
			dds2();
		}
		break;
	case WM_CLOSE:
		DestroyWindow(hwnd);
		//SaveGUIConfig();
		break;
	case WM_DESTROY:
		KillTimer(hwnd,1);
		delete ps;
		hwndprev=NULL;
		prevskin.Kill();
		break;
	case SKN_BTUP:
        switch (LOWORD(wParam)){
        case 0:
			DestroyWindow(hwnd);
			break;
        case 1:
			ShowWindow(hwnd,SW_MINIMIZE);
			break;
        case 2:
			//f->m->TaskWin();
			break;
		case 3:
			if (ps->done)
			{
				DestroyWindow(hwnd);
				break;
			}
			if (!ps->spliton)
			{
				ps->spliton=skprev->tr[0].val;
				time(&ps->starttime);
				ps->sbytes=0;
			}
			else
			{
				ps->spliton=0;
				UpdatePrevSmall(txt,ps);
			}
			break;
		case 4:
			//if ((f->bdl==NULL) && (f->m->mftp->hbuffer!=NULL))
			//	f->killbuffer=true;
//			f->BufferWin();
			break;
		case 5:
			DestroyWindow(hwnd);
			break;
		case 6:
			PostMessage(hwnd,_SKN_BTSET,MAKELONG(6,1),1);
			PostMessage(hwnd,_SKN_RGN,MAKELONG(3,4),
						MAKELONG(_S_RGIN|_S_RGOUT,0));
			break;
		}
        break;
	case SKN_TRLV:
		ps->spliton=lParam;
        break;
	case SKN_TRUP:
		if (trtxti==-1) break;
		sprintf(txt[10],"%ld",lParam);
		PostMessage(hwnd,_SKN_TXTUP,MAKELONG(trtxti,0),0);
        break;
    default:
        if (ret==-1)
			return DefWindowProc(hwnd, message, wParam, lParam);
	}
	return ret;
}

LRESULT CALLBACK ServerFunc(HWND hwnd, UINT message,
                            WPARAM wParam, LPARAM lParam)
{
	char htxt[9][50],str[1024];
//	static char sksplits[10];
//	LV_DISPINFO *pnmv;
	int j,j2,i;//,r,s,h;
	//maindl *mdl=NULL;
	server *ser;
//	bool ex;
	if (slv.LVFunc(hwnd,message,wParam,lParam))
		return 0;
	SkinWinNfo *skserver=(SkinWinNfo*)GetWindowLong(hwnd,GWL_USERDATA);
	LRESULT ret=serverskin.fn(hwnd,message,wParam,lParam);
	switch(message)
	{
	case WM_ACTIVATE:
		if (IsWindow(hwndSV))
			SetFocus(hwndSV);
		if	(LOWORD(wParam) == WA_INACTIVE)
			hgdlg=NULL;
		else
			hgdlg=hwnd;
		break;
    case WM_HELP:
		//WinHelp(hwnd, HelpFile, HELP_CONTEXT ,IDH_TASKMANAGER);
		break;
	case WM_CREATE:
		skserver=(SkinWinNfo*)(((LPCREATESTRUCT) lParam)->lpCreateParams); 
		if (ServerRect.top || ServerRect.left || ServerRect.right ||
												ServerRect.bottom)
		MoveWindow(hwnd,ServerRect.left,ServerRect.top,
				ServerRect.right-ServerRect.left,
				ServerRect.bottom-ServerRect.top,true);
		strcpy(str,GetSTR2(233,"Server manager"));
		SetWindowText(hwnd,str);
		hserver=hwnd;
		strcpy(htxt[0],GetSTR2(227,"Host"));
		strcpy(htxt[1],GetSTR2(234,"Files"));
		strcpy(htxt[2],GetSTR2(235,"Active DLs"));
		strcpy(htxt[3],GetSTR2(236,"Connections"));
		strcpy(htxt[4],GetSTR2(237,"Logged in connections"));
		strcpy(htxt[5],GetSTR2(238,"Max downloads"));
		strcpy(htxt[6],GetSTR2(239,"Max connections"));
		strcpy(htxt[7],GetSTR2(240,"Only 1 connection"));
		dds2();
		slv.pos.top=40;
		slv.pos.bottom=-40;
		slv.Init(hwnd,&htxt[0][0],&ServerCol[0],8);
		hwndSV=slv.hwndLV;
		ListView_SetImageList(hwndSV, hlvicons, LVSIL_SMALL);
		//hwndSV=DoCreateList(hwnd,&htxt[0][0],&ServerCol[0],8,true,0);
		ShowWindow(hwnd,SW_SHOW);
		break;
	case WM_SIZE:
		if (wParam==SIZE_MINIMIZED) break;
		RECT rc;
        GetClientRect(hwnd, &rc);
/*        SetWindowPos(hwndSV, HWND_TOP, rc.left, rc.top+40, 
				rc.right , rc.bottom-40, SWP_SHOWWINDOW);*/
		GetWindowRect(hwnd,&ServerRect);
		//SendMessage(hwnd,_SKN_RESIZE,0,0);
		break;
	case WM_MOVE:
		RECT re;
		GetClientRect(hwnd,&re);
		if (!re.bottom && !re.right) break;
		GetWindowRect(hwnd,&ServerRect);
		break;
	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case IDM_CONFIG:
			if (ListView_GetSelectedCount(hwndSV))
				DialogBox(hlang,"SERVERCFG",hwnd,
							(DLGPROC)ServerCfgFunc);
			break;
		}
		break;
	case WM_CLOSE:
		DestroyWindow(hwnd);
		SaveGUIConfig();
		break;
	case WM_NOTIFY:
		if (((LPNMHDR) lParam)->code==-307)
		{
			for (j=0;j<8;j++)
				ServerCol[j]=ListView_GetColumnWidth(hwndSV,j);
			break;
		}
		if (((LPNMHDR) lParam)->hwndFrom==hwndSV)
			switch (((LPNMHDR) lParam)->code)
			{
			case NM_DBLCLK:
				PostMessage(hwnd,WM_COMMAND,IDM_CONFIG,0);
				break;
/*			case LVN_GETDISPINFO:
				pnmv=(LV_DISPINFO *) lParam;
				if (pnmv->item.mask & LVIF_TEXT) 
				{
					SERVERITEM *pitem = (SERVERITEM *)(pnmv->item.lParam);
					lstrcpy(pnmv->item.pszText,pitem->c[pnmv->item.iSubItem]);
				}
				break;*/
			case LVN_DELETEALLITEMS:
				i=ListView_GetItemCount(hwndSV);
				for (j=i-1;j>=0;j--)
					ListView_DeleteItem(hwndSV,j);
				break;
			case LVN_DELETEITEM:
				NM_LISTVIEW *p;
		 		p = (NM_LISTVIEW FAR *) lParam;
				SERVERITEM *pitem = (SERVERITEM *) p->lParam;
				for (j=1;j<8;j++)
					free(pitem->c[j]);
				for (j=0;j<8;j++)
					free(pitem->cb[j]);
				j=pitem->pos;
				i=ListView_GetItemCount(hwndSV);
				free(pitem);
				for (j2=j+1;j2<i;j2++)
				{
					pitem=(SERVERITEM *) GetLVlParam(hwndSV,j2);
					pitem->pos--;
				}
				break;
			}
		if (((LPNMHDR) lParam)->code==TTN_NEEDTEXT)
		{
			LPTOOLTIPTEXT lpttt;
			lpttt = (LPTOOLTIPTEXT) lParam;
			lpttt->hinst = hinst;
			int idButton = lpttt->hdr.idFrom;
			switch (idButton)
			{
				char str[1024];
				case 0:
					strcpy(str,GetSTR2(241,"Configure selected servers"));
					lpttt->lpszText = str;
					break;
/*				case 1: 
					lpttt->lpszText = "Pause selected tasks";
					break;
				case 2:
				    lpttt->lpszText = "Stop download"; 
					break;*/
			}
			dds2();
		}
		break;

	case WM_USER+10:
		SERVERITEM *pitem;
		//int dx;
		pitem= (SERVERITEM *) ((DRAWITEMSTRUCT *)wParam)->itemData;
/*		if (lParam==0)
		{
			int ic;
			HICON hIcon3=NULL;
			GetMainLVIcon(hIcon3,pitem,ic);
			if (hIcon3)
			{
				DrawIconEx(lv.tmpdc,0,0,hIcon3,15,15,0,0,DI_NORMAL);
				DeleteObject(hIcon3);
			}
			else ImageList_Draw(lv.il,ic,lv.tmpdc,0,0,ILD_TRANSPARENT);
			dx=20;
		}
		else dx=2;*/
		slv.PutTXT(2,pitem->c[slv.colorder[lParam]]);
		break;

/*	case WM_USER+11:
		if (((signed)wParam)==lsortd)
		{
			if (sortd[wParam]) sortd[wParam]=0;
			else sortd[wParam]=1;
		}
		else lsortd=wParam;
		ListView_SortItems(hwndLV,StatusCmpFunc,
			(LPARAM) MAKELONG(wParam,sortd[wParam]));
		for (j=0;j<ListView_GetItemCount(hwndLV);j++)
		{
			STATUSITEM *pitem = (STATUSITEM *) GetLVlParam(hwndLV,j);
			pitem->pos=j;
		}
		break;*/

	case WM_DESTROY:
		ser=serhead;
		while (ser)
		{
			ser->guiparam=NULL;
			ser=ser->next;
		}
		SaveGUIConfig();
		ListView_SetImageList(hwndSV, 0, LVSIL_SMALL);
		DestroyWindow(hwndSV);
		hserver=NULL;
		slv.kill();
		PostMessage(hwndgui,_SKN_BTSET,MAKELONG(6,0),0);
		break;
	case SKN_BTUP:
        switch (LOWORD(wParam)){
        case 0:
			PostMessage(hwnd,WM_COMMAND,IDM_CONFIG,0);
			break;
/*        case 1:
			PostMessage(hwnd,WM_COMMAND,IDM_STOP,0);
			break;
        case 2:
			TELLDAEMON(STOP_MDL,mdl,0);
			break;*/
		}
        break;
	case SKN_TRLV:
		//time(tracktime);
		//m->trackpos=lParam;
        break;
	case SKN_TRUP:
		//sprintf(sksplits,"%ld",lParam);
		//PostMessage(hwnd,_SKN_TXT,MAKELONG(2,0),(LPARAM)sksplits);
		break;
    default:
        if (ret==-1)
			return DefWindowProc(hwnd, message, wParam, lParam);
	}
	return 0;
}

LRESULT CALLBACK MirrorFunc(HWND hwnd, UINT message,
                            WPARAM wParam, LPARAM lParam)
{
	char htxt[10][50],str[1024];
//	LV_DISPINFO *pnmv;
	int j,j2,i;//,r,s,h;
//	maindl *mdl=NULL;
	mirrors *mir;
	mainftp *m;
	SkinWinNfo *skmirror=(SkinWinNfo*)GetWindowLong(hwnd,GWL_USERDATA);
	if (skmirror)
	{
		m=(mainftp *)skmirror->data;
		if (m->mlv.LVFunc(hwnd,message,wParam,lParam))
			return 0;
	}
	LRESULT ret=mirrorskin.fn(hwnd,message,wParam,lParam);
	switch(message)
	{
	case WM_ACTIVATE:
		if (IsWindow(m->hwndMV))
			SetFocus(m->hwndMV);
		if	(LOWORD(wParam) == WA_INACTIVE)
			hgdlg=NULL;
		else
			hgdlg=hwnd;
		break;
    case WM_HELP:
		//WinHelp(hwnd, HelpFile, HELP_CONTEXT ,IDH_TASKMANAGER);
		break;
	case WM_CREATE:
		skmirror=(SkinWinNfo*)(((LPCREATESTRUCT) lParam)->lpCreateParams); 
		m=(mainftp *)skmirror->data;
		m->hmirror=hwnd;
		if (mainmirr==NULL)
			mainmirr=m;
		else
		{
			mainftp *tmp;
			tmp=mainmirr;
			while (tmp->mirnext!=NULL)
				tmp=tmp->mirnext;
			tmp->mirnext=m;
		}
		if (MirrorRect.top || MirrorRect.left || MirrorRect.right ||
												MirrorRect.bottom)
		MoveWindow(hwnd,MirrorRect.left,MirrorRect.top,
				MirrorRect.right-MirrorRect.left,
				MirrorRect.bottom-MirrorRect.top,true);
		sprintf(str,GetSTR2(242,"Mirrors for %s"),m->mdl->mirrorhead->nfo->rfn);
		SetWindowText(hwnd,str);
		strcpy(htxt[0],GetSTR2(227,"Host"));
		strcpy(htxt[1],GetSTR2(279,"Type"));
		strcpy(htxt[2],GetSTR2(103,"Size"));
		strcpy(htxt[3],GetSTR2(109,"Resume"));
		strcpy(htxt[4],GetSTR2(243,"Time until download"));
		strcpy(htxt[5],GetSTR2(215,"Ping"));
		strcpy(htxt[6],GetSTR2(244,"Lost"));
		strcpy(htxt[7],GetSTR2(245,"Used"));
		strcpy(htxt[8],GetSTR2(240,"One IP"));
		strcpy(htxt[9],GetSTR2(113,"Status"));
		dds2();
		m->mlv.pos.top=40;
		m->mlv.pos.bottom=-40;
		m->mlv.Init(hwnd,&htxt[0][0],&MirrorCol[0],10);
		m->hwndMV=m->mlv.hwndLV;
		ListView_SetImageList(m->hwndMV, hlvicons, LVSIL_SMALL);
		//m->hwndMV=DoCreateList(hwnd,&htxt[0][0],&MirrorCol[0],10,true,0);
		PostMessage(hwnd,_SKN_TXT,MAKELONG(0,0),(LPARAM)m->mdl->mirstatus);
		ShowWindow(hwnd,SW_SHOW);
		break;
	case WM_RBUTTONUP:
		if (HIWORD(lParam)<40)
				if (m->skmirror.bover!=-1)
					WinHelp(hwnd, HelpFile, 
							HELP_CONTEXTPOPUP,93+m->skmirror.bover);
		break;
	case WM_SIZE:
		if (wParam==SIZE_MINIMIZED) break;
		RECT rc;
        GetClientRect(hwnd, &rc);
/*        SetWindowPos(m->hwndMV, HWND_TOP, rc.left, rc.top+40, 
				rc.right , rc.bottom-40, SWP_SHOWWINDOW);  */
		GetWindowRect(hwnd,&MirrorRect);
		SendMessage(hwnd,_SKN_RESIZE,0,0);
		break;
	case WM_MOVE:
		RECT re;
		GetClientRect(hwnd,&re);
		if (!re.bottom && !re.right) break;
		GetWindowRect(hwnd,&MirrorRect);
		break;
	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case IDM_CONFIG:
			//if (ListView_GetSelectedCount(hwndMV))
			//	DialogBox(hlang,"SERVERCFG",hwnd,
			//				(DLGPROC)ServerCfgFunc);
			break;
		}
		break;
	case WM_CLOSE:
		DestroyWindow(hwnd);
		SaveGUIConfig();
		break;
	case WM_NOTIFY:
		if (((LPNMHDR) lParam)->code==-307)
		{
			for (j=0;j<10;j++)
				MirrorCol[j]=ListView_GetColumnWidth(m->hwndMV,j);
			break;
		}
		if (((LPNMHDR) lParam)->hwndFrom==m->hwndMV)
			switch (((LPNMHDR) lParam)->code)
			{
			case NM_DBLCLK:
				PostMessage(hwnd,WM_COMMAND,IDM_CONFIG,0);
				break;
/*			case LVN_GETDISPINFO:
				pnmv=(LV_DISPINFO *) lParam;
				if (pnmv->item.mask & LVIF_TEXT) 
				{
					MIRRORITEM *pitem = (MIRRORITEM *)(pnmv->item.lParam);
					lstrcpy(pnmv->item.pszText,pitem->c[pnmv->item.iSubItem]);
				}
				break;*/
			case LVN_DELETEALLITEMS:
				i=ListView_GetItemCount(m->hwndMV);
				for (j=i-1;j>=0;j--)
					ListView_DeleteItem(m->hwndMV,j);
				break;
			case LVN_DELETEITEM:
				NM_LISTVIEW *p;
		 		p = (NM_LISTVIEW FAR *) lParam;
				MIRRORITEM *pitem = (MIRRORITEM *) p->lParam;
				for (j=1;j<10;j++)
					free(pitem->c[j]);
				for (j=0;j<10;j++)
					free(pitem->cb[j]);
				j=pitem->pos;
				i=ListView_GetItemCount(m->hwndMV);
				free(pitem);
				for (j2=j+1;j2<i;j2++)
				{
					pitem=(MIRRORITEM *) GetLVlParam(m->hwndMV,j2);
					pitem->pos--;
				}
				break;
			}
		if (((LPNMHDR) lParam)->code==TTN_NEEDTEXT)
		{
			LPTOOLTIPTEXT lpttt;
			lpttt = (LPTOOLTIPTEXT) lParam;
			lpttt->hinst = hinst;
			int idButton = lpttt->hdr.idFrom;
			switch (idButton)
			{
				case 0:
					strcpy(str,GetSTR2(246,"Search for mirrors"));
					lpttt->lpszText = str;
					break;
				case 1:
					strcpy(str,GetSTR2(247,"Validate selected mirrors for use"));
					lpttt->lpszText = str;
					break;
				case 2:
					strcpy(str,GetSTR2(248,"Stop all mirrors checks"));
				    lpttt->lpszText = str;
					break;
				case 3:
					strcpy(str,GetSTR2(249,"Stop selected mirrors checks"));
				    lpttt->lpszText = str;
					break;
				case 4:
					strcpy(str,GetSTR2(250,"Remove selected mirrors"));
				    lpttt->lpszText = str;
					break;
				case 5:
					strcpy(str,GetSTR2(251,"Remove bad mirrors"));
				    lpttt->lpszText = str;
					break;
				case 6:
					strcpy(str,GetSTR2(252,"Increase the usage of the selected mirror"));
				    lpttt->lpszText = str;
					break;
				case 7:
					strcpy(str,GetSTR2(253,"Decrease the usage of the selected mirror"));
				    lpttt->lpszText = str;
					break;
				case 8:
					strcpy(str,GetSTR2(254,"Add a new mirror maually"));
				    lpttt->lpszText = str;
					break;
			}
			dds2();
		}
		break;

	case WM_USER+10:
		MIRRORITEM *pitem;
		//int dx;
		pitem= (MIRRORITEM *) ((DRAWITEMSTRUCT *)wParam)->itemData;
/*		if (lParam==0)
		{
			int ic;
			HICON hIcon3=NULL;
			GetMainLVIcon(hIcon3,pitem,ic);
			if (hIcon3)
			{
				DrawIconEx(lv.tmpdc,0,0,hIcon3,15,15,0,0,DI_NORMAL);
				DeleteObject(hIcon3);
			}
			else ImageList_Draw(lv.il,ic,lv.tmpdc,0,0,ILD_TRANSPARENT);
			dx=20;
		}
		else dx=2;*/
		m->mlv.PutTXT(2,pitem->c[m->mlv.colorder[lParam]]);
		break;

/*	case WM_USER+11:
		if (((signed)wParam)==lsortd)
		{
			if (sortd[wParam]) sortd[wParam]=0;
			else sortd[wParam]=1;
		}
		else lsortd=wParam;
		ListView_SortItems(hwndLV,StatusCmpFunc,
			(LPARAM) MAKELONG(wParam,sortd[wParam]));
		for (j=0;j<ListView_GetItemCount(hwndLV);j++)
		{
			STATUSITEM *pitem = (STATUSITEM *) GetLVlParam(hwndLV,j);
			pitem->pos=j;
		}
		break;*/

	case WM_DESTROY:
		if (mainmirr==m)
			mainmirr=m->mirnext;
		else
		{
			mainftp *tmp=mainmirr;
			while (tmp->mirnext!=m)
				tmp=tmp->mirnext;
			tmp->mirnext=m->mirnext;
		}
		m->mirnext=NULL;
		SaveGUIConfig();
		ListView_SetImageList(m->hwndMV, 0, LVSIL_SMALL);
		DestroyWindow(m->hwndMV);
		m->hmirror=NULL;
		m->mlv.kill();
		mir=m->mdl->mirrorhead;
		while (mir)
		{
			mir->guiparam=NULL;
			mir=mir->next;
		}
		//PostMessage(hwndgui,_SKN_BTSET,MAKELONG(6,0),0);
		break;
	case SKN_BTUP:
        switch (LOWORD(wParam))
		{
		case 0:
			TELLDAEMON(SEARCH_MIR,m->mdl,0);
			break;
		case 1:
			j=ListView_GetNextItem(m->hwndMV,-1,
									LVNI_ALL|LVNI_SELECTED);
			while (j!=-1)
			{
				MIRRORITEM *pitem=(MIRRORITEM*)GetLVlParam(m->hwndMV,
									j);
				mir=pitem->mir;
				TELLDAEMON(CHECK_MIR,mir,0);
				j=ListView_GetNextItem(m->hwndMV,j,
					LVNI_ALL|LVNI_SELECTED);
			}
			break;
		case 2:
			TELLDAEMON(STOPALL_MIR,m->mdl,0);
			break;
		case 3:
			j=ListView_GetNextItem(m->hwndMV,-1,LVNI_ALL|LVNI_SELECTED);
			while (j!=-1)
			{
				MIRRORITEM *pitem=(MIRRORITEM*)GetLVlParam(m->hwndMV,
								j);
				mir=pitem->mir;
				TELLDAEMON(STOP_MIR,mir,0);
				if (mir->rmdl)
					mir->rmdl->KillMain();
				if (mir->pmdl)
					mir->pmdl->KillMain();
				j=ListView_GetNextItem(m->hwndMV,j,
					LVNI_ALL|LVNI_SELECTED);
			}
			break;
		case 4:
			j=ListView_GetNextItem(m->hwndMV,-1,
				LVNI_ALL|LVNI_SELECTED);
			while (j!=-1)
			{
				MIRRORITEM *pitem = (MIRRORITEM *) GetLVlParam(m->hwndMV,j);
				mir=pitem->mir;
				TELLDAEMON(REMOVE_MIR,mir,0);
				j=ListView_GetNextItem(m->hwndMV,j,
					LVNI_ALL|LVNI_SELECTED);
			}
			break;
		case 5:
			TELLDAEMON(REMOVEBAD_MIR,m->mdl,0);
			break;
		case 6:
			j=ListView_GetNextItem(m->hwndMV,-1,
				LVNI_ALL|LVNI_SELECTED);
			while (j!=-1)
			{
				MIRRORITEM *pitem = (MIRRORITEM *) GetLVlParam(m->hwndMV,j);
				mir=pitem->mir;
				TELLDAEMON(INCREASE_MIR,mir,0);
				j=ListView_GetNextItem(m->hwndMV,j,
					LVNI_ALL|LVNI_SELECTED);
			}
			break;
		case 7:
			j=ListView_GetNextItem(m->hwndMV,-1,
				LVNI_ALL|LVNI_SELECTED);
			while (j!=-1)
			{
				MIRRORITEM *pitem = (MIRRORITEM *) GetLVlParam(m->hwndMV,j);
				mir=pitem->mir;
				TELLDAEMON(DECREASE_MIR,mir,0);
				j=ListView_GetNextItem(m->hwndMV,j,
					LVNI_ALL|LVNI_SELECTED);
			}
			break;
		case 8:
			if (DialogBoxParam(hlang,"INSSITE",hwnd,
					(DLGPROC)AddMirFunc,(LPARAM) str))
				STELLDAEMON(ADD_MIR,m->mdl,str);
		}
        break;
	case SKN_TRLV:
		//time(tracktime);
		//m->trackpos=lParam;
        break;
	case SKN_TRUP:
		//sprintf(sksplits,"%ld",lParam);
		//PostMessage(hwnd,_SKN_TXT,MAKELONG(2,0),(LPARAM)sksplits);
		break;
    default:
        if (ret==-1)
			return DefWindowProc(hwnd, message, wParam, lParam);
	}
	return 0;
}

VOID APIENTRY DisplayDropboxMenu(HWND hwnd,POINT pt)
{
	HMENU hmenu,hmenuTrackPopup;
	int r2l=0;
	if (cfg.r2l)
		r2l=MFT_RIGHTJUSTIFY|MFT_RIGHTORDER;

	hmenu=CreateMenu();
	hmenuTrackPopup=CreateMenu();

	MENUITEMINFO mi;
	memset(&mi,0,sizeof(MENUITEMINFO));
	mi.cbSize=sizeof(MENUITEMINFO);
	mi.fMask=MIIM_SUBMENU|MIIM_TYPE;
	mi.fType=r2l|MFT_STRING;
	mi.hSubMenu=hmenuTrackPopup;
	InsertMenuItem(hmenu,0,true,&mi);

	mi.fMask=MIIM_DATA|MIIM_ID|MIIM_TYPE|MIIM_STATE;
	mi.hSubMenu=NULL;
	mi.fState=MFS_CHECKED;
	mi.wID=IDM_NOTIPS;
	mi.dwTypeData=GetSTR(318,"Disable tool tips");
	InsertMenuItem(hmenuTrackPopup,0,true,&mi);

	mi.wID=IDM_SMALLDROP;
	mi.dwTypeData=GetSTR(319,"Keep \"thingy\" small");
	InsertMenuItem(hmenuTrackPopup,1,true,&mi);
	
	mi.fType=r2l|MFT_SEPARATOR;
	InsertMenuItem(hmenuTrackPopup,2,true,&mi);

	mi.fMask=MIIM_DATA|MIIM_ID|MIIM_TYPE;
	mi.fType=r2l|MFT_STRING;
	mi.wID=IDM_HIDE;
	mi.dwTypeData=GetSTR(320,"Hide Dropbox");
	InsertMenuItem(hmenuTrackPopup,3,true,&mi);

	mi.fType=r2l|MFT_SEPARATOR;
	InsertMenuItem(hmenuTrackPopup,4,true,&mi);

	mi.fType=r2l|MFT_STRING;
	mi.wID=IDM_SHOWLAST;
	mi.dwTypeData=GetSTR(321,"Show last tool tip");
	InsertMenuItem(hmenuTrackPopup,5,true,&mi);
	
	mi.wID=IDM_HELP;
	mi.dwTypeData=GetSTR(322,"Help - what is this?");
	InsertMenuItem(hmenuTrackPopup,6,true,&mi);
	
	mi.fType=r2l|MFT_SEPARATOR;
	InsertMenuItem(hmenuTrackPopup,7,true,&mi);

	mi.fType=r2l|MFT_STRING;
	mi.wID=ID_TOMAINGUIWIN;
	mi.dwTypeData=GetSTR(322,"to Main Gui-Win");
	InsertMenuItem(hmenuTrackPopup,8,true,&mi);

	mi.wID=ID_NEWDROPBOX;
	mi.dwTypeData=GetSTR(322,"new DropBox");
	InsertMenuItem(hmenuTrackPopup,9,true,&mi);
	
	if (gcfg.showtt)
		CheckMenuItem(hmenuTrackPopup,IDM_NOTIPS,MF_UNCHECKED);
	if (!gcfg.smalldrop)
		CheckMenuItem(hmenuTrackPopup,IDM_SMALLDROP,MF_UNCHECKED);
	TrackPopupMenuEx(hmenuTrackPopup,TPM_LEFTALIGN|TPM_LEFTBUTTON, 
		pt.x, pt.y,hwnd, NULL);
	DestroyMenu(hmenuTrackPopup);
	DestroyMenu(hmenu);
}

LRESULT CALLBACK DropboxFunc(HWND hwnd, UINT message,
                         WPARAM wParam, LPARAM lParam)
{
	static HBITMAP bm=NULL;
	HDC hdc,hdc1;
	static HDC hdc2;
	HBITMAP sbm;
	POINT pt;
	static unsigned short x,y;
//	unsigned short px,py;
	static LPDROPTARGET pDropTarget;
	static bool smallicon,showmenu=false;
	static HRGN hrgn=NULL;
	RECT re;
	PAINTSTRUCT ps;
	switch(message)
	{
	case WM_CREATE:
		pDropTarget = (LPDROPTARGET) new CDropTarget; 
		CoLockObjectExternal(pDropTarget, TRUE, TRUE);
		RegisterDragDrop(hwnd, pDropTarget);
		y=GetSystemMetrics(SM_CYSMICON);
		x=GetSystemMetrics(SM_CXSMICON);
		SetWindowPos(hwnd,HWND_TOPMOST,0, 0, x, y,
			SWP_NOMOVE | SWP_NOACTIVATE | SWP_SHOWWINDOW);
		hdc=GetDC(hwnd);
		hdc1=CreateCompatibleDC(hdc);
		hdc2=CreateCompatibleDC(hdc);
		hrgn=CreateEllipticRgn(0,0,x,y);
		sbm=LoadBitmap(hlang,"DROPBOX");
		bm=CreateCompatibleBitmap(hdc,x,y);
		sbm=SelectObject(hdc1,sbm);
		bm=SelectObject(hdc2,bm);
		StretchBlt(hdc2,0,0,x,y,hdc1,0,0,48,48,SRCCOPY);
		sbm=SelectObject(hdc1,sbm);
		DeleteObject(sbm);
		DeleteDC(hdc1);
		ReleaseDC(hwnd,hdc);
		int i;
		i=SetWindowRgn(hwnd,hrgn,true);
		//DeleteObject(hrgn);
//		ShowWindow(hwnd,SW_SHOW);
		smallicon=true;
		ttip=new PopUpTip("MS Sans Serif",13,0);
		ttip->bgcol=RGB(0,255,255);
		ttip->fgcol=RGB(0,0,255);
		GetWindowRect(hwnd,&re);
		ttip->x=(short)(re.right+re.left)/2;ttip->y=(short)re.top-1;
		//ttip->time_w=1500;ttip->time_xtra=6000;
		ttip->xhow=POPTIP_POINT_IS_CENTER;
		ttip->yhow=POPTIP_POINT_IS_END;
		ttip->time_w=30;ttip->time_xtra=60;
		ttip->xpad=3;ttip->ypad=3;
		ttip->timehow=POPTIP_TIMEVAL_IS_LETTER;
		ttip->init("Smart tips");
		SetTimer(hwnd,1,100,NULL);
		break;
	case WM_NCRBUTTONDOWN:
			showmenu=true;
			GetCursorPos(&pt);
			//ShowWindow(hwnd,SW_HIDE);
			//BringWindowToTop(hwndg);
			//SetForegroundWindow(hwndg);
			DisplayDropboxMenu(hwnd,pt);
			showmenu=false;
		break;

	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case IDM_HIDE:
			gcfg.showdropbox=false;
			Dropbox();
			MsgBox(GetSTR2(255,"If you change your mind later on, you can choose to\n get it back in the Configuration/Visual tab."),
					"Tip",MB_OK);
			dds2();
			break;
		case IDM_NOTIPS:
			gcfg.showtt=!gcfg.showtt;
			break;
		case IDM_SMALLDROP:
			gcfg.smalldrop=!gcfg.smalldrop;
			break;
		case IDM_SHOWLAST:
			PostMessage(ttip->hwnd,POPTIP_RESHOWLAST,0,0);
			break;
		case IDM_HELP:
			//SendMessage(ttip->hwnd,POPTIP_TXTUPDATE,(WPARAM)"test",0);
			SendMessage(ttip->hwnd,POPTIP_TONEXT,0,0);
			SendMessage(ttip->hwnd,POPTIP_TXTUPDATE,
				(WPARAM)GetSTR2(256,"To see this tip, you can always right click on the \"thingy\" and choose help\n\
This small icon will act as a drop box which you can drag links from your browser\n\
into it to start a download\n\
it will also show tips about some hidden stuff, so it's a good idea to keep it\n\
You can move it anywhere by clicking on your left mouse button and dragging it.\nThis message will automatically disappear in a moment."),0);
			dds2();
			break;
// oyd11, 14 nov, 1999:
		case ID_NEWDROPBOX:
			STELLGUI(MK_NEW_BOX,0,0);
			break;
		}
		break;

	case WM_TIMER:
		RECT r;
		unsigned short xx,yy;
		if (showmenu) break;
		GetCursorPos(&pt);
		GetWindowRect(hwnd,&r);
		if (smallicon)
		{
			if (gcfg.smalldrop) break;
			xx=r.left+x/2;
			yy=r.top+y/2;
			if ((pt.x>xx-24) && (pt.x<xx+24) &&
				(pt.y>yy-24) && (pt.y<yy+24))
			{
				HRGN tmp=hrgn;
				hrgn=CreateEllipticRgn(0,0,48,48);
				sbm=LoadBitmap(hlang,"DROPBOX");
				DeleteObject(SelectObject(hdc2,sbm));
				//StretchBlt(hdc2,0,0,x,y,hdc1,0,0,48,48,SRCCOPY);
				//DeleteDC(hdc1);
				//ReleaseDC(hwnd,hdc);
				//DeleteObject(sbm);
				SetWindowRgn(hwnd,hrgn,true);
				DeleteObject(tmp);
				//DeleteObject(hrgn);
				SetWindowPos(hwnd,HWND_TOPMOST,xx-24,yy-24,48,48,SWP_SHOWWINDOW|SWP_NOACTIVATE);
				smallicon=false;
				InvalidateRect(hwnd,NULL,false);
				if (!tipmsgs[1])
				{
					tipmsgs[1]=true;
					PostMessage(hwnd,WM_COMMAND,IDM_HELP,0);
					SaveGUIConfig();
				}
			}
		}
		else
		{
			xx=r.left+24;
			yy=r.top+24;
			if ((pt.x<xx-24) || (pt.x>xx+24) ||
				(pt.y<yy-24) || (pt.y>yy+24))
			{
				hdc=GetDC(hwnd);
				hdc1=CreateCompatibleDC(hdc);
				HRGN tmp=hrgn;
				hrgn=CreateEllipticRgn(0,0,x,y);
				sbm=LoadBitmap(hlang,"DROPBOX");
				HBITMAP bm2;
				bm2=CreateCompatibleBitmap(hdc,x,y);
				sbm=SelectObject(hdc1,sbm);
				DeleteObject(SelectObject(hdc2,bm2));
				StretchBlt(hdc2,0,0,x,y,hdc1,0,0,48,48,SRCCOPY);
				sbm=SelectObject(hdc1,sbm);
				DeleteObject(sbm);
				DeleteDC(hdc1);
				ReleaseDC(hwnd,hdc);
				SetWindowRgn(hwnd,hrgn,true);
				DeleteObject(tmp);
				SetWindowPos(hwnd,HWND_TOPMOST,xx-x/2,yy-y/2,x,y,SWP_SHOWWINDOW|SWP_NOACTIVATE);
				smallicon=true;
				InvalidateRect(hwnd,NULL,false);
				gcfg.dropposx=xx-x/2;
				gcfg.dropposy=yy-y/2;
				SaveGUIConfig();
			}
		}
		break;
	case WM_NCHITTEST:
		return (HTCAPTION);
	case WM_MOVE:
		GetWindowRect(hwnd,&re);
		ttip->x=(short)(re.right+re.left)/2;ttip->y=(short)re.top-1;
		SendMessage(ttip->hwnd,POPTIP_SHOWNOW,(WPARAM) 1,0);
		break;
	case WM_PAINT:
		hdc=BeginPaint(hwnd,&ps);
		if (smallicon)
			BitBlt(hdc,0,0,x,y,hdc2,0,0,SRCCOPY);
		else BitBlt(hdc,0,0,48,48,hdc2,0,0,SRCCOPY);
		ReleaseDC(hwnd,hdc);
		break;
	case WM_DESTROY:
		bm=SelectObject(hdc2,bm);
		DeleteObject(bm);
		DeleteDC(hdc2);
		RevokeDragDrop(hwnd);
		pDropTarget->Release();  
		CoLockObjectExternal(pDropTarget, FALSE, TRUE);
		delete ttip;
		ttip=NULL;
		KillTimer(hwnd,1);
		break;
	}
	return DefWindowProc(hwnd, message, wParam, lParam);
}

VOID CreateMainMenu()
{
	Hmenu=CreateMenu();

	int r2l=0;
	if (cfg.r2l)
		r2l=MFT_RIGHTJUSTIFY|MFT_RIGHTORDER;

	// creating bar
	hmmfile=CreateMenu();

	MENUITEMINFO mi;
	memset(&mi,0,sizeof(MENUITEMINFO));
	mi.cbSize=sizeof(MENUITEMINFO);
	mi.fMask=MIIM_DATA|MIIM_SUBMENU|MIIM_TYPE;
	mi.fType=r2l|MFT_STRING;
	mi.hSubMenu=hmmfile;
	mi.dwTypeData=GetSTR(280,"&File");
	InsertMenuItem(Hmenu,0,true,&mi);

	hmmedit=CreateMenu();
	mi.hSubMenu=hmmedit;
	mi.dwTypeData=GetSTR(281,"&Edit");
	InsertMenuItem(Hmenu,1,true,&mi);

	hmmaction=CreateMenu();
	mi.hSubMenu=hmmaction;
	mi.dwTypeData=GetSTR(282,"&Action");
	InsertMenuItem(Hmenu,2,true,&mi);

	hmmadvanced=CreateMenu();
	mi.hSubMenu=hmmadvanced;
	mi.dwTypeData=GetSTR(283,"A&dvanced");
	InsertMenuItem(Hmenu,3,true,&mi);

	hmmhelp=CreateMenu();
	mi.hSubMenu=hmmhelp;
	mi.dwTypeData=GetSTR(284,"&Help");
	InsertMenuItem(Hmenu,4,true,&mi);

	hmmrecent=CreateMenu();

	// creating recent
	memset(&mi,0,sizeof(MENUITEMINFO));
	mi.cbSize=sizeof(MENUITEMINFO);
	mi.fMask=MIIM_TYPE;
	mi.fType=r2l|MFT_SEPARATOR;
	InsertMenuItem(hmmrecent,0,true,&mi);

	// creating File menu
	memset(&mi,0,sizeof(MENUITEMINFO));
	mi.cbSize=sizeof(MENUITEMINFO);
	mi.fMask=MIIM_TYPE|MIIM_DATA|MIIM_ID;
	mi.fType=r2l|MFT_STRING;
	mi.wID=IDM_URL;
	mi.dwTypeData=GetSTR(285,"&Enter URL                       Ctrl+E");
	InsertMenuItem(hmmfile,0,true,&mi);

	mi.wID=IDM_GETURLCLIP;
	mi.dwTypeData=GetSTR(286,"&Get URL from Clipboard   Shift+INS");
	InsertMenuItem(hmmfile,1,true,&mi);

	memset(&mi,0,sizeof(MENUITEMINFO));
	mi.cbSize=sizeof(MENUITEMINFO);
	mi.fMask=MIIM_TYPE;
	mi.fType=r2l|MFT_SEPARATOR;
	InsertMenuItem(hmmfile,2,true,&mi);

	memset(&mi,0,sizeof(MENUITEMINFO));
	mi.cbSize=sizeof(MENUITEMINFO);
	mi.fMask=MIIM_TYPE|MIIM_DATA|MIIM_ID;
	mi.fType=r2l|MFT_STRING;
	mi.wID=IDM_EXPORT;
	mi.dwTypeData=GetSTR(287,"E&xport the download list");
	InsertMenuItem(hmmfile,3,true,&mi);

	mi.wID=IDM_IMPORT;
	mi.dwTypeData=GetSTR(288,"I&mport a download list");
	InsertMenuItem(hmmfile,4,true,&mi);
	
	memset(&mi,0,sizeof(MENUITEMINFO));
	mi.cbSize=sizeof(MENUITEMINFO);
	mi.fMask=MIIM_TYPE;
	mi.fType=r2l|MFT_SEPARATOR;
	InsertMenuItem(hmmfile,5,true,&mi);

	memset(&mi,0,sizeof(MENUITEMINFO));
	mi.cbSize=sizeof(MENUITEMINFO);
	mi.fMask=MIIM_DATA|MIIM_SUBMENU|MIIM_TYPE;
	mi.fType=r2l|MFT_STRING;
	mi.hSubMenu=hmmrecent;
	mi.dwTypeData=GetSTR(289,"Recent downloads");
	InsertMenuItem(hmmfile,6,true,&mi);

	memset(&mi,0,sizeof(MENUITEMINFO));
	mi.cbSize=sizeof(MENUITEMINFO);
	mi.fMask=MIIM_TYPE;
	mi.fType=r2l|MFT_SEPARATOR;
	InsertMenuItem(hmmfile,7,true,&mi);

	memset(&mi,0,sizeof(MENUITEMINFO));
	mi.cbSize=sizeof(MENUITEMINFO);
	mi.fMask=MIIM_TYPE|MIIM_DATA|MIIM_ID;
	mi.fType=r2l|MFT_STRING;
	mi.wID=IDM_EXIT;
	mi.dwTypeData=GetSTR(290,"&Shut down GetSmart        Ctrl+X");
	InsertMenuItem(hmmfile,8,true,&mi);

	mi.wID=IDM_SHUTGUI;
	mi.dwTypeData=GetSTR(291,"Shut down GUI only         Ctrl+G");
	InsertMenuItem(hmmfile,9,true,&mi);

	// creating Edit menu
	memset(&mi,0,sizeof(MENUITEMINFO));
	mi.cbSize=sizeof(MENUITEMINFO);
	mi.fMask=MIIM_TYPE|MIIM_DATA|MIIM_ID|MIIM_STATE;
	mi.fType=r2l|MFT_STRING;
	mi.fState=MFS_GRAYED;
	mi.wID=IDM_REMOVE;
	mi.dwTypeData=GetSTR(292,"&Remove entry                       DEL");
	InsertMenuItem(hmmedit,0,true,&mi);

	mi.wID=IDM_REMOVECLIP;
	mi.dwTypeData=GetSTR(293,"R&emove entry to clipboard    Shift+DEL");
	InsertMenuItem(hmmedit,1,true,&mi);

	mi.wID=IDM_COPYCLIP;
	mi.dwTypeData=GetSTR(294,"Copy URL to Clip&board         Ctrl+INS");
	InsertMenuItem(hmmedit,2,true,&mi);

	memset(&mi,0,sizeof(MENUITEMINFO));
	mi.cbSize=sizeof(MENUITEMINFO);
	mi.fMask=MIIM_TYPE;
	mi.fType=r2l|MFT_SEPARATOR;
	InsertMenuItem(hmmedit,3,true,&mi);

	memset(&mi,0,sizeof(MENUITEMINFO));
	mi.cbSize=sizeof(MENUITEMINFO);
	mi.fMask=MIIM_TYPE|MIIM_DATA|MIIM_ID;
	mi.fType=r2l|MFT_STRING;
	mi.wID=IDM_SELECTALL;
	mi.dwTypeData=GetSTR(295,"Select &All                             Ctrl+A");
	InsertMenuItem(hmmedit,4,true,&mi);

	mi.wID=IDM_SELECTACTIVE;
	mi.dwTypeData=GetSTR(296,"Select acti&ve                        Ctrl+V");
	InsertMenuItem(hmmedit,5,true,&mi);

	memset(&mi,0,sizeof(MENUITEMINFO));
	mi.cbSize=sizeof(MENUITEMINFO);
	mi.fMask=MIIM_TYPE;
	mi.fType=r2l|MFT_SEPARATOR;
	InsertMenuItem(hmmedit,6,true,&mi);

	memset(&mi,0,sizeof(MENUITEMINFO));
	mi.cbSize=sizeof(MENUITEMINFO);
	mi.fMask=MIIM_TYPE|MIIM_DATA|MIIM_ID;
	mi.fType=r2l|MFT_STRING;
	mi.wID=IDM_CONFIG;
	mi.dwTypeData=GetSTR(297,"&Configuration                        Ctrl+C");
	InsertMenuItem(hmmedit,7,true,&mi);

	// creating Action menu
	memset(&mi,0,sizeof(MENUITEMINFO));
	mi.cbSize=sizeof(MENUITEMINFO);
	mi.fMask=MIIM_TYPE|MIIM_DATA|MIIM_ID|MIIM_STATE;
	mi.fType=r2l|MFT_STRING;
	mi.fState=MFS_GRAYED;
	mi.wID=IDM_DOWNLOAD;
	mi.dwTypeData=GetSTR(298,"&Download");
	InsertMenuItem(hmmaction,0,true,&mi);

	mi.wID=IDM_PAUSE;
	mi.dwTypeData=GetSTR(299,"&Pause             Ctrl+P");
	InsertMenuItem(hmmaction,1,true,&mi);

	mi.wID=IDM_HIDE;
	mi.dwTypeData=GetSTR(300,"&Hide               Ctrl+H");
	InsertMenuItem(hmmaction,2,true,&mi);

	memset(&mi,0,sizeof(MENUITEMINFO));
	mi.cbSize=sizeof(MENUITEMINFO);
	mi.fMask=MIIM_TYPE;
	mi.fType=r2l|MFT_SEPARATOR;
	InsertMenuItem(hmmaction,3,true,&mi);

	memset(&mi,0,sizeof(MENUITEMINFO));
	mi.cbSize=sizeof(MENUITEMINFO);
	mi.fMask=MIIM_TYPE|MIIM_DATA|MIIM_ID|MIIM_STATE;
	mi.fType=r2l|MFT_STRING;
	mi.fState=MFS_GRAYED;
	mi.wID=IDM_MIRRORS;
	mi.dwTypeData=GetSTR(301,"&Mirrors           Ctrl+M");
	InsertMenuItem(hmmaction,4,true,&mi);

	memset(&mi,0,sizeof(MENUITEMINFO));
	mi.cbSize=sizeof(MENUITEMINFO);
	mi.fMask=MIIM_TYPE;
	mi.fType=r2l|MFT_SEPARATOR;
	InsertMenuItem(hmmaction,5,true,&mi);

	memset(&mi,0,sizeof(MENUITEMINFO));
	mi.cbSize=sizeof(MENUITEMINFO);
	mi.fMask=MIIM_TYPE|MIIM_DATA|MIIM_ID|MIIM_STATE;
	mi.fType=r2l|MFT_STRING;
	mi.fState=MFS_GRAYED;
	mi.wID=IDM_PROPERTIES;
	mi.dwTypeData=GetSTR(302,"P&roperties      Alt+ENTER");
	InsertMenuItem(hmmaction,6,true,&mi);

	// creating Advanced menu
	memset(&mi,0,sizeof(MENUITEMINFO));
	mi.cbSize=sizeof(MENUITEMINFO);
	mi.fMask=MIIM_TYPE|MIIM_DATA|MIIM_ID|MIIM_STATE;
	mi.fType=r2l|MFT_STRING;
	mi.fState=MFS_CHECKED;
	mi.wID=IDM_AUTODL;
	mi.dwTypeData=GetSTR(303,"Smart Pilot                           Ctrl+D");
	InsertMenuItem(hmmadvanced,0,true,&mi);

	memset(&mi,0,sizeof(MENUITEMINFO));
	mi.cbSize=sizeof(MENUITEMINFO);
	mi.fMask=MIIM_TYPE|MIIM_DATA|MIIM_ID;
	mi.fType=r2l|MFT_STRING;
	mi.wID=IDM_PAUSEALL;
	mi.dwTypeData=GetSTR(304,"Pa&use all                              Ctrl+U");
	InsertMenuItem(hmmadvanced,1,true,&mi);

	mi.wID=IDM_HIDEALL;
	mi.dwTypeData=GetSTR(305,"Hide all");
	InsertMenuItem(hmmadvanced,2,true,&mi);

	mi.wID=IDM_DIAL;
	mi.dwTypeData=GetSTR(306,"Dia&l to the InterNet              Ctrl+L");
	InsertMenuItem(hmmadvanced,3,true,&mi);

	mi.wID=IDM_SCHEDULE;
	mi.dwTypeData=GetSTR(307,"&Schedule                             Ctrl+S");
	InsertMenuItem(hmmadvanced,4,true,&mi);

	memset(&mi,0,sizeof(MENUITEMINFO));
	mi.cbSize=sizeof(MENUITEMINFO);
	mi.fMask=MIIM_TYPE|MIIM_DATA|MIIM_ID|MIIM_STATE;
	mi.fType=r2l|MFT_STRING;
	mi.fState=MFS_CHECKED;
	mi.wID=IDM_DISCONNECT;
	mi.dwTypeData=GetSTR(308,"Disconnect when do&ne       Ctrl+N");
	InsertMenuItem(hmmadvanced,5,true,&mi);

	memset(&mi,0,sizeof(MENUITEMINFO));
	mi.cbSize=sizeof(MENUITEMINFO);
	mi.fMask=MIIM_TYPE;
	mi.fType=r2l|MFT_SEPARATOR;
	InsertMenuItem(hmmadvanced,6,true,&mi);

	memset(&mi,0,sizeof(MENUITEMINFO));
	mi.cbSize=sizeof(MENUITEMINFO);
	mi.fMask=MIIM_TYPE|MIIM_DATA|MIIM_ID|MIIM_STATE;
	mi.fType=r2l|MFT_STRING;
	mi.fState=MFS_CHECKED;
	mi.wID=IDM_CATCHCLIPBOARD;
	mi.dwTypeData=GetSTR(309,"Catch URL from Clip&board   Ctrl+B");
	InsertMenuItem(hmmadvanced,7,true,&mi);

	memset(&mi,0,sizeof(MENUITEMINFO));
	mi.cbSize=sizeof(MENUITEMINFO);
	mi.fMask=MIIM_TYPE;
	mi.fType=r2l|MFT_SEPARATOR;
	InsertMenuItem(hmmadvanced,8,true,&mi);

	memset(&mi,0,sizeof(MENUITEMINFO));
	mi.cbSize=sizeof(MENUITEMINFO);
	mi.fMask=MIIM_TYPE|MIIM_DATA|MIIM_ID;
	mi.fType=r2l|MFT_STRING;
	mi.wID=IDM_FTPCLIENT;
	mi.dwTypeData=GetSTR(310,"Open the FTP client            Ctrl+F");
	InsertMenuItem(hmmadvanced,9,true,&mi);

	mi.wID=IDM_SHOWSER;
	mi.dwTypeData=GetSTR(311,"Show/Hide Server manager");
	InsertMenuItem(hmmadvanced,10,true,&mi);

	mi.wID=IDM_SPEEDLIMIT;
	mi.dwTypeData=GetSTR(312,"Change speed limit");
	InsertMenuItem(hmmadvanced,11,true,&mi);

	mi.wID=IDM_OFFERFILE;
	mi.dwTypeData=GetSTR(347,"Offer a file to a user");
	InsertMenuItem(hmmadvanced,12,true,&mi);

	// create Help menu
	memset(&mi,0,sizeof(MENUITEMINFO));
	mi.cbSize=sizeof(MENUITEMINFO);
	mi.fMask=MIIM_TYPE|MIIM_DATA|MIIM_ID;
	mi.fType=r2l|MFT_STRING;
	mi.wID=IDM_HELP;
	mi.dwTypeData=GetSTR(313,"&Help Contents");
	InsertMenuItem(hmmhelp,0,true,&mi);

	memset(&mi,0,sizeof(MENUITEMINFO));
	mi.cbSize=sizeof(MENUITEMINFO);
	mi.fMask=MIIM_TYPE;
	mi.fType=r2l|MFT_SEPARATOR;
	InsertMenuItem(hmmhelp,1,true,&mi);

	memset(&mi,0,sizeof(MENUITEMINFO));
	mi.cbSize=sizeof(MENUITEMINFO);
	mi.fMask=MIIM_TYPE|MIIM_DATA|MIIM_ID;
	mi.fType=r2l|MFT_STRING;
	mi.wID=IDM_ABOUT;
	mi.dwTypeData=GetSTR(314,"&About");
	InsertMenuItem(hmmhelp,2,true,&mi);

	mi.fMask=MIIM_TYPE;
	mi.fType=r2l|MFT_SEPARATOR;
	InsertMenuItem(hmmhelp,4,true,&mi);

	mi.fMask=MIIM_TYPE|MIIM_DATA|MIIM_ID;
	mi.fType=r2l|MFT_STRING;
	mi.wID=IDM_CHECK4UPDATE;
	mi.dwTypeData=GetSTR(349,"&Check for newer versions");
	InsertMenuItem(hmmhelp,5,true,&mi);

	mi.wID=IDM_UNINSTALL;
	mi.dwTypeData=GetSTR(348,"&Uninstall GetSmart");
	InsertMenuItem(hmmhelp,6,true,&mi);	
}

VOID CreateBrowseMenu()
{
	Hmenu2=CreateMenu();

	int r2l=0;
	if (cfg.r2l)
		r2l=MFT_RIGHTJUSTIFY|MFT_RIGHTORDER;

	// creating bar
	hbmconnection=CreateMenu();

	MENUITEMINFO mi;
	memset(&mi,0,sizeof(MENUITEMINFO));
	mi.cbSize=sizeof(MENUITEMINFO);
	mi.fMask=MIIM_DATA|MIIM_SUBMENU|MIIM_TYPE;
	mi.fType=r2l|MFT_STRING;
	mi.hSubMenu=hbmconnection;
	mi.dwTypeData=GetSTR(330,"&Connection");
	InsertMenuItem(Hmenu2,0,true,&mi);

	hbmdownloads=CreateMenu();
	mi.hSubMenu=hbmdownloads;
	mi.dwTypeData=GetSTR(331,"&Downloads");
	InsertMenuItem(Hmenu2,1,true,&mi);

	hbmsession=CreateMenu();
	mi.hSubMenu=hbmsession;
	mi.dwTypeData=GetSTR(332,"&Session");
	InsertMenuItem(Hmenu2,2,true,&mi);

	// creating Connection menu
	memset(&mi,0,sizeof(MENUITEMINFO));
	mi.cbSize=sizeof(MENUITEMINFO);
	mi.fMask=MIIM_TYPE|MIIM_DATA|MIIM_ID;
	mi.fType=r2l|MFT_STRING;
	mi.wID=IDM_CONNECT;
	mi.dwTypeData=GetSTR(115,"Connect");
	InsertMenuItem(hbmconnection,0,true,&mi);

	mi.wID=IDM_DISCONNECT;
	mi.dwTypeData=GetSTR(116,"Disconnect");
	InsertMenuItem(hbmconnection,1,true,&mi);

	mi.fType=r2l|MFT_SEPARATOR;
	InsertMenuItem(hbmconnection,2,true,&mi);

	mi.fType=r2l|MFT_STRING;
	mi.wID=IDM_ENTERURL;
	mi.dwTypeData=GetSTR(117,"Enter a URL manually");
	InsertMenuItem(hbmconnection,3,true,&mi);

	mi.fType=r2l|MFT_SEPARATOR;
	InsertMenuItem(hbmconnection,4,true,&mi);

	mi.fType=r2l|MFT_STRING;
	mi.wID=IDM_QUIT;
	mi.dwTypeData=GetSTR(317,"Quit");
	InsertMenuItem(hbmconnection,5,true,&mi);

	// creating Downloads menu
	memset(&mi,0,sizeof(MENUITEMINFO));
	mi.cbSize=sizeof(MENUITEMINFO);
	mi.fMask=MIIM_TYPE|MIIM_DATA|MIIM_ID;
	mi.fType=r2l|MFT_STRING;
	mi.wID=IDM_SELECTALL;
	mi.dwTypeData=GetSTR(333,"&Mark all");
	InsertMenuItem(hbmdownloads,0,true,&mi);

	mi.wID=IDM_UNMARKALL;
	mi.dwTypeData=GetSTR(334,"&Unmark all");
	InsertMenuItem(hbmdownloads,1,true,&mi);

	mi.wID=IDM_DOWNLOAD;
	mi.dwTypeData=GetSTR(335,"&Add selected files to GetSmart queue");
	InsertMenuItem(hbmdownloads,2,true,&mi);

	mi.wID=IDM_CUSTOMDL;
	mi.dwTypeData=GetSTR(336,"&Enter a filename to download");
	InsertMenuItem(hbmdownloads,3,true,&mi);

	// creating Session menu
	memset(&mi,0,sizeof(MENUITEMINFO));
	mi.cbSize=sizeof(MENUITEMINFO);
	mi.fMask=MIIM_TYPE|MIIM_DATA|MIIM_ID;
	mi.fType=r2l|MFT_STRING;
	mi.wID=IDM_ABORT;
	mi.dwTypeData=GetSTR(337,"&Abort current action");
	InsertMenuItem(hbmsession,0,true,&mi);

	mi.wID=IDM_REFRESH;
	mi.dwTypeData=GetSTR(338,"&Refresh listing");
	InsertMenuItem(hbmsession,1,true,&mi);

	mi.wID=IDM_CUSTOM;
	mi.dwTypeData=GetSTR(339,"&Enter custom command");
	InsertMenuItem(hbmsession,2,true,&mi);

	mi.fMask=MIIM_TYPE;
	mi.fType=r2l|MFT_SEPARATOR;
	InsertMenuItem(hbmsession,3,true,&mi);

	mi.fType=r2l|MFT_STRING;
	mi.wID=IDD_TASKSI;
	mi.dwTypeData=GetSTR(220,"Show/Hide Task manager");
	InsertMenuItem(hbmsession,4,true,&mi);
}

void GetMainLVIcon(HICON &hIcon3,STATUSITEM *pitem,int&ic)
{
	mainftp *m=(mainftp*)pitem->mdl->guiparam;
	if (pitem->mdl->spliton)
	{
		switch (pitem->mdl->type)
		{
		case 1:
			hIcon3=CreateIconIndirect(&m->IconInfo);
			break;
		case 2:
			ic=2;
			break;
		case 5:
			ic=3;
			break;
		default:
			ic=1;
			//if (pm->mftp->hwnd!=NULL)
			//	PostMessage(pm->mftp->hwnd,_SKN_BTSET,MAKELONG(7,0),0);
		}
	}
	else
		if (m->blink)
		{
			if (!m->bshow)
			{
				byte bx[16*16],bm[16][16];
				memset(bx,255,sizeof(bx));
				memset(bm,0,sizeof(bm));
				hIcon3 = CreateIcon(hinst,16,16,1,8,bx,&bm[0][0]);		
			}
			else
				hIcon3=CreateIconIndirect(&m->IconInfo);
		}
		else
			if (pitem->mdl->done)
			{
				ic=5;
				//if (pm->mftp->hwnd!=NULL)
				//PostMessage(pm->mftp->hwnd,_SKN_BTSET,MAKELONG(7,0),2);
			}
			else
				if (pitem->mdl->error.en && pitem->mdl->wait)
				{
					ic=6;
					//if (pm->mftp->hwnd!=NULL)
					//PostMessage(pm->mftp->hwnd,_SKN_BTSET,MAKELONG(7,0),3);
				}
				else
					if (pitem->mdl->wait)
						ic=4;
					else
					{
						ic=0;
						//if (pm->mftp->hwnd!=NULL)
						//PostMessage(pm->mftp->hwnd,_SKN_BTSET,MAKELONG(7,0),1);
					}
}

BOOL CALLBACK AddGSTable(HWND hdwnd, UINT message,
                         WPARAM wParam, LPARAM lParam)
{
	switch(message)
	{
	case WM_ACTIVATE:
		if	(LOWORD(wParam) == WA_INACTIVE)
			hgdlg=NULL;
		else
			hgdlg=hdwnd;
		return 1;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDCANCEL:
			EndDialog(hdwnd, 0);
			return 1;
		case IDOK:
			DWORD *ip;
			BYTE d[4];
			bool use=false;
			d[0]=(BYTE)GetDlgItemInt(hdwnd,IDD_IP1,0,0);
			d[1]=(BYTE)GetDlgItemInt(hdwnd,IDD_IP2,0,0);
			d[2]=(BYTE)GetDlgItemInt(hdwnd,IDD_IP3,0,0);
			d[3]=(BYTE)GetDlgItemInt(hdwnd,IDD_IP4,0,0);
			ip=(DWORD *)d;
			char reqname[1024],dir[1024],fn[1024];
			GetDlgItemText(hdwnd,IDD_REQ,reqname,1024);
			GetDlgItemText(hdwnd,IDD_DIR,dir,1024);
			GetDlgItemText(hdwnd,IDD_FN,fn,1024);
			new gsdltable(*ip,0,reqname,dir,fn,"",false);
			EndDialog(hdwnd, 1);
			return 1;
		}
		return 0;
	}
	return 0;
}

BOOL CALLBACK DLGS(HWND hdwnd, UINT message,
                         WPARAM wParam, LPARAM lParam)
{
	switch(message)
	{
	case WM_ACTIVATE:
		if	(LOWORD(wParam) == WA_INACTIVE)
			hgdlg=NULL;
		else
			hgdlg=hdwnd;
		return 1;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDCANCEL:
			EndDialog(hdwnd, 0);
			return 1;
		case IDOK:
			char ip[1024];
			BYTE d[4];
			bool use=false;
			d[0]=(BYTE)GetDlgItemInt(hdwnd,IDD_IP1,0,0);
			d[1]=(BYTE)GetDlgItemInt(hdwnd,IDD_IP2,0,0);
			d[2]=(BYTE)GetDlgItemInt(hdwnd,IDD_IP3,0,0);
			d[3]=(BYTE)GetDlgItemInt(hdwnd,IDD_IP4,0,0);
			sprintf(ip,"%d.%d.%d.%d",d[0],d[1],d[2],d[3]);
			char reqname[1024],dir[1024],fn[1024];
			GetDlgItemText(hdwnd,IDD_REQ,reqname,1024);
			GetDlgItemText(hdwnd,IDD_DIR,dir,1024);
			GetDlgItemText(hdwnd,IDD_FN,fn,1024);
			AddURL(new dlnfo(2,ip,GSULPORT,"anonymous",
				cfg.Email,"",reqname),dir,
				fn,7,9,0,cfg.resumeto,DEFPR,0,false,false,0,0);
			EndDialog(hdwnd, 1);
			return 1;
		}
		return 0;
	}
	return 0;
}
