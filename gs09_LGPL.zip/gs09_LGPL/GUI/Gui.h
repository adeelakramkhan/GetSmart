
#ifndef _WINSOCKAPI_
#define _WINSOCKAPI_   /* Prevent inclusion of winsock.h in windows.h */ 
#endif 
#include "../Daemon/Daemon.h"
#include <commctrl.h>
#include "../resrc1.h"
#include "../skin/SkinDefs.h"
#include "../skin/popupwin.h"
#include "LV.h"
#include <shlobj.h>

#include "mosheBox.h"

struct STATUSITEM
{     
	char* c[10];
	char* cb[10];
	maindl *mdl;
	int pos;
};

struct SERVERITEM
{     
	LPSTR c[10];
	LPSTR cb[10];
	server *ser;
	int pos;
};

struct MIRRORITEM
{     
	LPSTR c[10];
	LPSTR cb[10];
	mirrors *mir;
	int pos;
};

struct WILDITEM
{     
	LPSTR c[4];
};

struct lcl
{
	char ldir[_MAX_PATH],lfn[_MAX_PATH];
	lcl(char *ldir0,char *lfn0)
	{
		strcpy(ldir,ldir0);
		strcpy(lfn,lfn0);
	}
};

#ifdef _this_is_gui_
#define EXTERN2
#else
#define EXTERN2 extern
#endif

#define TRAY_MSG WM_USER+2

class mainftp;

/*struct smalltxt
{
	char title[80],url[80],got[30],ela[40],avg[30],est[40],cur[30],
			tasks[10],pause[20],to[10],track[10];
};*/

class smallftp
{
	public:	
	HWND hwnd,hbuffer,hwndBB;
	mainftp *m;
	smallftp *mftp;
	maindl *mdl;
	basicdl *bdl;
	SkinWinNfo sksmall,skbuffer;
	bool kill,killbuffer,opentrack,autoscroll;
	char txt[12][80];
	short trtxti;
	smallftp()
	{
		memset(txt,0,sizeof(txt));
		hbuffer=NULL;
		hwndBB=NULL;
		hwnd=NULL;
		kill=false;
		killbuffer=true;
		opentrack=false;
		autoscroll=true;
		m=NULL;
		mftp=NULL;
		mdl=NULL;
		bdl=NULL;
		trtxti=-1;
	}
	~smallftp()
	{
		if (hbuffer!=NULL)
		{
			if (mftp->hbuffer==hbuffer)
				mftp->killbuffer=false;
			DestroyWindow(hbuffer);
		}
		if (hwnd!=NULL)
			DestroyWindow(hwnd);
		if (bdl!=NULL) bdl->guiparam=NULL;
	}
	void BufferWin();
	void SmallWin();
};

EXTERN2 mainftp *donehead,*donelast,*mainmirr;

struct ITEMPOS
{     
	HWND hwndU;
	int pos;
};

class mainftp
{
public:
	void AddItem();
	void RMItem();
	maindl *mdl;
	mainftp *next,*prev,*mirnext;
	smallftp *mftp;
	HWND htask,hwndTV,hwndMV,hmirror,hwndLV2,hwndWV,hwild;
	mylv tlv,mlv,lv2,wlv;
	unsigned char ticon;
	bool showtasks,blink,bshow,skipmsg;
	STATUSITEM *item;
	STATUSITEM *titem[TOPMAXSPLIT+MAXHAMMER];
	time_t tracktime;
	int tlastsp,tlasthm,trackpos;
	unsigned long iconfill;
	SkinWinNfo sktask,skmirror;
	ICONINFO IconInfo;
	HDC hmem;
	HBITMAP prevbm;
	ITEMPOS itempos[50];
	mainftp()
	{
		memset(itempos,0,sizeof(itempos));
		ticon=0;
		showtasks=false;
		blink=false;
		bshow=false;
		memset(&IconInfo,0,sizeof(ICONINFO));
		hmem=NULL;
		tlastsp=0;
		tlasthm=0;
		memset(titem,0,sizeof(titem));
		htask=NULL;
		hwndTV=NULL;
		hwndMV=NULL;
		hmirror=NULL;
		hwndLV2=NULL;
		hwild=NULL;
		hwndWV=NULL;

		mdl=NULL;
		htask=NULL;
		hwndTV=NULL;
		item=NULL;
		tracktime=0;
		trackpos=0;
		next=NULL;
		prev=NULL;
		prevbm=NULL;
		mftp=NULL;
		mirnext=NULL;
		skipmsg=false;
		iconfill=0;
	}
	~mainftp()
	{
		if (ticon)
			RemoveTray();
		if (htask!=NULL) DestroyWindow(htask);
		if (hmirror!=NULL) DestroyWindow(hmirror);
		if (hwild!=NULL) DestroyWindow(hwild);
		if ((prev!=NULL) || (donehead==this))
			RMItem();
//		if (mftp->hbuffer!=NULL) DestroyWindow(hbuffer);
		delete mftp;
		mftp=NULL;
		for (int i=0;i<=mdl->splitdex;i++)
			if (mdl->splitdl[i] && mdl->splitdl[i]->guiparam)
			{
				delete (smallftp*)mdl->splitdl[i]->guiparam;
				mdl->splitdl[i]->guiparam=NULL;
			}
		mdl->guiparam=NULL;
	}
	void TaskWin();
	void BrowseWin();
	void MirrorWin();
	void UpdateTrack();
	int UpdateTray(unsigned long r,time_t tp);
	int RemoveTray();
	void ShowMSG();
	void ShowTTMSG();
	void RMLV();
};

class lastdl
{
private:
	void AddItem();
	void RMItem();
public:
	lastdl *next,*prev;
	dlnfo *nfo;
	char *ldir,*lfn;
	bool uh,ur;
	time_t to;
	unsigned short type,useproxy,prior,mode;
	lastdl(dlnfo *nfo0,char *ldir0,char *lfn0,unsigned short type0,
			unsigned short useproxy0,time_t to0,unsigned short prior0,
			unsigned short mode0,bool uh0,bool ur0)
	{
		nfo=nfo0;
		ldir=DupString(ldir0);
		lfn=DupString(lfn0);
		type=type0;
		useproxy=useproxy0;
		to=to0;
		prior=prior0;
		mode=mode0;
		uh=uh0;
		ur=ur0;
		next=NULL;
		prev=NULL;
		AddItem();
	}
	~lastdl()
	{
		delete nfo;
		free(ldir);
		free(lfn);
		RMItem();
	}
};

struct gcfg_lv
{
	bool bkcustom,bkwallpaper,bkload,dynbk;
	COLORREF bkclr,txtclr,txtclr2,hdclr,hdclr2,glassclr;
	char bkfn[1024];
};

struct gcfg_tag
{
	bool showdltray,showdlwin,finishmsgs,proxy_showtray,catchcb,
			catchns,showdropbox,useexskin,showtt,smalldrop,smalltrans;
	unsigned short maxlastdl;
	short dropposx,dropposy;
	unsigned long maxbuffer;
	char *skindir,*exskinfn;
	int smallalpha;
	gcfg_lv lv;
};

EXTERN2 char *HelpFile;
EXTERN2 lastdl *lastdlhead,*lastdllast;
EXTERN2 HWND hwndgui,hwndTB,hwndLV,hwndCV,hwndNextViewer,hwndprev,hserver,
				hwndSV,hwnddropbox,hgdlg;
EXTERN2 RECT StatusRect,TaskRect,BufferRect,ServerRect,MirrorRect,
				BrowseRect;
EXTERN2 HIMAGELIST hlvicons;
EXTERN2 HMENU Hmenu,Hmenu2;
EXTERN2 Skin mainskin,taskskin,smallskin,bufferskin,prevskin,
		serverskin,mirrorskin,browseskin;
EXTERN2 SkinWinNfo mainskinnfo,prevskinnfo,serverskinnfo;
EXTERN2 gcfg_tag gcfg;
EXTERN2 bool LoadLDL,prop[10],ignoreclipboard,inclipchain,killgui,
			 tipmsgs[20],StatusExc[10],datepick;
EXTERN2 PopUpTip *ttip;
EXTERN2 HFONT gfont;
EXTERN2 unsigned long ctlminor,ctlmajor;
EXTERN2 HINSTANCE hctl;
extern int StatusCol[10],TaskCol[9],ServerCol[9],MirrorCol[10],WildCol[4];
extern bool enablemenu;
extern long enableitem[8],enablecount;
extern short StatusOrder[10];

#define SendDefURL(nfo,t) \
 AddURL(nfo,NULL,NULL,t,9,cfg.defsplit,cfg.resumeto,DEFPR,0,cfg.usehammer,cfg.useretry,\
 cfg.checkint,cfg.checksmallint)

bool SendURL(dlnfo *dln,char *ldir,char *lfn,int dosplit,bool wc,
			 int proxy,int mode,time_t to,unsigned char prior,
			 bool uh,bool ur,bool checkint,bool smallint);

HWND DoCreateList(HWND hwndParent, char *h1,int *h2,int c,bool show,int who);
HWND InitColumns2(HWND hwndParent,char *h1,int *h2,int c,int who);
void AddItem(HWND hwndLV2, maindl *mdl);
void UpdateList(maindl *mdl);
void UpdateMDL(maindl *mdl);
void UpdateSerList(server *ser);
void AddSerItem(server *ser);
void AddMirrorItem(mirrors *mir);
void UpdateMirrorList(mirrors *mir);
int InitSkins();
int LoadLastDLs();
int SaveLastDLs();
int LoadGUIConfig();
int SaveGUIConfig();
bool Config();
void CatchCB();
void Dropbox();
void GotURL(char *url);
bool MakeTransparent(HWND hwnd,bool wstrans,int alpha);
bool MakeNotTransparent(HWND hwnd);

BOOL CALLBACK URLFunc(HWND hdwnd, UINT message,
                         WPARAM wParam, LPARAM lParam);
void RemoveTask(maindl* mdl,int sp,int hm);
LPARAM GetLVlParam(HWND hwnd,int j);
void UpdateTask(maindl *mdl, int sp, int hm);
