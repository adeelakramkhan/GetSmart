
#ifndef _WINSOCKAPI_
#define _WINSOCKAPI_   /* Prevent inclusion of winsock.h in windows.h */ 
#endif 
#include "../skin/SkinDefs.h"
#include "../Daemon/Daemon.h"
#include "../GUI/GUI.h"

Skinload *n;

int InitMainSkin(Skinload &nfo)
{
    // will return true if skin compiled correct, for now, just return true.
    //strcpy(nfo.bgfn,"bk1.bmp");
    nfo.name=_strdup("MainGSSkin");
	nfo.basedir=_strdup(gcfg.skindir);
	nfo.type=1;

    nfo.numrg=1;
    nfo.rg=new RGloadSt[nfo.numrg];
// rg <n> <bm filen> <xoff> <yoff> <init state: by _S_RG* macros>
	rgSet(nfo.rg[0],"TBBG",0,0,_S_RGSHOW|_S_RGIN|_S_RGOUT,1,1);

    nfo.numstbt=14;
	nfo.stbt=new STBTloadSt[nfo.numstbt];
// bt <n> <bm filename> <x> <y> <xoff> <yoff> <over policy> <pushed policy> <over bm> <pushed bm>

	STButtSet(nfo.stbt[0],1,2,4,0,1,0);
	SubST_st(nfo.stbt[0],0,"TMP",1,1,"","",-1,0,0);
	STButtSet(nfo.stbt[1],1,40,4,0,1,0);
	SubST_st(nfo.stbt[1],0,"TBSTOP",1,1,"","",-1,0,0);
	STButtSet(nfo.stbt[2],1,78,4,0,1,0);
	SubST_st(nfo.stbt[2],0,"TBSTOPALL",1,1,"","",-1,0,0);
	STButtSet(nfo.stbt[3],2,136,4,0,1,0);
	SubST_st(nfo.stbt[3],0,"ROBOTBM",1,1,"","",-1,0,0);
	SubST_st(nfo.stbt[3],1,"",0,0,"","",0,0,0);
	STButtSet(nfo.stbt[4],1,188,4,0,1,0);
	SubST_st(nfo.stbt[4],0,"TBDLTRAY",1,1,"","",-1,0,0);
	STButtSet(nfo.stbt[5],2,226,4,0,1,0);
	SubST_st(nfo.stbt[5],0,"TBMSG",1,1,"","",-1,0,0);
	SubST_st(nfo.stbt[5],1,"",0,0,"","",0,0,0);
	STButtSet(nfo.stbt[6],2,495,4,0,1,0);
	SubST_st(nfo.stbt[6],0,"TBSERVER",1,1,"","",-1,0,0);
	SubST_st(nfo.stbt[6],1,"",0,0,"","",0,0,0);
	STButtSet(nfo.stbt[7],1,545,11,0,1,0);
	SubST_st(nfo.stbt[7],0,"TBSPEEDLIM",1,1,"","",-1,0,0);
	STButtSet(nfo.stbt[8],1,590,9,0,1,0);
	SubST_st(nfo.stbt[8],0,"TBBROWSE",1,1,"","",-1,0,0);
	STButtSet(nfo.stbt[9],2,635,6,0,1,0);
	SubST_st(nfo.stbt[9],0,"TBDIS1",1,1,"","",-1,0,0);
	SubST_st(nfo.stbt[9],1,"TBDIS1",0,0,"","",0,0,0);
	STButtSet(nfo.stbt[10],2,635,14,0,1,0);
	SubST_st(nfo.stbt[10],0,"TBDIS2",1,1,"","",-1,0,0);
	SubST_st(nfo.stbt[10],1,"TBDIS2",0,0,"","",0,0,0);
	STButtSet(nfo.stbt[11],2,635,22,0,1,0);
	SubST_st(nfo.stbt[11],0,"TBDIS3",1,1,"","",-1,0,0);
	SubST_st(nfo.stbt[11],1,"TBDIS3",0,0,"","",0,0,0);
	STButtSet(nfo.stbt[12],1,680,4,0,1,0);
	SubST_st(nfo.stbt[12],0,"TBCLOCK",1,1,"","",-1,0,0);
	STButtSet(nfo.stbt[13],2,725,4,0,1,0);
	SubST_st(nfo.stbt[13],0,"TBCLOCK",1,1,"","",-1,0,0);
	SubST_st(nfo.stbt[13],1,"TBCLOCK",0,0,"","",0,0,0);


    nfo.numpr=0;
    //nfo.pr=new PRloadSt[nfo.numpr];
 // pr <n> <bm filename> <x> <y> <type param1> <type param2>
    //PRSet(nfo.pr[0],"R_prog.bmp",180,60,1,0);

    nfo.numtr=1;
    nfo.tr=new TRloadSt[nfo.numtr];
// tr <n> <bgbm filename> <x> <y> <fgbm filename> <type: 1=H/2=V> <min> <max> <xoff> <yoff> <sep>(SHRT_MAX=none)
    TRSet(nfo.tr[0],"TBTRBG",300,18,"TBTRFG",1,1,cfg.maxsplit,0,-5,-1,1,1);

	nfo.numtxt=3;

	nfo.txt=new txtLD[nfo.numtxt];
	// txtb <txtb_id> <use> <font> <h> <w> <from> <n> <r:: l t r b>
	// from: 0=rect; 1=button[n], rect is used as offset.
	// use: -1=create; otherwise, use another txt's

	TXT_tagset(nfo.txt[0],-1,"MS Sans Serif",15,0,0,0,287,1,330,17,0,0,0,0);
	TXT_tagset(nfo.txt[1],0,"MS Sans Serif",15,0,0,0,436,1,470,17,0,0,0,0);
	TXT_tagset(nfo.txt[2],0,"MS Sans Serif",15,0,0,0,460,20,490,40,0,0,0,0);
    return true;
}

int InitTaskSkin(Skinload &nfo)
{
    // will return true if skin compiled correct, for now, just return true.
    //strcpy(nfo.bgfn,"bk1.bmp");
    nfo.name=_strdup("TaskGSSkin");
	nfo.basedir=_strdup(gcfg.skindir);
	nfo.type=1;

    nfo.numrg=1;
    nfo.rg=new RGloadSt[nfo.numrg];
// rg <n> <bm filen> <xoff> <yoff> <init state: by _S_RG* macros>
	rgSet(nfo.rg[0],"TBBG",0,0,_S_RGSHOW|_S_RGIN|_S_RGOUT,1,1);

    nfo.numstbt=3;
	nfo.stbt=new STBTloadSt[nfo.numstbt];
// bt <n> <bm filename> <x> <y> <xoff> <yoff> <over policy> <pushed policy> <over bm> <pushed bm>

	STButtSet(nfo.stbt[0],1,2,4,0,1,0);
	SubST_st(nfo.stbt[0],0,"TBDL",1,1,"","",-1,0,0);
	STButtSet(nfo.stbt[1],1,40,4,0,1,0);
	SubST_st(nfo.stbt[1],0,"TBSTOP",1,1,"","",-1,0,0);
	STButtSet(nfo.stbt[2],1,98,4,0,1,0);
	SubST_st(nfo.stbt[2],0,"TBSTOPALL",1,1,"","",-1,0,0);
	//STButtSet(nfo.stbt[3],2,136,4,0,1);
	//SubST_st(nfo.stbt[3],0,"ROBOTBM",1,1,"","",-1);
	//SubST_st(nfo.stbt[3],1,"",0,0,"","",0);
	//SubST_st(nfo.stbt[3],1,"",2,2,"","",0);

    nfo.numpr=0;
    //nfo.pr=new PRloadSt[nfo.numpr];
 // pr <n> <bm filename> <x> <y> <type param1> <type param2>
 //   PRSet(nfo.pr[0],"R_prog.bmp",180,60,1,0);

    nfo.numtr=1;
    nfo.tr=new TRloadSt[nfo.numtr];
// tr <n> <bgbm filename> <x> <y> <fgbm filename> <type: 1=H/2=V> <min> <max> <xoff> <yoff> <sep>(SHRT_MAX=none)
    TRSet(nfo.tr[0],"TBTRBG",300,18,"TBTRFG",1,1,cfg.maxsplit,0,-5,-1,1,1);

	nfo.numtxt=3;

	nfo.txt=new txtLD[nfo.numtxt];
	// txtb <txtb_id> <use> <font> <h> <w> <from> <n> <r:: l t r b>
	// from: 0=rect; 1=button[n], rect is used as offset.
	// use: -1=create; otherwise, use another txt's

	TXT_tagset(nfo.txt[0],-1,"MS Sans Serif",15,0,0,0,287,1,330,17,0,0,0,0);
	TXT_tagset(nfo.txt[1],0,"MS Sans Serif",15,0,0,0,436,1,470,17,0,0,0,0);
	TXT_tagset(nfo.txt[2],0,"MS Sans Serif",15,0,0,0,460,20,490,40,0,0,0,0);
    return true;
}

int InitSmallSkin(Skinload &nfo)
{
    // will return true if skin compiled correct, for now, just return true.
    //strcpy(nfo.bgfn,"bk1.bmp");
    nfo.name=_strdup("SmallGSSkin");
	nfo.basedir=_strdup(gcfg.skindir);
	nfo.type=0;

    nfo.numrg=4;
    nfo.rg=new RGloadSt[nfo.numrg];
// rg <n> <bm filen> <xoff> <yoff> <init state: by _S_RG* macros>
	rgSet(nfo.rg[0],"CAPIN",0,0,_S_RGSHOW|_S_RGIN,1,1);
	rgSet(nfo.rg[1],"CAPOUT",0,0,_S_RGSHOW|_S_RGOUT,1,1);
	rgSet(nfo.rg[2],"BK1",0,20,_S_RGSHOW|_S_RGIN|_S_RGOUT,1,1);
	rgSet(nfo.rg[3],"BK2",0,161,_S_RGIN|_S_RGOUT,1,1);

    nfo.numstbt=9;
    nfo.stbt=new STBTloadSt[nfo.numstbt];
// bt <n> <bm filename> <x> <y> <xoff> <yoff> <over policy> <pushed policy> <over bm> <pushed bm>
	STButtSet(nfo.stbt[0],1,370,4,0,1,0);
	SubST_st(nfo.stbt[0],0,"KILL",0,1,"","",-1,0,0);
	STButtSet(nfo.stbt[1],1,350,4,0,1,0);
	SubST_st(nfo.stbt[1],0,"MIN",0,1,"","",-1,0,0);
	STButtSet(nfo.stbt[2],1,8,102,0,1,0);
	SubST_st(nfo.stbt[2],0,"TASKBT",0,1,"","",-1,0,0);
	STButtSet(nfo.stbt[3],3,176,135,0,1,0);
	SubST_st(nfo.stbt[3],0,"PAUSE",0,1,"","",-1,0,0);
	SubST_st(nfo.stbt[3],1,"PLAY",0,1,"","",-1,0,0);
	SubST_st(nfo.stbt[3],2,"DONE",0,1,"","",-1,0,0);
	STButtSet(nfo.stbt[4],1,70,135,0,1,0);
	SubST_st(nfo.stbt[4],0,"CON",1,1,"","",-1,0,0);
	STButtSet(nfo.stbt[5],1,10,135,0,1,0);
	SubST_st(nfo.stbt[5],0,"STBUTT",1,1,"","",-1,0,0);
	STButtSet(nfo.stbt[6],2,367,149,0,1,0);
	SubST_st(nfo.stbt[6],0,"SHAPE",1,1,"","",-1,0,0);
	SubST_st(nfo.stbt[6],1,"",0,0,"","",0,0,0);
	STButtSet(nfo.stbt[7],4,10,46,0,1,0);
	SubST_st(nfo.stbt[7],0,"TBDL",0,0,"","",-1,0,0);
	SubST_st(nfo.stbt[7],1,"TBSTOP",0,0,"","",-1,0,0);
	SubST_st(nfo.stbt[7],2,"SMDONE",0,0,"","",-1,0,0);
	SubST_st(nfo.stbt[7],3,"SMERROR",0,0,"","",-1,0,0);
	STButtSet(nfo.stbt[8],1,116,136,0,1,0);
	SubST_st(nfo.stbt[8],0,"STBUTT",1,1,"","",-1,0,0);


    nfo.numpr=1;
    nfo.pr=new PRloadSt[nfo.numpr];
 // pr <n> <bm filename> <x> <y> <type param1> <type param2>
    PRSet(nfo.pr[0],"PRFG",59,110,2,0,1);

    nfo.numtr=1;
    nfo.tr=new TRloadSt[nfo.numtr];
// tr <n> <bgbm filename> <x> <y> <fgbm filename> <type: 1=H/2=V> <min> <max> <xoff> <yoff> <sep>(SHRT_MAX=none)
    TRSet(nfo.tr[0],"TRBG",20,180,"TRFG",1,1,cfg.maxsplit,0,-5,7,1,1);

	nfo.numtxt=25;

	nfo.txt=new txtLD[nfo.numtxt];
	// txtb <txtb_id> <use> <font> <h> <w> <from> <n> <r:: l t r b>
	// from: 0=rect; 1=button[n], rect is used as offset.
	// use: -1=create; otherwise, use another txt's

	// title
	TXT_tagset(nfo.txt[0],-1,"MS Sans Serif",15,0,0,0,10,4,335,20,RGB(255,255,255),0,0,0);

	// URL
	TXT_tagset(nfo.txt[1],0,"MS Sans Serif",15,0,0,0,60,26,360,40,0,0,0,1);

	// got/rsize
	TXT_tagset(nfo.txt[2],0,"MS Sans Serif",15,0,0,0,60,48,210,62,0,0,0,2);

	// elapsed
	TXT_tagset(nfo.txt[3],0,"MS Sans Serif",15,0,0,0,277,48,360,62,0,0,0,3);
	
	// avg kb/s
	TXT_tagset(nfo.txt[4],0,"MS Sans Serif",15,0,0,0,60,72,134,85,0,0,0,4);

	// estimated
	TXT_tagset(nfo.txt[5],0,"MS Sans Serif",15,0,0,0,160,72,274,85,0,0,0,5);

	// cur kb/s
	TXT_tagset(nfo.txt[6],0,"MS Sans Serif",15,0,0,0,275,72,360,85,0,0,0,6);

	// status
	TXT_tagset(nfo.txt[7],0,"MS Sans Serif",15,0,0,0,60,91,360,110,0,0,0,20);

	// tasks
	TXT_tagset(nfo.txt[8],0,"MS Sans Serif",15,0,1,2,5,0,0,0,0,0,0,7);

	// pause/resume
	TXT_tagset(nfo.txt[9],0,"MS Sans Serif",15,0,1,3,21,5,0,0,0,0,0,8);

	// to
	TXT_tagset(nfo.txt[10],0,"MS Sans Serif",15,0,0,0,257,142,307,156,0,0,0,9);

	// track
	TXT_tagset(nfo.txt[11],0,"MS Sans Serif",15,0,0,0,322,179,364,195,0,0,0,10);

	// "tasks"
	TXT_tagset(nfo.txt[12],0,"MS Sans Serif",15,0,0,0,11,88,52,107,0,0,0,21);

	// "Timeout"
	TXT_tagset(nfo.txt[13],0,"MS Sans Serif",15,0,0,0,255,128,302,140,0,0,0,22);

	// "splits"
	TXT_tagset(nfo.txt[14],0,"MS Sans Serif",15,0,0,0,323,167,362,185,0,0,0,23);

	// "URL"
	TXT_tagset(nfo.txt[15],0,"MS Sans Serif",15,0,0,0,20,26,52,40,0,0,0,24);

	// "elapsed"
	TXT_tagset(nfo.txt[16],0,"MS Sans Serif",15,0,0,0,220,48,282,62,0,0,0,25);

	// "estimated"
	TXT_tagset(nfo.txt[17],0,"MS Sans Serif",15,0,0,0,135,72,180,85,0,0,0,26);
    
	// "cur"
	TXT_tagset(nfo.txt[18],0,"MS Sans Serif",15,0,0,0,251,72,274,85,0,0,0,27);

	// "hide"
	TXT_tagset(nfo.txt[19],0,"MS Sans Serif",15,0,1,5,8,4,0,0,0,0,0,28);

	// "Normal"
	TXT_tagset(nfo.txt[20],0,"MS Sans Serif",15,0,0,0,10,161,50,180,0,0,0,40);

	// "Fast"
	TXT_tagset(nfo.txt[21],0,"MS Sans Serif",15,0,0,0,274,161,320,180,0,0,0,41);

	// "Ping"
	TXT_tagset(nfo.txt[22],0,"MS Sans Serif",15,0,0,0,319,128,350,148,0,0,0,29);

	// Ping
	TXT_tagset(nfo.txt[23],-1,"MS Sans Serif",3,1,0,0,311,144,360,160,0,0,0,11);

	// "mirrors"
	TXT_tagset(nfo.txt[24],0,"MS Sans Serif",15,0,1,8,8,4,0,0,0,0,0,30);
	return true;
}

int InitBufferSkin(Skinload &nfo)
{
    // will return true if skin compiled correct, for now, just return true.
    //strcpy(nfo.bgfn,"bk1.bmp");
    nfo.name=_strdup("BufferGSSkin");
	nfo.basedir=_strdup(gcfg.skindir);
	nfo.type=1;

    nfo.numrg=1;
    nfo.rg=new RGloadSt[nfo.numrg];
// rg <n> <bm filen> <xoff> <yoff> <init state: by _S_RG* macros>
	rgSet(nfo.rg[0],"TBBG",0,0,_S_RGSHOW|_S_RGIN|_S_RGOUT,1,1);

    nfo.numstbt=1;
	nfo.stbt=new STBTloadSt[nfo.numstbt];
// bt <n> <bm filename> <x> <y> <xoff> <yoff> <over policy> <pushed policy> <over bm> <pushed bm>

	STButtSet(nfo.stbt[0],2,50,4,0,1,0);
	SubST_st(nfo.stbt[0],0,"TBSCROLL",1,1,"","",-1,0,0);
	SubST_st(nfo.stbt[0],1,"TBSCROLL",0,0,"","",0,0,0);

    nfo.numpr=0;
    //nfo.pr=new PRloadSt[nfo.numpr];
 // pr <n> <bm filename> <x> <y> <type param1> <type param2>
 //   PRSet(nfo.pr[0],"R_prog.bmp",180,60,1,0);

    nfo.numtr=0;
    //nfo.tr=new TRloadSt[nfo.numtr];
// tr <n> <bgbm filename> <x> <y> <fgbm filename> <type: 1=H/2=V> <min> <max> <xoff> <yoff> <sep>(SHRT_MAX=none)
    //TRSet(nfo.tr[0],"TBTRBG",300,18,"TBTRFG",1,1,cfg.maxsplit,1,-5,-1,1,1);

	nfo.numtxt=0;

	//nfo.txt=new txtLD[nfo.numtxt];
	// txtb <txtb_id> <use> <font> <h> <w> <from> <n> <r:: l t r b>
	// from: 0=rect; 1=button[n], rect is used as offset.
	// use: -1=create; otherwise, use another txt's

	//TXT_tagset(nfo.txt[0],-1,"MS Sans Serif",15,0,0,0,287,1,330,17);
    return true;
}

int InitServerSkin(Skinload &nfo)
{
    // will return true if skin compiled correct, for now, just return true.
    //strcpy(nfo.bgfn,"bk1.bmp");
    nfo.name=_strdup("ServerGSSkin");
	nfo.basedir=_strdup(gcfg.skindir);
	nfo.type=1;

    nfo.numrg=1;
    nfo.rg=new RGloadSt[nfo.numrg];
// rg <n> <bm filen> <xoff> <yoff> <init state: by _S_RG* macros>
	rgSet(nfo.rg[0],"TBBG",0,0,_S_RGSHOW|_S_RGIN|_S_RGOUT,1,1);

    nfo.numstbt=1;
	nfo.stbt=new STBTloadSt[nfo.numstbt];
// bt <n> <bm filename> <x> <y> <xoff> <yoff> <over policy> <pushed policy> <over bm> <pushed bm>

	STButtSet(nfo.stbt[0],1,50,4,0,1,0);
	SubST_st(nfo.stbt[0],0,"TBCFGSER",1,1,"","",-1,0,0);
//	SubST_st(nfo.stbt[0],1,"TBSCROLL",0,0,"","",0);

    nfo.numpr=0;
    //nfo.pr=new PRloadSt[nfo.numpr];
 // pr <n> <bm filename> <x> <y> <type param1> <type param2>
 //   PRSet(nfo.pr[0],"R_prog.bmp",180,60,1,0);

    nfo.numtr=0;
    //nfo.tr=new TRloadSt[nfo.numtr];
// tr <n> <bgbm filename> <x> <y> <fgbm filename> <type: 1=H/2=V> <min> <max> <xoff> <yoff> <sep>(SHRT_MAX=none)
    //TRSet(nfo.tr[0],"TBTRBG",300,18,"TBTRFG",1,1,cfg.maxsplit,1,-5,-1,1,1);

	nfo.numtxt=0;

	//nfo.txt=new txtLD[nfo.numtxt];
	// txtb <txtb_id> <use> <font> <h> <w> <from> <n> <r:: l t r b>
	// from: 0=rect; 1=button[n], rect is used as offset.
	// use: -1=create; otherwise, use another txt's

	//TXT_tagset(nfo.txt[0],-1,"MS Sans Serif",15,0,0,0,287,1,330,17);
    return true;
}

int InitMirrorSkin(Skinload &nfo)
{
    // will return true if skin compiled correct, for now, just return true.
    //strcpy(nfo.bgfn,"bk1.bmp");
    nfo.name=_strdup("MirrorGSSkin");
	nfo.basedir=_strdup(gcfg.skindir);
	nfo.type=1;

    nfo.numrg=1;
    nfo.rg=new RGloadSt[nfo.numrg];
// rg <n> <bm filen> <xoff> <yoff> <init state: by _S_RG* macros>
	rgSet(nfo.rg[0],"TBBG",0,0,_S_RGSHOW|_S_RGIN|_S_RGOUT,1,1);

    nfo.numstbt=9;
	nfo.stbt=new STBTloadSt[nfo.numstbt];
// bt <n> <bm filename> <x> <y> <xoff> <yoff> <over policy> <pushed policy> <over bm> <pushed bm>

	STButtSet(nfo.stbt[0],1,10,4,0,1,0);
	SubST_st(nfo.stbt[0],0,"MIRSEARCHTB",1,1,"","",-1,0,0);
	STButtSet(nfo.stbt[1],1,50,4,0,1,0);
	SubST_st(nfo.stbt[1],0,"MIRVALIDTB",1,1,"","",-1,0,0);
	STButtSet(nfo.stbt[2],1,90,4,0,1,0);
	SubST_st(nfo.stbt[2],0,"TBSTOPALL",1,1,"","",-1,0,0);
	STButtSet(nfo.stbt[3],1,130,4,0,1,0);
	SubST_st(nfo.stbt[3],0,"TBSTOP",1,1,"","",-1,0,0);
	STButtSet(nfo.stbt[4],1,170,4,0,1,0);
	SubST_st(nfo.stbt[4],0,"MIRRMSELTB",1,1,"","",-1,0,0);
	STButtSet(nfo.stbt[5],1,210,4,0,1,0);
	SubST_st(nfo.stbt[5],0,"MIRRMBADTB",1,1,"","",-1,0,0);
	STButtSet(nfo.stbt[6],1,250,4,0,1,0);
	SubST_st(nfo.stbt[6],0,"TBUP",1,1,"","",-1,0,0);
	STButtSet(nfo.stbt[7],1,250,21,0,1,0);
	SubST_st(nfo.stbt[7],0,"TBDOWN",1,1,"","",-1,0,0);
	STButtSet(nfo.stbt[8],1,500,4,0,1,0);
	SubST_st(nfo.stbt[8],0,"MIRADDTB",1,1,"","",-1,0,0);

//	SubST_st(nfo.stbt[0],1,"TBSCROLL",0,0,"","",0);

    nfo.numpr=0;
    //nfo.pr=new PRloadSt[nfo.numpr];
 // pr <n> <bm filename> <x> <y> <type param1> <type param2>
 //   PRSet(nfo.pr[0],"R_prog.bmp",180,60,1,0);

    nfo.numtr=0;
    //nfo.tr=new TRloadSt[nfo.numtr];
// tr <n> <bgbm filename> <x> <y> <fgbm filename> <type: 1=H/2=V> <min> <max> <xoff> <yoff> <sep>(SHRT_MAX=none)
    //TRSet(nfo.tr[0],"TBTRBG",300,18,"TBTRFG",1,1,cfg.maxsplit,1,-5,-1,1,1);

	nfo.numtxt=1;

	nfo.txt=new txtLD[nfo.numtxt];
	// txtb <txtb_id> <use> <font> <h> <w> <from> <n> <r:: l t r b>
	// from: 0=rect; 1=button[n], rect is used as offset.
	// use: -1=create; otherwise, use another txt's

	TXT_tagset(nfo.txt[0],-1,"MS Sans Serif",15,0,0,0,300,15,800,35,
				0,0,0,0);
    return true;
}

int InitBrowseSkin(Skinload &nfo)
{
    // will return true if skin compiled correct, for now, just return true.
    //strcpy(nfo.bgfn,"bk1.bmp");
    nfo.name=_strdup("BrowseGSSkin");
	nfo.basedir=_strdup(gcfg.skindir);
	nfo.type=1;

    nfo.numrg=3;
    nfo.rg=new RGloadSt[nfo.numrg];
// rg <n> <bm filen> <xoff> <yoff> <init state: by _S_RG* macros>
	rgSet(nfo.rg[0],"TBBG",0,0,_S_RGSHOW|_S_RGIN|_S_RGOUT,1,1);
	rgSet(nfo.rg[1],"TBBG",0,40,_S_RGSHOW|_S_RGIN|_S_RGOUT,1,1);
	rgSet(nfo.rg[2],"TBBG",0,159,_S_RGSHOW|_S_RGIN|_S_RGOUT,1,1);

    nfo.numstbt=10;
	nfo.stbt=new STBTloadSt[nfo.numstbt];
// bt <n> <bm filename> <x> <y> <xoff> <yoff> <over policy> <pushed policy> <over bm> <pushed bm>

	STButtSet(nfo.stbt[0],1,20,4,0,1,0);
	SubST_st(nfo.stbt[0],0,"BRCONNECT",1,1,"","",-1,0,0);
	STButtSet(nfo.stbt[1],1,60,4,0,1,0);
	SubST_st(nfo.stbt[1],0,"BRDISCONNECT",1,1,"","",-1,0,0);
	STButtSet(nfo.stbt[2],1,110,4,0,1,0);
	SubST_st(nfo.stbt[2],0,"BRURL",1,1,"","",-1,0,0);
	STButtSet(nfo.stbt[3],1,160,4,0,1,0);
	SubST_st(nfo.stbt[3],0,"TBSTOP",1,1,"","",-1,0,0);
	STButtSet(nfo.stbt[4],1,200,4,0,1,0);
	SubST_st(nfo.stbt[4],0,"BRREFRESH",1,1,"","",-1,0,0);
	STButtSet(nfo.stbt[5],1,240,4,0,1,0);
	SubST_st(nfo.stbt[5],0,"BRCUSTOM",1,1,"","",-1,0,0);
	STButtSet(nfo.stbt[6],1,290,4,0,1,0);
	SubST_st(nfo.stbt[6],0,"BRDLALL",1,1,"","",-1,0,0);
	STButtSet(nfo.stbt[7],2,340,4,0,1,0);
	SubST_st(nfo.stbt[7],0,"BRAUTO",1,1,"","",-1,0,0);
	SubST_st(nfo.stbt[7],1,"",0,0,"","",0,0,0);
	STButtSet(nfo.stbt[8],2,380,4,0,1,0);
	SubST_st(nfo.stbt[8],0,"BRASCII",1,1,"","",-1,0,0);
	SubST_st(nfo.stbt[8],1,"",0,0,"","",0,0,0);
	STButtSet(nfo.stbt[9],2,420,4,0,1,0);
	SubST_st(nfo.stbt[9],0,"BRBINARY",1,1,"","",-1,0,0);
	SubST_st(nfo.stbt[9],1,"",0,0,"","",0,0,0);


    nfo.numpr=0;
    //nfo.pr=new PRloadSt[nfo.numpr];
 // pr <n> <bm filename> <x> <y> <type param1> <type param2>
 //   PRSet(nfo.pr[0],"R_prog.bmp",180,60,1,0);

    nfo.numtr=0;
    //nfo.tr=new TRloadSt[nfo.numtr];
// tr <n> <bgbm filename> <x> <y> <fgbm filename> <type: 1=H/2=V> <min> <max> <xoff> <yoff> <sep>(SHRT_MAX=none)
    //TRSet(nfo.tr[0],"TBTRBG",300,18,"TBTRFG",1,1,cfg.maxsplit,1,-5,-1,1,1);

	nfo.numtxt=4;

	nfo.txt=new txtLD[nfo.numtxt];
	// txtb <txtb_id> <use> <font> <h> <w> <from> <n> <r:: l t r b>
	// from: 0=rect; 1=button[n], rect is used as offset.
	// use: -1=create; otherwise, use another txt's

	TXT_tagset(nfo.txt[0],-1,"MS Sans Serif",15,0,0,0,18,56,49,74,0,0,0,0);
	TXT_tagset(nfo.txt[1],0,"MS Sans Serif",15,0,0,0,229,56,259,74,0,0,0,0);
	TXT_tagset(nfo.txt[2],0,"MS Sans Serif",15,0,0,0,331,56,364,74,0,0,0,0);
	TXT_tagset(nfo.txt[3],0,"MS Sans Serif",15,0,0,0,491,56,524,74,0,0,0,0);
    return true;
}

int InitSkins()
{
	n=new Skinload;
	InitMainSkin(*n);
    mainskin.Init(*n,hlang);
	delete n;

	n=new Skinload;
	InitTaskSkin(*n);
	taskskin.Init(*n,hlang);
	delete n;

	n=new Skinload;
	FILE *fp0=NULL;
/*	char tmp[1024];
	strcpy(tmp,"Checking for external skin..\n");
	fwrite(tmp,1,strlen(tmp),gfp);
	sprintf(tmp,"External skin ? %ld\n",gcfg.useexskin);
	fwrite(tmp,1,strlen(tmp),gfp);
	sprintf(tmp,"Length of exskinfn %ld\n",strlen(gcfg.exskinfn));
	fwrite(tmp,1,strlen(tmp),gfp);
	sprintf(tmp,"exskinfn %s\n",gcfg.exskinfn);
	fwrite(tmp,1,strlen(tmp),gfp);
	fp0=fopen(gcfg.exskinfn,"r+t");
	if (fp0)
	{
		fclose(fp0);
		fp0=NULL;
		strcpy(tmp,"Opened file successfully\n");
		fwrite(tmp,1,strlen(tmp),gfp);
	}
	else
	{
		sprintf(tmp,"Can't open %s\n",gcfg.exskinfn);
		fwrite(tmp,1,strlen(tmp),gfp);
	}*/
	if (gcfg.useexskin && strlen(gcfg.exskinfn) && (fp0=fopen(gcfg.exskinfn,"r+t")))
	{
/*		strcpy(tmp,"Using external skin, closing tmp file..\n");
		fwrite(tmp,1,strlen(tmp),gfp);*/
		fclose(fp0);
		n->numpr=1;
		n->numrg=4;
		n->numstbt=9;
		n->numtxt=25;
		n->numtr=1;
		n->type=0;
/*		char tmp[1024];
		sprintf(tmp,"Basedir: %s\n",gcfg.skindir);
		fwrite(tmp,1,strlen(tmp),gfp);*/
		n->basedir=_strdup(gcfg.exskinfn);
		char *tc;
		if (tc=strrchr(n->basedir,'\\'))
			*(tc+1)='\0';
/*		n->rg=new RGloadSt[n->numrg];
		n->stbt=new STBTloadSt[n->numstbt];
		n->pr=new PRloadSt[n->numpr];
		n->tr=new TRloadSt[n->numtr];
		n->txt=new txtLD[n->numtxt];*/
/*		sprintf(tmp,"Loading external skin: %s\n",gcfg.exskinfn);
		fwrite(tmp,1,strlen(tmp),gfp);*/
		if (n->LoadFile(gcfg.exskinfn)!=-1)
		{
/*			strcpy(tmp,"Load ok.\n");
			fwrite(tmp,1,strlen(tmp),gfp);*/
			n->tr[0].max=cfg.maxsplit;
		}
		else
		{
/*			strcpy(tmp,"Load error.\n");
			fwrite(tmp,1,strlen(tmp),gfp);*/
			delete n;
			n=new Skinload;
			InitSmallSkin(*n);
		}
	}
	else
		InitSmallSkin(*n);
/*	strcpy(tmp,"Skin Init\n");
	fwrite(tmp,1,strlen(tmp),gfp);*/
	smallskin.Init(*n,hlang);
	delete n;

	n=new Skinload;
	InitBufferSkin(*n);
	bufferskin.Init(*n,hlang);
	delete n;

	n=new Skinload;
	InitServerSkin(*n);
	serverskin.Init(*n,hlang);
	delete n;

	n=new Skinload;
	InitMirrorSkin(*n);
	mirrorskin.Init(*n,hlang);
	delete n;

	n=new Skinload;
	InitBrowseSkin(*n);
	browseskin.Init(*n,hlang);
	delete n;

	return 1;
}
