
/*#define _WIN32_WINNT 0x500
#define WIN32 1

//#define WINVER 0x0500
#define _WIN32_IE 0x0400*/

#define WS_EX_LAYERED           0x00080000
#define LWA_ALPHA               0x00000002

#include "GUI.h"

int mylv::insts=0;
WNDCLASSEX mylv::wcx;
COLORREF mylv::bkclr,mylv::fgclr,mylv::fgclr2,mylv::hdclr,mylv::hdclr2,mylv::glassclr;
HDC mylv::memdc,mylv::tmpdc,mylv::txtdc;
TEXTMETRIC mylv::tm;
bool mylv::dynbg;

LRESULT CALLBACK MyLVFunc(HWND, UINT, WPARAM, LPARAM);
LRESULT WINAPI NewLVProc(HWND, UINT, WPARAM, LPARAM);
LRESULT WINAPI NewCVProc(HWND, UINT, WPARAM, LPARAM);

void mylv::InitCols(char *h1,int *h2,int c)
{
	struct htxts
	{ 
		char s[10][50];
	}*htxt;
	
	struct hls
	{
		int s[10];
	}*hl;
	htxt=(htxts*) h1;
	hl=(hls*)h2;

	LVCOLUMN lvc; 
    int iCol;
    lvc.mask = LVCF_FMT|LVCF_WIDTH|LVCF_SUBITEM;
    lvc.fmt = LVCFMT_LEFT;

	lvc.cx=0;

    for (iCol = 0; iCol < c; iCol++) 
		//lvc.cx = hl->s[c];
		lvc.cx+=hl->s[iCol];
	lvc.iSubItem = iCol; 
	//lvc.pszText =htxt->s[0,iCol];
	ListView_InsertColumn(hwndLV, iCol, &lvc);
}

void mylv::InitCols2(char *h1,int *h2,int c)
{ 
	RECT rcParent;
	HDLAYOUT hdl;
	WINDOWPOS wp;
#define HDS_DRAGDROP            0x0040
#define HDS_FULLDRAG            0x0080
	
	if ((hwndCV=CreateWindowEx(0,WC_HEADER,NULL,
		WS_CHILD|WS_BORDER|HDS_BUTTONS|HDS_HORZ|HDS_DRAGDROP|HDS_FULLDRAG,
		0, 0, 0, 0, hwnd, NULL,hinst,
		(LPVOID) NULL)) == NULL)
		return;

	SetProp(hwndCV, "OldProc",(HANDLE)GetWindowLong(hwndCV,GWL_WNDPROC));
	SetWindowLong(hwndCV,GWL_WNDPROC,(DWORD)NewCVProc);

/*	DWORD hbk=GetClassLong(hwndCV,GCL_HBRBACKGROUND);
	SetClassLong(hwndCV,GCL_HBRBACKGROUND,(LONG)NULL);*/
	
	// Retrieve the bounding rectangle of the parent window's
	// client area, and then request size and position values
	// from the header control.
	GetClientRect(hwnd, &rcParent);
	
	hdl.prc = &rcParent;
	hdl.pwpos = &wp;
	if (!SendMessage(hwndCV, HDM_LAYOUT, 0, (LPARAM) &hdl))
		return;
	
	// Set the size, position, and visibility of the header control.
	SetWindowPos(hwndCV, wp.hwndInsertAfter, wp.x, wp.y+40,
		wp.cx, wp.cy, wp.flags | SWP_SHOWWINDOW);

	struct htxts
	{
		char s[10][50];
	}*htxt;
	
	struct hls
	{
		int s[10];
	}*hl;
	htxt=(htxts*) h1;
	hl=(hls*)h2;

    HDITEM hdi;
    int index,iCol;

    for (iCol = 0; iCol < c; iCol++)
	{
		hdi.mask = /*HDI_TEXT | */HDI_FORMAT | HDI_WIDTH;
		//hdi.pszText = htxt->s[0,iCol];
		hdi.cxy = hl->s[iCol];
		//hdi.cchTextMax = strlen(hdi.pszText);
		hdi.fmt = HDF_LEFT | /*HDF_STRING |*/HDF_OWNERDRAW;
		
		index = SendMessage(hwndCV, HDM_INSERTITEM,
			(WPARAM) iCol, (LPARAM) &hdi);
	}
}

void mylv::CreateLV(char *h1,int *h2,int c)
{
	int r2l=0,ext=0;
	if (cfg.r2l)
		if ((os.dwPlatformId==VER_PLATFORM_WIN32_NT) && (os.dwMajorVersion>=5)
			|| (os.dwPlatformId==VER_PLATFORM_WIN32_WINDOWS) &&
			((os.dwMajorVersion!=4) || (os.dwMinorVersion)))
				r2l=0x0400000L|WS_EX_RTLREADING|WS_EX_LEFTSCROLLBAR;
	if ((ctlmajor>4) || (ctlmajor==4) && (ctlminor>=70))
	{
#define LVS_EX_HEADERDRAGDROP   0x00000010
#define LVS_EX_FULLROWSELECT    0x00000020
	ext=LVS_EX_FULLROWSELECT;//|LVS_EX_HEADERDRAGDROP;
	}
	hwndLV = CreateWindowEx(WS_EX_TOPMOST|r2l|ext,WC_LISTVIEW, "",
		WS_CHILD | WS_BORDER | LVS_REPORT | CCS_TOP | LVS_SHOWSELALWAYS|LVS_OWNERDRAWFIXED|/*LVS_NOSCROLL|*/LVS_NOCOLUMNHEADER,
		0, 0, 0, 0, hwnd, NULL, hinst, NULL);
	if (hwndLV == NULL)
        return;
/*
BOOL (STDAPICALLTYPE* SetLayeredWindowAttributesx)(
    HWND hwnd,
    COLORREF crKey,
    BYTE bAlpha,
    DWORD dwFlags);

	HINSTANCE hin;
	hin=LoadLibrary("user32.dll");
	SetLayeredWindowAttributesx= (BOOL (STDAPICALLTYPE*)(HWND hwnd,
				COLORREF crKey,
				BYTE bAlpha,
				DWORD dwFlags))
				GetProcAddress(hin,"SetLayeredWindowAttributes");

	DWORD dwLong = GetWindowLong(GetParent(hwnd), GWL_EXSTYLE);
	SetWindowLong(GetParent(hwnd), GWL_EXSTYLE, dwLong | 0x00080000);//WS_EX_LAYERED
	SetLayeredWindowAttributesx(GetParent(hwnd), RGB(0,0,0), 192, 0x00000002);//LWA_ALPHA
	FreeLibrary(hin);*/

	EnableScrollBar(hwndLV,SB_BOTH,ESB_DISABLE_BOTH);

	SetProp(hwndLV, "OldProc",(HANDLE)GetWindowLong(hwndLV,GWL_WNDPROC));
	SetWindowLong(hwndLV,GWL_WNDPROC,(DWORD)NewLVProc);
	InitCols(h1,h2,c);
}

LRESULT WINAPI NewLVProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	WNDPROC OldProc;
	
	OldProc = (WNDPROC)GetProp( hWnd, "OldProc");

	mylv *lv=(mylv*)GetWindowLong(GetParent(hWnd),GWL_USERDATA);

	if (msg==WM_NCCALCSIZE)
		return 1;

#define WM_MOUSEWHEEL                   0x020A

	if ((msg==LVM_DELETEITEM) || (msg==LVM_SCROLL) || (msg==WM_MOUSEWHEEL) || 
		(msg==WM_KEYDOWN))
	{
		LONG st=GetWindowLong(hWnd,GWL_STYLE);
		st|=WS_VISIBLE;
		st-=WS_VISIBLE;
		SetWindowLong(hWnd,GWL_STYLE,st);
		LRESULT lr=CallWindowProc( (int (__stdcall*)(void))OldProc, hWnd, msg, wParam, lParam);
		st|=WS_VISIBLE;
		SetWindowLong(hWnd,GWL_STYLE,st);
		RECT rc;
		GetClientRect(lv->hwnd,&rc);
		InvalidateRect(lv->hwnd,&rc,true);
		return lr;
	}

	if (msg==WM_PAINT)
	{
		POINT pt;
		RECT rc;
		if (!lv->height && ListView_GetItemCount(hWnd))
		{
			ListView_GetItemRect(hwndLV,0,&rc,LVIR_BOUNDS);
			lv->height=rc.bottom-rc.top+1;
		}
		ListView_GetItemPosition(hWnd,0,&pt);
		lv->cvx=pt.x-2;
		lv->xPos=lv->cvx*-1;
		lv->yPos=pt.y*-1;
		GetClientRect(lv->hwnd,&rc);
		SetWindowPos(lv->hwndCV,0,lv->cvx,0,rc.right-lv->cvx,20,SWP_SHOWWINDOW|SWP_NOZORDER);

#define HDM_GETORDERARRAY       (HDM_FIRST + 17)
		lv->ccols=SendMessage(lv->hwndCV,HDM_GETITEMCOUNT,0,0);
		SendMessage(lv->hwndCV,HDM_GETORDERARRAY,lv->ccols,(LPARAM)lv->colorder);
		lv->il=ListView_GetImageList(lv->hwndLV,LVSIL_SMALL);

		LRESULT lr=CallWindowProc( (int (__stdcall*)(void))OldProc, hWnd, msg, wParam, lParam);

        GetClientRect(lv->hwndLV, &rc);
		int yClient,xClient,yMax;
        yClient = rc.bottom;//-40;
        xClient = rc.right;//-20;
 
        yMax = max (0, ListView_GetItemCount(lv->hwndLV)*lv->height);
 
        lv->yPos = min (lv->yPos, yMax); 
 
		SCROLLINFO si;
 
        si.cbSize = sizeof(si); 
        si.fMask  = SIF_RANGE | SIF_PAGE | SIF_POS; 
        si.nMin   = 0; 
        si.nMax   = yMax;
        si.nPage  = yClient;
        si.nPos   = lv->yPos; 
        SetScrollInfo(lv->hwndVS, SB_CTL, &si, TRUE);

		if (yMax>yClient)
		{
			if (!lv->ShowVS)
			{
				lv->ShowVS=true;
				PostMessage(lv->hwnd,WM_SIZE,0,0);
			}
		}
		else
			if (lv->ShowVS)
			{
				lv->ShowVS=false;
				PostMessage(lv->hwnd,WM_SIZE,0,0);
			}

        lv->xPos = min (lv->xPos, lv->xMax);
 
        si.cbSize = sizeof(si);
        si.fMask  = SIF_RANGE | SIF_PAGE | SIF_POS;
        si.nMin   = 0;
        si.nMax   = lv->xMax;
        si.nPage  = xClient;
        si.nPos   = lv->xPos;
        SetScrollInfo(lv->hwndHS, SB_CTL, &si, TRUE);

		if (lv->xMax>xClient)
		{
			if (!lv->ShowHS)
			{
				lv->ShowHS=true;
				PostMessage(lv->hwnd,WM_SIZE,0,0);
			}
		}
		else
			if (lv->ShowHS)
			{
				lv->ShowHS=false;
				PostMessage(lv->hwnd,WM_SIZE,0,0);
			}

        UpdateWindow(lv->hwndVS);
		UpdateWindow(lv->hwndHS);
		return lr;
	}

	if( msg == WM_DESTROY )
	{
		SetWindowLong( hWnd, GWL_WNDPROC, (DWORD)OldProc);
		RemoveProp( hWnd, "OldProc");
	}


	if( msg == WM_ERASEBKGND )
	{
		RECT Rect, itemRect,rc;

		int iCount;
		iCount = SendMessage(hWnd, LVM_GETITEMCOUNT, 0, 0);
		itemRect.left=LVIR_BOUNDS;
		SendMessage(hWnd, LVM_GETITEMRECT,iCount - 1,(LPARAM)&itemRect);
		GetClientRect(hWnd, &Rect);
		if (Rect.right>(lv->xMax+lv->cvx))
		{
			rc.left=lv->xMax+lv->cvx;
			rc.right=Rect.right;
			rc.top=Rect.top;
			rc.bottom=Rect.bottom;
			if (lv->dynbg)
			{
				RECT rc2;
				GetWindowRect(lv->hwndLV,&rc2);
				lv->BitDyn((HDC)wParam,rc.left,rc.top,rc.right-rc.left+1,rc.bottom-rc.top+1,
					lv->memdc,rc.left+rc2.left,rc.top+rc2.top,SRCCOPY);
			}
			else
				BitBlt((HDC)wParam,rc.left,rc.top,rc.right-rc.left+1,rc.bottom-rc.top+1,
					lv->memdc,rc.left,rc.top,SRCCOPY);
		}
		if(itemRect.bottom < Rect.bottom)
		{
			Rect.top = itemRect.bottom;
			if (lv->dynbg)
			{
				RECT rc2;
				GetWindowRect(lv->hwndLV,&rc2);
				lv->BitDyn((HDC)wParam,Rect.left,Rect.top,Rect.right-Rect.left+1,Rect.bottom-Rect.top+1,
					lv->memdc,Rect.left+rc2.left,Rect.top+rc2.top,SRCCOPY);
			}
			else
				BitBlt((HDC)wParam,Rect.left,Rect.top,Rect.right-Rect.left+1,Rect.bottom-Rect.top+1,
					lv->memdc,Rect.left,Rect.top,SRCCOPY);
		}
		return 1;
	}
	return CallWindowProc( (int (__stdcall*)(void))OldProc, hWnd, msg, wParam, lParam);
}

LRESULT WINAPI NewCVProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	WNDPROC OldProc;
	
	OldProc = (WNDPROC)GetProp( hWnd, "OldProc");

	mylv *lv=(mylv*)GetWindowLong(GetParent(hWnd),GWL_USERDATA);

	if( msg == WM_DESTROY )
	{
		SetWindowLong( hWnd, GWL_WNDPROC, (DWORD)OldProc);
		RemoveProp( hWnd, "OldProc");
	}


	if( msg == WM_ERASEBKGND )
	{
		RECT Rect;
		GetClientRect(hWnd, &Rect);

		if (lv->xMax+lv->cvx<Rect.right)
		{
			Rect.left=lv->xMax+lv->cvx+2;
			Rect.right-=2;
			Rect.top+=2;
			Rect.bottom-=3;
			if (lv->dynbg)
			{
				RECT rc2;
				GetWindowRect(lv->hwndCV,&rc2);
				lv->BitDyn((HDC)wParam,Rect.left,Rect.top,Rect.right-Rect.left+1,Rect.bottom-Rect.top+1,
					lv->memdc,Rect.left+rc2.left,Rect.top+rc2.top,SRCCOPY);
			}
			else
				BitBlt((HDC)wParam,Rect.left,Rect.top,Rect.right-Rect.left+1,Rect.bottom-Rect.top+1,
					lv->memdc,Rect.left,Rect.top,SRCCOPY);
		}
		return 1;
	}
	return CallWindowProc( (int (__stdcall*)(void))OldProc, hWnd, msg, wParam, lParam);
}

LRESULT CALLBACK MyLVFunc(HWND hwnd, UINT message,
                            WPARAM wParam, LPARAM lParam)
{
	mylv *lv=(mylv*)GetWindowLong(hwnd,GWL_USERDATA);
	int xInc,yInc;
	RECT rc;
	switch(message)
	{
	case WM_CREATE:
		lv=(mylv*)(((LPCREATESTRUCT) lParam)->lpCreateParams);
		SetWindowLong(hwnd,GWL_USERDATA,(LONG)lv);
		break;

	case WM_ERASEBKGND:
		if (lv->ShowHS && lv->ShowVS)
		{
			RECT Rect;
			RECT rc2;
			GetWindowRect(lv->hwnd,&rc2);
			GetClientRect(hwnd,&Rect);
			Rect.top=Rect.bottom-lv->HSWidth;
			Rect.left=Rect.right-lv->VSWidth;
			lv->BitDyn((HDC)wParam,Rect.left,Rect.top,Rect.right-Rect.left+1,Rect.bottom-Rect.top+1,
				lv->memdc,Rect.left+rc2.left,Rect.top+rc2.top,SRCCOPY);
		}
		return 1;

	case WM_SIZE:
		if (wParam==SIZE_MINIMIZED) break;
        GetClientRect(lv->hwnd, &rc);
		SetWindowPos(lv->hwndLV, 0, rc.left, rc.top+20,
			lv->ShowVS ? rc.right-lv->VSWidth :rc.right, 
			lv->ShowHS ? rc.bottom-20-lv->HSWidth:rc.bottom-20, SWP_SHOWWINDOW|SWP_NOZORDER);
		SetWindowPos(lv->hwndCV,0,lv->cvx,0,rc.right-lv->cvx,20,SWP_SHOWWINDOW|SWP_NOZORDER);
		InvalidateRect(hwnd,&rc,true);
		if (lv->ShowHS)
			SetWindowPos(lv->hwndHS, 0,rc.left,rc.bottom-lv->HSWidth,
				rc.right-rc.left-(lv->ShowVS?lv->VSWidth:0), lv->HSWidth ,SWP_SHOWWINDOW|SWP_NOZORDER);
		else ShowWindow(lv->hwndHS,SW_HIDE);
		if (lv->ShowVS)
			SetWindowPos(lv->hwndVS, 0,rc.right-lv->VSWidth, rc.top+20,
				lv->VSWidth , rc.bottom-20-(lv->ShowHS?lv->HSWidth:0), SWP_SHOWWINDOW|SWP_NOZORDER);
		else ShowWindow(lv->hwndVS,SW_HIDE);
 		break;

    case WM_HSCROLL:
        switch(LOWORD (wParam)) 
        {
            // User clicked shaft left of the scroll box. 
            case SB_PAGEUP: 

                 break; 
 
            // User clicked shaft right of the scroll box. 
            case SB_PAGEDOWN: 

                 break; 
 
            // User clicked the left arrow. 
 
            case SB_LINEUP: 
				xInc=10;
                break; 
 
            // User clicked the right arrow. 
 
            case SB_LINEDOWN: 
				xInc=-10;
                break; 
 
            // User dragged the scroll box. 
 
            case SB_THUMBTRACK:
                 xInc = lv->xPos-HIWORD(wParam);
                 break; 
 
            default: 
                 xInc = 0;
         }
		//lv->cvx+=xInc;
		lv->xPos-=xInc;
		if (xInc)
		{
			//RECT r;
			//lv->scroll=true;
			SendMessage(lv->hwndLV,LVM_SCROLL,xInc*-1,0);
			//lv->scroll=false;
			//GetClientRect(hwnd,&r);
			//PostMessage(lv->hwndLV,WM_USER+1,0,0);
			//InvalidateRect(hwnd,&r,false);
		}
		//GetClientRect(hwnd,&rc);
		//SetWindowPos(lv->hwndCV,0,lv->cvx,0,rc.right-lv->cvx,20,SWP_SHOWWINDOW|SWP_NOZORDER);
		break;

    case WM_VSCROLL:
        switch(LOWORD (wParam)) 
        {
            // User clicked shaft left of the scroll box. 
 
            case SB_PAGEUP: 
                 break; 
 
            // User clicked shaft right of the scroll box. 
 
            case SB_PAGEDOWN: 
                 break; 
 
            // User clicked the left arrow. 
 
            case SB_LINEUP:
				yInc=-lv->height;
                break;
 
            // User clicked the right arrow. 
 
            case SB_LINEDOWN: 
				yInc=lv->height;
                break; 
 
            // User dragged the scroll box. 
 
            case SB_THUMBTRACK: 
                 yInc = (HIWORD(wParam)-lv->yPos);

                 break; 
            case SB_THUMBPOSITION: 
                 yInc = (HIWORD(wParam)-lv->yPos);
				 break;
 
            default: 
              yInc = 0;
         }
		//if (abs(yInc%15)>7)
		//	yInc=yInc/15+yInc/abs(yInc);
		//else yInc=yInc/15;
		//ScrollWindowEx(lv->hwndLV,0,-15*yInc,0,0,0,0,SW_INVALIDATE);
		if (yInc) SendMessage(lv->hwndLV,LVM_SCROLL,0,yInc);//+yInc/abs(yInc));
		break;

	case WM_NOTIFY:
#define HDN_ENDDRAG  (HDN_FIRST-11)

		if (((LPNMHDR) lParam)->hwndFrom==lv->hwndCV)
			switch (((LPNMHDR) lParam)->code)
			{
			//case HDN_TRACK:
			case HDN_ITEMCHANGING:
			case HDN_ENDDRAG:
				RECT r;
				GetClientRect(hwnd,&r);
				InvalidateRect(hwnd,&r,true);
				//RedrawWindow(hwndLV,0,0,RDW_INVALIDATE|RDW_UPDATENOW|RDW_ERASE);
				//return false;
				break;
			case HDN_ENDTRACK:
				NMHEADER *phdr;
				//phdr = (NMHEADER*) lParam;
				//HDITEM hi;
				//hi.mask=HDI_WIDTH;
				//SendMessage(lv->hwndCV,HDM_GETITEM,phdr->iItem,(LPARAM)&hi);
				//ListView_SetColumnWidth(lv->hwndLV,phdr->iItem,hi.cxy);
				LONG st;
				st=GetWindowLong(hwndLV,GWL_STYLE);
				st-=WS_VISIBLE;
				SetWindowLong(hwndLV,GWL_STYLE,st);
				ListView_SetColumnWidth(lv->hwndLV,0,lv->xMax);
				st|=WS_VISIBLE;
				SetWindowLong(hwndLV,GWL_STYLE,st);
				
				break;
			case HDN_ITEMCLICK:
				SendMessage(GetParent(hwnd),message,wParam,lParam);
				break;

			case HDN_ITEMDBLCLICK:
				phdr = (NMHEADER*) lParam; 
				//Header_DeleteItem(lv->hwndCV,phdr->iItem);
				//SendMessage(lv->hwndCV,HDM_DELETEITEM,,0);
				break;
			}
		if (((LPNMHDR) lParam)->hwndFrom==lv->hwndLV)
				SendMessage(GetParent(lv->hwnd),message,wParam,lParam);
		break;

	case WM_DRAWITEM:
		lv->LVFunc
		/*SendMessage*/(GetParent(lv->hwnd),message,wParam,lParam);
		break;

	default:
		return DefWindowProc(hwnd, message, wParam, lParam);
	}
	return 0;
}

void mylv::GetBK(HDC dc)
{
	HKEY hkey=HKEY_CURRENT_USER;
	char subkey[]="Control Panel\\Desktop";
	char str[1024];
	str[0]='\0';
	DWORD r;

	HBITMAP tmpbm=NULL;

	if (usewall)
	{
		r=RegOpenKeyEx(hkey,subkey,0,KEY_ALL_ACCESS,&regkey);
		if (r==ERROR_SUCCESS)
		{
			GetReg("Wallpaper",str);
			RegCloseKey(regkey);
		}
	}

	if (loadbkbmp) strcpy(str,bkfn);
	
	if (strlen(str))
		tmpbm=LoadImage(NULL,str,IMAGE_BITMAP,0,0,LR_DEFAULTCOLOR|LR_LOADFROMFILE);

	HDC tdc=CreateCompatibleDC(dc);

	BITMAP bmi;

	if (tmpbm==NULL)
	{
		tmpbm=CreateCompatibleBitmap(dc,4,4);
		GetObject(tmpbm,sizeof(BITMAP),&bmi);
		tmpbm=SelectObject(tdc,tmpbm);
		HBRUSH hbr=CreateSolidBrush(bkclr);
		hbr=SelectObject(tdc,hbr);
		PatBlt(tdc,0,0,4,4,PATCOPY);
		hbr=SelectObject(tdc,hbr);
		DeleteObject(hbr);
	}else{
		GetObject(tmpbm,sizeof(BITMAP),&bmi);
		tmpbm=SelectObject(tdc,tmpbm);
	}

	int cx,cy;
	cx=GetSystemMetrics(SM_CXSCREEN);
	cy=GetSystemMetrics(SM_CYSCREEN);

	hb=CreateCompatibleBitmap(dc,cx,cy);
	hb=SelectObject(memdc,hb);

	StretchBlt(memdc,0,0,cx,cy,
				tdc,0,0,bmi.bmWidth,bmi.bmHeight,SRCCOPY);


	tmpbm=SelectObject(tdc,tmpbm);
	DeleteObject(tmpbm);
	DeleteDC(tdc);
}

void mylv::DrawColumn(DRAWITEMSTRUCT *lpdis)
{
	COLORREF fg;
	if ((lpdis->itemState&ODS_SELECTED)==ODS_SELECTED)
		fg=hdclr2;
	else
		fg=hdclr;
	char *st;
	st=txt[lpdis->itemID];
	int w;
	w=lpdis->rcItem.bottom-lpdis->rcItem.top-1;
	ColTmp(lpdis->rcItem,w);
	SetBkMode(tmpdc,TRANSPARENT);
	SetTextColor(tmpdc,fg);
	TextOut(tmpdc,
		2,
		(w-tm.tmHeight)/2-2,
		st,
		strlen(st));
	BitBlt(lpdis->hDC,lpdis->rcItem.left+2,lpdis->rcItem.top+1,
		lpdis->rcItem.right-lpdis->rcItem.left-2,
		w,
		tmpdc,0,0,SRCCOPY);
}

void mylv::InitDrawList(DRAWITEMSTRUCT *lpdis)
{
	dlv_x=0;
	if ((lpdis->itemState&ODS_SELECTED)==ODS_SELECTED)
		SetTextColor(tmpdc,fgclr2);
	else
		SetTextColor(tmpdc,fgclr);
	dlv_w=lpdis->rcItem.bottom-lpdis->rcItem.top;
}

void mylv::MakeBK(DRAWITEMSTRUCT *lpdis,int i)
{
	HDITEM hi;
	hi.mask=HDI_WIDTH;
	SendMessage(hwndCV,HDM_GETITEM,colorder[i],(LPARAM)&hi);
	dlv_cxy=hi.cxy;
	LVTmp(lpdis,dlv_w,hi.cxy,dlv_x);
}

void mylv::DrawList(DRAWITEMSTRUCT *lpdis,int i,int winx)
{
	int dx=dlv_x+cvx,dy=lpdis->rcItem.top,dw=dlv_cxy,dh=dlv_w,sx=0,sy=0;
	if (dx<0)
	{
		sx-=dx;
		dw+=dx;
		dx=0;
	}
	if ((dx+dw)>winx)
		dw-=(dx+dw-winx);
	if (dw>0)
		BitBlt(lpdis->hDC,dx,dy,dw,dh,tmpdc,sx,sy,SRCCOPY);
	dlv_x+=dlv_cxy;
	if ((i+1)==ccols)
		xMax=dlv_x;
}

int mylv::LVFunc(HWND hwndp, UINT message,
                            WPARAM wParam, LPARAM lParam)
{
	LPDRAWITEMSTRUCT lpdis;
	RECT rc;
	switch (message)
	{
	case WM_SIZE:
        GetClientRect(hwndp, &rc);
		SetWindowPos(hwnd,0,rc.left+pos.left,rc.top+pos.top,
			fixedw ? pos.right : rc.right+pos.right,
			fixedh ? pos.bottom : rc.bottom+pos.bottom,SWP_SHOWWINDOW|SWP_NOZORDER);
		break;

	case WM_MOVE:
		if (dynbg)
		{
			GetClientRect(hwnd, &rc);
			InvalidateRect(hwnd,&rc,true);
		}
		break;

	case WM_NOTIFY:
		if (((LPNMHDR) lParam)->hwndFrom==hwndCV)
			switch (((LPNMHDR) lParam)->code)
			{
			case HDN_ITEMCLICK:
				SendMessage(hwndp,WM_USER+11+msg,((NMHEADER*)lParam)->iItem,0);
				return 1;
			}
		break;

	case WM_DRAWITEM:
		lpdis = (DRAWITEMSTRUCT *) lParam;
		switch (lpdis->CtlType)
		{
		case ODT_HEADER:
			if (lpdis->hwndItem==hwndCV)
			{
				DrawColumn(lpdis);
				return 1;
			}
			break;
		case ODT_LISTVIEW:
			if (lpdis->itemID == -1)
				break;
			if (lpdis->hwndItem==hwndLV)
			{
				InitDrawList(lpdis);
				RECT r;
				GetClientRect(hwnd,&r);
				for (int i=0;i<ccols;i++)
				{
					MakeBK(lpdis,i);
					SendMessage(hwndp,WM_USER+10+msg,(WPARAM)lpdis,(LPARAM)i);
					DrawList(lpdis,i,r.right);
				}
				return 1;
			}
			break;
		}
		break;
	}
	return 0;
}
