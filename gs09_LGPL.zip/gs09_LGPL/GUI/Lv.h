#include <windows.h>

LRESULT CALLBACK MyLVFunc(HWND, UINT, WPARAM, LPARAM);

class mylv
{
public:
	HWND hwnd,hwndLV,hwndCV,hwndHS,hwndVS;
	int cols,yPos,xPos,cvx,xMax,height,HSWidth,VSWidth,dlv_x,dlv_w,dlv_cxy,scrnx,scrny;
	static int insts;
	static WNDCLASSEX wcx;
	bool ShowHS,ShowVS,usewall,loadbkbmp,fixedh,fixedw;
	static bool dynbg;
	char **txt,bkfn[1024];
	static COLORREF bkclr,fgclr,fgclr2,hdclr,hdclr2,glassclr;
	RECT pos;

	static HDC memdc,tmpdc,txtdc;
	HBITMAP hb,hb2,hb3;
	HFONT fnt;
	static TEXTMETRIC tm;
	HIMAGELIST il;
	int colorder[10],ccols,msg;

	void CreateLV(char *h1,int *h2,int c);
	void InitCols2(char *h1,int *h2,int c);
	void InitCols(char *h1,int *h2,int c);
	void GetBK(HDC dc);
	void DrawColumn(DRAWITEMSTRUCT *);
	void InitDrawList(DRAWITEMSTRUCT *lpdis);
	void MakeBK(DRAWITEMSTRUCT *lpdis,int i);
	void DrawList(DRAWITEMSTRUCT *lpdis,int i,int winx);
	int LVFunc(HWND hwnd, UINT message,WPARAM wParam, LPARAM lParam);

	mylv()
	{
		if (!insts)
		{
			bkfn[0]='\0';
			usewall=false;
			loadbkbmp=false;
			bkclr=RGB(0,0,125);
			hdclr=RGB(55,255,55);
			hdclr2=RGB(255,55,55);
			fgclr=RGB(255,255,255);
			fgclr2=RGB(0,255,255);
			glassclr=RGB(127,127,255);
		}
		memset(&pos,0,sizeof(pos));
		fixedw=false;
		fixedh=false;
		msg=0;
	}

	void Init(HWND hwndParent, char *h1,int *h2,int c)
	{
		yPos=0;
		xPos=0;
		cvx=0;
		xMax=0;
		height=0;
		cols=c;
		ShowHS=false;
		ShowVS=false;
		HSWidth=20;
		VSWidth=20;
		scrnx=GetSystemMetrics(SM_CXSCREEN);
		scrny=GetSystemMetrics(SM_CYSCREEN);
		//dynbg=true;

		if (!insts)
		{
			HDC dc=GetDC(hwndParent);
			memdc=CreateCompatibleDC(dc);

			GetBK(dc);

			fnt=CreateFont(14,0,0,0,0/*FW_BOLD*/,0,0,0,ANSI_CHARSET,
				OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,
				DEFAULT_QUALITY,DEFAULT_PITCH|FF_DONTCARE,
				"Tahoma");

			tmpdc=CreateCompatibleDC(dc);
			hb2=CreateCompatibleBitmap(dc,scrnx,18/*height*/);
			hb2=SelectObject(tmpdc,hb2);

			txtdc=CreateCompatibleDC(dc);
			hb3=CreateCompatibleBitmap(dc,scrnx,18/*height*/);
			hb3=SelectObject(txtdc,hb3);

			ReleaseDC(hwndParent,dc);

			fnt=SelectObject(txtdc,fnt);
			GetTextMetrics(txtdc, &tm);

			wcx.cbSize = sizeof(WNDCLASSEX);
			wcx.style = CS_BYTEALIGNCLIENT|CS_BYTEALIGNWINDOW;
			wcx.lpfnWndProc = (WNDPROC)MyLVFunc;
			wcx.cbClsExtra = 0;
			wcx.cbWndExtra = 0;
			wcx.hInstance = hinst;
			wcx.hIcon = LoadIcon(hlang, "AAAA");
			wcx.hCursor = LoadCursor(NULL, IDC_ARROW);
			wcx.hbrBackground = NULL;
			wcx.lpszMenuName =  NULL;
			wcx.lpszClassName = "GSMYLV";
			wcx.hIconSm = NULL;
			RegisterClassEx(&wcx);
		}

		insts++;

		struct htxts
		{ 
			char s[10][50];
		}*htxt;
		htxt=(htxts*) h1;
		txt=new char*[c];
		for (int i=0;i<c;i++)
			txt[i]=DupString(htxt->s[i]);

		hwnd=CreateWindowEx(0,"GSMYLV",0,WS_CHILD|WS_VISIBLE,
						0,0,0,0,hwndParent,0,0,(void*)this);

		CreateLV(h1,h2,c);
		InitCols2(h1,h2,c);
		hwndHS = CreateWindowEx( 
			0L,                          // no extended styles 
			"SCROLLBAR",                 // scroll bar control class 
			(LPSTR) NULL,                // text for window title bar 
			WS_CHILD | SBS_HORZ,         // scroll bar styles 
			0,                           // horizontal position 
			0,                           // vertical position 
			200,                         // width of the scroll bar 
			CW_USEDEFAULT,               // default height 
			hwnd,                   // handle to main window 
			(HMENU) NULL,           // no menu for a scroll bar 
			hinst,                  // instance owning this window 
			(LPVOID) NULL           // pointer not needed 
		);
		hwndVS = CreateWindowEx( 
			0L,                          // no extended styles 
			"SCROLLBAR",                 // scroll bar control class 
			(LPSTR) NULL,                // text for window title bar 
			WS_CHILD | SBS_VERT,         // scroll bar styles 
			0,                           // horizontal position 
			0,                           // vertical position 
			0,                         // width of the scroll bar 
			CW_USEDEFAULT,               // default height 
			hwnd,                   // handle to main window 
			(HMENU) NULL,           // no menu for a scroll bar 
			hinst,                  // instance owning this window 
			(LPVOID) NULL           // pointer not needed 
		);
	}
	void kill()
	{
		//txt=new char*[c];
		for (int i=0;i<cols;i++)
			free(txt[i]);
		delete []txt;
		insts--;
		if (!insts)
		{
			UnregisterClass("GSMYLV",NULL);

			hb=SelectObject(memdc,hb);
			hb2=SelectObject(tmpdc,hb2);
			hb3=SelectObject(txtdc,hb3);

			fnt=SelectObject(txtdc,fnt);

			DeleteObject(hb);
			DeleteObject(hb2);
			DeleteObject(hb3);
			DeleteObject(fnt);

			DeleteDC(tmpdc);
			DeleteDC(txtdc);
			DeleteDC(memdc);
		}
	}

	bool BitDyn(HDC sdc,int sx,int sy,int sw,int sh,HDC ddc,int dx,int dy,DWORD how)
	{
		if (dx<0)
		{
			sx-=dx;
			sw+=dx;
			dx=0;
		}
		if ((dx+sw)>scrnx)
			sw-=(dx+sw-scrnx);
		if (dy<0)
		{
			sy-=dy;
			sh+=dy;
			dy=0;
		}
		if ((dy+sh)>scrny)
			sh-=(dy+sh-scrny);
		if ((sw<=0) || (sh<=0))
			return false;
		BitBlt(sdc,sx,sy,sw,sh,ddc,dx,dy,how);
		return true;
	}

	void ColTmp(RECT rcItem,int w)
	{
		if (dynbg)
		{
			RECT rc2;
			GetWindowRect(hwndCV,&rc2);
			BitDyn(tmpdc,0,0,rcItem.right-rcItem.left+1,
				w,memdc,rc2.left+rcItem.left+4,rc2.top+rcItem.top,SRCCOPY);
		}
		else
			BitBlt(tmpdc,0,0,rcItem.right-rcItem.left+1,
				w,memdc,0,0,SRCCOPY);
	}

	void LVTmp(DRAWITEMSTRUCT *lpdis,int w,int cxy,int x)
	{
		if (dynbg)
		{
			RECT rc2;
			GetWindowRect(hwndLV,&rc2);
			BitDyn(tmpdc,0,0,cxy,w,memdc,x+cvx+rc2.left,rc2.top+lpdis->rcItem.top,SRCCOPY);
		}
		else
			BitBlt(tmpdc,0,0,cxy,w,memdc,x+cvx,lpdis->rcItem.top,SRCCOPY);
		SetBkMode(tmpdc,TRANSPARENT);

		if ((lpdis->itemState&ODS_SELECTED)==ODS_SELECTED)
		{
			HBRUSH hbr;
			hbr=CreateSolidBrush(glassclr);
			//hbr=SelectObject(tmpdc,hbr);
			HDC dc=CreateCompatibleDC(tmpdc);
			HBITMAP bm=CreateCompatibleBitmap(tmpdc,cxy,w);
			bm=SelectObject(dc,bm);
			hbr=SelectObject(dc,hbr);
			PatBlt(dc,0,0,cxy,w,PATCOPY);
			BitBlt(tmpdc,0,0,cxy,w,dc,0,0,SRCPAINT);
			hbr=SelectObject(dc,hbr);
			bm=SelectObject(dc,bm);
			DeleteObject(hbr);
			DeleteObject(bm);
			DeleteDC(dc);
			//SetBkColor(tmpdc,bk);
		}
/*		else
		{

		}*/
	}

	void PutTXT(int x,char *str)
	{
		//HBRUSH hbr=CreateSolidBrush(RGB(255,255,255));
		RECT rc;
		rc.left=0;
		rc.top=0;
		rc.right=1023;
		rc.bottom=17;
		//FillRect(txtdc,&rc,hbr);
		//SetTextColor(tmpdc,RGB(0,0,0));
		SetBkMode(tmpdc,TRANSPARENT);
		TextOut(tmpdc,x,(dlv_w-tm.tmHeight)/2,str,strlen(str));
		//BitBlt(tmpdc,0,0,1024,18,txtdc,0,0,SRCINVERT);
		//FillRect(txtdc,&rc,hbr);
		//BitBlt(tmpdc,0,0,1024,18,txtdc,0,0,SRCCOPY);
		//DeleteObject(hbr);
	}
};
