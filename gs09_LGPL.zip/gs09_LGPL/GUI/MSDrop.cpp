// MS's OLE drop target class::
// (CDropTarget)

//*-------------------------------------------------------------------------
//| Title:
//|    drgdrpt.cpp
//|
//| Purpose:
//|      Demonstrates implementing an OLE drag-drop target. This drag-drop target
//|      accepts data of format CF_TEXT dragged from drag-drop sources.  
//|
//| Written by Microsoft Product Support Services, Windows Developer Support
//| (c) Copyright Microsoft Corp. 1994 All Rights Reserved                                                    
//|
//*-------------------------------------------------------------------------

#ifndef _WINSOCKAPI_
#define _WINSOCKAPI_   /* Prevent inclusion of winsock.h in windows.h */ 
#endif 
#include <ole2.h>
#include "MSDrop.h"

#include "mosheBox.h"

MSDrop::MSDrop(MyDropBox*box)
{
	_box=box;
   m_refs = 1; 
   m_bAcceptFmt = FALSE;
}   

MSDrop::~MSDrop(){
	RevokeDragDrop(_box->hwnd);
}

void MSDrop::regme(){
	RegisterDragDrop(_box->hwnd,this);
}

//---------------------------------------------------------------------
//                    IUnknown Methods
//---------------------------------------------------------------------


STDMETHODIMP
MSDrop::QueryInterface(REFIID iid, void FAR* FAR* ppv) 
{
    if(iid == IID_IUnknown || iid == IID_IDropTarget)
    {
      *ppv = this;
      AddRef();
      return NOERROR;
    }
    *ppv = NULL;
    return ResultFromScode(E_NOINTERFACE);
}


STDMETHODIMP_(ULONG)
MSDrop::AddRef(void)
{
    return ++m_refs;
}


STDMETHODIMP_(ULONG)
MSDrop::Release(void)
{
    if(--m_refs == 0)
    {
      delete this;
      return 0;
    }
    return m_refs;
}  

//---------------------------------------------------------------------
//                    IDropTarget Methods
//---------------------------------------------------------------------  

STDMETHODIMP
MSDrop::DragEnter(LPDATAOBJECT pDataObj, DWORD grfKeyState, POINTL pt, LPDWORD pdwEffect)
{  
    FORMATETC fmtetc;
       
    fmtetc.cfFormat = CF_TEXT;
    fmtetc.ptd      = NULL;
    fmtetc.dwAspect = DVASPECT_CONTENT;  
    fmtetc.lindex   = -1;
    fmtetc.tymed    = TYMED_HGLOBAL; 
    
    // Does the drag source provide CF_TEXT, which is the only format we accept.    
    m_bAcceptFmt = (NOERROR == pDataObj->QueryGetData(&fmtetc)) ? TRUE : FALSE;
    
    QueryDrop(grfKeyState, pdwEffect);
    return NOERROR;
}

STDMETHODIMP
MSDrop::DragOver(DWORD grfKeyState, POINTL pt, LPDWORD pdwEffect)
{
    QueryDrop(grfKeyState, pdwEffect);
    return NOERROR;
}

STDMETHODIMP 
MSDrop::DragLeave()
{   
    m_bAcceptFmt = FALSE;   
    return NOERROR;
}

STDMETHODIMP
MSDrop::Drop(LPDATAOBJECT pDataObj, DWORD grfKeyState, POINTL pt, LPDWORD pdwEffect)  
{   
    FORMATETC fmtetc;   
    STGMEDIUM medium;   
    HGLOBAL hText;
    LPSTR pszText;
    HRESULT hr;
     
    if (QueryDrop(grfKeyState, pdwEffect))
    {      
        fmtetc.cfFormat = CF_TEXT;
        fmtetc.ptd = NULL;
        fmtetc.dwAspect = DVASPECT_CONTENT;  
        fmtetc.lindex = -1;
        fmtetc.tymed = TYMED_HGLOBAL;       
        
        // User has dropped on us. Get the CF_TEXT data from drag source
        hr = pDataObj->GetData(&fmtetc, &medium);
        if (FAILED(hr))
            goto error; 
        
        // Display the data and release it.
        hText = medium.hGlobal;
        pszText = (char*)GlobalLock(hText);
		// WM_G_HWND+GOT_URL == WM_USER +3010
		//PostMessage(Hgui,WM_USER + 3010,(WPARAM) t,(LPARAM) 0);
		_box->regDropDPC(pszText);
        GlobalUnlock(hText);
        ReleaseStgMedium(&medium);
    }
    return NOERROR;      
    
error:
    *pdwEffect = DROPEFFECT_NONE;
    return hr; 
}   

/* OleStdGetDropEffect
** -------------------
**
** Convert a keyboard state into a DROPEFFECT.
**
** returns the DROPEFFECT value derived from the key state.
**    the following is the standard interpretation:
**          no modifier -- Default Drop     (0 is returned)
**          CTRL        -- DROPEFFECT_COPY
**          SHIFT       -- DROPEFFECT_MOVE
**          CTRL-SHIFT  -- DROPEFFECT_LINK
**
**    Default Drop: this depends on the type of the target application.
**    this is re-interpretable by each target application. a typical
**    interpretation is if the drag is local to the same document
**    (which is source of the drag) then a MOVE operation is
**    performed. if the drag is not local, then a COPY operation is
**    performed.
*/
#define OleStdGetDropEffect(grfKeyState)    \
    ( (grfKeyState & MK_CONTROL) ?          \
        ( (grfKeyState & MK_SHIFT) ? DROPEFFECT_LINK : DROPEFFECT_COPY ) :  \
        ( (grfKeyState & MK_SHIFT) ? DROPEFFECT_MOVE : 0 ) )

//---------------------------------------------------------------------
// CDropTarget::QueryDrop: Given key state, determines the type of 
// acceptable drag and returns the a dwEffect. 
//---------------------------------------------------------------------   
STDMETHODIMP_(BOOL)
MSDrop::QueryDrop(DWORD grfKeyState, LPDWORD pdwEffect)
{  
    DWORD dwOKEffects = *pdwEffect; 
    
    if (!m_bAcceptFmt)
        goto dropeffect_none; 
     
/*    *pdwEffect = OleStdGetDropEffect(grfKeyState);
    if (*pdwEffect == 0) {
        // No modifier keys used by user while dragging. Try in order: MOVE, COPY.
        if (DROPEFFECT_MOVE & dwOKEffects)
            *pdwEffect = DROPEFFECT_MOVE;
        else if (DROPEFFECT_COPY & dwOKEffects)
            *pdwEffect = DROPEFFECT_COPY; 
        else goto dropeffect_none;   
    } 
    else {
        // Check if the drag source application allows the drop effect desired by user.
        // The drag source specifies this in DoDragDrop
        if (!(*pdwEffect & dwOKEffects))
            goto dropeffect_none; 
        // We don't accept links
        if (*pdwEffect == DROPEFFECT_LINK)
            goto dropeffect_none; 
    }  */
    return TRUE;

dropeffect_none:
    *pdwEffect = DROPEFFECT_NONE;
    return FALSE;
}
