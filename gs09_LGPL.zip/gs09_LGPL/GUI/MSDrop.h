
// MS's OLE drop target class::
// (CDropTarget)

#ifndef __MS_DROP_H_
#define __MS_DROP_H_

// forward decl::
class MyDropBox;

class MSDrop : public IDropTarget
{
public:    
    MSDrop(MyDropBox*box);

    /* IUnknown methods */
    STDMETHOD(QueryInterface)(REFIID riid, void FAR* FAR* ppvObj);
    STDMETHOD_(ULONG, AddRef)(void);
    STDMETHOD_(ULONG, Release)(void);

    /* IDropTarget methods */
    STDMETHOD(DragEnter)(LPDATAOBJECT pDataObj, DWORD grfKeyState, POINTL pt, LPDWORD pdwEffect);
    STDMETHOD(DragOver)(DWORD grfKeyState, POINTL pt, LPDWORD pdwEffect);
    STDMETHOD(DragLeave)();
    STDMETHOD(Drop)(LPDATAOBJECT pDataObj, DWORD grfKeyState, POINTL pt, LPDWORD pdwEffect); 
    
    /* Utility function to read type of drag from key state*/
    STDMETHOD_(BOOL, QueryDrop)(DWORD grfKeyState, LPDWORD pdwEffect);
 
	void regme();
	virtual ~MSDrop();
private:
    ULONG m_refs;  
    BOOL m_bAcceptFmt;
	
	MyDropBox *_box;
};

#endif // 3OF