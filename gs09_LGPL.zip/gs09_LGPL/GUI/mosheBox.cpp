//#define WIN32_LEAN_AND_MEAN
//#include <windows.h>
//#undef WIN32_LEAN_AND_MEAN
#include "mosheBox.h"

unsigned int MyDropBox::cnt=0;
WNDCLASS MyDropBox::wcl={0};

Skinload MosheBox::SkinNfo;
Skin MosheBox::skin;

void MyDropBox::init(){
	if (!cnt++)
		init1st();
}

void MyDropBox::init1st(){
	wcl.hInstance=hinst;
	wcl.lpszClassName="mosheDropBoxes";
	wcl.lpfnWndProc=wRegFunc;
	wcl.hCursor=LoadCursor(NULL,IDC_ARROW);    
	wcl.hbrBackground=GetStockObject(WHITE_BRUSH);
	if (!RegisterClass(&wcl)){
		assert(0);
		return;
	}
}

LRESULT CALLBACK MyDropBox::wRegFunc(HWND hwnd,UINT message,
											WPARAM wParam,LPARAM lParam){
	ThisClass *This;
	This=(ThisClass*) GetWindowLong(hwnd,GWL_USERDATA);
	switch (message){
	case WM_NCCREATE:
		This=(ThisClass*)(((LPCREATESTRUCT) lParam)->lpCreateParams);
		SetWindowLong(hwnd,GWL_USERDATA,(long)This);
	default:
		return
			This->wFunc(hwnd,message,wParam,lParam);

		// DPC:
	case WM::DPC_onDroppedLink:
		This->onDroppedLink((char*)wParam);
		This->ThisClass::onDroppedLink((char*)wParam);
		return 0;
	}
}

void MosheBox::init(){
	Super::init();
	hwnd=CreateWindow("mosheDropBoxes",
		"A moshe Dropbox",
		WS_POPUP | WS_VISIBLE,
		CW_USEDEFAULT,
		CW_USEDEFAULT,
		48,
		48,
		hwndg,
		NULL,
		hinst,
		this);

	dropInformer->regme();
}

void MosheBox::onDroppedLink(char*link){
	int breakPoint=3;
}

#include "../skin/SkinDefs.h"

LRESULT MosheBox::wFunc(HWND hwnd,UINT message,
						WPARAM wParam,LPARAM lParam){
	LRESULT ret;
    ret=skin.fn(hwnd,message,wParam,lParam);
	switch (message){
	case WM_CREATE:
		break;

	case WM_NCHITTEST:
		return
			HTCAPTION;

	default:
        return (ret==-1) ?
            DefWindowProc(hwnd,message,wParam,lParam) : 0;
	}
	return 0;
}

void MosheBox::init1st(){
	Super::init1st();
	InitSkin();
	skin.Init(SkinNfo,NULL);
								/*  ^^ a win32 handle if resources 
								 *  are to be loaded 
								 */
}

int MosheBox::InitSkin(){
    SkinNfo.name=_strdup("DefaultMosheBox");
	SkinNfo.basedir=_strdup("c:/oyd11/GSart/");
	SkinNfo.type=0;

    SkinNfo.numrg=1;
    SkinNfo.rg=new RGloadSt[SkinNfo.numrg];
// rg <n> <bm filen> <xoff> <yoff> <init state: by _S_RG* macros>
	rgSet(SkinNfo.rg[0],"mosheBox1.bmp",0,0,_S_RGSHOW|_S_RGIN|_S_RGOUT,1,1);

    SkinNfo.numstbt=2;
	SkinNfo.stbt=new STBTloadSt[SkinNfo.numstbt];

	//#define STButtSet(bt,_n,_x,_y,_m,_rc,_sh)
// STButtSet( <butt>, <n-states>, <x>, <y>, <menu>(ingnored) , <rc?> , <shapescan?>
	STButtSet(SkinNfo.stbt[0],2,20,4,0,0,0);
// bt <n> <bm filename> <x> <y> <xoff> <yoff> <over policy> <pushed policy> <over bm> <pushed bm>
	SubST_st(SkinNfo.stbt[0],0,"mosheBox_Lup.bmp",1,1,"","",-1,0,0);
	SubST_st(SkinNfo.stbt[0],0,"mosheBox_Ldown.bmp",1,1,"","",-1,0,0);
	STButtSet(SkinNfo.stbt[1],1,40,4,0,1,0);
	SubST_st(SkinNfo.stbt[1],0,"mosheBox_LED_on.bmp",1,1,"","",-1,0,0);
	SubST_st(SkinNfo.stbt[1],0,"mosheBox_LED_off.bmp",1,1,"","",-1,0,0);

    SkinNfo.numpr=0;

    SkinNfo.numtr=0;

	SkinNfo.numtxt=0;

    return true;
}
