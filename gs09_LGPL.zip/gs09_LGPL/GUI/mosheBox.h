// moshe's drop box thingy..
#ifndef _MOSHE_BOX_H_
#define _MOSHE_BOX_H_

#include <assert.h>
#include "../Daemon/Daemon.h"

#include "../skin/SkinDefs.h"

//
extern HINSTANCE hinst; // global exec instance

#define NBOXES 0x100;

#include "MSDrop.h"

class MyDropBox{
private:
typedef MyDropBox ThisClass;
public:
	MyDropBox(){
		strcpy(_dlDir,exthead->dir);
		dropInformer=new MSDrop(this);
	}

	virtual ~MyDropBox(){
		dropInformer->Release();  
	}
	virtual void init();

	virtual void onDroppedLink(char*link){
		delete [] link;
	}

	inline void regDropDPC(char*dropText){
		PostMessage(hwnd,WM::DPC_onDroppedLink,
			(WPARAM)strcpy(new char[strlen(dropText)+1],dropText),0);
	}


private:
static LRESULT CALLBACK wRegFunc(HWND hwnd,UINT message,
								 WPARAM wParam,LPARAM lParam);
static unsigned int cnt;
static WNDCLASS wcl;

protected:
	void cfgDir();
	void init1st();
	virtual LRESULT wFunc(HWND hwnd,UINT message,
								 WPARAM wParam,LPARAM lParam)=0;

	char _dlDir[MAX_PATH];
	MSDrop *dropInformer;
	enum WM {DPC_onDroppedLink=WM_USER+0};
public:
	HWND hwnd;
}; // class MyDropBox;

class MosheBox:public MyDropBox{
private:
typedef MyDropBox Super;
typedef MosheBox ThisClass;
public:
	MosheBox(){
		memset(&skinWin,0,sizeof(skinWin));
	}
	virtual void init();
private:
	virtual void init1st();
	virtual void onDroppedLink(char*link);
	virtual LRESULT wFunc(HWND hwnd,UINT message,
		WPARAM wParam,LPARAM lParam);

	int InitSkin();

static Skinload SkinNfo;
static Skin skin;
	SkinWinNfo skinWin;
}; // class MosheBox;

#endif // 3OF