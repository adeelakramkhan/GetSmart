
#include "./Daemon/Daemon.h"
#ifdef DupString
#undef DupString
#endif
char *DupString(char *lpsz
#ifdef _DEBUG
               , const char *srcFile, int srcLine
#endif				
)
{     
  int cb = strlen(lpsz) + 1; 
#ifdef _DEBUG
  char *lpszNew = (char *) _malloc_dbg(cb, _NORMAL_BLOCK, 
        srcFile, srcLine);
#else
  char *lpszNew = (char *) malloc(cb);
#endif
  if (lpszNew != NULL) 
    memcpy(lpszNew, lpsz, cb);
  return lpszNew;
}

char *ReDupString(char *s,char *lpsz)
{
  int cb = strlen(lpsz)+1;
  s=(char *) realloc(s,cb);
  if (s!=NULL && lpsz!=NULL)
    strcpy(s, lpsz);
  return s;
}

char *GlobStr(char*in)
{
  StringLST *ret=new StringLST(in);
  return ret->str;
}

char *GetSTR(int n,char*s)
{
	char *str;
  if (!cfg.lang) return s;
  str=GetLangSTR(n);
  if (strlen(str)) return str;
  else return s;
}

char *GetLangSTR(int n)
{
  char st[1024];
#ifdef _WIN32
  LoadString(hlang,n,st,1024);
#endif
  //return GlobStr(st);
  return st;
}

void dds()
{
  StringLST*tmp=Dstrhead;
  while (Dstrhead){
    tmp=Dstrhead;
    Dstrhead=Dstrhead->next;
    delete tmp;
  }
  //	Dstrhead=NULL;
}

char *GlobStr2(char*in)
{
  StringLST2 *ret=new StringLST2(in);
  return ret->str;
}

char *GetLangSTR2(int n)
{
  char st[1024];
#ifdef _WIN32
  LoadString(hlang,n,st,1024);
#endif
  //return GlobStr2(st);
  return st;
}

char *GetSTR2(int n,char*s)
{
  char *str;
  if (!cfg.lang) return s;
  str=GetLangSTR2(n);
  if (strlen(str)) return str;
  else return s;
}


void dds2()
{
  StringLST2*tmp=Dstrhead2;
  while (Dstrhead2){
    tmp=Dstrhead2;
    Dstrhead2=Dstrhead2->next;
    delete tmp;
  }
  //	Dstrhead=NULL;
}

void GetLine(char*buff,char*str)
{
  int i=0;
  while ((buff[i]!='\n')&&(buff[i]))
    i++;
  if (!buff[i])
    {
      str[0]='\0';
      return;
    }
  i++;
  memcpy(str,buff,i);
  if ((*str!=13) &&(*str!=10))
    {
      if (str[i-2]=='\r')
	str[i-2]='\0';
      else
	str[i-1]='\0';
    }
  else (str[i]='\0');
  memmove(buff,buff+i,strlen(buff)-i);
  buff[strlen(buff)-i]='\0';
}

void ConstURL(dlnfo *d,char *str)
{
  char pr[10];
  if (d->prot==1) strcpy(pr,"ftp://");
  else strcpy(pr,"http://");
  if (strcmp(d->user,"anonymous") || (strcmp(d->pass,cfg.Email)))
    sprintf(str,"%s%s:%s@%s:%ld%s%s",pr,
	    d->user,d->pass,d->host,d->port,
	    d->rdir,d->rfn);
  else
    sprintf(str,"%s%s:%ld%s%s",pr,d->host,
	    d->port,d->rdir,d->rfn);
}

short GetProxy(short prot,short type)
{
  if (cfg.Proxy.socks)
    {
      return 3;
    }
  else
    if (cfg.Proxy.UseHTTP && ((prot==2) || 
			      cfg.Proxy.HTTP4FTP && (type!=2)))
      {
	return 2;
      }
    else
      if ((prot==1) && cfg.Proxy.UseFTP)
	{
	  return 1;
	}
      else
	if (!cfg.Proxy.OnlyProxy)
	  {
	    return 0;
	  }
	else
	  {
	    char str[1000];
	    if (type==2)
	      strcpy(str,GetSTR(22,"Your proxy configuration does not allow browsing FTP, change\
your settings."));
	    else						
	      strcpy(str,GetSTR(23,"Your proxy configuration does not support this protocol, change\
your settings."));
	    MsgBox(str,GetSTR(24,"Can't start download!"),MB_OK);
		dds();
	    return -1;
	  }
}

long MsgBox(char*txt,char*title,unsigned int how)
{
#ifdef _WIN32
	char *str;
	long l;
	str=_strdup(txt);//strcpy(str,txt);
	l=MessageBox(NULL,str,title,how|cfg.r2l);
	free(str);
	return l;
#endif
#ifdef __unix__
printf("%s\n",txt);
#endif
}

void FilterFN(char *fn)
{
  char *tmp;
  while (strchr(fn,'?') || strchr(fn,':') || strchr(fn,'|') || strchr(fn,'*'))
    {
      tmp=strchr(fn,'?');
      if (!tmp) tmp=strchr(fn,':');
      if (!tmp) tmp=strchr(fn,'|');
      if (!tmp) tmp=strchr(fn,'*');
      if (tmp) *tmp='_';
    }
}

dlnfo* ConvertURL(char *str0)
{
	char str2[5000],str[5024];
	char user[5000],pass[5000],addr[5000],sdir[5000],sfn[5000];
	unsigned short port;
	char prot;
	strcpy(str,str0);
	strcpy(user,"anonymous");
	strcpy(pass,cfg.Email);
	prot=1;
	port=21;
	memset(addr,0,5000);
	memset(sdir,0,5000);
	memset(sfn,0,5000);
	long ret=0,c=0;
	char *tmp,*tmp2,*tmp3,*tmp4;
	tmp=str;
	tmp2=NULL;
	/*tmp3=strchr(tmp,'/');
	while (tmp3)
	{
		if (*(tmp3+1)=='/') tmp2=tmp3;
		tmp3=strchr(tmp3+1,'/');
	}
	if (tmp2 && (tmp2-str>9))
	{
		strcpy(str2,tmp2-9);
		strcpy(str,str2);
	}
	tmp=strchr(str,'?');
	if (tmp) tmp[0]=0;*/
	tmp=strstr(str,"//");
	if (tmp) ret=tmp-str;
	if (!strnicmp(str,"HTTP:",5) || !strnicmp(str,"WWW.",4))
	{
		port=80;
		prot=2;
	}
	if (tmp)
	{
		tmp=tmp+2;
		c=ret+2;
	}
	else tmp=str;
	tmp2=tmp;
	tmp2=strchr(tmp,'@');
	tmp3=strchr(tmp,'/');
	memset(str2,0,sizeof(str2));
	if (tmp2 && (!tmp3 || (tmp3>tmp2)))
	{
		ret=tmp2-tmp;
		memcpy(str2,tmp,ret);
		tmp=tmp2+1;
		tmp2=str2;
		memset(user,0,sizeof(user));
		tmp2=strstr(str2,":");
		if (!tmp2)
			strcpy(user,str2);
		else
		{
			ret=tmp2-str2;
			memcpy(user,str2,ret);
			user[ret]=0;
			tmp2++;
			memset(pass,0,sizeof(pass));
			strcpy(pass,tmp2);
		}
	}
	memset(str2,0,sizeof(str2));
	tmp2=strstr(tmp,":");
	tmp3=strstr(tmp,"/");
	if (tmp2 && (!tmp3 || (tmp3>tmp2)))
	{
		tmp4=strstr(tmp,".");
		if ((tmp2>tmp4) || (tmp4>strchr(tmp,'/')))
		{
			if (tmp3)
				ret=tmp3-tmp2-1;
			else ret=strlen(tmp2)-1;
			memcpy(str2,tmp2+1,ret);
			for (;*tmp2;tmp2++)
				*tmp2=*(tmp2+ret+1);
		}
		else 
		{
			memcpy(str2,tmp,(tmp2-tmp));
			tmp=tmp2+1;
		}
		port=atoi(str2);
	}
	tmp2=strstr(tmp,"/");
	memset(addr,0,sizeof(addr));
	if (!tmp2)
		strcpy(addr,tmp);
	else
		memcpy(addr,tmp,tmp2-tmp);
	tmp3=strstr(addr," ");
	if (tmp3)
		*tmp3=0;
	tmp=tmp2;
	if (tmp)
		strcpy(sdir,tmp);
	if (strlen(sdir))
	{
		tmp = strrchr(sdir, '/' );
		tmp++;
		if (tmp) 
		{
			strcpy(sfn,tmp);
			memset(tmp,0,strlen(tmp)+1);
		}
		else memset(sfn,0,5000);
	}
	return new dlnfo(prot,addr,port,user,pass,sdir,sfn);
}

char Get64(unsigned char c)
{
	char t;
	if (c<26)
		return t='A'+c;
	if (c<52)
		return t='a'+c-26;
	if (c<62)
		return t='0'+c-52;
	if (c==62)
		return t='+';
	if (c==63)
		return t='/';
	return 0;
}

void Base64(char *s,char *d)
{
	memset(d,0,80);
	unsigned int i=0,i2=0,j,ii;
	unsigned char pl[4];
	//memset(pl,0,sizeof(pl));
	pl[3]='\0';
	long *res;
	res=(long*)pl;
	while (i<strlen(s))
	{
		for (j=0;j<3;j++)
		{
			if (i>=strlen(s))
				pl[2-j]=0;
			else pl[2-j]=s[i];
			i++;
		}
		ii=i2;
		for (j=0;j<4;j++)
		{
			d[3-j+ii]=Get64(*res%64);
			i2++;
			*res=*res>>6;
		}
		if ((i-2)==strlen(s))
			memcpy(&d[i2-2],"==",2);
		else
			if ((i-1)==strlen(s))
				memcpy(&d[i2-1],"=",1);
	}
}

void GetWord(char *t,int i,char *d, bool en)
{
	char *t2;
	for (int j=1;j<i;j++)
	{
		t=strchr(t,' ');
		if (!t) 
		{
			*d=0;
			return;
		}
		while ((*t==' ') && (*t!=0)) t++;
		if (!t)
		{
			*d=0;
			return;
		}
	}
	t2=strchr(t,' ');
	if (!t2 || en)
		strcpy(d,t);
	else
	{
		memset(d,0,t2-t+2);
		strncpy(d,t,t2-t);
	}
	t2=strchr(d,13);
	if (t2) *t2=0;
}
