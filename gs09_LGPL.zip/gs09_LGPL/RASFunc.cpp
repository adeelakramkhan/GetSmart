
#include "Daemon/Daemon.h"
#include "resrc1.h"

typedef struct cdial_tag
{
	int status,Long[10];
}CDIAL;

CDIAL Cdial;

VOID WINAPI RasDialFunc1(
						HRASCONN hrasconn,UINT unMsg,
						RASCONNSTATE rascs,DWORD dwError,
						DWORD dwExtendedError)
{
	static bool connect;
	char str[1000];
	RASCONNSTATUS rs;
	rs.dwSize=sizeof(rs);
	if (unMsg!=WM_RASDIALEVENT) return;
	if (dwError)
	{
		Hangup();
		Sleep(300);
		switch(dwError)
		{
		case 676:
			strcpy(str,GetSTR(258,"Detected busy signal."));
			Cdial.status=1;
			break;
		case 680:
			strcpy(str,GetSTR(259,"There is no dial tone."));
			Cdial.status=1;
			break;
		case 646:
			strcpy(str,GetSTR(260,"The account isn't permitted to logon this time of day."));
			Cdial.status=2;
			break;
		case 647:
			strcpy(str,GetSTR(261,"The account is disabled."));
			Cdial.status=2;
			break;
		case 650:
			strcpy(str,GetSTR(262,"The Remote Access server is not responding."));
			Cdial.status=2;
			break;
		case 677:
			strcpy(str,GetSTR(263,"A person answered instead of a modem."));
			break;
		case 679:
			strcpy(str,GetSTR(264,"Cannot detect carrier."));
			Cdial.status=2;
			break;
		case 691:
			strcpy(str,GetSTR(265,"Error authenticating. Name or Password are incorrect."));
			Cdial.status=2;
			break;
		case 638:
			strcpy(str,GetSTR(266,"Operation timed out."));
			if (connect) Cdial.status=2;
			else Cdial.status=1;
			break;
		default:
			if (connect)
			{
				strcpy(str,GetSTR(267,"Error connecting. No specific info."));
				Cdial.status=2;
			}
			else
			{
				strcpy(str,GetSTR(268,"Error dialing. No specific info."));
				Cdial.status=1;
			}
			break;
		}
		dds();
		SetDlgItemText(hwnddial,IDD_STATUS,str);
		return;
	}
	str[0]='\0';
	switch(rascs)
	{
	case RASCS_OpenPort:
		connect=false;
		strcpy(str,GetSTR(269,"Openning communication port."));
		break;
	case RASCS_ConnectDevice:
		strcpy(str,GetSTR(270,"Dialing..."));
		break;
	case RASCS_AllDevicesConnected:
		strcpy(str,GetSTR(17,"Connected."));
		break;
	case RASCS_Authenticate:
		strcpy(str,GetSTR(271,"Sending User name and password..."));
		break;
	case RASCS_Authenticated:
		strcpy(str,GetSTR(272,"User name and password accepted. logging in..."));
		break;
	case RASCS_Connected:
		strcpy(str,GetSTR(273,"Successfuly connected."));
		Cdial.status=9;
		break;
	}
	dds();
	if (strlen(str))
		SetDlgItemText(hwnddial,IDD_ACTION,str);
	return;
}
 
int DoDial(int sub)
{
	HRASCONN con=NULL;
	RASDIALPARAMS rdp;
	if (RasDialx)
	{
		memset(&rdp,0,sizeof(RASDIALPARAMS));
		rdp.dwSize=sizeof(RASDIALPARAMS);
		strcpy(rdp.szEntryName,cfg.Dial.Entry);
		strcpy(rdp.szPhoneNumber,cfg.Dial.Phone[sub]);
		if (!stricmp(rdp.szPhoneNumber,GetSTR(139,"Default")))
			strcpy(rdp.szPhoneNumber,"");
		if (strlen(rdp.szPhoneNumber))
		{
			char str[1024];
			if (cfg.Dial.pulse)
				sprintf(str,"P%s",rdp.szPhoneNumber);
			else sprintf(str,"T%s",rdp.szPhoneNumber);
			strcpy(rdp.szPhoneNumber,str);
		}
		dds();
		strcpy(rdp.szUserName,cfg.Dial.User);
		strcpy(rdp.szPassword,cfg.Dial.Pass);
		RasDialx(NULL,NULL,&rdp,1,(LPVOID) RasDialFunc1,&con);
	}
	return 1;
}

BOOL CALLBACK DialFunc(HWND hdwnd, UINT message,
							WPARAM wParam, LPARAM lParam)
{
	char str[1000];
	static int status=0,sub=0,Busy=0,Retry=0,Pause=0;
	static time_t lt;
	time_t ct;
	switch(message)
	{
	case WM_INITDIALOG:
		if (!cfg.Dial.Use || IsConnected())
		{
			EndDialog(hdwnd,1);
			return 1;
		}
		memset(&Cdial,0,sizeof(CDIAL));
		Retry=0;
		status=0;
		sub=-1;
		Pause=5;
		Busy=0;
		hwnddial=hdwnd;
		SetDlgItemText(hdwnd,IDD_TIMEOUT,itoa(cfg.Dial.TO,str,10));
		SetDlgItemText(hdwnd,IDD_ACTION,GetSTR(274,"Initiating dialing..."));
		dds();
		SetTimer(hdwnd,(UINT) hdwnd,1000,0);
		//SetForegroundWindow(hdwnd);
		time(&lt);
		return 1;
	
	case WM_TIMER:
		if (Cdial.status)
		{
			switch (Cdial.status)
			{
			case 1:
				Busy++;
				if (!cfg.Dial.Busy || (cfg.Dial.Busy>Busy))
				{
					if (cfg.Dial.Pause)
					{
						Pause=cfg.Dial.Pause;
						status=0;
						time(&lt);
					}
					else status=1;
				}
				else PostMessage(hdwnd,WM_COMMAND,IDCANCEL,0);
				break;
			case 2:
				Busy++;
				if (!cfg.Dial.Busy || (cfg.Dial.Busy>Busy))
				{
					if (cfg.Dial.LongPause)
					{
						if ((++Cdial.Long[sub]>cfg.Dial.MaxLong) &&
							(sub==cfg.Dial.Subi))
						{
							Pause=cfg.Dial.LongPause;
							status=0;
							time(&lt);
						}
					}
					if (status)
						if (cfg.Dial.Pause)
						{
							Pause=cfg.Dial.Pause;
							status=0;
							time(&lt);
						}
						else status=1;
				}
				else PostMessage(hdwnd,WM_COMMAND,IDCANCEL,0);
				break;
			case 9:
				KillTimer(hdwnd,(UINT) hdwnd);
				EndDialog(hdwnd,1);
				return 1;
				break;
			}
			Cdial.status=0;
		}
		switch (status)
		{
		case 0:
			time(&ct);
			if (ct-lt>=Pause)
			{
				status=1;
			}
			else
			{
				sprintf(str,GetSTR(275,"Dialing in %ld seconds..."),
					Pause-(ct-lt));
				dds();
				SetDlgItemText(hdwnd,IDD_ACTION,str);
			}
			return 1;
		case 1:
			if (++sub>cfg.Dial.Subi) sub=cfg.Dial.Subi;
			sprintf(str,GetSTR(276,"Dialing %s (%s)"),cfg.Dial.Entry,
				cfg.Dial.Phone[sub]);
			dds();
			SetWindowText(hdwnd,str);
			time(&lt);
			status=2;
			SetDlgItemInt(hdwnd,IDD_RETRY,Retry++,false);
			SetDlgItemText(hdwnd,IDD_TIMEOUT,itoa(cfg.Dial.TO,str,10));
			DoDial(sub);
			return 1;
		case 2:
			time(&ct);
			sprintf(str,"%ld",cfg.Dial.TO-(ct-lt));
			SetDlgItemText(hdwnd,IDD_TIMEOUT,str);
			if (cfg.Dial.TO-(ct-lt)<=0)
				RasDialFunc1(NULL,WM_RASDIALEVENT,
						(RASCONNSTATE) NULL,638,NULL);
			return 1;
		}
		return 1;

	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDCANCEL:
			Hangup();
			KillTimer(hdwnd,(UINT) hdwnd);
			maindl *next,*tmp;
			next=listhead;
			while (next)
			{
				tmp=next;
				next=next->next;
				if (tmp->wait || tmp->spliton)
					tmp->KillMain();
			}
			EndDialog(hdwnd,0);
			return 1;
		}
		return 0;
	}
	return 0;
}

bool IsConnected()
{
	if (!cfg.Dial.Use) return true;
	DWORD sb,nc=0;
	RASCONN rc[10];
	memset(&rc,0,sizeof(rc));
	RASCONNSTATUS rs;
	memset(&rs,0,sizeof(rs));
	rc[0].dwSize=sizeof(RASCONN);
	rs.dwSize=sizeof(rs);
	sb=sizeof(rc);
	if (hras != NULL)
	{ 
		if (RasEnumConnectionsx) RasEnumConnectionsx(rc,&sb,&nc);
		if (nc && RasGetConnectStatusx)
		{
			RasGetConnectStatusx(rc[0].hrasconn,&rs);
			if (rs.rasconnstate==RASCS_Connected)
				return true;
		}
	}
	else return true;
	return false;
}

void Hangup()
{
	for(int i=0;i<=lastact;i++)
		if (actdls[i]) actdls[i]->mdl->KillMain();
	cfg.Dial.reconnect=false;
	DWORD sb,nc=0;
	RASCONN rc[10];
	memset(&rc,0,sizeof(rc));
	RASCONNSTATUS rs;
	memset(&rs,0,sizeof(rs));
	rc[0].dwSize=sizeof(RASCONN);
	rs.dwSize=sizeof(rs);
	sb=sizeof(rc);
	if (!hras)
		LoadRas();
	if (hras != NULL)
	{ 
		if (RasEnumConnectionsx) RasEnumConnectionsx(rc,&sb,&nc);
		if (nc && RasGetConnectStatusx && RasHangUpx)
		{
			RasGetConnectStatusx(rc[0].hrasconn,&rs);
			if (RasHangUpx(rc[0].hrasconn)!=ERROR_INVALID_HANDLE)
				while ((RasGetConnectStatusx(rc[0].hrasconn,&rs)!=ERROR_INVALID_HANDLE)
					&& (rs.rasconnstate!=RASCS_Disconnected))
					Sleep(0);
		}
	}
}

void LoadRas()
{
	hras=LoadLibrary("RASAPI32.dll");
	if (hras != NULL)
	{ 
		RasEnumConnectionsx = (DWORD (STDAPICALLTYPE*)(HRASCONN rc, LPDWORD sb, LPDWORD nc))
			GetProcAddress(hras, "RasEnumConnectionsA");
		RasGetConnectStatusx = (DWORD (STDAPICALLTYPE*)(HRASCONN rc, LPRASCONNSTATUS rs))
			GetProcAddress(hras, "RasGetConnectStatusA");
		RasHangUpx= (DWORD (STDAPICALLTYPE*)(HRASCONN rc))
			GetProcAddress(hras, "RasHangUpA");
  		RasDialx= (DWORD (STDAPICALLTYPE*)(
			LPRASDIALEXTENSIONS lpRasDialExtensions,
			LPTSTR lpszPhonebook, 
			LPRASDIALPARAMS lpRasDialParams, 
			DWORD dwNotifierType, 
			LPVOID lpvNotifier, 
			LPHRASCONN lphRasConn))
			GetProcAddress(hras, "RasDialA");
  		RasEnumEntriesx= (DWORD (STDAPICALLTYPE*)(
			LPTSTR reserved,
			LPTSTR lpszPhonebook,
			LPRASENTRYNAME lprasentryname,
			LPDWORD lpcb,
			LPDWORD lpcEntries))
			GetProcAddress(hras,"RasEnumEntriesA");
		RasGetEntryPropertiesx= (DWORD (STDAPICALLTYPE*)(
			LPTSTR lpszPhonebook,
			LPTSTR lpszEntry,
			LPRASENTRY lpRasEntry,
			LPDWORD lpdwEntryInfoSize,
			LPBYTE lpbDeviceInfo,
			LPDWORD lpdwDeviceInfoSize))
			GetProcAddress(hras,"RasGetEntryPropertiesA");
		RasGetEntryDialParamsx=(DWORD (STDAPICALLTYPE*)(
			LPTSTR lpszPhonebook,
			LPRASDIALPARAMS lprasdialparams,
			LPBOOL lpfPassword))
			GetProcAddress(hras,"RasGetEntryDialParamsA");
	}
	else
	{
		MsgBox(GetSTR(257,"Can't find RASAPI32.DLL which is needed for dial up management!"),
			0,MB_OK);
		dds();
	}
}

void ShutDown()
{
	if (os.dwPlatformId==VER_PLATFORM_WIN32_NT)
	{
		HANDLE hdlProcessHandle;
		HANDLE hdlTokenHandle;
		LUID tmpLuid;
		TOKEN_PRIVILEGES tkp,tkpNewButIgnored;
		LUID_AND_ATTRIBUTES laa[1];
		DWORD lBufferNeeded;
		hdlProcessHandle=GetCurrentProcess();
		OpenProcessToken(hdlProcessHandle,
			TOKEN_ADJUST_PRIVILEGES|TOKEN_QUERY,&hdlTokenHandle);
		LookupPrivilegeValue("", "SeShutdownPrivilege",&tmpLuid);
		tkp.PrivilegeCount = 1;
		laa[0].Attributes= SE_PRIVILEGE_ENABLED;
		laa[0].Luid=tmpLuid;
		tkp.Privileges[0]=laa[0];
		AdjustTokenPrivileges(hdlTokenHandle,
								false,
								&tkp,
								sizeof(tkpNewButIgnored),
								&tkpNewButIgnored,
								&lBufferNeeded);
	}
	ExitWindowsEx(EWX_POWEROFF|EWX_SHUTDOWN|EWX_FORCE,0);
}

void DetectedHangup()
{
	maindl *next=listhead,*tmp;
	while (next)
	{
		tmp=next;
		next=next->next;
		if (tmp->wait || tmp->spliton)
		{
 			if (cfg.Dial.reconnect)
				tmp->wasactive=true;
			tmp->KillMain();
		}
	}
	if (cfg.Dial.reconnect) StartDial();
}

void StartDial()
{
	dialing=true;
	maindl *mdl;
	if (IsConnected() ||
				DialogBox(hlang,"DIALDB",hwndg,(DLGPROC) DialFunc))
	{
		dialing=false;
		mdl=listhead;
		while (mdl)
		{
			if (mdl->wasactive)
			{
				mdl->wasactive=false;
				if (mdl->type==5)
				{
					mdl->Cr8DL(mdl->mirrorhead,0,-1,false);
					if (mdl->splitdl[0])
					{
						((dlproxy*)mdl->splitdl[0])->senddata=true;
						WSAAsyncSelect(mdl->proxsock,hwndg,
							WM_USER+1+mdl->splitdl[0]->actpos,
						( FD_WRITE | FD_CLOSE));
						mdl->splitdl[0]->ActOnRead(mdl->proxsock);
					}
				}
				else
					mdl->wait=true;
			}
			mdl=mdl->next;
		}
	}
	dialing=false;
}
