#include <stdio.h>
#include "Bitmaps.h"

/* Put bitmap manipulations here!
 * Warnings: when a func gets a DC, make sure the bitmap you wanna process IS selected into this DC,
 *					  otherwise (for funcs getting HBITMAPs) make sure your HBITMAP ISN'T selected anywhere.
 */
/* Blts a bitmap with _SeeThruCol (defaults: "TruePink") segments as see thru
  * maybe add options, like in the usual blt funcs.
  * Warnings: no return value (TODO)
  */
void BltSeeThru(HDC mdc,long x,long y,long w,long h,HDC bdc)
{
    HDC monodc=CreateCompatibleDC(bdc);
    HBITMAP monomap=CreateBitmap(w,h,1,1,NULL);
    monomap=SelectObject(monodc,monomap);
    BitBlt(mdc,x,y,w,h,bdc,0,0,SRCINVERT);
    SetBkColor(bdc,_SeeThruCol);
    BitBlt(monodc,0,0,w,h,bdc,0,0,SRCCOPY);
    SetBkColor(mdc,RGB(255,255,255));
    SetTextColor(mdc,RGB(0,0,0));
    BitBlt(mdc,x,y,w,h,monodc,0,0,SRCAND);
    BitBlt(mdc,x,y,w,h,bdc,0,0,SRCINVERT);
    DeleteObject(SelectObject(monodc,monomap));
    DeleteDC(monodc);
}

/* gets a bitmap and makes a region that excludes _SeeThruCol parts
  * Warnings: on non-24bit displays it detects colors near TruePink to be TruePink
  * TODO: create a 24bit/DIB section to solve ^^^
  */
void _Bitmap2Rgn(HBITMAP hbitmap,HRGN &hrgn)
{
    // i think need a DIBSection (or just 24bit?) here, to detect "real" true pink pixels...
    BITMAP bmstruct;
    GetObject(hbitmap,sizeof(bmstruct),&bmstruct);
    HDC bdc=CreateCompatibleDC(NULL);
    hbitmap=SelectObject(bdc,hbitmap);
    int x0,y0,x,y;
    HRGN tmpRgn;
    hrgn=CreateRectRgn(0,0,bmstruct.bmWidth,bmstruct.bmHeight);
    for (y=0;y<bmstruct.bmHeight;y++){
        for (x=0;x<bmstruct.bmWidth;x++)
            if (GetPixel(bdc,x,y)==_SeeThruCol){
                x0=x,y0=y;
                while ((++x!=bmstruct.bmWidth) && (GetPixel(bdc,x,y)==_SeeThruCol))
                {} // seek end of pink
                tmpRgn=CreateRectRgn(x0,y0,x,y+1);
                CombineRgn(hrgn,hrgn,tmpRgn,RGN_XOR);
                DeleteObject(tmpRgn);
            }
    }
    hbitmap=SelectObject(bdc,hbitmap);
    DeleteDC(bdc);
}

/* Trying to implement instade with a monochrome bitmap to see if this improves performance
  * ___ TODO:  "Benchmark" these two implementations and decide on one...
  */
void Bitmap2Rgn(HBITMAP hbitmap,HRGN &hrgn)
{
    BITMAP bmstruct;
    GetObject(hbitmap,sizeof(bmstruct),&bmstruct);
    HDC bdc=CreateCompatibleDC(NULL);
    hbitmap=SelectObject(bdc,hbitmap);
    HDC monodc=CreateCompatibleDC(NULL);
    HBITMAP monomap=CreateBitmap(bmstruct.bmWidth,bmstruct.bmHeight,1,1,NULL);
    monomap=SelectObject(monodc,monomap);
    SetBkColor(bdc,_SeeThruCol);
    BitBlt(monodc,0,0,bmstruct.bmWidth,bmstruct.bmHeight,bdc,0,0,SRCCOPY);
    int x0,y0,x,y;
    HRGN tmpRgn;
    hrgn=CreateRectRgn(0,0,bmstruct.bmWidth,bmstruct.bmHeight);
    for (y=0;y<bmstruct.bmHeight;y++){
        for (x=0;x<bmstruct.bmWidth;x++)
            if (GetPixel(monodc,x,y)){
                x0=x,y0=y;
                while ((++x!=bmstruct.bmWidth) && (GetPixel(bdc,x,y)==_SeeThruCol))
                {} // seek end of pink
                tmpRgn=CreateRectRgn(x0,y0,x,y+1);
                CombineRgn(hrgn,hrgn,tmpRgn,RGN_XOR);
                DeleteObject(tmpRgn);
            }
    }
    DeleteObject(SelectObject(monodc,monomap));
    DeleteDC(monodc);
    hbitmap=SelectObject(bdc,hbitmap);
    DeleteDC(bdc);
}

/* gets DC, returns bitmap dup'd */
HBITMAP dupBMfDC(HDC bdc,long w,long h)
{
        HDC tmpdc=CreateCompatibleDC(bdc);
        HBITMAP newbm=CreateCompatibleBitmap(bdc,w,h);
        newbm=SelectObject(tmpdc,newbm);
        BitBlt(tmpdc,0,0,w,h,bdc,0,0,SRCCOPY);
        newbm=SelectObject(tmpdc,newbm);
        DeleteDC(tmpdc);
        return newbm;
}

/* Dups a bitmap.
 * Warnings: Didn't concider diffrent DC types n stuff. hmm....
 */
HBITMAP dupBM(HBITMAP hbitmap)
{
	BITMAP bmstruct;
    GetObject(hbitmap,sizeof(bmstruct),&bmstruct);
    HDC bdc=CreateCompatibleDC(NULL);
	hbitmap=SelectObject(bdc,hbitmap);
	HDC tmpdc=CreateCompatibleDC(bdc);
	HBITMAP newbm=CreateCompatibleBitmap(bdc,bmstruct.bmWidth,bmstruct.bmHeight);
	newbm=SelectObject(tmpdc,newbm);
	BitBlt(tmpdc,0,0,bmstruct.bmWidth,bmstruct.bmHeight,bdc,0,0,SRCCOPY);
	newbm=SelectObject(tmpdc,newbm);
	DeleteDC(tmpdc);
	hbitmap=SelectObject(bdc,hbitmap);
    DeleteDC(bdc);
	return newbm;
}

/* Gets a DC and returns the bitmap inside "Sunken" to indicate pressed buttons for example...
  */
HBITMAP mkSunk(HDC bdc,long w,long h)
{
        HDC tmpdc=CreateCompatibleDC(bdc);
        HBITMAP newbm=CreateCompatibleBitmap(bdc,w,h);
        newbm=SelectObject(tmpdc,newbm);
        BitBlt(tmpdc,0,0,w,h,bdc,0,0,SRCCOPY);
        RECT tmprect;
        SETRECT(tmprect,0,0,w-1,h-1);
        ScrollDC(tmpdc,1,1,&tmprect,&tmprect,NULL,NULL);
        HBRUSH hbrush=CreateSolidBrush(RGB(0,0,0));
        hbrush=SelectObject(tmpdc,hbrush);
        PatBlt(tmpdc,0,0,w,1,PATCOPY);
        PatBlt(tmpdc,0,0,1,h,PATCOPY);
        DeleteObject(SelectObject(tmpdc,hbrush));
        hbrush=CreateSolidBrush(RGB(255,255,255));
        hbrush=SelectObject(tmpdc,hbrush);
        w--,h--;
        PatBlt(tmpdc,0,h,w+1,1,PATCOPY);
        PatBlt(tmpdc,w,0,1,h,PATCOPY);
        DeleteObject(SelectObject(tmpdc,hbrush));
        newbm=SelectObject(tmpdc,newbm);
        DeleteDC(tmpdc);
        return newbm;
}

/* gets DC, returns bitmap inside "Risen" */
HBITMAP mkRise(HDC bdc,long w,long h)
{
        HDC tmpdc=CreateCompatibleDC(bdc);
        HBITMAP newbm=CreateCompatibleBitmap(bdc,w,h);
        newbm=SelectObject(tmpdc,newbm);
        BitBlt(tmpdc,0,0,w,h,bdc,0,0,SRCCOPY);
        RECT tmprect;
        SETRECT(tmprect,0,0,w-1,h-1);
        HBRUSH hbrush=CreateSolidBrush(RGB(255,255,255));
        hbrush=SelectObject(tmpdc,hbrush);
        PatBlt(tmpdc,0,0,w,1,PATCOPY);
        PatBlt(tmpdc,0,0,1,h,PATCOPY);
        DeleteObject(SelectObject(tmpdc,hbrush));
        hbrush=CreateSolidBrush(RGB(0,0,0));
        hbrush=SelectObject(tmpdc,hbrush);
        w--,h--;
        PatBlt(tmpdc,0,h,w+1,1,PATCOPY);
        PatBlt(tmpdc,w,0,1,h,PATCOPY);
        DeleteObject(SelectObject(tmpdc,hbrush));
        newbm=SelectObject(tmpdc,newbm);
        DeleteDC(tmpdc);
        return newbm;
}


/* Gets a DC and returns the bitmap inside tinted to indicate pressed buttons for example...
  */
HBITMAP mkTintGlass(HDC bdc,long w,long h,COLORREF col)
{
        HDC tmpdc=CreateCompatibleDC(bdc);
        HDC tintdc=CreateCompatibleDC(bdc);
        HBITMAP newbm=CreateCompatibleBitmap(bdc,w,h);
        HBITMAP tintbm=CreateCompatibleBitmap(bdc,w,h);
        newbm=SelectObject(tmpdc,newbm);
        tintbm=SelectObject(tintdc,tintbm);
        BitBlt(tmpdc,0,0,w,h,bdc,0,0,SRCCOPY);
        HBRUSH hbrush=CreateSolidBrush(col);
        hbrush=SelectObject(tintdc,hbrush);
        PatBlt(tintdc,0,0,w,h,PATCOPY);
        DeleteObject(SelectObject(tintdc,hbrush));
        BitBlt(tmpdc,0,0,w,h,tintdc,0,0,SRCPAINT);
        DeleteObject(SelectObject(tintdc,tintbm));
		DeleteDC(tintdc);
        newbm=SelectObject(tmpdc,newbm);
        DeleteDC(tmpdc);
        return newbm;
}

/* Gets a DC and returns the bitmap inside tinted to indicate pressed buttons for example...
  */
HBITMAP mkDarkGlass(HDC bdc,long w,long h,COLORREF col)
{
        HDC tmpdc=CreateCompatibleDC(bdc);
        HDC tintdc=CreateCompatibleDC(bdc);
        HBITMAP newbm=CreateCompatibleBitmap(bdc,w,h);
        HBITMAP tintbm=CreateCompatibleBitmap(bdc,w,h);
        newbm=SelectObject(tmpdc,newbm);
        tintbm=SelectObject(tintdc,tintbm);
        BitBlt(tmpdc,0,0,w,h,bdc,0,0,SRCCOPY);
        HBRUSH hbrush=CreateSolidBrush(col);
        hbrush=SelectObject(tintdc,hbrush);
        PatBlt(tintdc,0,0,w,h,PATCOPY);
        DeleteObject(SelectObject(tintdc,hbrush));
        BitBlt(tmpdc,0,0,w,h,tintdc,0,0,SRCAND);
        DeleteObject(SelectObject(tintdc,tintbm));
		DeleteDC(tintdc);
        newbm=SelectObject(tmpdc,newbm);
        DeleteDC(tmpdc);
        return newbm;
}

/* we should rename this file to GDI related funcs or something like that.
 */
/* callback function, gets a HWND and a hrgn, and removes the window's rgn
 * from the given rgn
 */
static POINT basewinorg;
BOOL CALLBACK RMThisWinsRgn(HWND gothwnd,HRGN mainhrgn)
{
	if (!IsWindowVisible(gothwnd))
		return true;
	HRGN wrgn;
	wrgn=CreateRectRgn(0,0,0,0);
	int rgnret=GetWindowRgn(gothwnd,wrgn);
	if (rgnret!=COMPLEXREGION){
		if (rgnret==NULLREGION) return true;
		RECT r;
		GetWindowRect(gothwnd,&r);
		wrgn=CreateRectRgn(0,0,r.right-r.left,r.bottom-r.top);
	}
	POINT thiswinoff;
	thiswinoff.x=0;thiswinoff.y=0;
	ClientToScreen(gothwnd,&thiswinoff);
	thiswinoff.x-=basewinorg.x;
	thiswinoff.y-=basewinorg.y;
	OffsetRgn(wrgn,thiswinoff.x,thiswinoff.y);
	CombineRgn(mainhrgn,mainhrgn,wrgn,RGN_OR);
	DeleteObject(wrgn);
	return true;
}

// adds all the child windowst o childshrgn
void AddChildRgns(HWND basehwnd,HRGN childshrgn)
{
	basewinorg.x=0;basewinorg.y=0;
	ClientToScreen(basehwnd,&basewinorg);
	EnumChildWindows(basehwnd,(WNDENUMPROC)&RMThisWinsRgn,
                (LPARAM) childshrgn);
}
