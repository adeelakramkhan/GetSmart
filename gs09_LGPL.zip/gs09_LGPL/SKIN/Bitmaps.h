/*
 * Bitmap handling unit
 */

#ifndef _S_bitmaps_h
#define _S_bitmaps_h

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#undef WIN32_LEAN_AND_MEAN

#ifndef _SeeThruCol
#define _SeeThruCol RGB(255,0,255)
#endif

// macros:
#define SETRECT(r,l,t,rt,b)     r.left=l;r.top=t;r.right=rt;r.bottom=b

// prototypes
void BltSeeThru(HDC mdc,long x,long y,long w,long h,HDC bdc);

void Bitmap2Rgn(HBITMAP,HRGN&);

HBITMAP dupBMfDC(HDC bdc,long w,long h);

HBITMAP dupBM(HBITMAP hbitmap);

HBITMAP mkSunk(HDC bdc,long w,long h);

HBITMAP mkRise(HDC bdc,long w,long h);

HBITMAP mkTintGlass(HDC bdc,long w,long h,COLORREF col);

HBITMAP mkDarkGlass(HDC bdc,long w,long h,COLORREF col);

void AddChildRgns(HWND basehwnd,HRGN childshrgn);
#endif // EOF