
#include "SkinDefs.h"
#include "PopUpWin.h"

short PopUpTip::cnt=0;
HDC PopUpTip::memdc;
const short &PopUpTip::cntread=PopUpTip::cnt;

LRESULT CALLBACK PopUpTip::TipWinFunc(HWND hwnd,UINT message,
										WPARAM wParam,LPARAM lParam)
{
	UNALIGNED PopUpTip *t;
	HDC hdc;
    t=(PopUpTip*) GetWindowLong(hwnd,GWL_USERDATA);
	switch (message){
	case WM_CREATE:
		t=(PopUpTip*)(((LPCREATESTRUCT) lParam)->lpCreateParams);
		SetWindowLong(hwnd,GWL_USERDATA,(long)t);
		//EnableWindow(hwnd,false);
		break;
		
/*    case WM_SETFOCUS: // reject focus.. shoultn't get here, but anyways.
		if (wParam!=NULL){
			SetForegroundWindow((HWND)wParam);
		}
		break;
*/
	case WM_NCHITTEST: // reject mousestuff
		HWND belowhwnd;
		belowhwnd=hwnd;
		while((belowhwnd=GetWindow(belowhwnd,GW_HWNDNEXT))!=NULL){
// we should GetWindowRect() or enumbelowz, and do all that stuff w/ rgns n' stuff...
			//hmm...
			// for now, quick n' dirty, return the first and hope for da best..
			if (belowhwnd!=hwnd)
				return SendMessage(belowhwnd,message,wParam,lParam);
		}

	case WM_ERASEBKGND:
        // paint bg
		return 0;
	
	case WM_PAINT:
	  PAINTSTRUCT ps;
	  hdc=BeginPaint(hwnd,&ps);
	  HBRUSH oldbr;
	  oldbr=SelectObject(hdc,CreateSolidBrush(t->bgcol));
	  PatBlt(hdc,0,0,t->wrect.right,t->wrect.bottom,PATCOPY);
	  DeleteObject(SelectObject(hdc,oldbr));
	  SetTextColor(hdc,t->fgcol);
	  SetBkMode(hdc,TRANSPARENT);
	  t->fnt=SelectObject(hdc,t->fnt);
	  DrawText(hdc,t->q.head->txt,t->q.head->len,&t->wrect, DT_NOPREFIX |DT_NOCLIP);
	  t->fnt=SelectObject(hdc,t->fnt);
	  break;
	  	
	case POPTIP_TXTUPDATE:
#define GOT_STRING (char*)wParam
		if (t->q.head==NULL){
			/* line appearing twice since it needs to run AFTER chking in
			 * both cases.. , an idea to try::
			 if (t->q.head || 
				!t->q.Add2Tail(new txtcell(GOT_STRING,LOWORD(lParam),HIWORD(lParam)))
				){
			*/
			t->q.Add2Tail(new txtcell(GOT_STRING,LOWORD(lParam),HIWORD(lParam)));
		}
		else{
			t->q.Add2Tail(new txtcell(GOT_STRING,LOWORD(lParam),HIWORD(lParam)));
			if (t->lowtimer==1){
				KillTimer(hwnd,2);
				t->q.FDItem();
			}
			else{ // 1st timeout isn't out yet
				break;
			}
		}
#undef GOT_STRING
		wParam=0;
	case POPTIP_SHOWNOW:
		if (t->sus==1)
			break;
		if (t->q.head==NULL)
			break;
		t->fnt=SelectObject(t->memdc,t->fnt);
		DrawText(t->memdc,t->q.head->txt,t->q.head->len,&t->wrect, DT_NOPREFIX |DT_NOCLIP |DT_CALCRECT);
		// ^^ calcs win rect
		t->fnt=SelectObject(t->memdc,t->fnt);

		// keep tip inside scr.
		short diff1;
		// placement policies:
		t->cx=t->x;
		switch (t->xhow){
		//case POPTIP_POINT_IS_BEG:	break;
		case POPTIP_POINT_IS_END:	t->cx-=(short)(t->wrect.right);		break;
		case POPTIP_POINT_IS_CENTER:	t->cx-=(short)(t->wrect.right/2);		break;
		}					
		diff1=(short)(Skin_SysNfo.SCRx-t->cx-t->wrect.right-t->xpad);
		if (diff1<0)
			t->cx+=diff1;
		if (t->cx<t->xpad)
			t->cx=t->xpad;
		t->cy=t->y;
		switch(t->yhow){
		//case POPTIP_POINT_IS_BEG:break;
		case POPTIP_POINT_IS_END:	t->cy-=(short)(t->wrect.bottom);		break;
		case POPTIP_POINT_IS_CENTER:	t->cy-=(short)(t->wrect.bottom/2);		break;
		}
		diff1=(short)(Skin_SysNfo.SCRy-t->cy-t->wrect.bottom-t->ypad);
		if (diff1<0)
			t->cy+=diff1;
		if (t->cy<t->ypad)
			t->cy=t->ypad;
		SetWindowPos(hwnd, HWND_TOPMOST ,t->cx,t->cy,t->wrect.right,t->wrect.bottom,
			SWP_SHOWWINDOW|SWP_NOACTIVATE|SWP_NOCOPYBITS);
		InvalidateRect(hwnd,NULL,FALSE);
		if (wParam==0){
			// set timer here.
			t->lowtimer=0;
			if (t->q.head->time_w==0){
				t->q.head->time_w=t->time_w;
				if (t->timehow==POPTIP_TIMEVAL_IS_LETTER)
					t->q.head->time_w*=t->q.head->len;
			}
			else
				if (t->timehow==POPTIP_TIMEVAL_IS_LETTER)
					t->q.head->time_w*=t->q.head->len;
			SetTimer(hwnd,1,t->q.head->time_w,NULL);
		}
		break;

	case POPTIP_RESHOWLAST:
		if (t->q.lasttip==NULL) break;
		KillTimer(hwnd,1);KillTimer(hwnd,2);
		t->q.Add2Head(t->q.lasttip);
		t->q.lasttip->time_w=LOWORD(lParam);
		t->q.lasttip->time_xtra=HIWORD(lParam);
		// ^^ we need to store copies of this. tmp..
		t->lowtimer=0;
		SendMessage(hwnd,POPTIP_SHOWNOW,0,0);
		break;

	case POPTIP_TONEXT:
		if (t->q.head==NULL)
			break;
		else
			if (t->q.head->next==NULL){
				KillTimer(hwnd,1);
				wParam=2;
			}
			else
				wParam=1;

	case WM_TIMER:
		KillTimer(hwnd,wParam);
		switch (wParam){
		case 1:
			t->lowtimer=1;
			if (t->q.head->next!=NULL){
				t->q.FDItem();
				SendMessage(hwnd,POPTIP_SHOWNOW,0,0);
			}
			else{
				if (t->q.head->time_xtra==0){
					t->q.head->time_xtra=t->time_xtra;
					if (t->timehow==POPTIP_TIMEVAL_IS_LETTER)
						t->q.head->time_xtra*=t->q.head->len;
				}
				else 
					if (t->timehow==POPTIP_TIMEVAL_IS_LETTER)
						t->q.head->time_xtra*=t->q.head->len;
				SetTimer(hwnd,2,t->q.head->time_xtra,NULL);
			}
			break;
		case 2:
			// xtra timerout.
			SetWindowPos(hwnd,0,0,0,0,0,SWP_HIDEWINDOW|SWP_NOACTIVATE|SWP_NOCOPYBITS|
						SWP_NOMOVE|SWP_NOSIZE|SWP_NOZORDER);
			// ^^ hide window ;)
			t->q.FDItem();
			break;
		}
		break;

	case WM_DESTROY:
		KillTimer(hwnd,1);KillTimer(hwnd,2); // i hope this doesn't harm anything if not set...
		break;

	default:
		return DefWindowProc(hwnd,message,wParam,lParam);
	}
	return 0;
}
