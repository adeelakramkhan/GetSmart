/* This is proboably a temp header to be replaced with some more general one, like commonskins.h
 * or something like dat.
 */

#include "SomeTemplates.h"

#ifndef _POPUPWIN_H_ 
#define _POPUPWIN_H_

#define POPBASE WM_USER+0x100

#define POPTIP_TXTUPDATE POPBASE+0
// new text string. wParam=(char*)str;  lParam=(timeout,xtra timeout)0 => use time out from struct
#define POPTIP_SHOWNOW POPBASE+1
// show text now. wParam: 0= for new text i.e. set a timer. 1= just update
#define POPTIP_TONEXT POPBASE+2
// jump to next tip.
#define POPTIP_RESHOWLAST POPBASE+3
// reshow last, possibly w/ new t/o lParam=(t,t2)

bool MakeTransparent(HWND hwnd,bool wstrans,int alpha);

// a txt cell for the que
struct txtcell{
	txtcell*next; // next...
	char*txt; // pointer to the string. new[]'d on constr, delete[]'d on desctruction..
	unsigned short len; // =strlen(txt);
	unsigned short time_w,time_xtra;
	txtcell(const char*c,unsigned short t1,unsigned short t2){
		len=strlen(c);
		txt=new char[len+1];
		strcpy(txt,c);
		time_w=t1;
		time_xtra=t2;
		next=NULL;
	}
	txtcell(const txtcell*t){
		*this=*t;
		txt=new char[len+1];
		strcpy(txt,t->txt);
	}
	~txtcell(){
		delete []txt;
	}
};


// A PopUpTip Window struct.
struct PopUpTip{
	HWND hwnd;
	COLORREF bgcol,fgcol;
	short xpad,ypad; // requested screen padding.
	short x,y; // requested x,y to center tip around.
	char xhow,yhow; // x,y placement policies.
	short cx,cy;// current x,y  coordinates.
	RECT wrect; // current window rect, accoring to string.
	HFONT fnt;
	QueW1undo<txtcell> q; // txt que
	unsigned short time_w; // timer when some1's waiting. (millisecs)
	unsigned short time_xtra;// xtra time when no1's waiting.
	char timehow; // how to interpate timevals.
	static HDC memdc;

   static LRESULT CALLBACK TipWinFunc(HWND hwnd,UINT message,
							WPARAM wParam,LPARAM lParam);
public:
	static const short &cntread; // a "read-only" version of the counter
private:
	char lowtimer; // flag. have the low timer ellapsed? 1=>yes
	char sus; // suspended state. 1=> suspended.

	static short cnt; // global popuptips counter
private:
	// internal init func, for contructors.
	void PopUpInit(){
		if ( cnt++ == 0){
			RegClass();
			HDC hdc=GetDC(hwnd);
			memdc=CreateCompatibleDC(hdc);
			ReleaseDC(hwnd,hdc);
		}
		memset(&wrect,0,sizeof(RECT));
		hwnd=NULL;
		sus=0;
		lowtimer=0;
	}
	static void RegClass()
	{
		WNDCLASS wcl;
		memset(&wcl,0,sizeof(wcl));
		wcl.lpszClassName="PopUpTipz";
		wcl.lpfnWndProc=TipWinFunc;
		wcl.hCursor=LoadCursor(NULL,IDC_ARROW);		
		wcl.hbrBackground=GetStockObject(NULL_BRUSH);
		RegisterClass(&wcl);
	}
public:
	PopUpTip(){
		PopUpInit();
		//fnt=NULL;
	}		
	PopUpTip(char*f,short h,short w) {
		PopUpInit();
		fnt=CreateFont(h,w,0,0,FW_BOLD,0,0,0,ANSI_CHARSET,
			OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,
			DEFAULT_QUALITY,DEFAULT_PITCH|FF_DONTCARE,
			f);
	}
	~PopUpTip(){
		if (hwnd)
			DestroyWindow(hwnd);
		DeleteObject(fnt);
		if (--cnt==0){
			UnregisterClass("PopUpTipz",NULL);
			DeleteDC(memdc);
		}
	}
	void init(char *name) // interface to get it rolling.
	{
		hwnd=CreateWindowEx(WS_EX_TOPMOST|WS_EX_TOOLWINDOW,
			"PopUpTipz",name,WS_POPUP,
			x,y,0, 0, // <- this will be calc'd by each string
			HWND_DESKTOP,
			NULL,NULL,this);
		MakeTransparent(hwnd,true,192);
	}

	// Suspend or release message que;
	void Suspend(bool pause){
		if (pause){
			sus=1;
			lowtimer=0;
			KillTimer(hwnd,1);KillTimer(hwnd,2);
			SetWindowPos(hwnd,0,0,0,0,0,SWP_HIDEWINDOW|SWP_NOACTIVATE|SWP_NOCOPYBITS|
						SWP_NOMOVE|SWP_NOSIZE|SWP_NOZORDER);
			// ^^ hide window ;)
		}
		else{
			sus=0;
			SendMessage(hwnd,POPTIP_SHOWNOW,1,0);
		}
	}
};

// x,y placement policies:
#define POPTIP_POINT_IS_BEG 0
#define POPTIP_POINT_IS_END 1
#define POPTIP_POINT_IS_CENTER 2

// timevals policies:
#define POPTIP_TIMEVAL_IS_TOT 0
#define POPTIP_TIMEVAL_IS_LETTER 1

#endif //3of