/*
 * Internals of the skin controls are implemented here
 */

#include "SkinDefs.h"
#include "Bitmaps.h"


// Progression bars:
void Progression::Draw(HDC mdc,unsigned long bytes,unsigned long size)
{
    HDC monodc=CreateCompatibleDC(mdc);
    HBITMAP monomap=CreateBitmap(sz.x,sz.y,1,1,NULL);
    monomap=SelectObject(monodc,monomap);
    PatBlt(monodc,0,0,sz.x,sz.y,WHITENESS);
	HBRUSH oldbr=SelectObject(monodc,GetStockObject(BLACK_BRUSH));
	if (size)
		DrawBar(monodc,bytes,size);
	SelectObject(monodc,oldbr);
	HDC bdc=CreateCompatibleDC(mdc);
    pic=SelectObject(bdc,pic);
	SetBkColor(bdc,_SeeThruCol);
	BitBlt(monodc,0,0,sz.x,sz.y,bdc,0,0,SRCPAINT);

	SetBkColor(bdc,RGB(255,255,255));
    
    BitBlt(mdc,r.left,r.top,sz.x,sz.y,bdc,0,0,SRCINVERT);
    BitBlt(mdc,r.left,r.top,sz.x,sz.y,monodc,0,0,SRCAND);
    BitBlt(mdc,r.left,r.top,sz.x,sz.y,bdc,0,0,SRCINVERT);
    pic=SelectObject(bdc,pic);
    DeleteDC(bdc);
    DeleteObject(SelectObject(monodc,monomap));
    DeleteDC(monodc);
}

void RoundProgression::DrawBar(HDC monodc,unsigned long bytes,unsigned long size)
{
    long dr=(long)((sz.x+sz.x+sz.y+sz.y)*(double)bytes/size);
    if (!dr) return;
    if (bytes>=size)
    {
        Ellipse(monodc,0,0,sz.x,sz.y);
        return;
    }
    long tmp=dr-sz.x/2;
    if (tmp<=0) //less than 1/8
    {
        Pie(monodc,0,0,sz.x,sz.y,
            beg.x+dr-1,0,
            beg.x-1,beg.y);
        return;
    }
    tmp-=sz.y;
    if (tmp<=0) //1/8 to 3/8
    {
        Pie(monodc,0,0,sz.x,sz.y,
            sz.x,dr-sz.x/2-1,
            beg.x-1,beg.y);
        return;
    }
    tmp-=sz.x;
    if (tmp<=0) // 3/8 to 5/8
    {
        Pie(monodc,0,0,sz.x,sz.y,
            sz.x-(dr-sz.x/2-sz.y),sz.y,
            beg.x-1,beg.y);
        return;
    }
    tmp-=sz.y;
    if (tmp<=0) // 5/8 to 7/8
    {
        Pie(monodc,0,0,sz.x,sz.y,
            0,sz.y-(dr-sz.x/2-sz.y-sz.x),
            beg.x-1,beg.y);
        return;
    }
    tmp-=sz.x/2;
    Pie(monodc,0,0,sz.x,sz.y,
        dr-sz.x/2-sz.y-sz.x-sz.y-2,0,
        beg.x-1,beg.y);
}

void Str8Progression::DrawBar(HDC monodc,unsigned long bytes,unsigned long size)
{
	unsigned long pix=(unsigned long)(sz.x*(double)bytes/size);
	PatBlt(monodc,0,0,pix,sz.y,BLACKNESS);
	return;
}

// Track Bars:
void Htr::DrawSep(HDC bdc,signed short sepoff,COLORREF col)
{
    float sz=(float)(r.right-r.left-xoff-w)/(max-min);
    long wd=w/2-1;
    int chk=0;
	HBRUSH hbrush=CreateSolidBrush(col);
    hbrush=SelectObject(bdc,hbrush);
    for (int i=0;i<=max-min;i++){
        if (i){
            chk=(int)(i*sz);
            chk=(i*sz==chk);
            if(chk)
                wd--;
        }
        PatBlt(bdc,(int)(xoff+r.left+i*sz+wd),r.bottom+sepoff,2,5,PATCOPY);
        if (chk)
            wd++;
    }
    DeleteObject(SelectObject(bdc,hbrush));
}



#define SH_H(r,x)  r.right+=x-r.left;r.left=x
// shift bar horizontaly
bool Htr::Drag(SkinWinNfo*s)
{
    long oldval=s->tr[s->dragtr].val;
    long land,tmpval=s->tr[s->dragtr].val;
    land=r.left;
    if  ((short signed)s->MousePT.x>land)
    {
        land=r.right-w-xoff;
        if (s->MousePT.x<land)
            land=s->MousePT.x;
    }
    SH_H(s->tr[s->dragtr].r,land);
    EvalPos(s);
    return (oldval!=s->tr[s->dragtr].val);
}

void Htr::EvalPos(SkinWinNfo*s)
{
        // val= offsetpixel*steps/pixrange +min:
        float value;
        unsigned long pixrange=(r.right-r.left-xoff-w);
        unsigned long steps=max-min;
#define BEGOFF (s->tr[s->dragtr].r.left-r.left+xoff)
        value=(float)BEGOFF*steps/pixrange;
#undef BEGOFF
        s->tr[s->dragtr].val=(int)value;
        if ((value-(int)value)>0.5)
                s->tr[s->dragtr].val++;
        s->tr[s->dragtr].val+=min;
}

void Htr::StopDrag(SkinWinNfo*s)
{
    unsigned long pixrange=r.right-r.left-xoff-w-1;
    unsigned long steps=max-min;
    SH_H(s->tr[s->dragtr].r,(s->tr[s->dragtr].val-min)*pixrange/steps+r.left+xoff);
}

void Htr::SetPos(SkinWinNfo*s,long newval)
{
        unsigned long pixrange=r.right-r.left-xoff-w;
        unsigned long steps=max-min;
        s->tr[s->dragtr].val=newval;
        SH_H(s->tr[s->dragtr].r,(s->tr[s->dragtr].val-min)*pixrange/steps+r.left+xoff);
        s->dragtr=-1;
}

bool Htr::PressPos(SkinWinNfo*s)
{
    if (s->MousePT.x<s->tr[s->dragtr].r.left){
        if (s->tr[s->dragtr].val>min){
            SetPos(s,s->tr[s->dragtr].val-1);
            return true;
        }
    }else
        if (s->tr[s->dragtr].val<max){
            SetPos(s,s->tr[s->dragtr].val+1);
            return true;
        }
    return false;
}

#undef SH_H

void Vtr::DrawSep(HDC bdc,signed short sepoff,COLORREF col)
{
    float sz=(float)(r.bottom-r.top-yoff-h)/(max-min);
    long wd=h/2-1;
    int chk=0;
    HBRUSH hbrush=CreateSolidBrush(col);
    hbrush=SelectObject(bdc,hbrush);
    for (int i=0;i<=max-min;i++){
        if (i){
            chk=(int)(i*sz);
            chk=(i*sz==chk);
            if(chk)
                wd--;
        }
        PatBlt(bdc,r.right+sepoff,(int)(yoff+r.top+i*sz+wd),5,2,PATCOPY);
        if (chk)
            wd++;
    }
    DeleteObject(SelectObject(bdc,hbrush));
}



#define SH_V(r,y)  r.bottom+=y-r.top;r.top=y
// shift bar vert
bool Vtr::Drag(SkinWinNfo*s)
{
    long oldval=s->tr[s->dragtr].val;
    long land,tmpval=s->tr[s->dragtr].val;
    land=r.top;
    if  ((short signed)s->MousePT.y>land)
    {
        land=r.bottom-h-yoff;
        if (s->MousePT.y<land)
            land=s->MousePT.y;
    }
    SH_V(s->tr[s->dragtr].r,land);
    EvalPos(s);       
    return (oldval!=s->tr[s->dragtr].val);
}

void Vtr::EvalPos(SkinWinNfo*s)
{
    // val= offsetpixel*steps/pixrange +min:
    float value;
    unsigned long pixrange=(r.bottom-r.top-yoff-h);
    unsigned long steps=max-min;
#define BEGOFF (s->tr[s->dragtr].r.top-r.top+yoff)
    value=(float)BEGOFF*steps/pixrange;
#undef BEGOFF
    s->tr[s->dragtr].val=(int)value;
    if ((value-(int)value)>0.5)
        s->tr[s->dragtr].val++;
    s->tr[s->dragtr].val+=min;
}

void Vtr::StopDrag(SkinWinNfo*s)
{
    unsigned long pixrange=r.bottom-r.top-yoff-h-1;
    unsigned long steps=max-min;
    SH_V(s->tr[s->dragtr].r,(s->tr[s->dragtr].val-min)*pixrange/steps+r.top+yoff);
}

void Vtr::SetPos(SkinWinNfo*s,long newval)
{
        unsigned long pixrange=r.bottom-r.top-yoff-h;
        unsigned long steps=max-min;
        s->tr[s->dragtr].val=newval;
        SH_V(s->tr[s->dragtr].r,(s->tr[s->dragtr].val-min)*pixrange/steps+r.top+yoff);
        s->dragtr=-1;
}

bool Vtr::PressPos(SkinWinNfo*s)
{
    if (s->MousePT.y<s->tr[s->dragtr].r.bottom){
        if (s->tr[s->dragtr].val>min){
            SetPos(s,s->tr[s->dragtr].val-1);
            return true;
        }
    }else
        if (s->tr[s->dragtr].val<max){
            SetPos(s,s->tr[s->dragtr].val+1);
            return true;
        }
    return false;
}

#undef SH_V


