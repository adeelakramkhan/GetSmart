/*
 *   The Smartitude Skin System. (c) 1999
 *   Version 0.026, 16-03-1999
 */
#ifndef _SkinDefs_h
#define _SkinDefs_h

/*#ifndef _WINSOCKAPI_
#define _WINSOCKAPI_   /* Prevent inclusion of winsock.h in windows.h */ 
//#endif 
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <io.h>

#define SKINVER "0.028, alpha"

#ifndef SHRT_MAX
#define SHRT_MAX 32767
#endif

#define DOMAX(_m,_f) {if ((_m)<(_f)) (_m)=(_f);}

#include "SkinInterface.h"
// ^^^ communication with the system thru here...

// Classes:

struct TRnfo;

// multi state button (or check box)
struct st_butt{
	HRGN rg; // rgn that gets checked.
	RECT r; // bounding rect, for invalidations, redraws and such..
	char n,menu;
	HBITMAP *plain,*pushed,*over;
	st_butt(){
		plain=NULL;pushed=NULL;over=NULL;
		n=0;
		memset(&r,0,sizeof(r));
	}
	~st_butt(){
		if (n){
			int j;
			for (j=0;j<n;j++){
				DeleteObject(plain[j]);
				DeleteObject(pushed[j]);
				DeleteObject(over[j]);
			}
			DeleteObject(rg);
			delete[]plain;
			delete[]pushed;
			delete[]over;
		}
	}
};

// rgn according to a bitmap
struct rgn_b{
    HRGN rgn; // effective rgn, calculated by pink areas
	unsigned char init;
	rgn_b()
	{
		init=0;
		rgn=NULL;
	}
	~rgn_b(){
		if (rgn)
			DeleteObject(rgn);
	}
};

struct SlideTrack{
    // the track button::
        RECT r;
        // range:
        long min,max;
        // the bar:
        long h,w;
        signed short xoff,yoff; // bar offset from track 0,0 when in min pos. (assumed: symetric)
        HBITMAP pic;
		SlideTrack()
		{
			pic=NULL;
			memset(&r,0,sizeof(r));
		}
        // member funcs::
        void virtual StopDrag(SkinWinNfo*s)=NULL;
        bool virtual Drag(SkinWinNfo*s)=NULL; // true=> pos changed
        void virtual EvalPos(SkinWinNfo*s)=NULL;
        void virtual DrawSep(HDC,signed short sepoff,COLORREF)=NULL;
        void virtual SetPos(SkinWinNfo*s,long newval)=NULL;
        bool virtual PressPos(SkinWinNfo*s)=NULL;
		virtual ~SlideTrack(){
			if (pic)
				DeleteObject(pic);
		}
};


struct Htr:SlideTrack{
    void StopDrag(SkinWinNfo*s);
    bool Drag(SkinWinNfo*s);
    void EvalPos(SkinWinNfo*s);
    void DrawSep(HDC,signed short sepoff,COLORREF);
    void SetPos(SkinWinNfo*s,long newval);
    bool PressPos(SkinWinNfo*s);
};

struct Vtr:SlideTrack{
    void StopDrag(SkinWinNfo*s);
    bool Drag(SkinWinNfo*s);
    void EvalPos(SkinWinNfo*s);
    void DrawSep(HDC,signed short sepoff,COLORREF);
    void SetPos(SkinWinNfo*s,long newval);
    bool PressPos(SkinWinNfo*s);
};

// txt struct, gets rect for whereever in loadtime.
struct txt_tag{
	HFONT hfont;
	RECT r;
	short def;
	COLORREF incol,outcol;
	char rastop;
	char wedel;
	txt_tag(){
		wedel=0;
		memset(&r,0,sizeof(r));
		hfont=NULL;
		def=-1;
	}
	~txt_tag(){
		if (wedel && hfont)
			DeleteObject(hfont);
	}
};

struct Progression{
        HBITMAP pic; // picture to reveal
        RECT r; // bounding rectangle
		POINT sz; // size, calc'd off rect..
		void Draw(HDC,unsigned long bytes,unsigned long size);
		Progression(){
			memset(&r,0,sizeof(r));
			pic=NULL;
		}
		virtual ~Progression(){
			if (pic)
				DeleteObject(pic);
		}
protected:
		virtual void DrawBar(HDC monodc,unsigned long bytes,unsigned long size)=NULL;
};

struct RoundProgression:Progression{
        POINT beg;// where does it all begin??
private:
        void DrawBar(HDC monodc,unsigned long bytes,unsigned long size);
};

struct Str8Progression:Progression{
private:
	void DrawBar(HDC monodc,unsigned long bytes,unsigned long size);
};

// per instance structs:
struct PRnfo{
    unsigned long tot,cur;
	~PRnfo(){
		tot=0;
	}
};

struct TRnfo{
    long val;
    RECT r;
	~TRnfo()
	{
		val=0;
	}
};

struct STBTnfo{
	unsigned char state;
	char i;
	HRGN rg; // rgn that gets checked.
	RECT r; // bounding rect, for invalidations, redraws and such..
	STBTnfo(){
		i=0;
		state=BT_OUT;
	}
	~STBTnfo(){
		DeleteObject(rg);
	}
};

struct RGnfo{
	char visible;
	~RGnfo(){
		visible=4;
	}
};

struct TXTnfo{
	COLORREF col,incol,outcol;
	char *str,rastop; // rastop: 0=normal, 1=cololrize on bg,
	TXTnfo(){
		col=0;
		str=NULL;
	}
	~TXTnfo()
	{
		col=1;
	}
};

// loadtime stucts:


// fromrc fields: 0 => file, 1 => rc. no mixing, to avoid mess...
struct RGloadSt{
	char *fn;
	unsigned short x,y;
	unsigned char init,fromrc,noscan;
	int proc(char*&bf);
	RGloadSt(){
		fn=NULL;
		fromrc=0;
	}
	~RGloadSt(){
		delete[]fn;
	}
};

struct TRloadSt{
    unsigned short x,y;
    signed short xo,yo;
    signed long min,max;
    char *fgfn,*bgfn;
    unsigned char type,fromrc; // 1=H, 2=V
    signed short sep; // SHRT_MAX=none offset for sep drawing
	COLORREF col;
	int proc(char*&bf);
	TRloadSt(){
		fgfn=NULL;bgfn=NULL;
		fromrc=0;
	}
	~TRloadSt(){
		delete []fgfn;delete[]bgfn;
	}
};

struct PRloadSt{
    unsigned short x,y;
    char *fn;
    unsigned char type,fromrc; // low-nibble: 0=none, 1= round, 2= str8, 3= rect,
                                    // hi-nibble: 0=none, 1= color scale
	int proc(char*&bf);
	PRloadSt(){
		fn=NULL;
		fromrc=0;
	}
	~PRloadSt(){
		delete[]fn;
	}
};

struct txtLD{
	char *fnt;
	unsigned char h,w,from,n; // from: 0= rect; 1= butt[n];
	short use,def; // use: -1= create font, other: borrow
	COLORREF incol,outcol;
	RECT r;
	char rastop;
	int proc(char*&bf);
	txtLD(){
		fnt=NULL;
		use=0;
		def=-1;
	}
	~txtLD(){
		delete[]fnt;
	}
};


//typedef char fnstr[_MAX_FNAME];

struct STBTloadSt{
	unsigned char fromrc,scanshape;
    char n,menu;
	char **fn,**ov_fn,**p_fn;
    unsigned short x,y;
    char *over,*pushed;// styles 0=nothing,1=frame,2=glass,3=dark,4=emboss, bf=loadbmp, fa=function
	short *use;
	unsigned long *tint1;//color for over
	unsigned long *tint2;// for pushed
	// ^^ these two will be general 32bit extra parameters for other things too proboably
	// "COLORREF"s
	STBTloadSt(){
		n=0;
		fromrc=0;
	}
	~STBTloadSt(){
		int i;
		if (n){
			for (i=0;i<n;i++){
				delete []fn[i];
				delete []ov_fn[i];
				delete []p_fn[i];
			}
			delete[]fn;delete[]ov_fn;delete[]p_fn;
			delete[]over;delete[]pushed;delete[]use;
			delete []tint1;delete []tint2;
		}
	}
	int proc(char*&bf);
	int procsubs(char*&bf);
};

struct Skinload{
	char type; // so far: 0= "normal" skin, 1= in big rect win
//	RECT r;
    char *basedir,*name,*author,*use,*ver,*date,*comment;
	short bpp; // recommended bits per pixel
    char numpr;
    char numtr;
	char numrg;
	char numstbt;
	char numtxt;
    TRloadSt *tr;
    PRloadSt *pr;
	RGloadSt *rg;
	STBTloadSt *stbt;
	txtLD*txt;
	// init with low lims
	Skinload(char npr=0,char ntr=0,char nrg=0,char nbutt=0,char ntxt=0){
		name=NULL;author=NULL;use=NULL;ver=NULL;bpp=-1;
		basedir=NULL;date=NULL;comment=NULL;
		numpr=npr;numtr=ntr;numrg=nrg;numstbt=nbutt;numtxt=ntxt;
		tr=NULL;pr=NULL;rg=NULL;stbt=NULL;txt=NULL;
	}
	// init from file right away;
	Skinload(const char*fn){
		name=NULL;author=NULL;use=NULL;ver=NULL;bpp=-1;
		basedir=NULL;date=NULL;comment=NULL;
		numpr=0;numtr=0;numrg=0;numstbt=0;numtxt=0;
		tr=NULL;pr=NULL;rg=NULL;stbt=NULL;txt=NULL;
		if (!LoadFile(fn)){
			//~Skinload();
			// hmmm.. can i not allocate this when an error is found, and return NULL??
		}
	}
	~Skinload(){
		delete []name;delete[]author;delete[]use;delete[]ver;
		delete[]basedir;delete[]date;delete[]comment;delete []tr;
		delete []pr;delete []rg;delete []txt;delete []stbt;
	}
	long LoadFile(const char*fn);
private:
	int Process(char*bf);
	int SetupLims(char*bf);
	int ReadSkin(char*bf);
};

struct Skin{
	char type; // so far: 0= "normal" skin, 1= in big rect win
	int Wmax,Hmax;
	HBITMAP bmshow; // bitmap for WM_PAINT
	HDC indc,outdc; // in and out DCs
	HBITMAP inbm,outbm; // their default bitmaps, for DeleteObject() cleanup
	HRGN inrgn,outrgn,mvrgn;
    char numpr;
    Progression**pr;
    char numtr;
    SlideTrack**tr;
	char numtxt;
	txt_tag*txt;
	char numrg;
	rgn_b*rg;
	char numstbt;
	st_butt*stbt;
    /* member functions: */
    LRESULT CALLBACK fn(HWND hwnd,UINT message,WPARAM wParam,LPARAM lParam);    
	// Init function.
    int Init(Skinload &nfo,HINSTANCE hinst);
	// Cleanup function, ~ calls it, you may call it maually.
	int Kill();
	Skin()
	{}
	Skin(Skinload nfo){
		Init(nfo,NULL);
	}
	~Skin(){
//		Kill();
	}
	/* Interface:: */
	void prtot(SkinWinNfo*s,unsigned short dex,unsigned short act,unsigned long val);
private:
    int LDskin(Skinload &nfo,HINSTANCE hinst);
};

// struct unique to every copy of the skin
struct SkinWinNfo{
	void *data;
    HWND hwnd,hwndTT;
	HDC showdc; // assigned to Skin::indc/outdc
	HRGN wrgn;// hrgn  that we give SetWindowRgn().
	HRGN inrgn,outrgn; // in/out rgns for setting wrgn
	HRGN mvrgn; // easy move rgn
	HRGN skiprgn; // rgn where we skip catpure;
    TRnfo *tr;// Array of trackbar infos
	PRnfo *pr;// Array of progbars infos
	STBTnfo *stbt;// Array of rect button infos
	TXTnfo*txt;// Array of txt infos
	RGnfo*rg;// Array of rgn infos
	char bpushed,bover;// which buttons are pushed/over'd in here
	char focus;// 1=in 2=out
	POINT MousePT; // Mouse
	POINT mmove; // mouse init point for winmove
	POINT mvbtoff;
	char drag; // which button is down but mouse isn't in rect
	char dragtr; //which track is being dragged
	char movewin; // not zero => window is moving.
	char movebt; // which button is moving. -1 => non
    SkinWinNfo(){
		memset(this,0,sizeof(*this));
        bover=-1;bpushed=-1;drag=-1;dragtr=-1;movebt=-1;
    }
};

// System Info struct. global.
struct Skin_SysNfo_tag{
	int SCRx,SCRy; // Screen x,y res.
	unsigned char bpp;// Bits Per Pixel
	Skin_SysNfo_tag(){
		SCRx=0;SCRy=0;bpp=0;
	}
};

#ifndef _SKIN_INIT_OBJ_
extern Skin_SysNfo_tag Skin_SysNfo;
#else
Skin_SysNfo_tag Skin_SysNfo;
#endif //_SKIN_INIT_OBJ_

#endif // EOF

/* README:
  * This is a skin system, #include it whereever you wanna use it, defs go like this:
  * define the variables defined above as extern, call the Skin::windowfunction before your
  * event loop passing everything to it, the Skin::fn will return -1 to messages it _doesn't_ process.
  * so if you have somekinda default: DefWinProc() or something change it to:
  * ret=Skin.fn();[........];defualt: if (ret==-1) DefWinProc();
  * that's it, you should be ready to go!
  * look at the example file (SkinMan.cpp) to see it run.
  */
