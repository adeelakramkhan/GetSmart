/*
  *   Skin Init functions.
  */

#define _SKIN_INIT_OBJ_

#include <direct.h>
#include "SkinDefs.h"
#include "Bitmaps.h"
#include "TxtProc.h"

// Globals:
//extern HBITMAP bmshow;
extern POINT MousePT;
extern char drag;
extern char dragtr;

//extern FILE *gfp;

/* Inits a skin */
int Skin::Init(Skinload &nfo,HINSTANCE hinst)
{
    int ret;
    ret=LDskin(nfo,hinst);
    return ret;
}


/* this will load a skinload from a file.
 * TODO: 
 *		[ ]	in loadtime, check if a bitmap is used multiple times and such things
 *		[ ] make alt functions in TxtProc.h that pass the size to each other to save down on strlen()s
 */

/* Loads a skin from a file
 */
long Skinload::LoadFile(const char*fn)
{
//	long sz;
	char*bf;
	long sz=PreProcess2Buff(bf,fn);
	if (sz==-1)
		return -1;
//	char _fn[_MAX_PATH];
//	strcpy(_fn,skins.basedir);
//	strcat(_fn,"Skin.post");
//	Buff2TxtFile(bf,_fn);
	Buff2TxtFile(bf,"./Skin.post"); // we don't care if this fails so far.
	if (Process(bf)==-1)
		return -1;

	delete[]bf;
    return 0;
}

/* Processes a postpreprocessor dot Skin phile.
 */
int Skinload::Process(char*bf)
{
	int havelims=-1; // flag for warning if lims rn't set up,
	char sep[]={" .,;{([\t\n"},*sc;
	long qq[]={6,8,4};
	keywords kwords("global\0skinlims\0skin\0",sizeof(qq)/sizeof(*qq),qq);
	long dex;
	sc=bf;
	while (sc[0]){
		dex=kwords.ScanInScope(sc,sep);
		if (dex==-1)
			return true; // no more words in scope
		while (sc[0] && (sc[0]!='{'))
			sc++;
		if (!sc[0]) return -1;
		sc++;
		switch (dex){
		case 0:
			// do global struct, set glob flag
			break;
		case 1:
			havelims=SetupLims(sc);
			if (havelims==-1)
				return -1;
			break;
		case 2:
			if (ReadSkin(sc)==-1)
				return -1;
			break;
		}
		SkipSubScope(sc);
		if (!sc[0]) return -1;
			sc++;
	}
	return 0;
}

int Skinload::SetupLims(char*bf)
{
	char sep[]={" =\t\n"},*sc;
	long qq[]={3,2,4,2,2,3};
	keywords kwords("rgn\0bt\0type\0pr\0tr\0txt\0",sizeof(qq)/sizeof(*qq),qq);
	long dex;
	char val;
	sc=bf;
	while (sc[0]){
		dex=kwords.ScanInScope(sc,sep);
		if (dex==-1)
			return true; // no more words in scope
		while (sc[0] && (sc[0]!='='))
			sc++;
		if (!sc[0]) return -1;
		sc++;
		val=atoi(sc);
		switch (dex){
		case 0:
			DOMAX(numrg,val);
                        if (numrg)
                                rg=new RGloadSt[numrg];
			break;
		case 1:
			DOMAX(numstbt,val);
                        if (numstbt)
                                stbt=new STBTloadSt[numstbt];
			break;
		case 2:
			type=atoi(sc);
			break;
		case 3:
			DOMAX(numpr,val);
                        if (numpr)
                                pr=new PRloadSt[numpr];
			break;
		case 4:
			DOMAX(numtr,val);
                        if (numtr)
                                tr=new TRloadSt[numtr];
			break;
		case 5:
			DOMAX(numtxt,val);
                        if (numtxt)
                                txt=new txtLD[numtxt];
			break;
		}
		while (sc[0] && (sc[0]!=';'))
			sc++;
		if (!sc[0]) return -1;
		sc++;
	}
	return 0;
}

int Skinload::ReadSkin(char*bf)
{
	int ret=0;
	char sep[]={" .,;{([\n"},*sc;
	long qq[]={3,3,4,6,3,7,4,7,3,2,10,2,2,3};
	keywords kwords("ver\0use\0name\0author\0bpp\0basedir\0date\0comment\0rgn\0bt\0btsubstate\0pr\0tr\0txt\0",
			sizeof(qq)/sizeof(*qq),qq);
	long dex,ind;
	sc=bf;
	while (sc[0]){
		dex=kwords.ScanInScope(sc,sep);
		if (dex==-1) 
			return true;
		if (dex>=8){
			ind=atoi(sc);
			if (dex!=10) // index for btsubstate
				while (sc[0] && (sc[0]!=','))
					sc++;
			else
				while (sc[0] && (sc[0]!='{'))
					sc++;
			if (!sc[0]) return -1;
			sc++;
		}
		switch (dex){
		case 0:
			ver=GetNextQuetedStr(sc);
			break;
		case 1:
			use=GetNextQuetedStr(sc);
			break;
		case 2:
			// do name;
			name=GetNextQuetedStr(sc);
			break;
		case 3:
			author=GetNextQuetedStr(sc);
			break;
		case 4:
			bpp=atoi(sc);
			break;
		case 5:
			if (basedir){
				char _basedir[_MAX_PATH];
				strcpy(_basedir,basedir);
				delete []basedir;
				basedir=GetNextQuetedStr(sc);
				if (basedir[0]=='/')
					break;
#ifdef _WIN32
				if ((basedir[0]=='\\') && (basedir[1]=='\\') || (basedir[1]==':'))
					break;
#endif // _WIN32
				strcat(_basedir,basedir);
				delete []basedir;
				basedir=_strdup(_basedir);
			}	
			else
				basedir=GetNextQuetedStr(sc);
			break;
		case 6:
			date=GetNextQuetedStr(sc);
			break;
		case 7:
			comment=GetNextQuetedStr(sc);
			break;	
		case 8:
			ret=rg[ind].proc(sc);
			break;
		case 9:
			ret=stbt[ind].proc(sc);
			break;
		case 10:
			ret=stbt[ind].procsubs(sc);
			break;
		case 11:
			ret=pr[ind].proc(sc);
			break;
		case 12:
			ret=tr[ind].proc(sc);
			break;
		case 13:
			ret=txt[ind].proc(sc);
			break;
		}
		if (ret==-1)
			return -1;
		while (sc[0] && (sc[0]!=';'))
			sc++;
		if (!sc[0]) return -1;
		sc++;
	}
	return 0;
}

int RGloadSt::proc(char*&bf)
{
#define NEXT_ARG \
p++;switch(SeekNextArg(bf)){\
	case 1:	return -1;\
	case -1: goto RG_SETDEFS;\
	}

	int p=0; // which parameter are we in.
	fn=GetNextQuetedStr(bf);
	NEXT_ARG;
	x=atoi(bf);
	NEXT_ARG;
	y=atoi(bf);
	NEXT_ARG;
	init=atoi(bf);
	NEXT_ARG;
	noscan=atoi(bf);
	return 0;
#undef NEXT_ARG
RG_SETDEFS:
	switch (p){
	case 1:
		x=0;
	case 2:
		y=0;
	case 3:
		init=7;
	case 4:
		noscan=0;
	default:
		return 0;
	}
}

int STBTloadSt::proc(char*&bf)
{
/* TODO:: convert these macros with another layer, like they'll be declared as:
 * " #define NEXT_ARG NXT_ARG(BT) "
 * simple, but find and replace..
 */
#define NEXT_ARG \
p++;switch(SeekNextArg(bf)){\
	case 1:	return -1;\
	case -1: goto BT_SETDEFS;\
	}

	int p=0;
	n=atoi(bf);
	NEXT_ARG;
	x=atoi(bf);
	NEXT_ARG;
	y=atoi(bf);
	NEXT_ARG;
	menu=atoi(bf);
	NEXT_ARG;
	scanshape=atoi(bf);
	p++;
#undef NEXT_ARG
BT_SETDEFS:		
	switch (p){
	case 0:
		n=0;
	case 1:
		x=0;
	case 2:
		y=0;
	case 3:
		menu=0;
	case 4:
		scanshape=0;
	}

	if (n==0)
		return -1;
	// now allocate struct for sub button fields:
	over=new char[n];//
	pushed=new char[n];//
	use=new short[n];//
	tint1=new unsigned long[n];
	tint2=new unsigned long[n];

	fn=new char*[n];
	ov_fn=new char*[n];
	p_fn=new char*[n];

	return 0;
}

int STBTloadSt::procsubs(char*&bf)
{
	// TODO:: check this bt is allocated before doing the sub..
#define NEXT_ARG \
p++;switch(SeekNextArg(bf)){\
	case 1:	return -1;\
	case -1: goto SUBST_SETDEFS;\
	}

	int p=0;
	while(bf[0] && (bf[0]!='}')){
	int subdex=atoi(bf);
	NEXT_ARG;
	fn[subdex]=GetNextQuetedStr(bf);
	NEXT_ARG;
	over[subdex]=atoi(bf);
	NEXT_ARG;
	pushed[subdex]=atoi(bf);
	NEXT_ARG;
	ov_fn[subdex]=GetNextQuetedStr(bf);
	NEXT_ARG;
	p_fn[subdex]=GetNextQuetedStr(bf);
	NEXT_ARG;
	use[subdex]=atoi(bf);
	NEXT_ARG;
	tint1[subdex]=atoi(bf);
	NEXT_ARG;
	tint2[subdex]=atoi(bf);
	while(bf[0] && (bf[0]!=';'))
		bf++;
	if (!bf[0]) return -1;
	bf++;
	while (bf[0] && ISWHITESP(bf[0]))
		bf++;
	if (!bf[0]) return -1;
	}
	if (!bf[0])return -1;
	bf++;
	return 0;
#undef NEXT_ARG
SUBST_SETDEFS:
	return -1;
	// for now..
}

int PRloadSt::proc(char*&bf)
{
#define NEXT_ARG \
p++;switch(SeekNextArg(bf)){\
	case 1:	return -1;\
	case -1: goto PR_DEFS;\
	}

	int	p=0;
	fn=GetNextQuetedStr(bf);
	NEXT_ARG;
	x=atoi(bf);
	NEXT_ARG;
	y=atoi(bf);
	NEXT_ARG;
	type=atoi(bf);
	return 0;	
#undef NEXT_ARG
PR_DEFS:
	switch (p){
	case 1:
		x=0;
	case 2:
		y=0;
	case 3:
		type=1;
	default:
		return 0;
	}

}

int TRloadSt::proc(char*&bf)
{
#define NEXT_ARG \
p++;switch(SeekNextArg(bf)){\
	case 1:	return -1;\
	case -1: goto TR_DEFS;\
	}

	int p=0;
	bgfn=GetNextQuetedStr(bf);
	NEXT_ARG;
	x=atoi(bf);
	NEXT_ARG;
	y=atoi(bf);
	NEXT_ARG;
	fgfn=GetNextQuetedStr(bf);
	NEXT_ARG;
	type=atoi(bf);
	NEXT_ARG;
	min=atoi(bf);
	NEXT_ARG;
	max=atoi(bf);
	NEXT_ARG;
	xo=atoi(bf);
	NEXT_ARG;
	yo=atoi(bf);
	NEXT_ARG;
	sep=atoi(bf);
	NEXT_ARG;
	col=atoi(bf);
	return 0;
#undef NEXT_ARG
TR_DEFS:
return -1;// for now
}

int txtLD::proc(char*&bf)
{
#define NEXT_ARG \
p++;switch(SeekNextArg(bf)){\
	case 1:	return -1;\
	case -1: goto TXT_DEFS;\
	}

	int p=0;
	use=atoi(bf);
	NEXT_ARG;
	fnt=GetNextQuetedStr(bf);
	NEXT_ARG;
	h=atoi(bf);
	NEXT_ARG;
	w=atoi(bf);
	NEXT_ARG;
	from=atoi(bf);
	NEXT_ARG;
	n=atoi(bf);
	NEXT_ARG;
	r.left=atoi(bf);
	NEXT_ARG;
	r.top=atoi(bf);
	NEXT_ARG;
	r.right=atoi(bf);
	NEXT_ARG;
	r.bottom=atoi(bf);
	NEXT_ARG;
	incol=atoi(bf);
	NEXT_ARG;
	outcol=atoi(bf);
	NEXT_ARG;
	rastop=atoi(bf);
	NEXT_ARG;
	def=atoi(bf);
	return 0;
#undef NEXT_ARG
TXT_DEFS:
	return -1;
	//... for now..
}

/* Loads a Skinload struct into action
*/
int Skin::LDskin(Skinload &nfo,HINSTANCE hinst /*instance to load rc*/)
{
	char curdir[_MAX_PATH];
	_getcwd(curdir,_MAX_PATH);
	_chdir(nfo.basedir);
    int i;
	int iW,oW,iH,oH;
    HBITMAP hbitmap,oldbdcbm;
    HDC bdc,t_indc,t_outdc;
    BITMAP bmstruct;
    HBITMAP Oldhbitmap1,Oldhbitmap2;
	
	type=nfo.type;
	/*if (type==1){
	Wmax=nfo.r.right,Hmax=nfo.r.bottom;
	inrgn=CreateRectRgnIndirect(&nfo.r);
	outrgn=CreateRectRgnIndirect(&nfo.r);
	}
	else*/{
	Wmax=0,Hmax=0;
	iW=0,oW=0,iH=0,oH=0;
	inrgn=CreateRectRgn(0,0,0,0);
	outrgn=CreateRectRgn(0,0,0,0);
	}
	HDC hdc=GetDC(NULL);
	Skin_SysNfo.SCRx=GetDeviceCaps(hdc,HORZRES);
	Skin_SysNfo.SCRy=GetDeviceCaps(hdc,VERTRES);
	Skin_SysNfo.bpp=GetDeviceCaps(hdc,BITSPIXEL);
    t_indc=CreateCompatibleDC(NULL);
	t_outdc=CreateCompatibleDC(NULL);
    
    bdc=CreateCompatibleDC(hdc);
	// mk  bitmaps for DCs:
	
	Oldhbitmap1=CreateCompatibleBitmap(hdc,Skin_SysNfo.SCRx,Skin_SysNfo.SCRy);
    Oldhbitmap1=SelectObject(t_indc,Oldhbitmap1);
	Oldhbitmap2=CreateCompatibleBitmap(hdc,Skin_SysNfo.SCRx,Skin_SysNfo.SCRy);
    Oldhbitmap2=SelectObject(t_outdc,Oldhbitmap2);
    
	PatBlt(t_indc,0,0,Skin_SysNfo.SCRx,Skin_SysNfo.SCRy,BLACKNESS);
	PatBlt(t_outdc,0,0,Skin_SysNfo.SCRx,Skin_SysNfo.SCRy,BLACKNESS);
	
    // load rgs:
/*	char tmp[1024];
	strcpy(tmp,"Loading bitmaps...");
	fwrite(tmp,1,strlen(tmp),gfp);*/
	numrg=nfo.numrg;
    rg=new rgn_b[numrg];
	for (i=0;i<numrg;i++){
		if (nfo.rg[i].fn==NULL)
			continue;
		if (nfo.rg[i].fromrc)
			hbitmap=LoadImage(hinst,nfo.rg[i].fn,IMAGE_BITMAP,0,0,LR_DEFAULTCOLOR);
		else
			hbitmap=LoadImage(NULL,nfo.rg[i].fn,IMAGE_BITMAP,0,0,LR_DEFAULTCOLOR|LR_LOADFROMFILE);
		if (!hbitmap)
			return -1; // Add somekinda info struct, which file wasn't found and such..!
		GetObject(hbitmap,sizeof(bmstruct),&bmstruct);
		if (!nfo.rg[i].noscan)
			Bitmap2Rgn(hbitmap,rg[i].rgn);
		else
			rg[i].rgn=CreateRectRgn(0,0,bmstruct.bmWidth,bmstruct.bmHeight);
		OffsetRgn(rg[i].rgn,nfo.rg[i].x,nfo.rg[i].y);
		hbitmap=SelectObject(bdc,hbitmap);
		if (nfo.rg[i].init&_S_RGIN){
			DOMAX(iW,bmstruct.bmWidth+nfo.rg[i].x);
			DOMAX(iH,bmstruct.bmHeight+nfo.rg[i].y);
			BltSeeThru(t_indc,nfo.rg[i].x,nfo.rg[i].y,bmstruct.bmWidth,bmstruct.bmHeight,
				bdc);
			CombineRgn(inrgn,inrgn,rg[i].rgn,RGN_OR);
		}
		if (nfo.rg[i].init&_S_RGOUT){
			DOMAX(oW,bmstruct.bmWidth+nfo.rg[i].x);
			DOMAX(oH,bmstruct.bmHeight+nfo.rg[i].y);
			BltSeeThru(t_outdc,nfo.rg[i].x,nfo.rg[i].y,bmstruct.bmWidth,bmstruct.bmHeight,
				bdc);
			CombineRgn(outrgn,outrgn,rg[i].rgn,RGN_OR);
		}
		DeleteObject(SelectObject(bdc,hbitmap));
		rg[i].init=nfo.rg[i].init;
	}
	Wmax=max(iW,oW);
	Hmax=max(iH,oH);

	// Making correct sized BMs after scanning maxes. another thing compiled skins'll be good for.
	indc=CreateCompatibleDC(NULL);
	inbm=CreateCompatibleBitmap(hdc,iW,iH);
	inbm=SelectObject(indc,inbm);
	BitBlt(indc,0,0,iW,iH,t_indc,0,0,SRCCOPY);
	Oldhbitmap1=SelectObject(t_indc,Oldhbitmap1);
	DeleteDC(t_indc);
	DeleteObject(Oldhbitmap1);

	outdc=CreateCompatibleDC(NULL);
	outbm=CreateCompatibleBitmap(hdc,oW,oH);
	outbm=SelectObject(outdc,outbm);
	BitBlt(outdc,0,0,oW,oH,t_outdc,0,0,SRCCOPY);
	//BltSeeThru(outdc,0,0,Wmax,Hmax,t_outdc);
	Oldhbitmap2=SelectObject(t_outdc,Oldhbitmap2);
	DeleteDC(t_outdc);
	DeleteObject(Oldhbitmap2);
	// wondering why i didn't make these two a macro??

	bmshow=CreateCompatibleBitmap(hdc,Wmax,Hmax);
    // ^^ this is used in the main loop, but should only be init'd once. here's just a nice place to init it.
	ReleaseDC(NULL,hdc);


	// Buttons:
/*	strcpy(tmp,"Loading buttons...");
	fwrite(tmp,1,strlen(tmp),gfp);*/
	numstbt=nfo.numstbt;
	stbt=new st_butt[numstbt];
	for (i=0;i<numstbt;i++){
		stbt[i].n=nfo.stbt[i].n;
		if (!stbt[i].n)	continue;
		stbt[i].menu=nfo.stbt[i].menu;
		stbt[i].plain=new HBITMAP[stbt[i].n];
		stbt[i].over=new HBITMAP[stbt[i].n];
		stbt[i].pushed=new HBITMAP[stbt[i].n];
		for (int j=0;j<stbt[i].n;j++){
			if (nfo.stbt[i].use[j]==-1){ // Note: 1st bitmap must NOT have a -1 here
				if (nfo.stbt[i].fromrc)
					hbitmap=LoadImage(hinst,nfo.stbt[i].fn[j],IMAGE_BITMAP,0,0,LR_DEFAULTCOLOR);
				else
					hbitmap=LoadImage(NULL,nfo.stbt[i].fn[j],IMAGE_BITMAP,0,0,LR_DEFAULTCOLOR|LR_LOADFROMFILE);
				if (!hbitmap)
					return -1; // Add somekinda info struct, which file wasn't found and such..!
				if (j==0){  // first BM sets sence rgn.
					GetObject(hbitmap,sizeof(bmstruct),&bmstruct);
					stbt[i].r.left=nfo.stbt[i].x;stbt[i].r.top=nfo.stbt[i].y;
					stbt[i].r.right=stbt[i].r.left+bmstruct.bmWidth;stbt[i].r.bottom=stbt[i].r.top+bmstruct.bmHeight;
					if (nfo.stbt[i].scanshape==0)
						stbt[i].rg=CreateRectRgnIndirect(&stbt[i].r);
					else{
						Bitmap2Rgn(hbitmap,stbt[i].rg);
						OffsetRgn(stbt[i].rg,stbt[i].r.left,stbt[i].r.top);
					}
				}
				oldbdcbm=SelectObject(bdc,hbitmap);
				stbt[i].plain[j]=dupBMfDC(bdc,bmstruct.bmWidth,bmstruct.bmHeight);
			}
			else{
				stbt[i].plain[j]=stbt[i].pushed[nfo.stbt[i].use[j]];
				hbitmap=dupBM(stbt[i].plain[j]);
				oldbdcbm=SelectObject(bdc,hbitmap);
			}
			switch (nfo.stbt[i].over[j]){
			case 0: // nothing
				stbt[i].over[j]=dupBM(stbt[i].plain[j]);
				break;
			case 1:  //  frame
				stbt[i].over[j]=mkRise(bdc,bmstruct.bmWidth,bmstruct.bmHeight);
				break;
			case 2: // glass tint
				stbt[i].over[j]=mkTintGlass(bdc,bmstruct.bmWidth,bmstruct.bmHeight,nfo.stbt[i].tint1[j]);
				break;
			case 3: // darkening tint
				stbt[i].over[j]=mkDarkGlass(bdc,bmstruct.bmWidth,bmstruct.bmHeight,RGB(127,255,127));
				break;
			case 4: // try emboss
				break;
			case 0xbf: // some other bitmap
				break;
			case 0xfa: // give function pointer to operate on bitmap
				// in a given mk<XXX>(hbitmap,h,w) format;
				break;
			}
			switch (nfo.stbt[i].pushed[j]){
			case 0: // nothing
				stbt[i].pushed[j]=dupBM(stbt[i].plain[j]);
				break;				
			case 1: // frame
				stbt[i].pushed[j]=mkSunk(bdc,bmstruct.bmWidth,bmstruct.bmHeight);
				break;
			case 2:
				stbt[i].pushed[j]=mkTintGlass(bdc,bmstruct.bmWidth,bmstruct.bmHeight,nfo.stbt[i].tint2[j]);
				break;
			case 3:
				break;
			case 4: // emboss
				break;
			case 0xbf: // some other bitmap
				break;
			case 0xfa: // give function pointer to operate on bitmap
				// in a given mk<XXX>(hbitmap,h,w) format;
				break;
			}
			DeleteObject(SelectObject(bdc,oldbdcbm)); // rm the previous loaded map
		}
	}
	
/*	strcpy(tmp,"Loading progressions...");
	fwrite(tmp,1,strlen(tmp),gfp);	*/
	numpr=nfo.numpr;
	//pr=(Progression**)malloc(sizeof(Progression*)*(numpr));
	pr=new Progression*[numpr];
	// _ALLO_, ^^^^^^^^  didn't u tell me these don't work??
	for (i=0;i<numpr;i++)
		pr[i]=NULL;
    // load Progression bars by type:
    for (i=0;i<numpr;i++){
		if (nfo.pr[i].fn==NULL) continue;
		if (nfo.pr[i].fromrc)
			hbitmap=LoadImage(hinst,nfo.pr[i].fn,IMAGE_BITMAP,0,0,LR_DEFAULTCOLOR);
		else
			hbitmap=LoadImage(NULL/*hinst*/,nfo.pr[i].fn,IMAGE_BITMAP,0,0,LR_DEFAULTCOLOR|LR_LOADFROMFILE);
		if (!hbitmap)
			return -1; // Add somekinda info struct, which file wasn't found and such..!
		//        SelectObject(bdc,hbitmap);
        GetObject(hbitmap,sizeof(bmstruct),&bmstruct);
        switch (nfo.pr[i].type&0x0f){
        case 1: // round
#define _PR ((RoundProgression*)pr[i])
            pr[i]=new RoundProgression;
            _PR->beg.x=(bmstruct.bmWidth>>1);
            _PR->beg.y=0;
#undef _PR
            break;
        case 2: //str8            
#define _PR ((Str8Progression*)pr[i])
			pr[i]=new Str8Progression;
#undef _PR
            break;
        case 3:// rect            
#define _PR ((RectProgression*)pr[i])
#undef _PR
            break;
        }
        switch (nfo.pr[i].type&0xf0){
        case 1: // colors
            break;
        case 2:
            break;
        }
        // common part:
		pr[i]->pic=hbitmap;
        SETRECT(pr[i]->r,nfo.pr[i].x,nfo.pr[i].y,nfo.pr[i].x+bmstruct.bmWidth,nfo.pr[i].y+bmstruct.bmHeight);
        pr[i]->sz.x=pr[i]->r.right-pr[i]->r.left;pr[i]->sz.y=pr[i]->r.bottom-pr[i]->r.top;
    }
	
/*	strcpy(tmp,"Loading tracks...");
	fwrite(tmp,1,strlen(tmp),gfp);*/
    numtr=nfo.numtr;
    //tr=(SlideTrack**)malloc(sizeof(SlideTrack*)*(numtr));
	tr=new SlideTrack*[numtr];
	for (i=0;i<numtr;i++)
		tr[i]=NULL;
	// now the track bars:
    for (i=0;i<numtr;i++){
		if (nfo.tr[i].bgfn==NULL) continue;
        switch (nfo.tr[i].type&0x0f){
        case 1: // H
            tr[i]=new Htr;
            break;
        case 2: // V
            tr[i]=new Vtr;
            break;
        }
		if (nfo.tr[i].fromrc)
			hbitmap=LoadImage(hinst,nfo.tr[i].bgfn,IMAGE_BITMAP,0,0,LR_DEFAULTCOLOR);
		else
			hbitmap=LoadImage(NULL,nfo.tr[i].bgfn,IMAGE_BITMAP,0,0,LR_DEFAULTCOLOR|LR_LOADFROMFILE);
		if (!hbitmap)
			return -1; // Add somekinda info struct, which file wasn't found and such..!
        oldbdcbm=SelectObject(bdc,hbitmap);
        GetObject(hbitmap,sizeof(bmstruct),&bmstruct);
        tr[i]->r.left=nfo.tr[i].x;tr[i]->r.top=nfo.tr[i].y;
        tr[i]->r.right=tr[i]->r.left+bmstruct.bmWidth;tr[i]->r.bottom=tr[i]->r.top+bmstruct.bmHeight;
        BltSeeThru(indc,tr[i]->r.left,tr[i]->r.top,bmstruct.bmWidth,bmstruct.bmHeight,bdc);
		BltSeeThru(outdc,tr[i]->r.left,tr[i]->r.top,bmstruct.bmWidth,bmstruct.bmHeight,bdc);
        DeleteObject(SelectObject(bdc,oldbdcbm)); // rm the previous loaded map
        tr[i]->min=nfo.tr[i].min;tr[i]->max=nfo.tr[i].max;
		if (nfo.tr[i].fromrc)
			hbitmap=LoadImage(hinst,nfo.tr[i].fgfn,IMAGE_BITMAP,0,0,LR_DEFAULTCOLOR);
		else
			hbitmap=LoadImage(NULL,nfo.tr[i].fgfn,IMAGE_BITMAP,0,0,LR_DEFAULTCOLOR|LR_LOADFROMFILE);
		if (!hbitmap)
			return -1; // Add somekinda info struct, which file wasn't found and such..!
        tr[i]->pic=hbitmap;
        GetObject(hbitmap,sizeof(bmstruct),&bmstruct);
        tr[i]->w=bmstruct.bmWidth;tr[i]->h=bmstruct.bmHeight;
        tr[i]->xoff=nfo.tr[i].xo;tr[i]->yoff=nfo.tr[i].yo;
        if (nfo.tr[i].sep!=SHRT_MAX){
            tr[i]->DrawSep(indc,nfo.tr[i].sep,nfo.tr[i].col);
			tr[i]->DrawSep(outdc,nfo.tr[i].sep,nfo.tr[i].col);
		}
    }

	numtxt=nfo.numtxt;
	txt=new txt_tag[numtxt];
	// and texts...
    for (i=0;i<numtxt;i++){
		if ((nfo.txt[i].fnt==NULL) && (nfo.txt[i].use!=-1)) continue;
		txt[i].incol=nfo.txt[i].incol;
		txt[i].outcol=nfo.txt[i].outcol;
		txt[i].rastop=nfo.txt[i].rastop;
		txt[i].def=nfo.txt[i].def;
		if (nfo.txt[i].use==-1){
			txt[i].hfont=CreateFont(nfo.txt[i].h,nfo.txt[i].w,0,0,FW_BOLD,0,0,0,ANSI_CHARSET,
									OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,
									DEFAULT_QUALITY,DEFAULT_PITCH|FF_DONTCARE,
									nfo.txt[i].fnt);
			txt[i].wedel=-1;
		}
		else{
			txt[i].hfont=txt[nfo.txt[i].use].hfont;
			txt[i].wedel=0;
		}
		switch (nfo.txt[i].from){
		case 0: // rect
			txt[i].r=nfo.txt[i].r;
			break;
		case 1: // button
            txt[i].r=stbt[nfo.txt[i].n].r;
			txt[i].r.left+=nfo.txt[i].r.left;
			txt[i].r.top+=nfo.txt[i].r.top;
			txt[i].r.right+=nfo.txt[i].r.right;
			txt[i].r.bottom+=nfo.txt[i].r.bottom;
			break; // 2,3 :           |3/>.|=/-||< !
		}
	}


	// calculate mvrgn:= inrgn - <all sence areas>
	mvrgn=CreateRectRgn(0,0,0,0);
	if (type==0){
		CombineRgn(mvrgn,mvrgn,inrgn,RGN_OR);
		HRGN rmrgn;
		for (i=0;i<numstbt;i++){
			if (!stbt[i].n) continue;
			CombineRgn(mvrgn,mvrgn,stbt[i].rg,RGN_DIFF);
		}
		for (i=0;i<numtr;i++){
			if (tr[i]==NULL) continue;
			rmrgn=CreateRectRgnIndirect(&tr[i]->r);
			CombineRgn(mvrgn,mvrgn,rmrgn,RGN_DIFF);
			DeleteObject(rmrgn);
		}
	}
/*	strcpy(tmp,"Finished init...\n");
	fwrite(tmp,1,strlen(tmp),gfp);*/
/* we should do this always, not only on success..
 * we need a terminator for this func..  a wrapper with access to locals...
 *	hmm.., or try/catch stuff... but this should be in "finally"..
 */
    DeleteDC(bdc);
    _chdir(curdir);
    return 0;
}

/* Cleanup function, i hope it'll workout plain n easy..
 * Warnings: close all instaces of this skin before calling.
 * Note: Test each return value, on NT..
 * Warning:: untested, but it doesn't crash the system..
 */
int Skin::Kill()
{
	int i;
	i=DeleteObject(inrgn);
	i=DeleteObject(outrgn);
	i=DeleteObject(mvrgn);
	//DeleteObject(SelectObject(indc,inbm));
	inbm=SelectObject(indc,inbm);
	i=DeleteObject(inbm);
	//DeleteObject(SelectObject(outdc,outbm));
	outbm=SelectObject(outdc,outbm);
	i=DeleteObject(outbm);
	i=DeleteDC(indc);
	i=DeleteDC(outdc);
	i=DeleteObject(bmshow);

	//delete []tr;
	//delete []pr;

	for(i=0;i<numtr;i++){
		if (tr[i]==NULL) continue;
		delete tr[i];
	}

	for(i=0;i<numpr;i++){
		if (pr[i]==NULL) continue;
		delete pr[i];
	}
	delete[]tr;
	delete[]pr;

	delete []rg;
	delete []stbt;
	delete []txt;

	return true;
}



