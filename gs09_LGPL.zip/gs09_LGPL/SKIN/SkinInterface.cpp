/*
 * Skin System, Interface file,
 * here are the interface functions that other programs'll access.
 */
#include "SkinDefs.h"

void Skin::prtot(/*HWND hwnd,*/SkinWinNfo*s,unsigned short dex,unsigned short act,unsigned long val)
{
//	SkinWinNfo*s;
//	s=(SkinWinNfo*) GetWindowLong(hwnd,GWL_USERDATA);	
	switch (act){
		case 0:			s->pr[dex].cur=val; break;
		case 1:			s->pr[dex].cur+=val; break;
		case 2:			s->pr[dex].cur-=val; break;
		case 3:			s->pr[dex].cur|=val; break;
		case 4:			s->pr[dex].cur^=val; break;
		case 5:			s->pr[dex].cur&=val; break;
		}
	InvalidateRect(s->hwnd,&pr[dex]->r,false);
}
