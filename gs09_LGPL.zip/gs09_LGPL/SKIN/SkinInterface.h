
struct SkinWinNfo;

// definitions for SKN_* messages in apps using this window class:
#define SKN_BASE WM_USER+0x100
// Messages send by the SkinFunc
#define _SKN_BASE WM_USER+0x200
// Messages addressed for the SkinFunc

#define SKN_BTUP SKN_BASE+0
#define SKN_BTDN SKN_BASE+1
// a button was pressed, wParam=(bt_id,newstate) lParam=(xmouseoffset,ymouseoffset)
#define SKN_BTOV SKN_BASE+2
// we are over a button!
#define SKN_TRUP SKN_BASE+3
// a track value was updated, wParam=(tr_id,0) lParam=newval
#define SKN_TRLV SKN_BASE+4
// track leave, wParam=(tr_id,0) lParam=newval
#define SKN_XPAINT SKN_BASE+20
/* Extra painting to be down, send from inside the WM_PAINT event of the SkinWinFunc
  * wParam=HDC, lParam=*PAINTSTRUCT
  * the DC has a bitmap select into it, so just copy stuff in, and don't leave
  * anything inside.
  */

// actions: 0- set 1- add, 2- sub, 3- or, 4- xor, 5- and
#define _SKN_TRJMP _SKN_BASE+0
// make tracker no wParam=(tr_id,action) jmp to value lParam
#define _SKN_PRCUR _SKN_BASE+1
// set progression bar cur value: wParam=(pr_id,action) lParam=val
#define _SKN_PRTOT _SKN_BASE+2
// set progression bar tot value: wParam=(pr_id,action) lParam=val
// Skin::prtot()
#define _SKN_TXT _SKN_BASE+3
// update text no. LOWORD(wParam) to string pointed by lParam
#define _SKN_TXTUP _SKN_BASE+4
// update txt no. LOWOWRD(wParam)
#define _SKN_TXTP _SKN_BASE+5
// change text properties wParam=(txt_id,which property?) lParam=new pr
//																		1=col; 2=rastop
#define _SKN_RGN _SKN_BASE+6
// show/hide a certain rgn in skin wParam=(rgn_id,act) lParam=(where,?) : where: 0=_S_RG* vals
#define _SKN_BTSET _SKN_BASE+7
// change button status: wParam=(bt_id,action) lParam=val
#define _SKN_RESIZE _SKN_BASE+8
#define _SKN_BTMV _SKN_BASE+9
// wParam=(bt_id,0) lParam=(xoff,yoff)

#define _S_RGSHOW 1
#define _S_RGIN 2
#define _S_RGOUT 4


// Macros for runtime skin loading::
#define rgSet(rg,_f,_x,_y,_i,_rc,_noscan)\
	rg.fn=_strdup(_f);\
	rg.x=_x;rg.y=_y;rg.init=_i;\
	rg.fromrc=_rc;rg.noscan=_noscan

#define PRSet(pr,_fn,_x,_y,_t1,_t2,_rc)\
    pr.fn=_strdup(_fn);\
    pr.x=_x;pr.y=_y;\
    pr.type=_t1+(_t2<<4);pr.fromrc=_rc

#define TRSet(tr,_bg,_x,_y,_fg,_t,_min,_max,_xo,_yo,_sep,_col,_rc)\
    tr.x=_x;tr.y=_y;tr.xo=_xo;tr.yo=_yo;tr.type=_t;tr.min=_min;tr.max=_max;tr.sep=_sep;\
    tr.bgfn=_strdup(_bg);tr.fgfn=_strdup(_fg);\
	tr.col=_col;tr.fromrc=_rc

#define STButtSet(bt,_n,_x,_y,_m,_rc,_sh)\
    bt.n=_n;bt.x=_x;bt.y=_y;bt.menu=_m;\
	bt.fn=(char**)malloc(sizeof(char*)*(_n));\
	bt.ov_fn=(char**)malloc(sizeof(char*)*(_n));\
	bt.p_fn=(char**)malloc(sizeof(char*)*(_n));\
	bt.over=(char*)malloc(_n);\
	bt.pushed=(char*)malloc(_n);\
	bt.use=(short*)malloc(_n*2);\
	bt.tint1=(unsigned long*)malloc(_n*sizeof(long));\
	bt.tint2=(unsigned long*)malloc(_n*sizeof(long));\
        bt.fromrc=_rc;bt.scanshape=_sh

#define SubST_st(bt,_i,_fn,_op,_pp,_ofn,_pfn,_use,_t1,_t2)\
	bt.fn[_i]=_strdup(_fn);\
	bt.over[_i]=_op;bt.pushed[_i]=_pp;\
	bt.ov_fn[_i]=_strdup(_ofn);bt.p_fn[_i]=_strdup(_pfn);\
	bt.use[_i]=_use;bt.tint1[_i]=_t1;bt.tint2[_i]=_t2

#define TXT_tagset(txt_,_use,_fnt,_h,_w,_fr,_n,_rl,_rt,_rr,_rb,_incol,_outcol,_rastop,_def)\
	txt_.use=_use;\
	txt_.fnt=_strdup(_fnt);\
	txt_.h=_h;txt_.w=_w;txt_.from=_fr;txt_.n=_n;txt_.r.left=_rl;txt_.r.top=_rt;txt_.r.right=_rr;txt_.r.bottom=_rb;\
	txt_.incol=_incol;txt_.outcol=_outcol;txt_.rastop=_rastop;txt_.def=_def

// button states:
#define BT_OUT 1
#define BT_OVER 2
#define BT_PUSHED 3
