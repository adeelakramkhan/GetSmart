// just an example/testapp for how to use the new skin class.
// the skin "manager" main window that lets us create new windows from types we define/load
// this is just a small test app for the SkinClass

#define _main_skinman
#include "SkinMan.h"

#if 0
// example that inits a skin on runtime.
int InitExampleSkin(Skinload &nfo)
{
	nfo.name=_strdup("Skin1");
	// types: 0 = let the skin resize and re-region. 1 = don't. (do it yourself)
	nfo.type=0;

    nfo.numrg=4;
    nfo.rg=(RGloadSt*)malloc(sizeof(RGloadSt)*(nfo.numrg));
	// rg <rg_id> <bm filen> <xoff> <yoff> <init state: by _S_RG* macros>
	rgSet(nfo.rg[0],"s2_bg.bmp",5,30,_S_RGSHOW|_S_RGIN|_S_RGOUT,0,0);
	rgSet(nfo.rg[1],"s2_cp_i.bmp",0,0,_S_RGSHOW|_S_RGIN,0,0);
	rgSet(nfo.rg[2],"s2_cp_o.bmp",5,0,_S_RGSHOW|_S_RGOUT,0,0);

	rgSet(nfo.rg[3],"s2_bginrc.bmp",280,90,_S_RGIN|_S_RGOUT,0,0);
	//rgSet(nfo.rg[3],BGINRC_RC,280,90,_S_RGSHOW|_S_RGIN|_S_RGOUT,1);
	// allo! replace these ^^^^ two lines, it should work when you define a .rc script

	nfo.numstbt=8;
	nfo.stbt=(STBTloadSt*)malloc(sizeof(STBTloadSt)*(nfo.numstbt));
	// multi (n) state button:
	// stbt <stbt_id> <n> <x> <y> <menu: 0=non;1=H;2=V;>
	// {...; _st <i> <bm i filename>  <over policy> <pushed policy> <over bm> <pushed bm> <use a pushed bm: -1= don't,
	// otherwise fn is ignored>;...} -- note: first state must NOT have a -1 here
	// policies: 0 nothing, 1=frame, 2= glass, 3=dark (no tint param for these _YET_), 4= emboss (not implemented yet)
	//					0xbf = another bitmat; 0xfa = function; (both not implemented yet)
	STButtSet(nfo.stbt[0],1,190,5,0,0);
	SubST_st(nfo.stbt[0],0,"s2_kill.bmp",1,1,"","",-1,0,0);
	STButtSet(nfo.stbt[1],1,160,5,0,0);
	SubST_st(nfo.stbt[1],0,"s2_min.bmp",1,1,"","",-1,0,0);
	STButtSet(nfo.stbt[2],1,130,5,0,0);
	SubST_st(nfo.stbt[2],0,"s2_sh.bmp",1,1,"","",-1,0,0);
	STButtSet(nfo.stbt[3],1,100,55,0,0);
	SubST_st(nfo.stbt[3],0,"s2_smile.bmp",2,2,"","",-1,RGB(0,0,255),RGB(255,0,0));
	STButtSet(nfo.stbt[4],7,50,55,0,0);
	SubST_st(nfo.stbt[4],0,"s2_s1.bmp",1,1,"","",-1,0,0);
	SubST_st(nfo.stbt[4],1,"s2_s2.bmp",1,1,"","",-1,0,0);
	SubST_st(nfo.stbt[4],2,"s2_s3.bmp",1,1,"","",-1,0,0);
	SubST_st(nfo.stbt[4],3,"s2_s4.bmp",1,1,"","",-1,0,0);
	SubST_st(nfo.stbt[4],4,"s2_s5.bmp",1,1,"","",-1,0,0);
	SubST_st(nfo.stbt[4],5,"s2_s6.bmp",1,1,"","",-1,0,0);
	SubST_st(nfo.stbt[4],6,"",1,1,"","",3,0,0);
	STButtSet(nfo.stbt[5],1,50,90,0,0);
	SubST_st(nfo.stbt[5],0,"s2_4txt.bmp",1,1,"","",-1,0,0);
	STButtSet(nfo.stbt[6],2,150,50,0,0);
	SubST_st(nfo.stbt[6],0,"s2_pushstatetst.bmp",1,1,"","",-1,0,0);
	SubST_st(nfo.stbt[6],1,"",2,2,"","",0,0,0); // ^^ uses this pushed state
	STButtSet(nfo.stbt[7],2,187,50,0,0);
	SubST_st(nfo.stbt[7],0,"s2_nonspbutt.bmp",1,1,"","",-1,0,0);
	SubST_st(nfo.stbt[7],1,"",2,2,"","",0,0,0); // ^^ uses this pushed state

    nfo.numpr=1;
	    nfo.pr=(PRloadSt*)malloc(sizeof(PRloadSt)*(nfo.numpr));
	// pr <pr_id> <bm filename> <x> <y> <type param1> <type param2> <fromrc>
	   PRSet(nfo.pr[0],"R_prog.bmp",180,60,1,0,0);
	
    nfo.numtr=2;
    nfo.tr=(TRloadSt*)malloc(sizeof(TRloadSt)*(nfo.numtr));
	// tr <tr_id> <bgbm filename> <x> <y> <fgbm filename> <type: 1=H/2=V> <min> <max> <xoff> <yoff> <sep>(SHRT_MAX=none) <col>
    TRSet(nfo.tr[0],"Vbar1.bmp",20,40,"Vbar2.bmp",2,1,5,0,0,-5,RGB(0,255,120),0);
		//"Vbar2slime.bmp",2,1,5,0,0,-5);
	TRSet(nfo.tr[1],"Hbar1.bmp",300,100,"Hbar2.bmp",1,1,5/*max*/,0,0,1,RGB(0,0,0),0);

	nfo.numtxt=1;
	nfo.txt=(txtLD*)malloc(sizeof(txtLD)*nfo.numtxt);
	// txtb <txtb_id> <use> <font> <h> <w> <from> <n> <r:: l t r b>
	// from: 0=rect; 1=button[n], rect is used as offset.
	// use: -1=create; otherwise, use another txt's
	TXT_tagset(nfo.txt[0],-1,"MS Sans Serif",15,0,1,5,10,5,0,0,0,0,0,0);

    return true;
}

// example that inits a skin on runtime.
int InitExampleInWindowSkin(Skinload &nfo)
{
	nfo.name=_strdup("InWindowSkin1");
	nfo.basedir=_strdup("c:/oyd11/graph/tstskin/");
	// types: 0 = let the skin resize and re-region. 1 = don't. (do it yourself)
	nfo.type=1;

    nfo.numrg=1;
    nfo.rg=(RGloadSt*)malloc(sizeof(RGloadSt)*(nfo.numrg));
	// rg <rg_id> <bm filen> <xoff> <yoff> <init state: by _S_RG* macros>
	rgSet(nfo.rg[0],"inw_bg.bmp",5,5,_S_RGSHOW|_S_RGIN|_S_RGOUT,0,0);

	nfo.numstbt=2;
	nfo.stbt=(STBTloadSt*)malloc(sizeof(STBTloadSt)*(nfo.numstbt));
	// multi (n) state button:
	// stbt <stbt_id> <n> <x> <y> <menu: 0=non;1=H;2=V;>
	// {...; _st <i> <bm i filename>  <over policy> <pushed policy> <over bm> <pushed bm> <use a pushed bm: -1= don't,
	// otherwise fn is ignored>;...} -- note: first state must NOT have a -1 here
	// policies: 0 nothing, 1=frame, 2= glass, 3=dark (no tint param for these _YET_), 4= emboss (not implemented yet)
	//					0xbf = another bitmat; 0xfa = function; (both not implemented yet)
	STButtSet(nfo.stbt[0],1,150,10,0,0);
	SubST_st(nfo.stbt[0],0,"inw_bt1.bmp",1,1,"","",-1,0,0);
	STButtSet(nfo.stbt[1],1,100,10,0,0);
	SubST_st(nfo.stbt[1],0,"inw_bt2.bmp",1,1,"","",-1,0,0);

    nfo.numpr=1;
	    nfo.pr=(PRloadSt*)malloc(sizeof(PRloadSt)*(nfo.numpr));
	// pr <pr_id> <bm filename> <x> <y> <type param1> <type param2> <from rc>
	   PRSet(nfo.pr[0],"inw_pr1.bmp",10,60,2,0,0);
	
    nfo.numtr=0;
//    nfo.tr=(TRloadSt*)malloc(sizeof(TRloadSt)*(nfo.numtr));
	// tr <tr_id> <bgbm filename> <x> <y> <fgbm filename> <type: 1=H/2=V> <min> <max> <xoff> <yoff> <sep>(SHRT_MAX=none)

	nfo.numtxt=0;
//	nfo.txt=(txtLD*)malloc(sizeof(txtLD)*nfo.numtxt);
	// txtb <txtb_id> <use> <font> <h> <w> <from> <n> <r:: l t r b>
	// from: 0=rect; 1=button[n], rect is used as offset.
	// use: -1=create; otherwise, use another txt's
	//TXT_tagset(nfo.txt[0],-1,"MS Sans Serif",15,0,1,5,10,5,0,0);

    return true;
}
#endif //0

int WINAPI WinMain(HINSTANCE hThisInst, HINSTANCE hPrevInst,
                   LPSTR lpszArgs, int nWinMode)
{
    HWND hwnd;
    MSG msg;
    WNDCLASS wcl;
#ifdef _DEBUG
SET_CRT_DEBUG_FIELD(_CRTDBG_ALLOC_MEM_DF|_CRTDBG_LEAK_CHECK_DF);
_CrtSetReportMode(_CRT_WARN,_CRTDBG_MODE_FILE|_CRTDBG_MODE_WNDW);
_CrtSetReportMode(_CRT_ERROR,_CRTDBG_MODE_FILE|_CRTDBG_MODE_WNDW);
_CrtSetReportMode(_CRT_ASSERT,_CRTDBG_MODE_FILE|_CRTDBG_MODE_WNDW);

#endif // _DEBUG
    hinst=hThisInst;
    wcl.hInstance=hThisInst;
    wcl.lpszClassName="SkinMan";
    wcl.lpfnWndProc=SkinManFunc;
    wcl.style=0;
    
    wcl.hIcon=NULL;
    wcl.hCursor=LoadCursor(NULL,IDC_ARROW);
    wcl.cbClsExtra=0;
    wcl.cbWndExtra=0;
    
    wcl.hbrBackground=GetStockObject(WHITE_BRUSH);
    
    if (!RegisterClass(&wcl)) return 0;
        
	wcl.hInstance=hThisInst;
    wcl.lpszClassName="Skind1";
    wcl.lpfnWndProc=SkinableFunc;
    wcl.style=0;
    
    wcl.hIcon=NULL;
    wcl.hCursor=LoadCursor(NULL,IDC_ARROW);
    wcl.cbClsExtra=0;
    wcl.cbWndExtra=0;
    
    wcl.hbrBackground=GetStockObject(NULL_BRUSH);
    
    if (!RegisterClass(&wcl)) return 0;

	wcl.hInstance=hThisInst;
    wcl.lpszClassName="Skin2";
    wcl.lpfnWndProc=SkinableFunc2;
    wcl.style=0;
    
    wcl.hIcon=NULL;
    wcl.hCursor=LoadCursor(NULL,IDC_ARROW);
    wcl.cbClsExtra=0;
    wcl.cbWndExtra=0;
    
    wcl.hbrBackground=GetStockObject(NULL_BRUSH);
    
    if (!RegisterClass(&wcl)) return 0;
	

/*	if (!nfo1.LoadFile("./Skin1.Skin")){
		MessageBox(NULL,"Error processing ./Skin1.Skin phile!","Allo!, Shutdown!",MB_OK);
		exit(1);
	}*/

//	InitExampleSkin(nfo1);
    //if (!Skin1.Init(nfo1)) return 0;

//	Skinload nfotst("./Skin2.Skin");
//	 Skinload nfotst("./NewST.WiCKED.gsk");
//	nfo1.basedir=_strdup("c:/oyd11/graph/gs/");
	//nfo1.LoadFile("./NewST.WiCKED.gsk");
		nfo1.basedir=_strdup("c:/gs08/Skins/");
		//	nfo1.LoadFile("./11.skin");
		if (nfo1.LoadFile("./11.skin")==-1){
			MessageBox(NULL,"Error processing ./Skin1.Skin phile!","Allo!, Shutdown!",MB_OK);
			exit(1);
		}
	//nfo1.LoadFile("c:/gs08/Skins/Tin2.gsk");
//	nfo1.LoadFile("c:/gs08/Skins/NEWST.GSK");
	//nfo1.LoadFile("./NewST.WiCKED.gsk");
//	if (!Skin1.Init(nfo1)) return 0;

/*	InitExampleInWindowSkin(nfo1);
    if (!Skin2.Init(nfo1)) return 0;
*/
    hwnd=CreateWindow("SkinMan",
        "Skin Manager",
        WS_VISIBLE |WS_OVERLAPPEDWINDOW,//WS_BORDER|WS_SIZEBOX,//|WS_POPUP,
        50,100,
        420,
        180,
        HWND_DESKTOP,
        NULL,hThisInst,NULL);

    //ShowWindow(hwnd,nWinMode);
    //UpdateWindow(hwnd);
    
    while (GetMessage(&msg,NULL,0,0))
    {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

//	Skin1.Kill();
//	Skin2.Kill();

    return msg.wParam;
}

LRESULT CALLBACK SkinManFunc(HWND hwnd,UINT message,
                             WPARAM wParam,LPARAM lParam)
{
	static char isinit=0;

			static char qweqwe[]={"Allo is moshe!!"};
		static char qweqwe4[]={"is not very qwerty right now!!! moshe!!"};
		static char qweqwe3[]={"short"};
		static char qweqwe2[]={"er"};
		static char qweqwe1[]={"is Allo\nis qwerty\nu moshe!!\nis qwerty!!!!!"};
		static char qweqwe5[]={"this is some text\nwith multi lines!\nand\nmore\nand more\nand more\nlines!!\n1\n2\n3\nqweqwe"};


	switch (message){
	case WM_CREATE:
		S=new SkinWinNfo[20];

		
		// PopUpTip p1("MS Sans Serif",13,0);
		// decl'd global ^^^^^^^ instade
		p1=new PopUpTip("MS Sans Serif",13,0);
		p1->bgcol=RGB(0,255,255);
		p1->fgcol=RGB(0,0,255);
		p1->x=700;p1->y=500;
/*		p1->xhow=POPTIP_POINT_IS_BEG;
		p1->yhow=POPTIP_POINT_IS_BEG;*/
				p1->xhow=POPTIP_POINT_IS_END;
		p1->yhow=POPTIP_POINT_IS_END;
/*				p1->xhow=POPTIP_POINT_IS_CENTER;
		p1->yhow=POPTIP_POINT_IS_CENTER;
*/
		//		p1->time_w=1500;p1->time_xtra=3500;
//		p1->timehow=POPTIP_TIMEVAL_IS_TOT;
				p1->time_w=20;p1->time_xtra=50;
				p1->xpad=30;p1->ypad=10;
		p1->timehow=POPTIP_TIMEVAL_IS_LETTER;


		p1->init("Smart Tips!");

		SendMessage(hwnd,WM_KEYUP,'A',0);
		break;

	case WM_DESTROY:
		if (isinit)
			Skin1.Kill();
		delete[]S;
		delete p1;
		PostQuitMessage(0);
		break;
		
    case WM_LBUTTONDOWN:
		if (!isinit){
			MessageBox(NULL,"Please init 1st! (press A)","INIT!",MB_OK);
			break;
		}
        if (wcnt<20){
            S[wcnt].hwnd=CreateWindow("Skind1",
                "lalalalaaAAALLAAA!!!",
                WS_POPUP,
                20+(wcnt<<1),10+(wcnt<<1),
                0, 0, // <- this skin is typed "0"
                HWND_DESKTOP,
                NULL,hinst,(void*)&S[wcnt]);
            ShowWindow(S[wcnt].hwnd,SW_SHOW);
            wcnt++;
        }
        else 
            MessageBox(hwnd,"...","20 windows should be enough for everybody!",MB_OK);
        break;

	case WM_KEYUP:
		switch (wParam){
		case 'A':
			if (isinit){
				MessageBox(NULL,"Already init!!!","Warning!:",MB_OK);
				break;
			}
			if (Skin1.Init(nfo1,NULL)==-1){
				MessageBox(NULL,"Error loading something in from skin specs!","Allo!, Shutdown!",MB_OK);
				exit(1);
			}
			isinit=1;
			break;
		case 'Q':
			if (!isinit){
				MessageBox(NULL,"not init","ignoring!",MB_OK);
				break;
			}
			Skin1.Kill();
			isinit=0;
			break;
		case 'Z':
			SendMessage(p1->hwnd,POPTIP_TXTUPDATE,(WPARAM)qweqwe,0);
			break;
		case 'X':
			SendMessage(p1->hwnd,POPTIP_TXTUPDATE,(WPARAM)qweqwe4,0);
			break;
		case 'C':
			SendMessage(p1->hwnd,POPTIP_TXTUPDATE,(WPARAM)qweqwe3,0);
			break;
		case 'V':
			SendMessage(p1->hwnd,POPTIP_TXTUPDATE,(WPARAM)qweqwe2,0);
			break;
		case 'B':
			SendMessage(p1->hwnd,POPTIP_TXTUPDATE,(WPARAM)qweqwe1,0);
			break;
		case 'M':
			SendMessage(p1->hwnd,POPTIP_TXTUPDATE,(WPARAM)qweqwe5,0);
			break;
		case 37: // left arrow
			p1->x-=10; 			SendMessage(p1->hwnd,POPTIP_SHOWNOW,1,0);break;
		case 38: // up arrow
			p1->y-=10; 			SendMessage(p1->hwnd,POPTIP_SHOWNOW,1,0);break;
		case 39:// right arrow
			p1->x+=10; 			SendMessage(p1->hwnd,POPTIP_SHOWNOW,1,0);break;
		case 40: // down arrow
			p1->y+=10; 			SendMessage(p1->hwnd,POPTIP_SHOWNOW,1,0);break;
		case 'N':
			SendMessage(p1->hwnd,POPTIP_TONEXT,1,0);
			break;
		case 'P': // pause
			p1->Suspend(true);
			break;
		case 'U':// unpause
			p1->Suspend(false);
			break;
		case 'R': // ReShow Last
			SendMessage(p1->hwnd,POPTIP_RESHOWLAST,0,0);
			break;
		}
		return 0;

    case WM_RBUTTONDOWN:
		//AnimateWindow( hwnd,200,AW_BLEND);
		// damn... this soundz kewl... make it work...
/*        if (w2cnt<20){			
            S2[w2cnt].hwnd=CreateWindow("Skin2",
                "lalalalaaAAALLAAA!!!",
                WS_OVERLAPPEDWINDOW,
                220+(w2cnt<<1),10+(w2cnt<<1),
                400,300,
                HWND_DESKTOP,
                NULL,hinst,(void*)&S2[w2cnt]);
            ShowWindow(S2[w2cnt].hwnd,SW_SHOW);
            w2cnt++;
        }
        else 
            MessageBox(hwnd,"...","20 windows should be enough for everybody!",MB_OK);
        break;
*/
    default:
        return DefWindowProc(hwnd,message,wParam,lParam);
    }
    return 0;
}


LRESULT CALLBACK SkinableFunc(HWND hwnd,UINT message,
                              WPARAM wParam,LPARAM lParam)
{
    LRESULT ret;
    char _qqq[0xff];
	static char txt4u[]={"_"};
	static char strqwe[]={"Allo is STRQWE!!!"};
	UNALIGNED SkinWinNfo *s;
    s=(SkinWinNfo*) GetWindowLong(hwnd,GWL_USERDATA);	
    ret=Skin1.fn(hwnd,message,wParam,lParam);
    switch(message)
    {
	case WM_CREATE:
		s=(SkinWinNfo*)(((LPCREATESTRUCT) lParam)->lpCreateParams);
		SetWindowLong(hwnd,GWL_USERDATA,(long)s);
		s->pr[0].tot=66*1024*1024;
		s->pr[0].cur=0;
		CreateWindowEx(0,"EDIT","",WS_CHILD|WS_VISIBLE,50,30,100,20,hwnd,NULL,hinst,0);
		CreateWindowEx(0,"EDIT","",WS_CHILD|WS_VISIBLE,50,80,100,20,hwnd,NULL,hinst,0);
		SendMessage(hwnd,_SKN_RESIZE,0,0);
		break;

	case WM_SIZE:
		SendMessage(hwnd,_SKN_RESIZE,0,0);
		break;

	case SKN_BTOV:
		switch (LOWORD(wParam)){
		case 3:
			SendMessage(p1->hwnd,POPTIP_TXTUPDATE,(WPARAM)strqwe,0);
			break;
		}
		break;

    case SKN_BTUP:
        sprintf(_qqq,"bt %d, status: %d offset: %d,%d!",LOWORD(wParam),HIWORD(wParam),LOWORD(lParam),HIWORD(lParam));
        switch (LOWORD(wParam)){
		case 0:
			//SendMessage(hwnd,_SKN_TXTP,MAKELONG(0,2),1);
			DestroyWindow(hwnd);
//			SendMessage(hwnd,_SKN_RGN,MAKELONG(3,4),MAKELONG(_S_RGIN|_S_RGOUT,0));
			break;
        case 1: 
//			MessageBox(NULL,_qqq,"haha",MB_OK);
			SendMessage(hwnd,_SKN_RGN,MAKELONG(3,4),MAKELONG(_S_RGIN|_S_RGOUT,0));
			SendMessage(hwnd,_SKN_BTMV,MAKELONG(1,0),MAKELONG(0,10));
	//		SendMessage(hwnd,_SKN_TXTP,MAKELONG(0,1),RGB(0,70,200));
			break;
        case 2:
//			SendMessage(hwnd,_SKN_TXTP,MAKELONG(0,1),RGB(255,0,0));
			SendMessage(hwnd,_SKN_PRCUR,MAKELONG(0,1),1024*1024);
			break;
		case 3:
			MessageBox(NULL,"Allo is moshe!!!","QWEQWE!",MB_OK);
			break;
//			s->pr[0].cur++;
	//		InvalidateRect(hwnd,&Skin1.pr[0]->r,false);
			// manually ^^^
/*			SendMessage(hwnd,_SKN_TRJMP,MAKELONG(0,1),5);
			break;
        case 3: MessageBox(NULL,_qqq,"haha",MB_OK);         break;*/
        case 4:
//			MessageBox(NULL,_qqq,"haha",MB_OK);      
			SendMessage(hwnd,_SKN_BTSET,MAKELONG(4,1),1);    
			break;
        case 5: 
			sprintf(txt4u,"t:%d",s->tr[1].val);
//			SendMessage(hwnd,_SKN_TXT,MAKELONG(0,0),(LPARAM)txt4u);
			//SendMessage(hwnd,_SKN_TXTP,MAKELONG(0,1),RGB(255,0,0));
			break;
		case 6:
			SendMessage(hwnd,_SKN_BTSET,MAKELONG(6,1),1);    
			break;
		case 7:
			SendMessage(hwnd,_SKN_BTSET,MAKELONG(7,1),1);    
			break;

        }
        break;

        case SKN_TRUP:
            /*sprintf(_qqq,"Track %d! updated! value: %d",LOWORD(wParam),lParam);
            MessageBox(NULL,_qqq,"qq",MB_OK);*/
//			sprintf(txt4u,"t:%d",s->tr[1].val);
			sprintf(txt4u,"t:%d",lParam);
//			SendMessage(hwnd,_SKN_TXT,MAKELONG(0,0),(LPARAM)txt4u);

//			InvalidateRect(hwnd,&Skin1.txt[0].r,FALSE);
            break;

		case SKN_TRLV:
/*			sprintf(_qqq,"Track %d! leave! value: %d",LOWORD(wParam),lParam);
            MessageBox(NULL,_qqq,"qq",MB_OK);*/
            break;

        case SKN_XPAINT:
            // do extra window specific painting here
            break;

		case WM_DESTROY:
//			delete s;
			return 0;

    default:
        if (ret==-1)
            return DefWindowProc(hwnd,message,wParam,lParam);
    }
    return ret;
}

LRESULT CALLBACK SkinableFunc2(HWND hwnd,UINT message,
                              WPARAM wParam,LPARAM lParam)
{
    LRESULT ret;
	char _qqq[0xff];
	UNALIGNED SkinWinNfo *s;
    s=(SkinWinNfo*) GetWindowLong(hwnd,GWL_USERDATA);	
    ret=Skin2.fn(hwnd,message,wParam,lParam);
    switch(message)
    {        
    case WM_CREATE:
		s=(SkinWinNfo*)(((LPCREATESTRUCT) lParam)->lpCreateParams);
		SetWindowLong(hwnd,GWL_USERDATA,(long)s);
		s->pr[0].tot=100;
		s->pr[0].cur=0;
		break;

	case SKN_BTUP:
        sprintf(_qqq,"bt %d, status: %d offset: %d,%d!",LOWORD(wParam),HIWORD(wParam),LOWORD(lParam),HIWORD(lParam));
        switch (LOWORD(wParam)){
		case 0:
			Skin2.prtot(s,0,1,5);
			//Skin2.prtot(hwnd,0,1,5);
			//SendMessage(hwnd,_SKN_PRCUR,MAKELONG(0,1),5);
			break;
        case 1: 
			Skin2.prtot(s,0,2,5);
			//Skin2.prtot(hwnd,0,2,5);
//			SendMessage(hwnd,_SKN_PRCUR,MAKELONG(0,2),5);
			break;
		}
		break;


    default:
        if (ret==-1)
            return DefWindowProc(hwnd,message,wParam,lParam);
    }
    return ret;
}
