//#define WINVER 0x0500

/*
 * Skin System TestApp
 */

#ifndef _SkinMan_h
#define _SkinMan_h

#include <windows.h>
#include <stdio.h>
#ifdef _DEBUG
#include <crtdbg.h>
#endif
#include "SkinDefs.h"
#include "PopUpWin.h"

#ifdef _DEBUG
#define CRTDBG_MAP_ALLOC
#define SET_CRT_DEBUG_FIELD(a) _CrtSetDbgFlag((a)|_CrtSetDbgFlag(_CRTDBG_REPORT_FLAG))
#endif // db

//globals:
#ifndef _main_skinman
#define EXTERN extern
#else
#define EXTERN
unsigned char wcnt=0,w2cnt=0;
SkinWinNfo *S;
Skinload nfo1;
Skin Skin1,Skin2;
PopUpTip *p1;
#endif

HINSTANCE hinst;


// prototypes:
LRESULT CALLBACK SkinManFunc(HWND hwnd,UINT message,
                             WPARAM wParam,LPARAM lParam);

LRESULT CALLBACK SkinableFunc(HWND hwnd,UINT message,
                              WPARAM wParam,LPARAM lParam);

LRESULT CALLBACK SkinableFunc2(HWND hwnd,UINT message,
                              WPARAM wParam,LPARAM lParam);

#endif // EOF