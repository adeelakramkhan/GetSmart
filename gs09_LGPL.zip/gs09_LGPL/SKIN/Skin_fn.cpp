/*
  *   The Skin WindowFunction
  */

#include "SkinDefs.h"
#include "Bitmaps.h"


#include <commctrl.h>
HWND CreateToolTip(Skin *s,SkinWinNfo *w);


LRESULT Skin::fn(HWND hwnd,UINT message,
                      WPARAM wParam,LPARAM lParam)
{
    int i;
    static bool ch=false;
    static HDC tmpdc;
    UNALIGNED SkinWinNfo *s;
    s=(SkinWinNfo*) GetWindowLong(hwnd,GWL_USERDATA);
    switch(message){
    default:
        return -1; // -1 => we didn't process it

	case WM_KEYDOWN:
		// for breakpointz..
		int qw;
		qw=5;
		return -1;

    case WM_CREATE:
        s=(SkinWinNfo*)(((LPCREATESTRUCT) lParam)->lpCreateParams);
		s->hwnd=hwnd;
		SetWindowLong(hwnd,GWL_USERDATA,(long)s);
        s->inrgn=CreateRectRgn(0,0,0,0);
		s->outrgn=CreateRectRgn(0,0,0,0);
		s->mvrgn=CreateRectRgn(0,0,0,0);
		CombineRgn(s->inrgn,s->inrgn,inrgn,RGN_OR);
		CombineRgn(s->outrgn,s->outrgn,outrgn,RGN_OR);
		CombineRgn(s->mvrgn,s->mvrgn,mvrgn,RGN_OR);
		s->skiprgn=CreateRectRgn(0,0,0,0);
		s->showdc=indc;
		s->focus=1;
		if (numstbt){
			s->stbt=new STBTnfo[numstbt];
			for (i=0;i<numstbt;i++){
				s->stbt[i].r=stbt[i].r;
				s->stbt[i].rg=CreateRectRgn(0,0,0,0);
				CombineRgn(s->stbt[i].rg,s->stbt[i].rg,stbt[i].rg,RGN_OR);
			}
		}
		if (numtxt){
			s->txt=new TXTnfo[numtxt];
			for (i=0;i<numtxt;i++){
				s->txt[i].incol=txt[i].incol;
				s->txt[i].outcol=txt[i].outcol;
				s->txt[i].rastop=txt[i].rastop;
			}
		}
		if (numtr){
			s->tr=new TRnfo[numtr];
			for (i=0;i<numtr;i++){
				if (tr[i]==NULL) continue;
				// setting track bar in minimal possition;
				s->tr[i].r.left=tr[i]->r.left+tr[i]->xoff;s->tr[i].r.top=tr[i]->r.top+tr[i]->yoff;
				s->tr[i].r.right=s->tr[i].r.left+tr[i]->w;s->tr[i].r.bottom=s->tr[i].r.top+tr[i]->h;
				s->tr[i].val=tr[i]->min;
			}
			// now call tr[i].SetPos(val) whenever u wish ;)
		}
		if (numpr)
			s->pr=new PRnfo[numpr];
		if (numrg){
			s->rg=new RGnfo[numrg];
			for (i=0;i<numrg;i++){
				if (!(rg[i].init&_S_RGSHOW))
					SendMessage(hwnd,_SKN_RGN,MAKELONG(i,2),MAKELONG(rg[i].init,0));
			}
		}
// do these last, since other messages will require structs...       
		if (type==0) {
			SetWindowPos(hwnd,0,0,0,Wmax,Hmax,SWP_NOMOVE |  SWP_NOZORDER|SWP_NOREDRAW|
				SWP_NOSENDCHANGING);
		}
		s->hwndTT=CreateToolTip(this,s);
		SendMessage(hwnd,WM_NCACTIVATE,TRUE,0);
        break;
		// ^^ 3nd of Cr8

	case _SKN_RESIZE:
		DeleteObject(s->skiprgn);
		s->skiprgn=CreateRectRgn(0,0,0,0);
		AddChildRgns(hwnd,s->skiprgn);
		break;

        // mouse events:
    case WM_MOUSEMOVE:
		RECT rr;
        s->MousePT.x=(signed short)LOWORD(lParam);s->MousePT.y=(signed short)HIWORD(lParam);
		if (s->movewin){
			GetWindowRect(hwnd,&rr);
			SetWindowPos(hwnd,0,rr.left+s->MousePT.x-s->mmove.x,rr.top+s->MousePT.y-s->mmove.y,
					0,0,SWP_NOSIZE |  SWP_NOZORDER);
			break;
		}
		if (s->movebt!=-1){
			InvalidateRect(hwnd,&s->stbt[s->movebt].r,FALSE);
			s->stbt[s->movebt].r.right-=s->stbt[s->movebt].r.left;
			s->stbt[s->movebt].r.left=s->MousePT.x-s->mvbtoff.x;
			s->stbt[s->movebt].r.right+=s->stbt[s->movebt].r.left;
			s->stbt[s->movebt].r.bottom-=s->stbt[s->movebt].r.top;
			s->stbt[s->movebt].r.top=s->MousePT.y-s->mvbtoff.y;
			s->stbt[s->movebt].r.bottom+=s->stbt[s->movebt].r.top;
			InvalidateRect(hwnd,&s->stbt[s->movebt].r,FALSE);
			break;
		}
        if (s->dragtr!=-1){
            InvalidateRect(hwnd,&s->tr[s->dragtr].r,false);
            if (tr[s->dragtr]->Drag(s))
                SendMessage(hwnd,SKN_TRUP,MAKELONG(s->dragtr,0),s->tr[s->dragtr].val);
            InvalidateRect(hwnd,&s->tr[s->dragtr].r,false);
        }
        else{
			if ((s->focus==1) ? PtInRegion(s->inrgn,s->MousePT.x,s->MousePT.y) : 
					PtInRegion(s->outrgn,s->MousePT.x,s->MousePT.y)){
				if (PtInRegion(s->skiprgn,s->MousePT.x,s->MousePT.y)){
					ReleaseCapture();
					break;
				}
				// scan Z order;
				HWND zscan;
				HRGN hrgnz;
				hrgnz=CreateRectRgn(0,0,0,0);
				POINT myorg;
				myorg.x=0;myorg.y=0;
				ClientToScreen(hwnd,&myorg);
				zscan=hwnd;
				while ((zscan=GetWindow(zscan, GW_HWNDPREV)) != NULL){
					if (IsWindowVisible(zscan) && 
						!(GetWindowLong(zscan,GWL_EXSTYLE)&WS_EX_TRANSPARENT)){
						POINT zmouse;
						zmouse=s->MousePT;
						ClientToScreen(hwnd,&zmouse);
						RECT rr;
						GetWindowRect(zscan,&rr);
						if (PtInRect(&rr,zmouse)){
							int rgnflag=GetWindowRgn(zscan,hrgnz);
							switch (rgnflag){
							case  COMPLEXREGION:
								zmouse.x-=rr.left;zmouse.y-=rr.top;
								if (!PtInRegion(hrgnz,zmouse.x,zmouse.y))
									break;
							default:
								ReleaseCapture();
								SendMessage(hwnd,WM_CAPTURECHANGED,0,0);
								return 0;
							}
						}
					}
				}
				if ((zscan==NULL) && (hwnd!=GetCapture()))
					SetCapture(hwnd);
				DeleteObject(hrgnz);
			}
			else if (s->drag==-1){
				ReleaseCapture();
			}
			for (i=0;i<numstbt;i++){
				if (!stbt[i].n) continue;
				//if (PtInRect(&stbt[i].r,s->MousePT)){
				if (PtInRegion(s->stbt[i].rg,s->MousePT.x,s->MousePT.y)){
					RECT rq;
					int zxc=GetRgnBox(s->stbt[i].rg,&rq);
					// chking rgn type n size...
					if (s->stbt[i].state==BT_OUT)
						if (s->drag!=-1){
							if (s->drag==i){
								ch=true;
								s->stbt[i].state=BT_PUSHED;
								s->bpushed=i;
								InvalidateRect(hwnd,&s->stbt[i].r,false);
							}
						}
						else{
							ch=true;
							s->stbt[i].state=BT_OVER;
							s->bover=i;
							InvalidateRect(hwnd,&s->stbt[i].r,false);
							PostMessage(hwnd,SKN_BTOV,MAKELONG(i,s->stbt[i].i),
									MAKELONG(s->MousePT.x-s->stbt[i].r.left,s->MousePT.y-s->stbt[i].r.top));
						}
				}
				else if ((s->stbt[i].state==BT_OVER)||(s->stbt[i].state==BT_PUSHED)){
					if (s->stbt[i].state==BT_PUSHED){
						s->drag=i;
						s->bpushed=-1;
						SetCapture(hwnd);
						/// +++__QWE__ break here??
					}
					s->stbt[i].state=BT_OUT;
					if (!ch) s->bover=-1;
					InvalidateRect(hwnd,&s->stbt[i].r,false);
					ch=true;
				}
			}
		}
		/*                     if (ch)                        {                        }*/
		ch=false;
		break;
		
    case WM_LBUTTONDOWN:
		if (!(GetKeyState(VK_MENU)&0x8000))
			if (wParam==MK_LBUTTON){
				SetActiveWindow(hwnd);
				if (PtInRegion(s->mvrgn,s->MousePT.x,s->MousePT.y)){
					for (i=0;i<numtr;i++){
						if (tr[i]==NULL) continue;
						if (PtInRect(&s->tr[i].r,s->MousePT))
							goto _NOMV;
					}
					s->movewin=1;
					s->mmove=s->MousePT;
					return 0;
				}
_NOMV:
				for (i=0;i<numstbt;i++){
					if (!stbt[i].n) continue;
					if (PtInRegion(s->stbt[i].rg,s->MousePT.x,s->MousePT.y)){
						if (s->stbt[i].state==BT_OVER){
							ch=true;
							s->bover=-1;
							s->stbt[i].state=BT_PUSHED;
							SetCapture(hwnd);
						}
					}
					if (ch){
						s->bpushed=i;
						ch=false;
						InvalidateRect(hwnd,&s->stbt[i].r,false);
					}
				}
				// handled buttons, now handle track
				for (i=0;i<numtr;i++){
					if (tr[i]==NULL) continue;
					if (PtInRect(&s->tr[i].r, s->MousePT)){
						// in Bar rect
						s->dragtr=i;
						SetCapture(hwnd);
						break;
					}
					else
						if (PtInRect(&tr[i]->r,s->MousePT)){
							// in the track area rect
							InvalidateRect(hwnd,&s->tr[i].r,false);
							s->dragtr=i;
							if (tr[i]->PressPos(s)){
								SendMessage(hwnd,SKN_TRUP,MAKELONG(i,0),s->tr[i].val);
								// ^^ maybe remove this ^^
								SendMessage(hwnd,SKN_TRLV,MAKELONG(i,0),s->tr[i].val);
							}
							InvalidateRect(hwnd,&s->tr[i].r,false);
							s->dragtr=-1;
							break;
						}
				}
			}
			else{ // some stuff is down, but alt isn't..
			}
			else{
				//alt is down
				// TODO: Do some key down checks here...
				// here: only alt is down => move the button
				for (i=0;i<numstbt;i++){
					if (!stbt[i].n) continue;
					if (PtInRegion(s->stbt[i].rg,s->MousePT.x,s->MousePT.y)){
						s->movebt=i;
						s->mmove=s->MousePT;
						s->mvbtoff=s->MousePT;
						s->mvbtoff.x-=s->stbt[i].r.left;
						s->mvbtoff.y-=s->stbt[i].r.top;
						break;
					}
				}
			}
			break;
			
    case WM_LBUTTONUP:
        ReleaseCapture();
		if (s->movebt!=-1){
			s->MousePT.x-=s->mmove.x;
			s->MousePT.y-=s->mmove.y;
			// move buttons
			CombineRgn(s->mvrgn,s->mvrgn,s->stbt[s->movebt].rg,RGN_OR);
			OffsetRgn(s->stbt[s->movebt].rg,s->MousePT.x,s->MousePT.y);
			CombineRgn(s->mvrgn,s->mvrgn,s->stbt[s->movebt].rg,RGN_DIFF);
			s->movebt=-1;
			break;
		}
		s->movewin=0;
        if (s->dragtr!=-1){
			InvalidateRect(hwnd,&s->tr[s->dragtr].r,false);
			tr[s->dragtr]->StopDrag(s);
			SendMessage(hwnd,SKN_TRLV,MAKELONG(s->dragtr,0),s->tr[s->dragtr].val);
			InvalidateRect(hwnd,&s->tr[s->dragtr].r,false);
			s->dragtr=-1;
		}
        for (i=0;i<numstbt;i++){
			if (!stbt[i].n) continue;
			if (s->drag!=-1){
				i=s->drag;
				s->stbt[i].state=BT_OUT;
				ch=true;
			}
			if (PtInRegion(s->stbt[i].rg,s->MousePT.x,s->MousePT.y)){
				if ((s->stbt[i].state==BT_PUSHED)||(s->drag!=-1)){
					if (s->stbt[i].state==BT_PUSHED){
						ch=true;
						s->stbt[i].state=BT_OVER;
						s->bover=i;
						InvalidateRect(hwnd,&s->stbt[i].r,false);
					}
					s->drag=-1;
					// send message that activates button action...
					// cuz we're here iff the button is released
					PostMessage(hwnd,SKN_BTUP,MAKELONG(i,s->stbt[i].i),
						MAKELONG(s->MousePT.x-s->stbt[i].r.left,s->MousePT.y-s->stbt[i].r.top));
					break;
				}
			}
			if (s->drag!=-1){
				s->drag=-1;
				//SendMessage(hwnd,WM_MOUSEMOVE,0,MAKELONG(MousePT.x,MousePT.y));
				break;
			}                    
        }
		
        if (ch){
            ch=false;
            s->bpushed=-1;
            InvalidateRect(hwnd,&s->stbt[i].r,false);
        }
        break;                    
		
	case WM_MBUTTONDOWN:
		SetActiveWindow(hwnd);
		break;
		
    case WM_RBUTTONDOWN:
		SetActiveWindow(hwnd);
        for (i=0;i<numtr;i++){
			if (tr[i]==NULL) continue;
            if (PtInRect(&tr[i]->r,s->MousePT)){
                s->dragtr=i;
                SendMessage(hwnd,WM_MOUSEMOVE,0,MAKELONG(s->MousePT.x,s->MousePT.y));
                SetCapture(hwnd);
                break;
            }
        }
        break;

    case WM_RBUTTONUP:
        if (s->dragtr!=-1){
			ReleaseCapture();
            InvalidateRect(hwnd,&s->tr[s->dragtr].r,false);
            tr[s->dragtr]->StopDrag(s);
			SendMessage(hwnd,SKN_TRLV,MAKELONG(s->dragtr,0),s->tr[s->dragtr].val);
            InvalidateRect(hwnd,&s->tr[s->dragtr].r,false);
            s->dragtr=-1;
        }            
        break;
/*
	case WM_NCLBUTTONDOWN:
		if (1==123)
			i=3;
		return -1;

	case WM_CANCELMODE:
		if (1==123)
			i=3;
		return -1;


	case WM_SETCURSOR:
		if (1==123)
			i=3;
		return -1;

*/
		
	case WM_CAPTURECHANGED:
		if (((HWND)lParam==hwnd))
			break;
	case WM_KILLFOCUS:
		s->movewin=0;
		  if (s->bover!=-1){
			InvalidateRect(hwnd,&s->stbt[s->bover].r,FALSE);
			s->stbt[s->bover].state=BT_OUT;
			s->bover=-1;
		  }
/*		  else if (s->bpushed!=-1){
			  InvalidateRect(hwnd,&stbt[s->bpushed].r,FALSE);
			  s->stbt[s->bpushed].state=BT_OUT;
			  s->bpushed=-1;
		  }*/
	  break;

  case WM_NCACTIVATE: // focal change.
	  if (wParam){
		  s->showdc=indc;
		  if ((type==0) && (s->focus)){
			SetWindowRgn(hwnd,NULL,FALSE);
			DeleteObject(s->wrgn);
			s->wrgn=CreateRectRgn(0,0,0,0);
			CombineRgn(s->wrgn,s->wrgn,s->inrgn,RGN_OR);
			SetWindowRgn(hwnd,s->wrgn,TRUE);
		  }
		  s->focus=1;
	  }
	  else /*if (!wParam)*/{
		  if (s->bover!=-1){
			  InvalidateRect(hwnd,&stbt[s->bover].r,FALSE);
			  s->stbt[s->bover].state=BT_OUT;
			  s->bover=-1;
		  }
		  if (s->bpushed!=-1){
			  InvalidateRect(hwnd,&stbt[s->bpushed].r,FALSE);
			  s->stbt[s->bpushed].state=BT_OUT;
			  s->bpushed=-1;
		  }
		  s->showdc=outdc;
		  if ((type==0) && (s->focus)){
			SetWindowRgn(hwnd,NULL,FALSE);
			DeleteObject(s->wrgn);
			s->wrgn=CreateRectRgn(0,0,0,0);
			CombineRgn(s->wrgn,s->wrgn,s->outrgn,RGN_OR);
			SetWindowRgn(hwnd,s->wrgn,TRUE);
		  }
		  s->focus=2;
	  }
	  if (s->focus==1){
		for (i=0;i<numtxt;i++)
		  s->txt[i].col=s->txt[i].incol;
	  }
	  else {
		  for (i=0;i<numtxt;i++)
			s->txt[i].col=s->txt[i].outcol;
	  }
	  InvalidateRect(hwnd,NULL,false);
	  return -1;

  case WM_ERASEBKGND:        return(0);
	  
  case WM_PAINT:
	  HDC hdc,hdcshow;
	  PAINTSTRUCT ps;
	  RECT chkr;
	  hdc=BeginPaint(hwnd,&ps);
	  hdcshow=CreateCompatibleDC(hdc);
	  SetBkMode(hdcshow,TRANSPARENT);

	  bmshow=SelectObject(hdcshow,bmshow);

	  BitBlt(hdcshow,ps.rcPaint.left,ps.rcPaint.top,ps.rcPaint.right-ps.rcPaint.left,ps.rcPaint.bottom-ps.rcPaint.top,
		  s->showdc,ps.rcPaint.left,ps.rcPaint.top,SRCCOPY);

	  tmpdc=CreateCompatibleDC(hdc);
	  
#define RECTBLT(mdc,r)\
	  BltSeeThru(mdc,r.left,r.top,r.right-r.left,r.bottom-r.top,tmpdc)
	  // draw buttons:
	  for (i=0;i<numstbt;i++){
		  if (!stbt[i].n) continue;
		  if (!IntersectRect(&chkr,&ps.rcPaint,&s->stbt[i].r)) continue;
		  if (i==s->bover){
			  stbt[i].over[s->stbt[i].i]=SelectObject(tmpdc,stbt[i].over[s->stbt[i].i]);
			  RECTBLT(hdcshow,s->stbt[s->bover].r);
//			  RECTBLT(hdcshow,chkr);
			  stbt[i].over[s->stbt[i].i]=SelectObject(tmpdc,stbt[i].over[s->stbt[i].i]);
		  }
		  else if (i==s->bpushed){
			  stbt[i].pushed[s->stbt[i].i]=SelectObject(tmpdc,stbt[i].pushed[s->stbt[i].i]);
			  RECTBLT(hdcshow,s->stbt[s->bpushed].r);
//			  RECTBLT(hdcshow,chkr);
			  stbt[i].pushed[s->stbt[i].i]=SelectObject(tmpdc,stbt[i].pushed[s->stbt[i].i]);
		  }
		  else {
		  stbt[i].plain[s->stbt[i].i]=SelectObject(tmpdc,stbt[i].plain[s->stbt[i].i]);
//		  RECTBLT(hdcshow,chkr);
		  RECTBLT(hdcshow,s->stbt[i].r);
		  stbt[i].plain[s->stbt[i].i]=SelectObject(tmpdc,stbt[i].plain[s->stbt[i].i]);
		  }
	  }
/*	  if (s->bover!=-1){
		  stbt[s->bover].over[s->stbt[s->bover].i]=SelectObject(tmpdc,stbt[s->bover].over[s->stbt[s->bover].i]);
		  RECTBLT(hdcshow,stbt[s->bover].r);
		  stbt[s->bover].over[s->stbt[s->bover].i]=SelectObject(tmpdc,stbt[s->bover].over[s->stbt[s->bover].i]);
	  } 
	  else if (s->bpushed!=-1){
		  stbt[s->bpushed].pushed[s->stbt[s->bpushed].i]=SelectObject(tmpdc,stbt[s->bpushed].pushed[s->stbt[s->bpushed].i]);
		  RECTBLT(hdcshow,stbt[s->bpushed].r);
		  stbt[s->bpushed].pushed[s->stbt[s->bpushed].i]=SelectObject(tmpdc,stbt[s->bpushed].pushed[s->stbt[s->bpushed].i]);
	  }*/
	  
	  // draw progression bars
	  for (i=0;i<numpr;i++){
		  if ((pr[i]==NULL) || (!IntersectRect(&chkr,&ps.rcPaint,&pr[i]->r))) continue;
			  pr[i]->Draw(hdcshow,s->pr[i].cur,s->pr[i].tot);
	  }

	  // Draw tracks:
	  for (i=0;i<numtr;i++){
		  if ((tr[i]==NULL) || (!IntersectRect(&chkr,&ps.rcPaint,&tr[i]->r))) continue;
		  tr[i]->pic=SelectObject(tmpdc,tr[i]->pic);
		  RECTBLT(hdcshow,s->tr[i].r);
//		  RECTBLT(hdcshow,chkr);
		  tr[i]->pic=SelectObject(tmpdc,tr[i]->pic);
	  }
	  // Put txts:
	  for (i=0;i<numtxt;i++)
		  if (s->txt[i].str!=NULL){
			  long szx,szy;
			  szx=txt[i].r.right-txt[i].r.left;
			  szy=txt[i].r.bottom-txt[i].r.top;
			  HDC monodc=CreateCompatibleDC(NULL);
			  HBITMAP monomap=CreateBitmap(szx,szy,1,1,NULL);
			  monomap=SelectObject(monodc,monomap);
			  PatBlt(monodc,0,0,szx,szy,WHITENESS);
			  txt[i].hfont=SelectObject(monodc,txt[i].hfont);
			  TextOut(monodc,0,0,s->txt[i].str,strlen(s->txt[i].str));
			  txt[i].hfont=SelectObject(monodc,txt[i].hfont);
			  switch (s->txt[i].rastop){
			  case 0: SetTextColor(hdcshow,s->txt[i].col); break;
			  case 1:	SetTextColor(hdcshow,0);	break;
			  }
			  SetBkColor(hdcshow,RGB(255,255,255));
			  BitBlt(hdcshow,txt[i].r.left,txt[i].r.top,
				  szx,szy,
				  monodc,0,0,SRCINVERT);
			  switch (s->txt[i].rastop){
			  case 1: SetTextColor(hdcshow,s->txt[i].col); break;
			  case 0:	SetTextColor(hdcshow,0);	break;
			  }
			  
			  BitBlt(hdcshow,txt[i].r.left,txt[i].r.top,
				  szx,szy,
				  monodc,0,0,SRCAND);
			  switch (s->txt[i].rastop){
			  case 0: SetTextColor(hdcshow,s->txt[i].col); break;
			  case 1:	SetTextColor(hdcshow,0);	break;
			  }
			  BitBlt(hdcshow,txt[i].r.left,txt[i].r.top,
				  szx,szy,
				  monodc,0,0,SRCINVERT);
			  monomap=SelectObject(monodc,monomap);
			  DeleteObject(monomap);
			  DeleteDC(monodc);
		  }
		  
#undef RECTBLT
		  DeleteDC(tmpdc);
		  
		  SendMessage(hwnd,SKN_XPAINT,(WPARAM)hdcshow,(LPARAM)&ps);

		  BitBlt(hdc,ps.rcPaint.left,ps.rcPaint.top,ps.rcPaint.right-ps.rcPaint.left,ps.rcPaint.bottom-ps.rcPaint.top,
				  hdcshow,ps.rcPaint.left,ps.rcPaint.top,SRCCOPY);

		  bmshow=SelectObject(hdcshow,bmshow);
		  DeleteDC(hdcshow);
		  EndPaint(hwnd,&ps);
		  ReleaseDC(hwnd,hdc);
		  break;
		  

	case WM_DESTROY:
		//SetWindowRgn(hwnd,NULL,FALSE);
		DeleteObject(s->wrgn);
		DeleteObject(s->inrgn);
		DeleteObject(s->outrgn);
		DeleteObject(s->mvrgn);
		delete []s->stbt;
		delete []s->tr;
		delete []s->pr;
		delete []s->txt;
		delete []s->rg;
		DestroyWindow(s->hwndTT);
		break;

		// process skin specific messages::
#define _dex LOWORD(wParam)
// ^^^^ this plays as the index in all these calls
	case _SKN_PRCUR:
		if (pr[_dex]==NULL) break;
		switch (HIWORD(wParam)){
		case 0:			s->pr[_dex].cur=lParam; break;
		case 1:			s->pr[_dex].cur+=lParam; break;
		case 2:			s->pr[_dex].cur-=lParam; break;
		case 3:			s->pr[_dex].cur|=lParam; break;
		case 4:			s->pr[_dex].cur^=lParam; break;
		case 5:			s->pr[_dex].cur&=lParam; break;
		}
		InvalidateRect(hwnd,&pr[_dex]->r,false);
		break;
		
		case _SKN_PRTOT:
			if (pr[_dex]==NULL) break;
			switch (HIWORD(wParam)){
			case 0:			s->pr[_dex].tot=lParam; break;
			case 1:			s->pr[_dex].tot+=lParam; break;
			case 2:			s->pr[_dex].tot-=lParam; break;
			case 3:			s->pr[_dex].tot|=lParam; break;
			case 4:			s->pr[_dex].tot^=lParam; break;
			case 5:			s->pr[_dex].tot&=lParam; break;
			}
			InvalidateRect(hwnd,&pr[_dex]->r,false);
			break;
			
			case _SKN_TRJMP:
				if (tr[_dex]==NULL) break;
				InvalidateRect(hwnd,&s->tr[_dex].r,false);
				s->dragtr=(char)_dex;
				switch (HIWORD(wParam)){
				case 0:	tr[_dex]->SetPos(s,lParam); break;
				case 1:	tr[_dex]->SetPos(s,s->tr[_dex].val+lParam); break;
				case 2:	tr[_dex]->SetPos(s,s->tr[_dex].val+lParam); break;
				case 3:	tr[_dex]->SetPos(s,s->tr[_dex].val+lParam); break;
				case 4:	tr[_dex]->SetPos(s,s->tr[_dex].val+lParam); break;
				case 5:	tr[_dex]->SetPos(s,s->tr[_dex].val+lParam); break;
				}
				SendMessage(hwnd,SKN_TRUP,MAKELONG(_dex,0),s->tr[_dex].val);
				InvalidateRect(hwnd,&s->tr[_dex].r,false);
				break;

			case _SKN_BTSET:
				if (!stbt[_dex].n)break;
				InvalidateRect(hwnd,&stbt[_dex].r,false);
				switch (HIWORD(wParam)){
				case 0: s->stbt[_dex].i=(unsigned char)lParam; break;
				case 1:	s->stbt[_dex].i+=(unsigned char)lParam; break;
				case 2:	s->stbt[_dex].i-=(unsigned char)lParam; break;
				case 3:	s->stbt[_dex].i|=(unsigned char)lParam; break;
				case 4:	s->stbt[_dex].i^=(unsigned char)lParam; break;
				case 5:	s->stbt[_dex].i&=(unsigned char)lParam; break;
				}
				if (s->stbt[_dex].i>=stbt[_dex].n)
					s->stbt[_dex].i=0;
				else if (s->stbt[_dex].i<0)
					s->stbt[_dex].i=stbt[_dex].n;
				break;

			case _SKN_BTMV:
				if (!stbt[_dex].n)break;
				// double code.. do something else..
				InvalidateRect(hwnd,&s->stbt[_dex].r,FALSE);
				CombineRgn(s->mvrgn,s->mvrgn,s->stbt[_dex].rg,RGN_OR);
				OffsetRgn(s->stbt[_dex].rg,LOWORD(lParam),HIWORD(lParam));
				CombineRgn(s->mvrgn,s->mvrgn,s->stbt[_dex].rg,RGN_DIFF);
				OffsetRect(&s->stbt[_dex].r,LOWORD(lParam),HIWORD(lParam));
				InvalidateRect(hwnd,&s->stbt[_dex].r,FALSE);
				break;
					
			case _SKN_RGN:
				if (rg[_dex].rgn==NULL) break;
				if (LOWORD(lParam)&_S_RGIN)
					switch (HIWORD(wParam)){
					case 1: case 3: CombineRgn(s->inrgn,s->inrgn,rg[_dex].rgn,RGN_OR); break;
					case 2:			    CombineRgn(s->inrgn,s->inrgn,rg[_dex].rgn,RGN_DIFF); break;
					case 4:				CombineRgn(s->inrgn,s->inrgn,rg[_dex].rgn,RGN_XOR); break;
					case 5:				CombineRgn(s->inrgn,s->inrgn,rg[_dex].rgn,RGN_AND); break;
					}
				if (LOWORD(lParam)&_S_RGOUT)
					switch (HIWORD(wParam)){
					case 1: case 3: CombineRgn(s->outrgn,s->outrgn,rg[_dex].rgn,RGN_OR); break;
					case 2:			    CombineRgn(s->outrgn,s->outrgn,rg[_dex].rgn,RGN_DIFF); break;
					case 4:				CombineRgn(s->outrgn,s->outrgn,rg[_dex].rgn,RGN_XOR); break;
					case 5:				CombineRgn(s->outrgn,s->outrgn,rg[_dex].rgn,RGN_AND); break;
					}
				SendMessage(hwnd,WM_NCACTIVATE,TRUE,0);
				break;

			case _SKN_TXT:
				s->txt[_dex].str=(char*)lParam;
			case _SKN_TXTUP:
				InvalidateRect(hwnd,&txt[_dex].r,false);
				break;

			case _SKN_TXTP:
				switch (HIWORD(wParam)){
				case 1: // color
					s->txt[_dex].col=lParam;
					break;
				case 2: // rastop
					s->txt[_dex].rastop=(char)lParam;
					break;
				}
				InvalidateRect(hwnd,&txt[_dex].r,false);
				break;


#undef _dex
    }
    return 0;
}


HWND CreateToolTip(Skin *s,SkinWinNfo *w)
{
	HWND hwndOwner=w->hwnd;
    HWND hwndTT;
    TOOLINFO ti;
    int id = 0;
 
    hwndTT = CreateWindow(TOOLTIPS_CLASS, (LPSTR) NULL, TTS_ALWAYSTIP,
        CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
        w->hwnd, (HMENU) NULL, NULL, NULL);
 
    if (hwndTT == (HWND) NULL) 
        return (HWND) NULL; 
	memset(&ti,0,sizeof(ti));
	for (int i=0; i<s->numstbt; i++)
		if (s->stbt[i].n)
		{ 
			ti.cbSize = sizeof(TOOLINFO);
			ti.uFlags = TTF_SUBCLASS;
			ti.hwnd = hwndOwner;
			ti.hinst = NULL;
			ti.uId = (UINT) i;
			ti.lpszText = LPSTR_TEXTCALLBACK;
			ti.rect= s->stbt[i].r;

		if (!SendMessage(hwndTT, TTM_ADDTOOL, 0, 
			(LPARAM) (LPTOOLINFO) &ti)) 
				return NULL; 
	}
 	return hwndTT; 
}
