/* Just some commonly used templates here.
 * when writting new templates add em here and put this file in a common <basedir>/common
 * dir.
 */

#ifndef _SMRT_SOME_TEMPLATES_H_
#define _SMRT_SOME_TEMPLATES_H_

/* a linked list que
 * requires: a type with a next pointer called "next"
 * who's ctor will allocate stuff for it'self, and who's destructor'll clean up for itself.
 */
template<class CELL>
struct ListQue{
	CELL*head; // list head
	CELL*last; // last item
	ListQue(){
		head=NULL;last=NULL;
	}
// destructor that kills the list. you can call it expliticialy for cleanup.
	virtual ~ListQue(){
#define TMP_ last
// ^^ a less confusing name for this task..
		TMP_=head;
		while (TMP_!=NULL){
			head=head->next;
			delete TMP_;
			TMP_=head;
		}
#undef TMP_
	}
	// addes item after "last" and updates last.
	virtual void Add2Tail(CELL*newcell){
		if (last==NULL)
			last=head=newcell;
		else
			last=last->next=newcell;
	}
	// adds b4 head.
	virtual void Add2Head(CELL*newcell){
		if (head==NULL)
			last=head=newcell;
		else{
			newcell->next=head;
			head=newcell;
		}
	}
	// kills 1st item and moves que forward.
	virtual void FDItem(){
		CELL*tmp=head->next;
		delete head;
		head=tmp;
		if (head==NULL)
			last=NULL;
	}
};

// list que with 1 undo cell;
template <class CELL>
struct QueW1undo: ListQue<CELL>  {
	CELL *lasttip; // backup for 1 undo
	QueW1undo():ListQue<CELL>(){
		lasttip=NULL;
	}
	~QueW1undo(){
		head=lasttip;
	}
	// override this func for undoing.
	void FDItem(){
		if (lasttip!=head){
			delete lasttip;
			lasttip=head;
			head=head->next;
		}
		else{
			head=head->next;
		}
	}
	void Add2Tail(CELL*newcell){
		if (head==NULL)
			head=last=newcell;
		else
			last=last->next=newcell;
		if (lasttip==NULL)
			lasttip=head;
	}
	void Add2Head(CELL*newcell){
		if (head!=lasttip)
			ListQue<CELL>::Add2Head(newcell);
	}
};

#endif // 3OF
