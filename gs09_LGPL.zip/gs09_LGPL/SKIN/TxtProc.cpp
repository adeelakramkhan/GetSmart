/* txt processing functions, for pre-processing.
 */

#include "TxtProc.h"

/* Loads a TXT file into a properly malloc()'d buffer
 * returns: buffer size, should EQ strlen(bf);
 */
long TxtFile2Buff(char **bfp,const char *fn)
{
	FILE*f;
	long sz,i=0,r;
	f=fopen(fn,"rt");
	if (!f)
		return -1;
	sz=_filelength(_fileno(f));
	sz++; // for terminating '0'
	*bfp=new char[sz];
	do
		i+=r=fread(*bfp+i,1,sz,f);
	while(r);
	fclose(f);
	(*bfp)[i]=0;
	sz=i;
//	*bfp=(char*)realloc(*bfp,++sz); // reallocate to reflect size after ascii convertion
	return sz;
}

// ...
bool Buff2TxtFile(char*bf,const char*fn)
{
	FILE*f;
	long i=0,w,sz;
	f=fopen(fn,"wt");
	if (!f)
		return false;
	sz=strlen(bf);
	i=0;
	do
		i+=w=fwrite(bf+i,1,sz,f);
	while(i<sz);
	fclose(f);
	return true;
}

// //// //// PreProcess funcs... \\\\\\\\ \\\ \\\\\\\ \ ______

// glue together lines ending with '\'
void GlueSlashEnd(char*bf)
{
	int cnt;
	cnt=strlen(bf);
	if (!bf) return;
	for (;;){
		while (bf[0] && (bf[0]!='\n'))
			bf++,cnt--;
		if (!bf[0]) return;
		bf--;cnt++;
		if (bf[0]=='\\'){
			memmove(bf,bf+2,cnt);
			cnt--,cnt--;
		}
		else{
			bf++;cnt--;
			if (bf[0])
				bf++,cnt--;
			else
				return;
		}
	}
}

// Nullifies multi spaces.
// TODO:: ignore inside "", ''
void NullifySPs(char*bf)
{
	char*sc;
	int cnt;
	cnt=strlen(bf);
	cnt++;
	for (;;){
		while (bf[0] && (bf[0]!=' '))
			bf++,cnt--;
		if (!bf[0]) return;
		sc=++bf;
		cnt--;
		while (sc[0] && (sc[0]==' '))
			sc++,cnt--;
		if (sc[0] && (sc!=bf)){
			memcpy(bf,sc,cnt);
			cnt+=sc-bf;
		}
		else
			bf++,cnt--;
	}
}

// Remove // and /* */ style comments from file..
// TODO::
// ___ ignore chars in ""s and  ''s
void rmcomments(char*bf)
{
	char*sc;
	long cnt;
	cnt=strlen(bf);
	for (;;){
		while (bf[0] && (bf[0]!='/'))
			bf++,cnt--;
		if (!bf[0]) return;
		sc=bf;
		sc++;
		if (!sc[0]) return;
		if ((sc[0]!='*') && (sc[0]!='/')){
			bf++,cnt--;
			continue;
		}
		if (sc[0]=='/'){
			// seek EOL
			while (sc[0] && (sc[0]!='\n'))
				sc++,cnt--;
			if (!sc[0])	return;
			memmove(bf,sc,cnt);
			cnt+=sc-bf;
		}
		else{
			sc++,cnt--;
_MORE_slashstar:
			while (sc[0] && (sc[0]!='*'))
				sc++,cnt--;
			if (!sc[0])	return;
			sc++;cnt--;
			if (!sc[0]) return;
			if (sc[0]!='/'){
				sc++,cnt--;
				goto _MORE_slashstar;
			}
			sc++,cnt--;
			memmove(bf,sc,cnt);
			cnt+=sc-bf;
		}
	}
}

// //// //// ~End of PreProcess funcs... \\\\\\\\ \\\ \\\\\\\ \ ______

long PreProcess2Buff(char*&bf,const char*fn)
{
	long sz;
	char _rmcomments=1;
	sz=TxtFile2Buff(&bf,fn);
	if (sz==-1)
		return -1;
	if (_rmcomments)
		rmcomments(bf);
	GlueSlashEnd(bf);
	NullifySPs(bf);
	// ExpandEscs(bf);
	// ExpandDefines();
	// InsertInternalDefs();
	// ProcessIfDefs();
	// InsertInternalVars();
	// EvalPreMath();
	// ProcessPreConditions();
/* hmm... we need the vars before this, like #ifdef __unix__ #inlcude "this.h" #else #include "that.h" #endif
 * but we need the include files for the defs...
 * is this the way??
 */
	// IncludeSharps();
	// ExpandDefines();
	// GlueDblSharps();
	// InsertInternalDefs();
	// ProcessIfDefs();
	// InsertInternalVars();
	// EvalPreMath();
	// ProcessPreConditions();
	return sz;
}

/* Scans bf for keywords, terminated by any sep member, or '}', skips sub {} pairs
 * returns: index of keyword found, -1 if not.
 * updates: *bf to after keyword (moves the pointer, buffer is clean)
 * warnings: scanning is "raw", the only conciderations are: " '
 * TODO: consider the " and '						:^/
 */
long keywords::ScanInScope(char*&bf,char*sep)
{
	long i;
	for (;;){
		while (bf[0] && ISWHITESP(bf[0]))
			bf++;
		if (!bf[0]) return -1;

		if ISALPHA(bf[0]){
			char*kw=k;
			for (i=0;i<n;i++){
				if (!strncmp(bf,kw,l[i]))
					if  (strchr(sep,bf[l[i]])){
						bf+=l[i];
						return i; // found keyword i followed by a sep;
					}
				kw+=l[i];
				kw++;
			}
		}
		else
			switch (bf[0]){
			case '}': return -1; // scope terminated
			case '{': // skip sub scope
				SkipSubScope(++bf);
				break;
			}
		while (bf[0] && !ISWHITESP(bf[0]))
				bf++;
		if (!bf[0]) return -1;
		bf++;
	}
}

/* Same, but freescans, doesn't mind '{' '}'s and such..
 * note: left here intentionally, case we need a simple scan.
 */
long keywords::ScanInBuff(char*&bf,char*sep)
{
	long i;
	for (;;){
		while (bf[0] && ISWHITESP(bf[0]))
			bf++;
		if (!bf[0]) return -1;

		if ISALPHA(bf[0]){
			char*kw=k;
			for (i=0;i<n;i++){
				if (!strncmp(bf,kw,l[i]))
					if  (strchr(sep,bf[l[i]])){
						bf+=l[i];
						return i; // found keyword i followed by a sep;
					}
				kw+=l[i];
				kw++;
			}
		}
		while (bf[0] && !ISWHITESP(bf[0]))
				bf++;
		if (!bf[0]) return -1;
		bf++;
	}
}

// //// ////_____ Process funcs... \\\\\\\\ \\\ \\\\\\\ ____

/* scans a buffer untill a "" enclosed string is found,
 * sets the buffer after the ending "s, and dups the sting
 */
char*GetNextQuetedStr(char*&bf)
{
	while (bf[0] && (bf[0]!='\"'))
		bf++;
	if (!bf[0]) return NULL;
	bf++;
	int len;
	char*loc=strchr(bf,'\"');
	if (!loc) return NULL;
	len=loc-bf;
	if (!len) return NULL;
	char*newstr;
	newstr=new char[len+1];
	strncpy(newstr,bf,len);
	newstr[len]=0;
	bf+=len;
	return newstr;
}

// Seek next arg after ,
int SeekNextArg(char*&bf)
{
	while (bf[0] && (bf[0]!=',') && (bf[0]!=';'))
		bf++;
	if (!bf[0])
		return 1;
	if(bf[0]==';') return -1;
	bf++;
	return 0;
}

/* Call this func when u'r after a '{' and wanna skip to the matching '}'
 * Bugs/Warnings: ignores escape sequences, queted strings and such.
 * TODO: a "SkipQueteStr()" and a "SkipEscSeq()" and such thingies...
 */
void SkipSubScope(char*&bf)
{				
	int parCnt=1;
SkipSubScope_Rec:
	while (bf[0] && bf[0]!='}' && bf[0]!='{') 
		bf++;
	switch (bf[0]){
	case '{': bf++;parCnt++; goto SkipSubScope_Rec;
	case '}':
		bf++;
		if (--parCnt==0)
			break;
		goto SkipSubScope_Rec;
	case 0:
		break;
	}
}

// //// ////_____ ~End of Process funcs... \\\\\\\\ \\\ \\\\\\\ ____