/* Txt processing unit.
 */

#ifndef _TxtProc_h
#define _TxtProc_h

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef _WIN32
#include <io.h>
#endif //_WIN32

// macros:
#define ISWHITESP(c) ((c==' ' || c=='\n' || c=='\t' || c=='\r') ? 1 : 0)
#define ISUPCASE(c) ((c>='A' && c<='Z') ? 1 : 0)
#define ISLOWCASE(c) ((c>='a' && c<='z') ? 1 : 0)
#define ISALPHA(c) (ISUPCASE(c) || ISLOWCASE(c))
#define ISDIGIT(c) ((c>='0' && c<='9') ? 1:0)

long TxtFile2Buff(char **bfp,const char *fn);

bool Buff2TxtFile(char*bf,const char*fn);

void GlueSlashEnd(char*bf);

void NullifySPs(char*bf);

void rmcomments(char*bf);

long PreProcess2Buff(char*&bf,const char*fn);

char *StrQueteDup(char*&bf);

char*GetNextQuetedStr(char*&bf);

int SeekNextArg(char*&bf);

struct keywords{
	char*k; // string of keys, seperated by "\0"
	long n; // num of keys
	long *l; // array of lengths of keys
	keywords(char*_k,long _n,long*_l){
		int sigma=0,i;
		n=_n;
		l=new long[n];
		memcpy(l,_l,n*sizeof(long));
		for (i=0;i<n;i++){
			sigma+=l[i];
			sigma++;
		}
		sigma++;
		k=new char[sigma];
		memcpy(k,_k,sigma);
	}		
	~keywords(){
		delete[]k;
		delete []l;
	}
	long ScanInScope(char*&bf,char*sep);
	long ScanInBuff(char*&bf,char*sep);
};

void SkipSubScope(char*&bf);

#endif //EOF
