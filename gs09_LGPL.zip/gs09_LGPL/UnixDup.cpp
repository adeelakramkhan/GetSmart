
#include "Daemon/Daemon.h"

void DetectedHangup()
{}

bool IsConnected()
{
	return true;
}

void StartDial(){}

void Hangup(){}







