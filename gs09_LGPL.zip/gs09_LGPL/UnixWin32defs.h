/* Emulation of several win32 macros for porting code over.
 */


#define strnicmp strncasecmp
#define stricmp strcasecmp

// stuff::
typedef void* HANDLE;
#define HLOCAL HANDLE
typedef unsigned long WPARAM;
typedef long LPARAM;



#define MAKEWORD(a, b) ((unsigned short)(((unsigned char)(a)) | ((unsigned short)((unsigned char)(b))) << 8))
#define MAKELONG(a, b) ((long)(((unsigned short)(a)) | ((unsigned long)((unsigned short)(b))) << 16))
#define LOWORD(l) ((unsigned short)(l))
#define HIWORD(l) ((unsigned short)(((unsigned long)(l) >> 16) & 0xFFFF))
#define LOBYTE(w) ((unsigned char)(w))
#define HIBYTE(w) ((unsigned char)(((unsigned short)(w) >> 8) & 0xFF))

#define _unlink unlink
#define _strdup strdup
#define _access access

#define FAR
#define NEAR

// winsock::
typedef int SOCKET;
#define INVALID_SOCKET -1
#define SOCKET_ERROR -1
#define SOCKADDR sockaddr
#define SOCKADDR_IN sockaddr_in
#define LINGER linger
#define closesocket(sock) close(sock)

#define LocalAlloc(how,m) _WINMALLOC_ ## how(m)
#define _WINMALLOC_LMEM_FIXED(m) malloc(m)
#define _WINMALLOC_LPTR(m) calloc(1,m)
#define LocalFree(p) free(p)
#define LocalReAlloc(old,size,how) realloc(old,size)

// Message box::
#define MB_OK 1

#ifndef _MAX_PATH
#define _MAX_PATH 1024
#endif
